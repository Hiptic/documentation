---
title: "Product Overview"
excerpt: "About OneSignal and how to get started"
---
## What is OneSignal?
OneSignal is a high volume and reliable push notification service for websites and mobile applications. We support all major native and mobile platforms by providing dedicated SDKs for each platform, a [RESTful server API](ref:create-notification), and an [online dashboard](https://onesignal.com) for marketers to design and send push notifications.

----
## Why should I use OneSignal?

<span class="label-all label-benefit">Easy to use</span> - Implementing reliable interfaces to the GCM/FCM (Google), APNS (Apple), and the Web Push protocols is difficult. There are open source projects to do it, but even the best ones break when message quantity begins to exceed 500,000 at a time. These protocols also change frequently, for instance, Apple recently released a new notification protocol and deprecated their old one.

<span class="label-all label-benefit">Better Than The Competition</span> - Other notification services lack features such as segmentation, automatic/triggered notifications, variable substitution, a notification delivery API, or detailed reporting tools.

<span class="label-all label-benefit">Advanced Functionality</span> - OneSignal provides marketing tools including A/B testing, segment targeting, variable-substitution, localization, drip marketing, and conversion tracking.

<span class="label-all label-benefit">Platform Support</span> - OneSignal provides a single UI and API to deliver messages across iOS, Android, Amazon Fire, Windows Phone, Chrome Apps, Safari, Chrome Web, and Firefox. 

<span class="label-all label-benefit">SDK Support</span> - OneSignal provides SDKs for nearly every major cross-platform mobile development environment, including Unity, PhoneGap, Cordova, Ionic, React Native, Intel XDK, Corona, Xamarin, Marmalade, Adobe Air, and Web Push.

<span class="label-all label-benefit">Popular</span> - OneSignal is the most widely used push notification service for both web and mobile developers, with over 190,000 registered developers and 125,000 applications and websites.

<span class="label-all label-benefit">Free</span> - Best of all, OneSignal is a **free** service that supports **unlimited** devices and notifications. OneSignal makes money by selling data to advertisers and research companies. We also offer paid service options for clients that require increased data privacy.

----
## How do I get started?
<span class="label-all label-developers">Developers</span> - Go to our [Mobile](doc:mobile-sdk-setup) or [Web Push](doc:web-push-setup) setup guides to get started implementing OneSignal in your product today!

<span class="label-all label-marketers">Marketers</span> - Talk to your developers, and meanwhile get acquainted with [OneSignal Features](doc:dashboard) in our user manual.
[block:callout]
{
  "type": "info",
  "body": "If you have any questions feel free to drop us a line! Email us at [support@onesignal.com](mailto:support@onesignal.com) or chat with us using the bright red button!",
  "title": "Questions?"
}
[/block]
----
## OneSignal Screenshots

** Create a New Message prompt **
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/856e990-Screen_Shot_2017-05-08_at_12.54.01_PM.png",
        "Screen Shot 2017-05-08 at 12.54.01 PM.png",
        2440,
        1198,
        "#e6e6e7"
      ]
    }
  ]
}
[/block]

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/99961ec-Screen_Shot_2017-05-08_at_12.54.08_PM.png",
        "Screen Shot 2017-05-08 at 12.54.08 PM.png",
        1714,
        1372,
        "#eceded"
      ]
    }
  ]
}
[/block]

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/0de4cd4-Screen_Shot_2017-05-08_at_12.54.18_PM.png",
        "Screen Shot 2017-05-08 at 12.54.18 PM.png",
        1650,
        1250,
        "#f3f3f3"
      ]
    }
  ]
}
[/block]

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/019f5a1-Screen_Shot_2017-05-08_at_12.54.24_PM.png",
        "Screen Shot 2017-05-08 at 12.54.24 PM.png",
        2482,
        936,
        "#6ba1d0"
      ]
    }
  ]
}
[/block]
** All Users view **
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/1d3da36-Screen_Shot_2017-05-08_at_12.54.42_PM.png",
        "Screen Shot 2017-05-08 at 12.54.42 PM.png",
        2162,
        1356,
        "#f1f2f2"
      ]
    }
  ]
}
[/block]
** Sent notification stats **
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/d9dfdcc-Screen_Shot_2017-05-08_at_12.54.33_PM.png",
        "Screen Shot 2017-05-08 at 12.54.33 PM.png",
        2072,
        1106,
        "#7fa8c6"
      ]
    }
  ]
}
[/block]
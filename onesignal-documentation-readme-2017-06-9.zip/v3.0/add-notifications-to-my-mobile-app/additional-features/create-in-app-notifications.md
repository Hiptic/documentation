---
title: "Create In-App Notifications"
excerpt: "<div class=\"tag-all tag-developers\">For Developers</div> <div class=\"tag-all tag-advanced\">Advanced Topic</div>"
---
OneSignal does not have any built-in UI for in app messages, however OneSignal does provide the necessary functionality to create your own in app messages.

For in app messages that are shown when a user taps a notification, you can use the NotificationClicked handler of the SDK you are using to display a popup window with the contents of your choice.

For in app messages based on notifications the user has previously received, please follow our [Activity Feed guide](doc:create-an-activity-feed).
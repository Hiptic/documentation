---
title: "Web Push for News Publishers"
excerpt: "Getting Started with Web Push for News Publishers"
---
Thanks for your interest in using OneSignal for Web Push -- I’ve tried to lay out the process for you to quickly get started using us for Web Push for News. 

## Web Push Overview 

At the moment Web Push is enabled on over 75% of Desktop Traffic and growing. Today, web push is enabled on the following browsers:
Chrome - 50%  
Firefox - 20%
Safari - 7% 
Microsoft Edge - coming soon 

With email from most websites being ignored or moved to Gmail’s “Promotions” tab, e-mail open rates are declining.

Meanwhile, we see opt-in rates as high at 70% for web push. Web Push guarantees the immediate visibility of your message to visitors who have opted in on their desktop or mobile device, even long after they’ve closed your website.

[What are Push Notifications?](doc:what-are-push-notifications) 

##Why use Web Push?
  * Access to users who are not on your website: Using web push notifications, you can reach out to those users who are not on your website
  * Ability to re-engage users without knowing their contact details: Web push notifications don’t need a user’s email or other contact details.
  * Higher opt-ins as compared to emails: Since users don’t need to give their email id or other contact details and they also have the ability to unsubscribe from receiving notification easily whenever they want, the opt-ins for web push notifications are higher than emails.
  * Lower unsubscribe / opt-out rates: Studies have shown that less than 20% of the subscribers who opted for notifications from a site, unsubscribed in a year.
  * Prompt and assured content delivery: The moment you click on “send notification now”, it will be delivered to the users immediately. Unlike emails that sometimes fail to deliver or get marked as spam, these notifications are certain to be seen.
  * Higher conversion rates: Web push notifications typically have 30 times higher conversion when compared with e-mail.
  * Tech savvy user base: Since this is a nascent technology, it is safe to assume that your content will reach to the most tech savvy user base.
  * Take advantage of more timely updates: Headline news, Trending Content, Abandoned Shopping carts, etc 

## Best Practices 

  * Best practices are highly dependent on the type of product they're being deployed in - what the intended usage is, who the users are, and what value the product delivers. We always recommend that web publishers us a secure website for web push as well as for Google AMP search [HTTP vs. HTTPS](doc:web-push-http-vs-https) 
  * When to prompt -- generally it’s best to explain why the user is being prompted to enable push notifications, and what they get from them. Often sites will have an interstitial page that explains what push is used for, and gives the user the choice of Enable or Not Now. If the user taps Enable, the app opens the system prompt to get notifications. 
  * What to say in a notification -- a good notification is timely, relevant, and precise. Take a look at [this video](https://www.youtube.com/watch?v=Zq-tRtBN3ws&t=2m44s) which breaks these down with several examples.
  * Frequency -- a general principle is to send notifications when there is something of value to the user. The principles laid out in the video above are the main things to consider. 

[Working with OneSignal - Free vs Enterprise](doc:faq) 

##News Publisher Use Cases

Onboarding Users to Subscription 
Tag users based on activity
Integrate with Analytics / UTM
Integrate with CRM 
Marketing Automation 
Automated Messages 
RSS Automation 
Reengage Users 
Scheduling Notifcations 
Use Webhooks 
Benchmarks
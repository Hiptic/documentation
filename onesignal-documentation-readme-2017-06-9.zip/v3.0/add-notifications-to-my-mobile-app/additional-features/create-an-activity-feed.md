---
title: "Create an Activity Feed"
excerpt: "How to build an activity feed of notifications using OneSignal\n<div class=\"tag-all tag-developers\">For Developers</div> <div class=\"tag-all tag-advanced\">Advanced Topic</div>"
---
## What is an Activity Feed?
An activity feed lets users see the history of notifications they've received within your app. 

## How-To
OneSignal primarily focuses on delivery of messages, so at this current time OneSignal does not store notifications the history of notifications sent to each individual user. However, you can implement this yourself by storing the data on your own server or on the device.

### Method 1: Save the notification when received
First, you must setup the required code to cause your application to be automatically woken up in the background whenever a notification is received (even if it's not clicked).

<span class="label-all label-ios">iOS</span> - This requires a [Notification Service Extension](https://developer.apple.com/reference/usernotifications/unnotificationserviceextension). See Step 1 of our [iOS Native SDK setup guide](doc:ios-sdk-setup) to add one to your Xcode project. This will only fire for iOS 10.

For iOS 9 and older device support you will need to use the `content-available` flag. Read Apple's [content-available](https://developer.apple.com/reference/uikit/uiapplicationdelegate/1623013-application?language=objc) guide for details on receiving and processing the event.

<span class="label-all label-android">Android</span> - Read our [Android Background Data](doc:android-customizations#section-background-data-and-notification-overriding) guide for details on receiving and processing the event.

When you process the event, you can save a copy of the notification to your app.

### Method 2: Saving to Server
Instead of using background processing in your app, you may choose to create all your notifications with our [Create notification](ref:create-notification) REST API and additionally save a copy of the contents on your server. Then each time your app is started check your server for updates.

Once the data is stored by your app or on your server, you can display it to the user when you choose.
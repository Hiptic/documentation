---
title: "Location-Triggered Notifications"
excerpt: "Tutorial - Setting up notifications that trigger based on user location.\n<div class=\"tag-all tag-developers\">For Developers</div> <div class=\"tag-all tag-marketers\">For Marketers</div>"
---
OneSignal supports both sending notifications to devices that have been seen in a specific area, as well as location-triggered (Geofencing) notifications.

# Sending notifications based on Location
## iOS & Android How-To
### 1. Get Location Permissions
To send messages to users by location, make sure you have the location permission set in your app and are prompting for location permissions in your app's code. 

### 2. Set up a Segment
Within <a class="dash-link" href="/docs/segmentation">Segments</a>, create a segment that uses the "Location Radius" filter, and set a distance (in meters) from a set of geo-coordinates (lat,long). 

You may skip this step if you pass filters through using the [Server REST API](ref:create-notification).

### 3. Send to Segment or Filter
Now you can send a message to users in the segment you just created. 

You can do this manually via the New Messages Page, automatically via the [Server REST API](ref:create-notification), or automatically via the Automated Messages Page.

## Other Platform How-To

### 1. Determine the user's location
To send messages to users by location, make sure you have the location permission set in your app and are prompting for location permissions in your app's code. 

### 2. Assign location tags
Using the the `SendTags` method, assign `"longitude"` and `"latitude"` tags. For example, you could set `"longitude"="37.160"` and `"latitude"="-117.773"`.

### 3. Send to Segment or Filter
Now you can send a message to users in a segment based on these tags.

For example, you could define a segment with tags `"longitude" > 37, "longitude" < 38, "latitude" > -118, "latitude" < -117` to create a square target region containing users with location tags in that range.

You can do this manually via the New Messages Page, automatically via the [Server REST API](ref:create-notification), or automatically via the Automated Messages Page.

#Sending Notifications automatically based on a Geofence Trigger

##iOS

1. Follow [this guide](https://www.raywenderlich.com/136165/core-location-geofencing-tutorial) to set up Geofencing on iOS
2. When a Geofence is triggered, use the OneSignal [postNotification](https://documentation.onesignal.com/docs/ios-native-sdk#section--postnotification-) method to send a notification to the device.

##Android

1. Follow [this guide](https://developer.android.com/training/location/geofencing.html) to set up Geofencing on Android.
2. When a Geofence is triggered, use the OneSignal [postNotification](https://documentation.onesignal.com/docs/android-native-sdk#section--postnotification-) method to send a notification to the device.
---
title: "Tagging"
excerpt: "Tagging users for <span class=\"label-all\">Web Push</span> (<span class=\"label-all label-chrome\">Chrome</span>, <span class=\"label-all label-firefox\">Firefox</span>, <span class=\"label-all label-safari\">Safari</span>)\n<div class=\"tag-all tag-developers\">For Developers</div> <div class=\"tag-all tag-advanced\">Advanced Topic</div>"
---
OneSignal supports tagging users with simple string data. Once you've integrated web push on your website, you have access to all the [JavaScript web SDK API methods listed here](doc:web-push-sdk) .

Tags can be used for targeting notifications to specific users or groups. Tag values can also be used as [variables in notification content](doc:tag-variable-substitution).

Using JavaScript, you may tag your users with a key-value pair of simple string data at any time using the [sendTags() API method](doc:web-push-sdk). Here's an example of calling that:
[block:code]
{
  "codes": [
    {
      "code": "OneSignal.push([\"sendTags\", {key2: \"value2\", key3: \"value3\"}]);",
      "language": "javascript"
    }
  ]
}
[/block]
On your app's users page, you'll see the user with the tagged value:
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/1c1245e-Screen_Shot_2017-05-11_at_7.54.20_PM.png",
        "Screen Shot 2017-05-11 at 7.54.20 PM.png",
        1401,
        282,
        "#58393e"
      ]
    }
  ]
}
[/block]

[block:callout]
{
  "type": "warning",
  "title": "Tag Using Simple Strings Only",
  "body": "Don't tag users with arrays or hashes of data. Use only simple strings or numbers. We use exact string matching when targeting users by tags,"
}
[/block]
----
### Sending Notifications to Specific Users

There are two ways to send notifications:
- Through our dashboard at onesignal.com
- Programmatically using our REST API

----
**Sending Notifications via the Dashboard**

To target specific users, you have to first create a *Segment*. Add filters matching your key and value.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/aa1baea-Screen_Shot_2017-05-11_at_7.58.31_PM.png",
        "Screen Shot 2017-05-11 at 7.58.31 PM.png",
        1386,
        523,
        "#f0f1f0"
      ]
    }
  ]
}
[/block]

[block:callout]
{
  "type": "warning",
  "title": "Segment Filters Conditions are Combined",
  "body": "A segment includes all users that *matches all the filter conditions*. In other words the segment *AND*s filter conditions together, and does not *OR* filter conditions."
}
[/block]
Please keep in mind that filter conditions are *combined* together to include users and are not evaluated separately!

Now that you've created your segment matching at least one user, you can send a notification targeting this segment using this option:
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/2799ed8-Screen_Shot_2017-05-11_at_8.04.14_PM.png",
        "Screen Shot 2017-05-11 at 8.04.14 PM.png",
        782,
        400,
        "#404149"
      ]
    }
  ]
}
[/block]
If you get an error saying "The selected segments does not have any users", go back to your Segments page and check the filter conditions. Remember they are *AND*ed together and not *OR*ed together. Make sure the segment includes at least one user.

----
#### Sending Notifications via the REST API

To send notifications programmatically via the API, use our [Create notification](ref:create-notification). To send notifications targeting users matching certain tags, use the filters parameter (check out the documentation).

----
## Integrating With Existing User Data

To link the subscribed user to your existing data, you can do one or more of the following: 
- You can [tag](#tagging) your user with a unique identifier from your system (e.g. your system's account email address)
- You can store the user's OneSignal ID on your own system

The first will associate our user with your user account ID on our system. The second will associate our user ID with your user info on your system.

Please see the [tagging guide](#tagging) to learn how to tag your user with a unique identifier from your system.

Please see below to learn how to store the user's OneSignal ID on your own system.

----
### Storing the OneSignal User ID

Each subscribed user, corresponding to the user's phone that installs your Android app / iOS app or the user's browser that visited your website, has a unique and randomly generated OneSignal user ID.

A OneSignal user ID looks like `b3aaabc2-9a47-4647-adda-3e4583a2d19e`. All of our IDs are [UUIDs](https://en.wikipedia.org/wiki/Universally_unique_identifier).

For web push, you can obtain and send the OneSignal user ID to your server after the user subscribes to your website's notifications. We provide an event handler to be notified of when the user has successfully subscribed. Below is example code that waits for the user to subscribe, and then obtains the user's OneSignal ID:
[block:code]
{
  "codes": [
    {
      "code": "OneSignal.push(function() {\n  OneSignal.on('subscriptionChange', function(isSubscribed) {\n    if (isSubscribed) {\n      // The user is subscribed\n      //   Either the user subscribed for the first time\n      //   Or the user was subscribed -> unsubscribed -> subscribed\n      OneSignal.getUserId( function(userId) {\n        // Make a POST call to your server with the user ID\n      });\n    }\n  });\n});",
      "language": "javascript"
    }
  ]
}
[/block]
Once the OneSignal user ID is on your server, you can use our REST API to send notifications programmatically targeting just this user. You would use our [Create notification](ref:create-notification) and use the `include_player_ids` parameter and pass in an array of strings specifying the list of OneSignal user IDs you would like to target.

Every time you use our REST API to send notifications, up to 2,000 user IDs of users who are no longer subscribed will be returned to you. You can use these IDs to mark users as not being unsubscribed so that you do not include them in the next send notifications API call.
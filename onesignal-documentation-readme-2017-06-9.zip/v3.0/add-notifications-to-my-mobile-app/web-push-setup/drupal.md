---
title: "Drupal"
excerpt: "Setting up OneSignal with Drupal"
---
There is a third-party [drupal module](https://www.drupal.org/project/onesignal) that walks you through configuring OneSignal for Drupal sites. You may have to follow one of our [Web Push SDK Setup guides](doc:web-push-setup) in addition to following the Drupal instructions, however.
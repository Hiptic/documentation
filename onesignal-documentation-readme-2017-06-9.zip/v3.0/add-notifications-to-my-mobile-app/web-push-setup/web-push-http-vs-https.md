---
title: "HTTP vs. HTTPS"
excerpt: "Setting up features for HTTP and HTTPS sites for <span class=\"label-all\">Web Push</span> (<span class=\"label-all label-chrome\">Chrome</span>, <span class=\"label-all label-firefox\">Firefox</span>, <span class=\"label-all label-safari\">Safari</span>).\n<div class=\"tag-all tag-developers\">For Developers</div>"
---
Using push notifications on HTTPS websites allows extra features not available on HTTP websites.

----
## HTTPS Sites
Setting up OneSignal using HTTPS means that push notifications are seen as officially coming from your domain name

----
## HTTP Sites
Setting up OneSignal with the HTTP option means the following:

1. This option works on both HTTP and HTTPS sites. If your site supports both protocols, use this option.

2. Push notifications come from a subdomain of onesignal.com.

3. Users must click on a button in a modal window that is displayed after they opt-in to notifications in order to become subscribed.

**How we support HTTP Sites:**

HTTP only support auto-prompting *if a modal is displayed and clicked after*. 

Web push notifications actually do not support HTTP sites at all. We work around the issue by sending notifications from a subdomain of our site, onesignal.com, which *is* an HTTPS site. You choose a subdomain to represent your site, and push notifications are officially sent from *subdomain*.onesignal.com. Due to browser restrictions, our workaround requires a popup to be shown, since users are actually subscribing to *subdomain*.onesignal.com. **As long as you are using our HTTP integration, this is always true and a popup *will always be required*.**

Our auto-prompting feature works only by taking advantage of some browser APIs, but it is *not* the same as a native integration (even if it looks similar).

Please note that users can never be subscribed automatically to push notifications, unless they have previously granted notification permissions to your site.

----
## Custom Domains
A custom sending domain is only possible for **HTTPS** sites.
[block:html]
{
  "html": "<img src=\"http://i.imgur.com/QT54slt.png\" style=\"background: url(http://i.imgur.com/QT54slt.png) no-repeat 0 0;\tbackground-size: contain;\theight: auto;\tmax-width: 50%; margin: 0 auto; display: block;\"/>"
}
[/block]
HTTP sites must use a *subdomain*.onesignal.com sending domain. Web push notifications actually do not support HTTP sites at all. We work around the issue by sending notifications from a subdomain of our site, onesignal.com, which *is* an HTTPS site. You choose a subdomain to represent your site, and push notifications are officially sent from *subdomain*.onesignal.com. This workaround is required because web push notifications are not actually supported on HTTP sites.

----
## Upgrading Sites to HTTPS
[block:callout]
{
  "type": "info",
  "title": "Free Upgrades to HTTPS",
  "body": "If you're looking for a free and easy way to add SSL to your site, you can use [CloudFlare's Flexible SSL option](https://support.cloudflare.com/hc/en-us/articles/200170516-How-do-I-add-SSL-to-my-site-). You don't need to buy an SSL certificate, but if you'd like to be [more secure](https://support.cloudflare.com/hc/en-us/articles/200170416-What-do-the-SSL-options-Off-Flexible-SSL-Full-SSL-Full-SSL-Strict-mean-) you can."
}
[/block]

[block:callout]
{
  "type": "warning",
  "title": "Your Site Should Only Support HTTPS",
  "body": "If the HTTP version of your site is still accessible, you **should not** follow these steps below. The HTTPS method of subscription will not work for users visiting the HTTP version of your site. Your site will only work for HTTPS visitors.\n\nIf you're using CloudFlare, you can [forcefully redirect all HTTP visitors --> HTTPS](https://support.cloudflare.com/hc/en-us/articles/200170536-How-do-I-redirect-all-visitors-to-HTTPS-SSL-)."
}
[/block]
### Non-WordPress Users Only

1. **Create a new** app for your HTTPS site following our [HTTPS web push setup guide](doc:web-push-sdk-setup-https). 
 
  - **If you have other HTTPS sites, please DO NOT re-use custom gcm_sender_id values from other apps, and DO follow our web push setup guide to use the Project Number of 482941778795.** This is because new apps use our shared web push keys and you must use our provided GCM Sender ID so things match.
    
  - Following our HTTPS web push setup guide, be sure to [update your site with the new initialization code](doc:web-push-sdk-setup-https#section-3-include-and-initialize-the-sdk). There *should not* be a 'subdomainName' parameter in your init code.

**Important**: It's important that your new HTTPS site's manifest.json uses a gcm_sender_id of 482941778795 if you've created a new HTTPS app.
   
### WordPress Users Only
 
1. Create a new app for your HTTPS site. Enter your new HTTPS site URL, choose a default notification icon, click Save and then exit the dialog and continue to step #2 below.

2. Visit your WordPress admin panel, visit our plugin admin page, select the Configuration tab, and at the top under Account Settings enable "My site uses an HTTPS connection (SSL)". 

3. Make sure the "App ID" textbox points to your new app's ID.
 
4. Make sure your "REST API Key" textbox points to your new app's REST API key.

5. **Important**: If your Configuration page shows a *Google Project Number* textbox, **be sure to clear this value** and then click Save.
 
Now that your site is HTTPS, you'll see more options, including the ability to automatically prompt users to subscribe to notifications ("Automatically prompt new site visitors to subscribe to push notifications" under Prompt Settings & Notify Button).

### What to Know After Upgrading

#### Will my subscriber base start over from zero?

Yes. Web push permissions and subscriptions are separated by domain/protocol, and the browser considers *http://site.com* and *https://site.com* to be two entirely different sites, and so there isn't a way to transfer the subscription.

#### Can I still use my old HTTP app?

We don't recommend using your old HTTP app to send notifications anymore. Your old users are still subscribed and can be reached, but if they subscribe to your HTTPS site as well, and if you send a notification using both your old HTTP app and your new HTTPS app, users will receive two notifications, which can be confusing. After setting up your HTTPS app, you can send one last message to your old subscribers letting them know you've switched over.
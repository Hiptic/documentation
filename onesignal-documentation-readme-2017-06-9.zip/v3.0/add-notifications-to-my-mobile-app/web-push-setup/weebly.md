---
title: "Weebly"
excerpt: "<div class=\"tag-all tag-developers\">For Developers</div> <div class=\"tag-all tag-marketers\">For Marketers</div>"
---
[block:callout]
{
  "type": "info",
  "title": "Setup Weebly",
  "body": "[Setup or log in to Weebly here](https://www.weebly.com/).\n\nIf setting up for the first time, follow Weebly's prompt until reaching the site editor."
}
[/block]
----
## 1. Configure OneSignal settings
<div class="label-all label-type"><span class="label-chrome">Chrome</span>, <span class="label-firefox">Firefox</span></div>

If setting up OneSignal for the first time:
After creating a OneSignal account, in your dashboard click "Add a new app". 
Select the "Website Push" platform to configure and click "next".
Select "Google Chrome & Mozilla Firefox" (will add Apple Safari in a moment) and click "next".
Continue to step 1.1...

If your OneSignal app is already created:
Go to <a class="dash-link" href="/docs/platforms">App Settings</a> and click **Configure** for the **Google Chrome** platform (instructions for Safari are [below](#section-3-safari-support-optional-)).
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/d365dff-Screen_Shot_2017-05-11_at_8.35.10_PM.png",
        "Screen Shot 2017-05-11 at 8.35.10 PM.png",
        2034,
        672,
        "#ecdddb"
      ],
      "sizing": "smart"
    }
  ]
}
[/block]
### 1.1 Enter Site URL
Most users just enter their base site URL for this field (e.g. `example.com` or `example.weebly.com`).

### 1.2 Enter Icon URL
Enter a link to an icon file that is at least 80x80 pixels (<span class="label-all label-recommended">Recommended</span> size is 192x192). The file must be `.png`, `.jpg`, or `.gif`.

### 1.3 Indicate Non-HTTPS Site
Check the box *My site is not fully HTTPS*, and scroll down to see the *Subdomain* field.

### 1.4 Choose subdomain
We recommend using the name of your site as your subdomian.

- Use only one word -- do not include `.com`
- Dashes, letters, and numbers are allowed (e.g. `my-blog` is a valid subdomain)
- Push notifications will be showing as coming from *subdomain*.onesignal.com

### 1.5 (For first time apps) Select your target SDK
Select Website Push.
Click "next."
Exit out of the prompt. Click "Yes" to finish later.

----
## 2. Include and initialize the SDK
Place the below code on all pages you'd like to OneSignal to prompt users to subscribe.
- `subdomainName`: [Where can I get my subdomain name?](http://imgur.com/a/f6hqN)
- `appId` is available in <a class="dash-link" href="/docs/accounts-and-keys#section-keys-ids">Keys & IDs</a>. 

[block:code]
{
  "codes": [
    {
      "code": "<head>\n  <script src=\"https://cdn.onesignal.com/sdks/OneSignalSDK.js\" async='async'></script>\n  <script>\n    var OneSignal = window.OneSignal || [];\n    OneSignal.push([\"init\", {\n      appId: \"YOUR_APP_ID\",\n      autoRegister: false, /* Set to true to automatically prompt visitors */\n      subdomainName: \"SUBDOMAIN_NAME_SEE_STEP_1.4\",\n      /*\n      subdomainName: Use the value you entered in step 1.4: http://imgur.com/a/f6hqN\n      */\n      httpPermissionRequest: {\n        enable: true\n      },\n      notifyButton: {\n          enable: true /* Set to false to hide */\n      }\n    }]);\n  </script>\n</head>",
      "language": "html"
    }
  ]
}
[/block]
### Weebly Site Editor Steps
#### 1. In your Weebly website editor, find your "Embed Code" element in your side panel under "BASIC".
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/18c3b86-Embed_Code.png",
        "Embed Code.png",
        218,
        156,
        "#464e4e"
      ]
    }
  ]
}
[/block]
#### 2. Click and drag the element to an area of each page that you want to include OneSignal.
#### 3. Click inside the element where it says "Click to set custom HTML" and "Edit Custom HTML".
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/2505f47-Screen_Shot_2017-03-02_at_9.02.08_PM.png",
        "Screen Shot 2017-03-02 at 9.02.08 PM.png",
        1456,
        428,
        "#387595"
      ]
    }
  ]
}
[/block]
#### 4. Copy and paste the above code with the correct `appId` and `subdomainName`.
#### 5. After clicking out of the "Embed Code" editor, you should see the OneSignal bell in the bottom right corner.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/4bee3e9-Screen_Shot_2017-03-02_at_9.09.45_PM.png",
        "Screen Shot 2017-03-02 at 9.09.45 PM.png",
        754,
        376,
        "#ba9783"
      ]
    }
  ]
}
[/block]
#### 6. Continue these steps on each page you would like OneSignal bell to appear.
#### 7. Publish your site and you are good to go!

----
## 3. Safari Support (Optional)
<div class="label-all label-type"><span class="label-safari">Safari</span></div>
[block:callout]
{
  "type": "info",
  "body": "Safari on iOS does not support web push. [See our list of supported browsers here](doc:web-push-setup)."
}
[/block]
**3.1** Go to <a class="dash-link" href="/docs/platforms">App Settings</a> and click **Configure** for the **Apple Safari** platform.

**3.2** Type in your *Site Name*. This is shown when prompting users to subscribe ([show me](http://notify.tech/wp-content/plugins/onesignal-free-web-push-notifications/views/images/settings/safari-prompt.jpg)).

**3.3** Type in the same *Site URL* as you typed above, except don't enter trailing slashes or subfolders.
  
**3.4** If you don't have a `.p12` certificate file, don't upload one.

**3.5** Upload your site icons. Please upload a `256 x 256` icon for each of the sizes (the icon will be automatically resized for each textbox). Please be sure to upload an icon for each slot!

**3.6** Add your `safari_web_id` to the *existing* init() call. Your `safari_web_id` can be found on the App Settings page of your app.

Your final code should look similar to this but with your `appId`, `subdomainName`, and `safari_web_id`:
[block:code]
{
  "codes": [
    {
      "code": "<head>\n  <script src=\"https://cdn.onesignal.com/sdks/OneSignalSDK.js\" async='async'></script>\n  <script>\n    var OneSignal = window.OneSignal || [];\n    OneSignal.push([\"init\", {\n      appId: \"YOUR_APP_ID\",\n      autoRegister: true, /* Set to true to automatically prompt visitors */\n      subdomainName: \"SUBDOMAIN_NAME_SEE_STEP_1.4\",\n      /*\n      subdomainName: Use the value you entered in step 1.4: http://imgur.com/a/f6hqN\n      */\n      httpPermissionRequest: {\n        enable: true\n      },\n      notifyButton: {\n          enable: true /* Set to false to hide */\n      },\n\t  safari_web_id: \"YOUR_SAFARI_WEB_ID\"\n    }]);\n  </script>\n</head>",
      "language": "html"
    }
  ]
}
[/block]
----
[block:callout]
{
  "type": "success",
  "title": "Done with Web Push on Weebly setup!",
  "body": "You're all set with push notifications for your Weebly website. \n\nNext step: [Customize Permission Messages](doc:customize-permission-messages)"
}
[/block]
----
## Miscellaneous

### How can I automatically dismiss a notification after some time?

On Firefox and Safari, notifications are automatically dismissed after a short amount of time. On Chrome, by default, notifications last indefinitely (they are displayed until the user interacts with it by dismissing it or clicking it). On Chrome Desktop v47+, you can add [the `persistNotification` parameter](doc:web-push-sdk#section--init-) to your OneSignal init call to control whether a notification is displayed indefinitely or dismissed after 20 seconds.

`persistNotification` defaults to true if unset. Set it to false to automatically dismiss the notification after 20 seconds (Chrome Desktop v47+ only).

**Dismissing Notifications After ~20 Sec. (Chrome Desktop v47+)**
[block:code]
{
  "codes": [
    {
      "code": "// Do NOT call init() twice\nOneSignal.push([\"init\", {\n  // Your other init options here\n  persistNotification: false // Automatically dismiss the notification after ~20 seconds in Chrome Deskop v47+\n}]);",
      "language": "javascript"
    }
  ]
}
[/block]

[block:callout]
{
  "type": "success",
  "body": "You're all set up! See our [Web Push Prompts](doc:web-push-prompts) page as well.",
  "title": "Setup Complete"
}
[/block]
---
title: "Wordpress"
excerpt: "<div class=\"tag-all tag-developers\">For Developers</div> <div class=\"tag-all tag-marketers\">For Marketers</div>"
---
[block:callout]
{
  "type": "info",
  "title": "Installing the WordPress Plugin",
  "body": "[Download and install the plugin here](https://wordpress.org/plugins/onesignal-free-web-push-notifications/).\n\nPlease follow the instructions on our WordPress plugin's Setup guide, and ignore our documentation here for SDK installation. The same steps are in our plugin's Setup guide."
}
[/block]
## About the WordPress Plugin

Our plugin:

  - Outputs a script tag on each of your site's pages to [our web SDK](doc:web-push-sdk) with the options you've configured

    You may use any of the web SDK JavaScript APIs documented above to customize the web push experience.

  - Hooks in to WordPress whenever a post is created or modified, and sends a notification based on the settings you've configured.

    See [Customizing WordPress Plugin Behavior](#section-customizing-wordpress-plugin-behavior) to learn how to use PHP to control what our plugin hooks into and to modify the notification that gets sent out.

---

# How do I ...?

## How do I send a notification when a post is published?

Notifications can be sent for when:

- A post is created using WordPress's default post editor
- A post is created using a third-party plugin
- An RSS feed is updated

### For posts created from WordPress's default post editor

<img src="http://i.imgur.com/ts0Vq6o.png">

Create your post as normal, and then check *Send notification on post publish*.

If your post is a different post type, you might see "Send notification on forum publish". If you are updating instead of creating, you might see "Send notification on post update". Each of these options should also successfully send a notification on the described action.

### For posts created from 3rd party plugins

#### "Post" post types

Make sure *Automatically send a push notification when I publish a post from 3rd party plugins* is checked, like shown here:

<img src="http://i.imgur.com/gxAslQH.png">

#### Custom post types

If your 3rd party plugin is sending custom post types, a notification *will not* be sent out by default. You must add the custom post type to this textbox (comma separated) to allow our plugin to automatically send out notifications. This is done to prevent accidental spam if a plugin sends many notifications of a custom type.

<img src="http://i.imgur.com/TQ2LsBu.png">

### For RSS feed updates

*(no programming experience required)*

Zapier is a service that allows you to perform actions when another trigger occurs. OneSignal has a Zapier integration for RSS feed updates.

Please [view our OneSignal integration here](https://zapier.com/zapbook/onesignal).

## How do I categorize users and send notifications to specific categories of users?

This guide will show you how to tag subscribers with a category or multiple categories and send to all subscribers that matches one or more categories.

This requires JavaScript and PHP coding. If you're not familiar with how to add JavaScript code to your WordPress site, you can use the WordPress plugin [CSS & JavaScript Toolbox](https://wordpress.org/plugins/css-javascript-toolbox/).

Please read our [Tagging Guide](doc:web-push-tagging-guide) to learn what it means to tag users and how you can do this. This will be done in JavaScript from your website. To ask users what categories they'd like to subscribe to, you may need to build a simple dialog for this. We do not provide a built-in dialog to ask users to subscribe to specific categories. The entire implementation is up to you.

You may end up tagging a user who is interested in only sports like:

<code>{sports: 1}</code>

A user who is interested in sports, news, and science, might be tagged like:

<code>{sports: 1, news: 1, science: 1}</code>

As our guide mentions, please note that tag values should be simple strings and integers. Using arrays or hashes as tag values will not allow you to match them correctly, since our tag value comparisons are exact matching (for strings) or comparison matching (for integers only, greater than or less than).

Once users are now categorized, you have to intercept our WordPress plugin's sending code, since notifications are still going to all users. To send the notification to one set of users only, you want to send notifications to only a certain *Segment*. Please create segments after reading our [Segments guide](doc:segmentation).

Then please read the beginning of [Customizing WordPress Plugin Behavior](#section-customizing-wordpress-plugin-behavior) (including the orange Important Note on where to place the code). You will want to use the [onesignal_send_notification filter](doc:wordpress#section-onesignal_send_notification-filter). You can use the code below:

(*please modify "PUT YOUR SEGMENT NAME HERE" with the segment name you created above*)
[block:code]
{
  "codes": [
    {
      "code": "<?php\nadd_filter('onesignal_send_notification', 'onesignal_send_notification_filter', 10, 4);\n\nfunction onesignal_send_notification_filter($fields, $new_status, $old_status, $post)\n{\n   // Change which segment the notification goes to\n  $fields['included_segments'] = array('PUT YOUR SEGMENT NAME HERE');\n  \n  return $fields;\n}",
      "language": "php"
    }
  ]
}
[/block]
## How do I customize the prompt text or welcome notification?

See [Customizing Welcome Notifications, Permission Messages, Subscription Bell](https://documentation.onesignal.com/docs/web-push-setup-faq).

## How do I change the prompt text language?

See [Customizing Welcome Notifications, Permission Messages, Subscription Bell](https://documentation.onesignal.com/docs/web-push-setup-faq).

## How do I change the subscription bell text, color, or position?

See [Customizing Subscription Bell](https://documentation.onesignal.com/docs/web-push-setup-faq#section-subscription-bell).

## How do I send notifications to my mobile app only?

See [Opening web and mobile notifications in the browser and app](#section-opening-web-and-mobile-notifications-in-the-browser-and-app) and [Sending notifications only to mobile apps not browsers](#section-sending-notifications-only-to-mobile-apps-not-browsers-).

## How can the clicked notification be opened in the mobile app instead of the browser?

See [Opening web and mobile notifications in the browser and app](#section-opening-web-and-mobile-notifications-in-the-browser-and-app) and [Sending notifications only to mobile apps not browsers](#section-sending-notifications-only-to-mobile-apps-not-browsers-).

## How can I send notifications to both my mobile app and browser?

See [Opening web and mobile notifications in the browser and app](#section-opening-web-and-mobile-notifications-in-the-browser-and-app) and [Sending notifications to both browsers and mobile apps](#section-sending-notifications-to-both-browsers-and-mobile-apps).

## How do I use the article's featured image for my notification icon?

[See this image](http://i.imgur.com/MdpUTfF.png) and enable *Use the post's featured image for the notification icon*.

*Note:* Your theme must support featured images. Not all themes support featured images (you may want to contact the theme author if you are having trouble with this). Another way to check if your theme supports featured images, is by opening the theme editor (*Appearance -> Editor*), finding the `functions.php` file, and search for `post-thumbnails`. You should see:

`add_theme_support( 'post-thumbnails' ); `

As explained in [WordPress's Post Thumbnails documentation](https://codex.wordpress.org/Post_Thumbnails). If you do not see this, your theme does not support featured images.

## How do I enable the plugin for certain pages only?

We offer two options that can optionally be combined:

- **Initializing OneSignal conditionally from server-sided PHP**

    See [Customizing WordPress Plugin Behavior](#section-customizing-wordpress-plugin-behavior) and [onesignal_initialize_sdk Filter](#section-onesignal_initialize_sdk-filter). Using this hook allows server-sided PHP code to determine when to initialize OneSignal.

  This is useful if you want to target pages based on properties that are only available on the server side.

- **Never initialize OneSignal automatically, manually initialize OneSignal on target pages using client-sided JavaScript**

  Please visit our WordPress plugin's Configuration page in your WordPress admin area. Scroll down to the bottom and enable "Disable OneSignal initialization".

  When this option is enabled, OneSignal *will not* be automatically initialized on *any* page, and you must add JavaScript code to each page to initialize OneSignal.

  This creates a global JavaScript variable on the page `window._oneSignalInitOptions` that you can use to initialize OneSignal with (see below) any time you choose.

  You can add conditional JavaScript rules to modify when you'd like to initialize OneSignal.

  Initialize OneSignal with:
[block:code]
{
  "codes": [
    {
      "code": "window.OneSignal = window.OneSignal || [];\n/* Why use .push? See: http://stackoverflow.com/a/38466780/555547 */\nwindow.OneSignal.push(function() {\n  /* Never call init() more than once. An error will occur. */\n  window.OneSignal.init(window._oneSignalInitOptions);\n});",
      "language": "javascript"
    }
  ]
}
[/block]
## How do I delay prompting users?

You will need to add JavaScript code to your site using our [JavaScript web SDK API](web-push-sdk).

1. Disable the option *Automatically prompt new site visitors to subscribe to push notifications*.

2. Find a way to add JavaScript code to your site. If you don't know how to do this, we recommend installing the WordPress plugin [CSS & JavaScript Toolbox](https://wordpress.org/plugins/css-javascript-toolbox/).

3. Using our [JavaScript web SDK API](web-push-sdk), call `registerForPushNotifications()` to prompt your user under your specific conditions. For example:

#### Delay prompting for X seconds
[block:code]
{
  "codes": [
    {
      "code": "<!-- data-cfasync: Ignore CloudFlare's Rocket Loader, which may impact the triggering of the DOMContentLoaded event (see: https://goo.gl/CvZewv) -->\n<script data-cfasync=\"false\">\n  window.OneSignal = window.OneSignal || [];\n  \n  /* In milliseconds, time to wait before prompting user. This time is relative to right after the user presses <ENTER> on the address bar and navigates to your page */\n  var notificationPromptDelay = 30000;\n  \n  /* Why use .push? See: http://stackoverflow.com/a/38466780/555547 */\n  window.OneSignal.push(function() {\n    /* Use navigation timing to find out when the page actually loaded instead of using setTimeout() only which can be delayed by script execution */\n    var navigationStart = window.performance.timing.navigationStart;\n\n    /* Get current time */\n    var timeNow = Date.now();\n\n    /* Prompt the user if enough time has elapsed */\n    setTimeout(promptAndSubscribeUser, Math.max(notificationPromptDelay - (timeNow - navigationStart), 0));\n  });\n  \n  function promptAndSubscribeUser() {\n    /* Want to trigger different permission messages? See: https://documentation.onesignal.com/docs/permission-requests#section-onesignal-permission-messages */\n    window.OneSignal.isPushNotificationsEnabled(function(isEnabled) {\n      if (!isEnabled) {        \n        window.OneSignal.registerForPushNotifications();\n      }\n    });\n  }\n</script>",
      "language": "html"
    }
  ]
}
[/block]
#### Prompt after X visits only
[block:code]
{
  "codes": [
    {
      "code": "<!-- data-cfasync: Ignore CloudFlare's Rocket Loader, which may impact the triggering of the DOMContentLoaded event (see: https://goo.gl/CvZewv) -->\n<script data-cfasync=\"false\">\n  window.OneSignal = window.OneSignal || [];\n  var numVisitsTrigger = 3; /* Number of page visits before prompting user */\n  \n  /* Why use .push? See: http://stackoverflow.com/a/38466780/555547 */\n  window.OneSignal.push(function() {\n    var numVisits = new Number(localStorage['numVisitsTrigger'] || 0);\n    numVisits += 1;\n    localStorage['numVisitsTrigger'] = numVisits;\n    if (numVisits >= numVisitsTrigger) {\n      promptAndSubscribeUser();\n    }\n  });\n  \n  function promptAndSubscribeUser() {\n    /* Want to trigger different permission messages? See: https://documentation.onesignal.com/docs/permission-requests#section-onesignal-permission-messages */\n    window.OneSignal.isPushNotificationsEnabled(function(isEnabled) {\n      if (!isEnabled) {        \n        window.OneSignal.registerForPushNotifications();\n      }\n    });\n  }\n</script>",
      "language": "javascript"
    }
  ]
}
[/block]
----

# Customizing WordPress Plugin Behavior
<div class="label-type"><span class="label-all label-advanced">Advanced Topic</span> &middot; <span class="label-all label-developers">For Developers</span></div>

Our WordPress plugin comes with some [action and filter hooks](https://www.tipsandtricks-hq.com/wordpress-action-hooks-and-filter-hooks-an-introduction-4163) that allow you to write PHP code to extend our plugin's functionality.

For example, our hooks can be used to:
- Automatically check or uncheck the [meta box checkbox](http://i.imgur.com/xJ4BuSb.png) "Send notification on post publish"
  - You can use this to make it easier for content publishes to automatically send notifications for certain kind of posts
- Always send a notification for certain post
  - (e.g. custom post types)
- Never send a notification for certain posts
  - You can combine the include/exclude filter
- Override any notification parameter, add extra parameters, remove extra parameters, and even send multiple notifications using the same call
[block:callout]
{
  "type": "warning",
  "body": "For all the following example usage calls, you'll have to copy and paste the PHP code into a file that will always be called. The goal is to add the below code to this file so that it will get called when our plugin takes the specified action. We recommend using [WordPress' must-use plugins feature](https://www.sitepoint.com/wordpress-mu-plugins/) to add your code to a file in the special specified directory to ensure your code is not overwritten when our plugin updates or when you update WordPress.",
  "title": "Important Note"
}
[/block]
### onesignal_initialize_sdk Filter

Return `true` to allow our WordPress plugin to automatically initialize our web SDK on the target page, which (if you've configured to do so) will create the SDK widgets like the red subscription button or prompt users to subscribe.

Return `false` to prevent our WordPress plugin from automatically initializing our web SDK on the target page.

You can customize when you would like the SDK to be initialized by returning `true` for some pages and `false` for other pages.

On pages in which you are returning `false`, our plugin will not automatically initialize our web SDK *and you must initialize OneSignal manually on those pages using client-sided JavaScript code on the page.* All the configuration options you've set on our WordPress plugin are still outputted to the page, in a variable called `window._oneSignalInitOptions`. You must then manually initialize OneSignal by calling  `OneSignal.init(window._oneSignalInitOptions);` in the client-sided JavaScript code of the page. You may [modify `window._oneSignalInitOptions` according to our Web SDK `init()` documentation](doc:web-push-sdk#section--init-).

On pages in which you are returning `true`, the target pages will be automatically initialized (like normal) -- unless you have the option *Use my own SDK initialization script* enabled in the WordPress Configuration page (near the bottom). 

Enabling *Use my own SDK initialization script* in our plugin's options is equivalent to returning `false` for all pages; our plugin will not automatically initialize the web SDK on *all* pages and you must them manually initialize OneSignal in JavaScript on all pages. 
[block:code]
{
  "codes": [
    {
      "code": "<?php\nadd_filter('onesignal_initialize_sdk', 'onesignal_initialize_sdk_filter', 10, 1);\nfunction onesignal_initialize_sdk_filter($onesignal_settings) {\n    // Returning true allow the SDK to initialize normally on the current page\n    // Returning false prevents the SDK from initializing automatically on the current page\n    return true;\n}",
      "language": "php"
    }
  ]
}
[/block]
### onesignal_meta_box_send_notification_checkbox_state Filter

Overrides the state of the [meta box checkbox "Send notification on post publish"](http://i.imgur.com/xJ4BuSb.png).
[block:code]
{
  "codes": [
    {
      "code": "<?php\nadd_filter('onesignal_meta_box_send_notification_checkbox_state', 'filter', 10, 2);\n// Available keys for $onesignal_wp_settings: https://github.com/OneSignal/OneSignal-WordPress-Plugin/blob/master/onesignal-settings.php#L5\nfunction filter($post, $onesignal_wp_settings) {\n  // Always leave the checkbox \"Send notification on <post type> <action> (e.g. post publish)\" unchecked\n  return false;\n}   ",
      "language": "php"
    }
  ]
}
[/block]
### onesignal_include_post Filter

Called every time a post's status changes as part of WordPress's [transition_post_status](https://codex.wordpress.org/Post_Status_Transitions#transition_post_status_Hook).

Returning `true` will always send a notification for the specified post. Returning `false` does nothing; it simply passes control back to our main plugin logic. It's important to note returning `false` does not exclude the post -- that is done in the `onesignal_exclude_post` filter.

You can use the `onesignal_include_post` and `onesignal_exclude_post` filter together. The order of operations is *INCLUDE -> EXCLUDE*. The `onesignal_include_post` filter is run first to determine whether a post is included. If a post is not included, the `onesignal_exclude_post` filter is run next to determine whether this post is excluded. If the post is not excluded, our normal plugin logic runs.

[block:code]
{
  "codes": [
    {
      "code": "<?php\nadd_filter('onesignal_include_post', 'onesignal_include_post_filter', 10, 3);\nfunction onesignal_include_post_filter($new_status, $old_status, $post) {\n  return false;\n}",
      "language": "php"
    }
  ]
}
[/block]
### onesignal_exclude_post Filter

Called every time a post's status changes as part of WordPress's [transition_post_status](https://codex.wordpress.org/Post_Status_Transitions#transition_post_status_Hook).

Returning `true` will never send a notification for the specified post. Returning `false` does nothing; it simply passes control back to our main plugin logic. It's important to note returning `false` does not include the post -- that is done in the `onesignal_include_post` filter.

You can use the `onesignal_include_post` and `onesignal_exclude_post` filter together. The order of operations is *INCLUDE -> EXCLUDE*. The `onesignal_include_post` filter is run first to determine whether a post is included. If a post is not included, the `onesignal_exclude_post` filter is run next to determine whether this post is excluded. If the post is not excluded, our normal plugin logic runs.

[block:code]
{
  "codes": [
    {
      "code": "<?php\nadd_filter('onesignal_exclude_post', 'onesignal_exclude_post_filter', 10, 3);\nfunction onesignal_exclude_post_filter($new_status, $old_status, $post) {\n  return false;\n}",
      "language": "php"
    }
  ]
}
[/block]
### onesignal_send_notification Filter

Called after all the notification creation parameters have been determined, and right before the notification is actually sent.

You may modify any of the parameters to, for example:
- Change the notification's title, message, and URL
- Send the notification to additional platforms (e.g. Android and iOS)
- Prevent the notification from being sent to certain platforms
- Schedule the notification to be sent in the future
- Add [action buttons](doc:web-push-action-buttons) 
- Cancel the notification from being sent

Please see our [Create notification](ref:create-notification) docs page for the full parameter list and description of what's accepted in the `$fields` hash.

[block:code]
{
  "codes": [
    {
      "code": "<?php\nadd_filter('onesignal_send_notification', 'onesignal_send_notification_filter', 10, 4);\n\nfunction onesignal_send_notification_filter($fields, $new_status, $old_status, $post)\n{\n   // Change the notification's title, message, and URL\n  $fields['headings'] = array(\"en\" => \"English notification title\");\n  $fields['contents'] = array(\"en\" => \"English notification message body\");\n  $fields['url'] = 'https://example.com';\n  \n  // Send to additional platforms (e.g. Android and iOS)\n  $fields['isAndroid'] = true;\n  $fields['isIos'] = true;\n  \n  // Prevent the notification from being sent to certain platforms\n  $fields['isFirefox'] = false;\n  \n  // Schedule the notification to be sent in the future\n  $fields['send_after'] = \"Sept 24 2018 14:00:00 GMT-0700\";\n  \n  // Schedule the notification to be delivered at the specific hour of the destination timezone\n  $fields['delayed_option'] = 'timezone';\n  $fields['delivery_time_of_day'] = '9:00AM';\n  \n  // Add web push action buttons (different action buttons are used for Android and iOS)\n  $fields['web_buttons'] = array(\n    \"id\" => \"like-button\",\n    \"text\" => \"Like\",\n    \"icon\" => \"http://i.imgur.com/N8SN8ZS.png\",\n    \"url\" => \"https://example.com\"\n  );\n  \n  // Cancel the notification from being sent\n  $fields['do_send_notification'] = false;\n  \n  return $fields;\n}",
      "language": "php"
    }
  ]
}
[/block]
----
## Opening web and mobile notifications in the browser and app
<div class="label-type"><span class="label-all label-advanced">Advanced Topic</span> &middot; <span class="label-all label-developers">For Developers</span></div>

If you have web and mobile platforms users, you can send two notifications: the first notification to web browsers and the second notification to mobile phones. The web push notification will open in a web browser and the mobile push notification will open in your app.

For the first notification sent to web push users, send the notification normally without specifically excluding any parameters.

For the second notification sent to mobile users, *make sure to exclude* the `url` parameter. If the `url` parameter is included, a new browser tab will be opened to that URL. Instead, pass data in to the `additionalData` field (in a custom format your app will be able to parse), and then use the mobile notification opened / notification clicked handler to navigate the user to a section in your app.

Here is [an example using native Android](http://stackoverflow.com/a/37935082/555547). Here is the documentation for the [native notificationOpened handler](doc:android-native-sdk#section--setnotificationopenedhandler-) used by the example.

If you're using Cordova, Phonegap, or Ionic, be sure to [use the notificationOpened handler from the Cordova, Phonegap, or Ionic section of our docs](doc:cordova-sdk#section--notificationopenedcallback-) . On the code example, be sure to click the variant describing how to open a page in your app.

### WordPress Users Only

To take advantage of our WordPress plugin doing this for you, you will have to follow some additional instructions below to add a WordPress filter hook.

1. On our plugin's Configuration page, please *disable* the option "Send notifications additionally to iOS & Android platforms". This option does not allow customizing the mobile notifications so we have to disable this option first.

2. You'll have to copy and paste the PHP code into a file that will always be called. The goal is to add the below code to this file so that it will get called when our plugin takes the specified action. We recommend using [WordPress' must-use plugins feature](https://www.sitepoint.com/wordpress-mu-plugins/) to add your code to a file in the special specified directory to ensure your code is not overwritten when our plugin updates or when you update WordPress.

#### Sending notifications *only* to mobile apps (not browsers) 
[block:code]
{
  "codes": [
    {
      "code": "<?php\nfunction onesignal_send_notification_filter($fields, $new_status, $old_status, $post)\n{\n    $fields['isAndroid'] = true;\n    $fields['isIos'] = true;\n    $fields['isAnyWeb'] = false;\n    $fields['isChrome'] = false;\n    $fields['data'] = array(\n        \"myappurl\" => $fields['url']\n    );\n    /* Unset the URL to prevent opening the browser when the notification is clicked */\n    unset($fields['url']);\n    return $fields;\n}",
      "language": "php"
    }
  ]
}
[/block]
#### Sending notifications to *both* browsers *and* mobile apps 
[block:code]
{
  "codes": [
    {
      "code": "<?php\nadd_filter('onesignal_send_notification', 'onesignal_send_notification_filter', 10, 4);\n\nfunction onesignal_send_notification_filter($fields, $new_status, $old_status, $post)\n{\n    /* Goal: We don't want to modify the original $fields array, because we want the original web push notification to go out unmodified. However, we want to send an additional notification to Android and iOS devices with an additionalData property.\n    */\n    $fields_dup = $fields;\n    $fields_dup['isAndroid'] = true;\n    $fields_dup['isIos'] = true;\n    $fields_dup['isAnyWeb'] = false;\n    $fields_dup['isWP'] = false;\n    $fields_dup['isAdm'] = false;\n    $fields_dup['isChrome'] = false;\n    $fields_dup['data'] = array(\n        \"myappurl\" => $fields['url']\n    );\n    /* Important to unset the URL to prevent opening the browser when the notification is clicked */\n    unset($fields_dup['url']);\n    /* Send another notification via cURL */\n    $ch = curl_init();\n    $onesignal_post_url = \"https://onesignal.com/api/v1/notifications\";\n    /* Hopefully OneSignal::get_onesignal_settings(); can be called outside of the plugin */\n    $onesignal_wp_settings = OneSignal::get_onesignal_settings();\n    $onesignal_auth_key = $onesignal_wp_settings['app_rest_api_key'];\n    curl_setopt($ch, CURLOPT_URL, $onesignal_post_url);\n    curl_setopt($ch, CURLOPT_HTTPHEADER, array(\n        'Content-Type: application/json',\n        'Authorization: Basic ' . $onesignal_auth_key\n    ));\n    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);\n    curl_setopt($ch, CURLOPT_HEADER, true);\n    curl_setopt($ch, CURLOPT_POST, true);\n    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields_dup));\n    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);\n\n    // Optional: Turn off host verification if SSL errors for local testing\n    // curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);\n\n    /* Optional: cURL settings to help log cURL output response\n    curl_setopt($ch, CURLOPT_FAILONERROR, false);\n    curl_setopt($ch, CURLOPT_HTTP200ALIASES, array(400));\n    curl_setopt($ch, CURLOPT_VERBOSE, true);\n    curl_setopt($ch, CURLOPT_STDERR, $out);\n    */\n    $response = curl_exec($ch);\n    /* Optional: Log cURL output response\n    fclose($out);\n    $debug_output = ob_get_clean();\n    $curl_effective_url = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);\n    $curl_http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);\n    $curl_total_time = curl_getinfo($ch, CURLINFO_TOTAL_TIME);\n    onesignal_debug('OneSignal API POST Data:', $fields);\n    onesignal_debug('OneSignal API URL:', $curl_effective_url);\n    onesignal_debug('OneSignal API Response Status Code:', $curl_http_code);\n    if ($curl_http_code != 200) {\n    onesignal_debug('cURL Request Time:', $curl_total_time, 'seconds');\n    onesignal_debug('cURL Error Number:', curl_errno($ch));\n    onesignal_debug('cURL Error Description:', curl_error($ch));\n    onesignal_debug('cURL Response:', print_r($response, true));\n    onesignal_debug('cURL Verbose Log:', $debug_output);\n    }\n\n    */\n    curl_close($ch);\n    return $fields;\n}",
      "language": "php"
    }
  ]
}
[/block]
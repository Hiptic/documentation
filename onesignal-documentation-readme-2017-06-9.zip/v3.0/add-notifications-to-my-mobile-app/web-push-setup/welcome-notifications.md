---
title: "Thanks for Subscribing Notifications"
excerpt: "Tutorial - Setting up welcome notifications for <span class=\"label-all\">Web Push</span> (<span class=\"label-all label-chrome\">Chrome</span>, <span class=\"label-all label-firefox\">Firefox</span>, and <span class=\"label-all label-safari\">Safari</span>).\n<div class=\"tag-all tag-developers\">For Developers</div>"
---
## Web Push

### How do I customize or disable the automatic welcome notification when a new site visitor subscribes?

Use the `welcomeNotification` parameter in your [init()](doc:web-push-sdk#section--init-) options. The `url` parameter is, by default, set to a special value that, on Chrome and Firefox, disables the notification from opening a separate webpage. By default, Safari must open a webpage and it will default to your site's URL. You may optionally set `url` so the notification opens a separate URL (on Chrome, Safari, and Firefox).

**Showing a Welcome Notification**
[block:code]
{
  "codes": [
    {
      "code": "// Do NOT call init() twice\nOneSignal.push([\"init\", {\n    /* Your other init options here */\n    welcomeNotification: {\n        \"title\": \"My Custom Title\",\n        \"message\": \"Thanks for subscribing!\",\n        // \"url\": \"\" /* Leave commented for the notification to not open a window on Chrome and Firefox (on Safari, it opens to your webpage) */\n    }\n}]);",
      "language": "javascript"
    }
  ]
}
[/block]
**Disabling Welcome Notifications**
[block:code]
{
  "codes": [
    {
      "code": "// Do NOT call init() twice\nOneSignal.push([\"init\", {\n    welcomeNotification: {\n        disable: true\n    }\n}]);",
      "language": "javascript"
    }
  ]
}
[/block]
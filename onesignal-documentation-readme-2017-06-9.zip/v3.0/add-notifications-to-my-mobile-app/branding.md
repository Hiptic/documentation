---
title: "Customizing Notifications"
excerpt: "Customizing your notifications with your app icons, colors, and style\n<div class=\"tag-all tag-developers\">For Developers</div> <div class=\"tag-all tag-marketers\">For Marketers</div>"
---
## Customizing Notification Features
- [Customize Permission Messages](doc:customize-permission-messages) 
- [Customize Action Buttons](doc:customize-action-buttons) 
- [Customize Notification Sounds](doc:customize-notification-sounds) 
- [Customize Notification Icons](doc:customize-notification-icons) 

## Platform-specific Features
<span class="label-all label-android">Android</span> - Android allows for many customization options, including icons, background images, sounds, and more.  Read more in [Android Customizations](doc:android-customizations).
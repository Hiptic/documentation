---
title: "Creating Notifications"
excerpt: "Tutorials for how to set up notifications for a variety of use cases\n<div class=\"tag-all tag-developers\">For Developers</div> <div class=\"tag-all tag-marketers\">For Marketers</div>"
---
The following are guides for some different types of notifications your app or website may send.

- [User-User Messages](doc:user-user-messages) 
- [Location-Triggered Notifications](doc:location-triggered-event) 
- [Welcome Notifications](doc:welcome-notifications)
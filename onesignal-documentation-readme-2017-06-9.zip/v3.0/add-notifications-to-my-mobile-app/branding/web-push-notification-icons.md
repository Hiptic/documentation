---
title: "Web Push Notification Icons"
excerpt: "Customizing <span class=\"label-all label-web\">Web Push</span> notifications with your app icons, colors, and style.\n<div class=\"tag-all tag-developers\">For Developers</div>"
---
Web push notifications support icon and image customization options.

---
## Setting the Icon and Image

On the dashboard, the icon and image can be set here:
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/26aef97-Screen_Shot_2017-05-09_at_8.53.23_PM.png",
        "Screen Shot 2017-05-09 at 8.53.23 PM.png",
        850,
        272,
        "#f2f2f2"
      ]
    }
  ]
}
[/block]
----
## Icon

The icon displays to the left of the notification's title and message. In this example, it is the OneSignal logo:

<img src="https://i.imgur.com/uocZdlD.png" style="max-width: 80%;">

The icon should be:

- At least 192 x 192 to display well on high-DPI devices
- A JPG, PNG, GIF, WebP, ICO/CUR, or BMP type. SVG images are not supported
    - *GIF images will not animate and are frozen on the first frame*

----
## Image

Chrome 56+ supports displaying a large image below the notification's title and message:
<img src="http://i.imgur.com/9mAdbTH.png" style="max-width: 80%">

Keep in mind:

On Chrome Desktop:
  - The image should be at least 360px wide by 240px tall, with a 1.5 aspect ratio
  - Smaller images will be upscaled to fit the container while preserving the aspect ratio; larger images will be downscaled
  - The image is displayed using 'contain' sizing: each side of the image is as large as possible while not exceeding the the container side's length

On Chrome on Android:
  - The image is displayed using 'cover' sizing:  the image covers the container entirely, even it means cropping the top/bottom or sides of the images
  - If the notification tray has too many notifications, the image will not be displayed by default, and the user must "scroll down" on the notification to see it. Examples are below.
  - Use a 2:1 aspect ratio. Android not have a size limit, but we recommend:
    - Minimum - 512x256
    - Balanced - 1024x512
    - Maximum - 2048x1024


Platform size example are below.

### Chrome Desktop Image Examples

#### 360 x 240: 1.5 Aspect Ratio

<img src="https://i.imgur.com/onBdl7m.png" width="65%">

#### 90 x 60: 1.5 Aspect Ratio

<img src="http://i.imgur.com/nWZVvdQ.png" width="65%">

#### 360 x 120: 3 Aspect Ratio

<img src="http://i.imgur.com/gL0UuiF.png" width="65%">

#### 180 x 240: 0.75 Aspect Ratio

<img src="http://i.imgur.com/cH6Aci0.png" width="65%">

#### 80 x 80: 1 Aspect Ratio

<img src="http://i.imgur.com/3rGy6qk.png" width="65%">


### Chrome on Android Image Examples

#### 500x500 x : 1 Aspect Ratio

Because of 'cover' sizing, a 500x500 image fills up the viewport:

<img src="http://i.imgur.com/dv468hx.png" width="65%">

#### Desktop vs. Android 500x500 Same Image

Comparing the difference between the 'contain' and 'cover' sizing in Desktop vs. Android using the same image:

<img src="http://i.imgur.com/Os55F1z.png" width="45%" style="float: left;">
<img src="http://i.imgur.com/uidPuor.png" width="45%">

#### Sliding Image on Android (too many notifications in tray)

When there are too many notifications in the tray, your image may not be shown at first. The notification has to be "scrolled down" to see the image:

<img src="https://i.imgur.com/FTTfx6r.gif" width="65%">
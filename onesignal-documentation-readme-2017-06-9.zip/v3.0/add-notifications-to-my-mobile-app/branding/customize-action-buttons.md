---
title: "Customize Action Buttons"
excerpt: "Tutorial - How to add action buttons to notifications. Works with  <span class=\"label-all label-ios\">iOS</span>,  <span class=\"label-all label-android\">Android</span> (and derivatives like <span class=\"label-all label-amazon\">Amazon</span>) and <span class=\"label-all label-chrome\">Chrome</span>.\n<div class=\"tag-all tag-developers\">For Developers</div>"
---
## What are Action Buttons?
Action Buttons allow more than one action to be taken on a notification, allowing for greater interactivity to be captured in your notifications. To read more about Action Button support in OneSignal, go to [Action Buttons](doc:action-buttons).

## How to Add Action Buttons

### Add Action Buttons from the Dashboard
Go to <a class="dash-link" href="/docs/sending-notifications">New Message</a> and select **Options**. Then input your follow platform-specific instructions:

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/4109387-Screen_Shot_2017-05-16_at_5.32.00_PM.png",
        "Screen Shot 2017-05-16 at 5.32.00 PM.png",
        548,
        479,
        "#f2f2f2"
      ]
    }
  ]
}
[/block]
<span class="label-all label-ios">iOS</span>, <span class="label-all label-android">Android</span>, <span class="label-all label-amazon">Amazon</span> - Fill in with the parameters below:
[block:parameters]
{
  "data": {
    "0-0": "`id`",
    "h-0": "Parameter",
    "h-1": "Notes",
    "1-0": "`text`",
    "2-0": "`icon`",
    "2-1": "<span class=\"label-all label-android\">Android</span>, <span class=\"label-all label-amazon\">Amazon</span> - add icon to button",
    "1-1": "The text the button should display.",
    "0-1": "A unique identifier for your button action."
  },
  "cols": 2,
  "rows": 3
}
[/block]
<span class="label-all label-chrome">Chrome</span> - Enable *Include Chrome Web Push Action Buttons?* and fill in the parameters below:
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/160507d-Screen_Shot_2017-05-09_at_8.04.29_PM.png",
        "Screen Shot 2017-05-09 at 8.04.29 PM.png",
        853,
        345,
        "#f2f2f2"
      ]
    }
  ]
}
[/block]

[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Notes",
    "0-0": "`Action ID`",
    "1-0": "`Button Text`",
    "2-0": "`Icon URL`",
    "3-0": "`Launch URL`",
    "0-1": "A unique identifier for your button action. The ID of the clicked button is passed to you so you can identify which button was clicked. (e.g. 'accept-button')",
    "1-1": "The text the button should display. Passed to your app so you can identify which button was clicked. (e.g. 'Accept')",
    "2-1": "A valid publicly reachable URL to an icon. Keep this small because it's downloaded on every notification display. (e.g. 'http://site.com/icon.png')",
    "3-1": "The URL to open when the notification is clicked. Pass 'do_not_open' to prevent opening any URL. (e.g. 'do_not_open')"
  },
  "cols": 2,
  "rows": 4
}
[/block]
### Add Action Buttons from the REST API

<span class="label-all label-ios">iOS</span>, <span class="label-all label-android">Android</span>, <span class="label-all label-amazon">Amazon</span> - See REST API [Create Notification: Action Buttons](ref:create-notification#section-action-buttons). The button id is added to the `additionalData` variable in the notification opened callback. 

<span class="label-all label-chrome">Chrome</span> -  Use the `web_buttons` parameter and pass an array of hashes (up to the two) describing the button with `id`, `text`, `icon`, and `url`. See description of the parameters above.

### Add Action Buttons from the SDK
<span class="label-all label-ios">iOS</span>, <span class="label-all label-android">Android</span>, <span class="label-all label-amazon">Amazon</span> - See the [SDK Reference](doc:sdk-reference) for whichever SDK you are using to build your app. The button id is added to the `additionalData` variable in the notification opened callback. 


<span class="label-chrome label-all">Chrome</span> - If OneSignal is active on your webpage, you can send the current webpage visitor a test notification using the following code:
[block:code]
{
  "codes": [
    {
      "code": "/******************/\n/** EXAMPLE CODE **/\n/******************/\nOneSignal.sendSelfNotification(\n  /* Title (defaults if unset) */\n  \"OneSignal Web Push Notification\",\n  /* Message (defaults if unset) */\n  \"Action buttons increase the ways your users can interact with your notification.\", \n   /* URL (defaults if unset) */\n  'https://example.com/?_osp=do_not_open',\n  /* Icon */\n  'https://onesignal.com/images/notification_logo.png',\n  {\n    /* Additional data hash */\n    notificationType: 'news-feature'\n  }, \n  [{ /* Buttons */\n    /* Choose any unique identifier for your button. The ID of the clicked button \t\t\t is passed to you so you can identify which button is clicked */\n    id: 'like-button',\n    /* The text the button should display. Supports emojis. */\n    text: 'Like',\n    /* A valid publicly reachable URL to an icon. Keep this small because it's \t\t\t\t downloaded on each notification display. */\n    icon: 'http://i.imgur.com/N8SN8ZS.png',\n    /* The URL to open when this action button is clicked. See the sections below \t\t\t for special URLs that prevent opening any window. */\n    url: 'https://example.com/?_osp=do_not_open'\n  },\n  {\n    id: 'read-more-button',\n    text: 'Read more',\n    icon: 'http://i.imgur.com/MIxJp1L.png',\n    url: 'https://example.com/?_osp=do_not_open'\n  }]\n);",
      "language": "javascript"
    }
  ]
}
[/block]
## Action Button Icons (Optional)
<div class="label-type label-all"><span class="label-android">Android</span>, <span class="label-all label-amazon">Amazon</span></div>

By default icons will not display on Action Buttons. If you're adding buttons to your notifications we highly recommend adding icons to them. You will need to make your icons 32x32dp (24x24dp optical square) in size, this means the following pixel sizes:
```
mdpi = 24x24 pixels in a 32x32 area
hdpi = 36x36 pixels in a 48x48 area
xhdpi = 48x48 pixels in a 64x64 area
xxhdpi = 72x72 pixels in a 96x96 area
```
Action Button icons will appear next to the button text, such as the icons next to 'Share' and 'View' in this example:
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/3552f8f-ActionButton-Android.png",
        "ActionButton-Android.png",
        373,
        263,
        "#1b1a1c"
      ]
    }
  ]
}
[/block]

[block:callout]
{
  "type": "success",
  "body": "Done! You should be able to send notifications with Action Buttons now."
}
[/block]
----
##  FAQ

### What platforms are supported?
See our [platforms support](doc:action-buttons#section-platforms-supported) table.


### How can I use the action button click event?
<div class="label-type label-all"><span class="label-chrome">Chrome</span></div>

When an action button is clicked, or when the notification body is clicked:

- A notification click event is fired [according to these specifications](doc:web-push-sdk#section--notificationopenedcallback-)
- If the notification body was clicked, the notification URL is opened. If an action button was clicked, the action button URL is opened.
- Finally, the notification click webhook is fired [Webhooks](doc:webhooks) 

You can take advantage of these three events to perform whatever you need. For example, using webhooks, you can perform a custom action (e.g. upvoting a story, analytics) when an action button is clicked.


### How can I prevent the action button from opening any URL?
<div class="label-type label-all"><span class="label-chrome">Chrome</span></div>

You can use the following special URL for both the notification launch URL and action button URL.

- Any URL containing the magic string `_osp=do_not_open` *will not open any URL*

This is supported on Chrome and Firefox, but not supported for the Safari web browser. If you target Safari, please provide a URL so that Safari users have somewhere to go. For example, you could use `https://yoursite.com/page?_osp=do_not_open`.


### How can I use the action button to do some work on my page without opening extra windows?
<div class="label-type label-all"><span class="label-chrome">Chrome</span></div>

Our goal in this example is to open a new tab to our site (if our site isn't already open) when the action button is clicked, and do some work on the page.

Please first [read this section of our API reference](doc:web-push-sdk#section--notificationopenedcallback-) to understand when our notification click handler fires. It only ever fires on one tab, and the notification launch URL or action button launch URL must at least be the same *origin* as your site's in order for the notification click handler to trigger.

We'll first modify our JavaScript initialization options so that the notification click handler is called as long as our notification launch URL or action button launch URL shares our site's origin. For https://site.com, this means our notification click handler will be called as long as our notification launch URL or action button launch URL begins with "https://site.com...".
[block:code]
{
  "codes": [
    {
      "code": "/* Do NOT call init twice */\nOneSignal.push([\"init\", {\n  /* Your other init settings ... */\n  notificationClickHandlerMatch: 'origin', /* See API reference: https://documentation.onesignal.com/docs/web-push-sdk#section--notificationopenedcallback- *.\n  /* Your other init settings ... */\n}]);",
      "language": "javascript"
    }
  ]
}
[/block]
Now we'll add a listener to capture the notification click event, that does some pretend work:
[block:code]
{
  "codes": [
    {
      "code": "OneSignal.push([\"addListenerForNotificationOpened\", function(event) {\n  console.log(\"OneSignal notification clicked:\", event);\n  /*\n  {\n      \"id\": \"96a0dd96-5b63-47e2-9e67-58ca9a315325\",\n      \"heading\": \"OneSignal Web Push Notification\",\n      \"content\": \"Action buttons increase the ways your users can interact with your notification.\",\n      \"data\": {\n          \"notificationType\": \"news-feature\"\n      },\n      \"url\": \"https://example.com\",\n      \"icon\": \"https://onesignal.com/images/notification_logo.png\",\n      \"buttons\": [\n          {\n              \"action\": \"like-button\",\n              \"title\": \"Like\",\n              \"icon\": \"http://i.imgur.com/N8SN8ZS.png\",\n              \"url\": \"https://example.com\"\n          },\n          {\n              \"action\": \"read-more-button\",\n              \"title\": \"Read more\",\n              \"icon\": \"http://i.imgur.com/MIxJp1L.png\",\n              \"url\": \"https://example.com\"\n          }\n      ],\n      \"action\": \"like-button\"\n  }\n  */\n  \n  // We might send a lot of different notifications; the notification we just sent came with additional data that describes the kind of notification that was sent. We sent \"notificationType\" with our additional data field (notificationType is not built in).\n  var isNewsFeatureNotification = event.data && event.data.notificationType === 'news-feature';\n  if (isNewsFeatureNotification) {\n    // What action button did they click?\n    if (event.action === \"\") {\n      // An empty string means the notification body was clicked (no action button was clicked)\n      // Keep in mind action buttons are only supported on Chrome 48+ so some users will only be able to click the notification body\n    } else if (event.action === 'like-button') {\n      // The \"Like\" action button was clicked\n      alert(\"Glad you liked it! We'll show you similar stories in the future\");\n    } else if (event.action === 'read-more-button') {\n      // The \"Read more\" action button was clicked\n      alert('Showing you the full news article...');\n    }\n  }\n}]);",
      "language": "javascript"
    }
  ]
}
[/block]
Now when sending a notification (see above for how to send a notification with action buttons), we can use a notification launch URL and action button launch URLs that begin with our site's origin to trigger our notification click event.

If the site is already open, no new tab will be opened. Otherwise, a new tab will be opened and the new tab will receive the notification click event.


### How can I send a Notification with a Launch Action button?
<div class="label-type label-all"><span class="label-ios">iOS</span>, <span class="label-android">Android</span>, <span class="label-amazon">Amazon</span></div>

We provide a callback method that you can set in your app code that will receive data about which button was pressed (if any) on the notification that launched the app. With this method, you can run custom code to execute depending on the pressed button. This method can be found in the [SDK Reference](doc:sdk-reference) for the SDK you are using to build your app.
---
title: "Additional Features"
excerpt: "Additional features you can build around notifications\n<div class=\"tag-all tag-developers\">For Developers</div> <div class=\"tag-all tag-advanced\">Advanced Topic</div>"
---
The following are tutorials for implementing some additional notification-related features in your app:

- [Create an Activity Feed](doc:create-an-activity-feed) 
- [Create In-App Notifications](doc:create-in-app-notifications)

The following are guides for some different types of notifications your app or website may send.

- [User-User Messages](doc:user-user-messages) 
- [Location-Triggered Notifications](doc:location-triggered-event) 
- [Welcome Notifications](doc:welcome-notifications)
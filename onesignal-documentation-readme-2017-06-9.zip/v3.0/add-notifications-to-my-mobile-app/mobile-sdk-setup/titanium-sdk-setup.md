---
title: "Titanium SDK Setup"
excerpt: ""
---
## Setup SDK

### Generate Credentials
Before setting up the Titanium SDK, you must generate the appropriate credentials for the platform(s) you are releasing on:

<span class="label-all label-ios">iOS</span> - [Generate an iOS Push Certificate](doc:generate-an-ios-push-certificate) 

<span class="label-all label-android">Android</span> - [Generate a Google Server API Key](doc:generate-a-google-server-api-key) 

### Follow Guide
Then, [follow this guide](https://github.com/williamrijksen/com.williamrijksen.onesignal) to setup OneSignal with your Titanium App.
---
title: "PhoneGap SDK Setup"
excerpt: "OneSignal PhoneGap SDK Setup Guide. Works with <span class=\"label-all label-ios\">iOS</span>, <span class=\"label-all label-android\">Android</span> (and derivatives like <span class=\"label-all label-amazon\">Amazon</span>) and <span class=\"label-all label-windows\">Windows Phone 8.1</span>.\n<div class=\"tag-all tag-developers\">For Developers</div>"
---
## Update SDK
If you already have an app with the PhoneGap SDK, you can run this to ensure your SDK is on the latest version:
[block:code]
{
  "codes": [
    {
      "code": "phonegap plugin update onesignal-cordova-plugin",
      "language": "shell",
      "name": "Command Line"
    }
  ]
}
[/block]
If you have not set up an app yet, follow the instructions below.

----

## Setup SDK

### Generate Credentials
Before setting up the PhoneGap SDK, you must generate the appropriate credentials for the platform(s) you are releasing on:

<span class="label-all label-ios">iOS</span> - [Generate an iOS Push Certificate](doc:generate-an-ios-push-certificate) 

<span class="label-all label-android">Android</span> - [Generate a Google Server API Key](doc:generate-a-google-server-api-key) 

<span class="label-all label-amazon">Amazon</span> - [Generate an Amazon API Key](doc:generate-an-amazon-api-key) 

<span class="label-all label-windows">Windows Phone 8.1</span> - [Generate a Windows Phone Package SID and Secret](doc:generate-a-windows-phone-package-sid-and-secret) 


### 1. Import OneSignal Plugin
*Please follow step 1A or 1B based which PhoneGap version you use to build your app.*

You should also remove other Push SDKs that you are not using, otherwise you may see duplicate notifications.

### 1A. PhoneGap CLI
Run the following from your project directory.
[block:code]
{
  "codes": [
    {
      "code": "phonegap plugin add onesignal-cordova-plugin --save",
      "language": "shell",
      "name": "Command Line"
    }
  ]
}
[/block]
*-- OR --*

### 1B. PhoneGap Build (PGB)
Add the following lines to `<project-dir>/www/config.xml`
[block:code]
{
  "codes": [
    {
      "code": "<gap:plugin name=\"onesignal-cordova-plugin\" spec=\"^2.1.1\" source=\"npm\" />\n\n<!--Requires cli-6.4.0 but we recommend using the latest version. -->\n<preference name=\"phonegap-version\" value=\"cli-6.4.0\" />\n<preference name=\"android-build-tool\" value=\"gradle\" />\n\n<!-- Window Phone 8.1 builds must use cli-6.1.0+ above -->\n<preference name=\"windows-appx-target\" value=\"8.1-phone\" />\n<preference name=\"WindowsToastCapable\" value=\"true\" />",
      "language": "xml",
      "name": "Adobe PhoneGap Build (PGB)"
    }
  ]
}
[/block]

### 2. Add required code
**2.1.** Add the following to the first javascript file that loads with your app.
- This is `<project-dir>/www/js/index.js` for most PhoneGap projects.
[block:code]
{
  "codes": [
    {
      "code": "// Add to index.js or the first page that loads with your app.\n// For Intel XDK and please add this to your app.js.\n\ndocument.addEventListener('deviceready', function () {\n  // Enable to debug issues.\n  // window.plugins.OneSignal.setLogLevel({logLevel: 4, visualLevel: 4});\n  \n  var notificationOpenedCallback = function(jsonData) {\n    console.log('notificationOpenedCallback: ' + JSON.stringify(jsonData));\n  };\n\n  window.plugins.OneSignal\n    .startInit(\"YOUR_APPID\")\n    .handleNotificationOpened(notificationOpenedCallback)\n    .endInit();\n  \n  // Call syncHashedEmail anywhere in your app if you have the user's email.\n  // This improves the effectiveness of OneSignal's \"best-time\" notification scheduling feature.\n  // window.plugins.OneSignal.syncHashedEmail(userEmail);\n}, false);",
      "language": "javascript",
      "name": "Javascript"
    }
  ]
}
[/block]
**2.2 ** Update initialization parameters 

Replace `YOUR_APPID` with your OneSignal AppId, available in <a class="dash-link" href="/docs/accounts-and-keys#section-keys-ids">Keys & IDs</a>

<span class="label-all label-recommended">Recommended</span> - Change `inFocusDisplaying` to `None` when app is ready for launch. See [PhoneGap SDK Reference](doc:phonegap-sdk#section--infocusdisplaying-) for instructions.

<span class="label-all label-optional">Optional</span> - follow the [PhoneGap SDK reference](doc:phonegap-sdk) to add code for when users tap on and open notifications to your liking by using the chaining methods `handleNotificationReceived` and `handleNotificationOpened`.


----
### 3. Android
*Skip this section if you use PhoneGap Build*

**3.1 ** Open the Android SDK Manager.

**3.2 ** Make sure to install and update the following under Extras:

- Android Support **Repository**
- Google **Repository**
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/cfbZBwxSmeToNEbZJoz0_AndroidSDKGoogleRepository.png",
        "AndroidSDKGoogleRepository.png",
        "600",
        "341",
        "#c7413e",
        ""
      ]
    }
  ]
}
[/block]

**3.3 ** Follow the [Customize Notification Icons](doc:customize-notification-icons) instructions to create a small notification icon required for Android 5.0+ devices.

----
### 4. Amazon ADM
*Skip this section if you use PhoneGap Build*

Place your `api_key.txt` file into your `<project-dir>/platforms/android/assets/` folder.

*To create an `api_key.txt` for your app follow our [Generate an Amazon API Key](doc:generate-an-amazon-api-key)*

----
### 5. iOS
**5.1** No extra steps, you're all set if you already setup your provisioning profile and push certificate.


----
### 6. Windows Phone 8.1 (WP8.1)
*Skip this section if you use PhoneGap Build*

*Your app does not have to be published however, you must have it created on the Windows Dev Center. Follow our [Windows Phone Project SID & Secret](generate-a-windows-phone-package-sid-and-secret) setup if you have not done this yet.*

**6.1** Run `phonegap build windows` and open the .sln in <project-root>/platforms/windows/

**6.2** Under the Windows Phone 8.1 project double click on `Package.appxmanifest` then select the "Application" tab and scroll down to the "Notifications:" section. Change "Toast capable:" to Yes.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/0eX5aHISfWQhNWmLJGoJ_WindowPhone8.1_SDK_2.1.png",
        "WindowPhone8.1_SDK_2.1.png",
        "851",
        "282",
        "#384868",
        ""
      ]
    }
  ]
}
[/block]
**6.3** Right click on your VS project and select Store>Associate App with the Store...
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/tKhdtb2jQdSMnHskkysn_WindowPhone8.1__SDK_1.1.png",
        "WindowPhone8.1__SDK_1.1.png",
        "714",
        "510",
        "#2f4363",
        ""
      ]
    }
  ]
}
[/block]
**6.4** Click Next and sign into your Microsoft account.

**6.5** Select your app and press Next.

**6.6.** Lastly press Associate.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/mUHzdp7SlyXIpWn71Y6Q_WindowPhone8.1_SDK_4.3.png",
        "WindowPhone8.1_SDK_4.3.png",
        "786",
        "643",
        "#3489da",
        ""
      ]
    }
  ]
}
[/block]

----
[block:callout]
{
  "type": "danger",
  "title": "Troubleshooting",
  "body": "If you run into any errors see [Troubleshooting Cordova Variants](doc:troubleshooting-cordova-variants), our our general [Troubleshooting](doc:troubleshooting) section."
}
[/block]

[block:callout]
{
  "type": "warning",
  "title": "Push Notification Testing Requirements",
  "body": "* *iOS* - Must test on a real device, Simulator does not support Apple push notifications.\n* *Android*\n   * You **MUST** build and install your app's APK. \n   * You may use an emulator but it must have an updated version of Google Play services installed.\n* Does **NOT** work with the [PhoneGap Developer App](http://phonegap.com/products/#mobile-app-section)."
}
[/block]
## SDK API
Check out our [PhoneGap SDK](doc:phonegap-sdk) for more OneSignal functions.
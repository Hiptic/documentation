---
title: "Cocos2d-x SDK Setup"
excerpt: "OneSignal Cocos2d-x SDK Reference. Works with <span class=\"label-all label-ios\">iOS</span> and <span class=\"label-all label-android\">Android</span> (and derivatives like <span class=\"label-all label-amazon\">Amazon</span>)."
---
## Setup SDK

### Generate Credentials
Before setting up the Cocos2d-X SDK, you must generate the appropriate credentials for the platform(s) you are releasing on:

<span class="label-all label-ios">iOS</span> - [Generate an iOS Push Certificate](doc:generate-an-ios-push-certificate) 

<span class="label-all label-android">Android</span> - [Generate a Google Server API Key](doc:generate-a-google-server-api-key) 

<span class="label-all label-amazon">Amazon</span> - [Generate an Amazon API Key](doc:generate-an-amazon-api-key) 

### Follow Guide
[Follow this guide](http://www.sdkbox.com/plugins/onesignal) to download and setup OneSignal in Cocos2d-x with SDKBox.
---
title: "Windows Phone SDK Setup"
excerpt: "OneSignal <span class=\"label-all label-windows\">Windows Phone 8.0 and 8.1</span> SDK Setup Guide.\n<div class=\"tag-all tag-developers\">For Developers</div>"
---
[block:callout]
{
  "type": "info",
  "title": "Using an app framework?",
  "body": "If you're using an app framework to build your <span class=\"label-all label-windows\">Windows Phone</span> app, we have higher level SDKs for the following: [Unity](doc:unity-sdk-setup), [PhoneGap](doc:phonegap-sdk-setup), [Cordova](doc:cordova-sdk-setup), [Ionic](doc:ionic-sdk-setup), [Intel XDK](doc:intel-xdk-setup), and [Marmalade](doc:marmalade-sdk-setup)."
}
[/block]
## Windows Phone 10
OneSignal does **not** support UWP projects yet. However Windows Phone 8.1 projects will run and support push notifications on both Window Phone 8.1 & 10 devices.

----
## Setup SDK
<div class="label-type label-all"><span class="label-windows">Windows Phone 8.1</span></div>

### Generate Credentials
Before you start you must [generate a Windows Phone Package SID and Secret](doc:generate-a-windows-phone-package-sid-and-secret) 

### 1. Add OneSignal to your Project
**1.1** Download the [OneSignal Windows Phone SDK](https://github.com/one-signal/OneSignal-WindowsPhone-SDK/releases).

**1.2** Copy the `Release/OneSignalSDK_WP81_Release` folder into your project folder.

**1.3** In Visual Studio, right click on References and go to "Add Reference...".
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/efjHDkcFTUe3q0FhwLqu_WindowPhone8.1_SDK_1.3.png",
        "WindowPhone8.1_SDK_1.3.png",
        "312",
        "241",
        "#3498f1",
        ""
      ]
    }
  ]
}
[/block]
**1.4** Browse for OneSignalSDK_WP_WNS.dll and press OK.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/MLd8XN0ORKyFaGxLHQlX_WindowPhone8.1_SDK_1.4.png",
        "WindowPhone8.1_SDK_1.4.png",
        "685",
        "342",
        "",
        ""
      ]
    }
  ]
}
[/block]

[block:callout]
{
  "type": "warning",
  "title": "Silverlight Compatibility",
  "body": "The OneSignal SDK is currently not compatibility with Silverlight or Windows UWP (Windows Universal Platform) Projects."
}
[/block]
### 2. Package.appxmanifest Settings

**2.1** Double click on Package.appxmanifest then select the "Application" tab and scroll down to the "Notifications:" section. Change "Toast capable:" to Yes.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/1LwTYKvTR7ydlx1Km5a0_WindowPhone8.1_SDK_2.1.png",
        "WindowPhone8.1_SDK_2.1.png",
        "851",
        "282",
        "#384868",
        ""
      ]
    }
  ]
}
[/block]
**2.2** Under the Capabilities tab make sure "Internet (Client & Server)" is checked. Lastly make sure to save.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/SD0OLNWSjW2WkqVMJ7kp_WindowPhone8.1_SDK_2.2.png",
        "WindowPhone8.1_SDK_2.2.png",
        "856",
        "294",
        "#38547c",
        ""
      ]
    }
  ]
}
[/block]
### 3. Add Code

**3.1** Open `App.xaml.cs` under App.xaml and the following OneSignal.init code below to your `OnLaunched` method.
[block:code]
{
  "codes": [
    {
      "code": "using OneSignalSDK_WP_WNS;\n\nprotected override void OnLaunched(LaunchActivatedEventArgs e) {\n\tOneSignal.Init(\"b2f7f966-d8cc-11e4-bed1-df8f05be55ba\", e);\n}",
      "language": "csharp"
    }
  ]
}
[/block]
Repalce `b2f7f966-d8cc-11e4-bed1-df8f05be55ba` with your OneSignal App Id.

**3.2** Optionally, you can add a notification opened callback that fires when a notification is opened. This callback also fires when a notification is received when your app is being used instead of displaying a notification.
[block:code]
{
  "codes": [
    {
      "code": "protected override void OnLaunched(LaunchActivatedEventArgs e) {   \n\tOneSignal.Init(\"b2f7f966-d8cc-11e4-bed1-df8f05be55ba\", e, notificationOpened);\n}\n\nprivate void notificationOpened(string message, IDictionary<string, string> additionalData, bool isActive) {\n   System.Diagnostics.Debug.WriteLine(\"notificationOpened:message:\" + message);\n   System.Diagnostics.Debug.WriteLine(\"notificationOpened:additionalData:\" + additionalData);\n   System.Diagnostics.Debug.WriteLine(\"notificationOpened:isActive:\" + isActive);\n}",
      "language": "csharp"
    }
  ]
}
[/block]
### 4. Associate App with the Store

*Your app does not have to be published however, you must have it created on the Windows Dev Center. Follow our [Windows Phone Project SID & Secret](http://documentation.onesignal.com/v2.0/docs/windows-phone-client-sid-secret) setup if you have not done this yet.*

**4.1** Right click on your VS project and select Store>Associate App with the Store...
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/eNxxC2JrSc6b3vsT5eCG_WindowPhone8.1__SDK_1.1.png",
        "WindowPhone8.1__SDK_1.1.png",
        "714",
        "510",
        "#2f4363",
        ""
      ]
    }
  ]
}
[/block]
**4.2** Click Next and sign into your Microsoft account.

**4.3** Select your app and press Next.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/IW0sI5AR2SI9hVvbZkAA_WindowPhone8.1_SDK_4.3.png",
        "WindowPhone8.1_SDK_4.3.png",
        "786",
        "643",
        "#3489da",
        ""
      ]
    }
  ]
}
[/block]
**4.4.** Lastly, press Associate.
[block:callout]
{
  "type": "success",
  "body": "Done! You should be all set to go with your Windows Phone 8.1 app."
}
[/block]
----
## Setup SDK (Windows Phone 8.0)
<div class="label-type label-all"><span class="label-windows">Windows Phone 8.0</span></div>

### 1. Add our library

**1.1** Download the [OneSignal Windows Phone SDK](https://github.com/one-signal/OneSignal-WindowsPhone-SDK/releases).

**1.2** Copy the Release/OneSignalSDK_WP80_Release folder into your project folder.

**1.3** In Visual Studio, right click on References and go to "Add Reference...".
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/vAjIgQB6S3WwSGfO2irY_windows.jpg",
        "windows.jpg",
        "700",
        "350",
        "#4d9692",
        ""
      ]
    }
  ]
}
[/block]
### 2. Add the required Capabilities

**2.1** Under Properties folder, open **WMAppManifest.xml** and then select the Capabilities tab on top. Enable the following 3 capabilities; `ID_CAP_IDENTITY_DEVICE`,` ID_CAP_NETWORKING`, and `ID_CAP_PUSH_NOTIFICATION`.

### 3. Add Required Code

**3.1** In your **MainPage.xaml.cs** file add **using OneSignalSDK;** to the top.

**3.2** Add the following methods to your **MainPage.xaml.cs** file:
[block:code]
{
  "codes": [
    {
      "code": "protected override void OnNavigatedTo(NavigationEventArgs navEventArgs) {\n    base.OnNavigatedTo(navEventArgs);\n    OneSignal.Init(\"5eb5a37e-b458-11e3-ac11-000c2940e62c\", ReceivedNotification);\n}\n// Called when the user opens a notification or one comes in while using the app.\nprivate static void ReceivedNotification(string message, IDictionary<string, string> additionalData, bool isActive) {\n}",
      "language": "csharp"
    }
  ]
}
[/block]
**3.3** Replace `5eb5a37e-b458-11e3-ac11-000c2940e62c` with your OneSignal App Id.
[block:callout]
{
  "type": "success",
  "body": "Done! You should be all set to go with your Windows Phone 8.0 app."
}
[/block]
----
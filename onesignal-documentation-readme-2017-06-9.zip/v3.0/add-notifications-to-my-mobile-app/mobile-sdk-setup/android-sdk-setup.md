---
title: "Android SDK Setup"
excerpt: "OneSignal <span class=\"label-all label-android\">Android</span> SDK Setup Guide. Also for <span class=\"label-all label-amazon\">Amazon</span> apps using Android Studio.\n<div class=\"tag-all tag-developers\">For Developers</div>"
---
Android Studio is the most common way to build <span class="label-all label-android">Android</span> projects. The following instructions are also applicable if you're using Android Studio to build your <span class="label-all label-amazon">Amazon</span> app ([see more](doc:amazon-sdk-setup)).
If you're still using Eclipse instead of Android studio, [follow the guide here instead](doc:android-sdk-setup-eclipse).

### Before proceeding, follow the steps to [Generating a Google Server API Key](doc:generate-a-google-server-api-key).
### 1. Gradle Setup

**1.1** Open your `build.gradle` (Module: app) file and add the following to your dependencies.
[block:code]
{
  "codes": [
    {
      "code": "dependencies {\n    // OneSignal SDK\n    compile 'com.onesignal:OneSignal:[3.5.3,4.0.0)'\n}",
      "language": "groovy",
      "name": "Gradle"
    }
  ]
}
[/block]

[block:callout]
{
  "type": "warning",
  "title": "com.android.support:appcompat WARNING",
  "body": "Please make sure to use `compile 'com.android.support:appcompat-v7:24.0.0'`"
}
[/block]
**1.2** In the same `build.gradle` file, add the following in your `android` > `defaultConfig` section.
* Update `PUT YOUR ONESIGNAL APP ID HERE` with your OneSignal app id
[block:code]
{
  "codes": [
    {
      "code": "android {\n   defaultConfig {\n      manifestPlaceholders = [onesignal_app_id: \"PUT YOUR ONESIGNAL APP ID HERE\",\n                              // Project number pulled from dashboard, local value is ignored.\n                              onesignal_google_project_number: \"REMOTE\"]\n    }\n }",
      "language": "c",
      "name": "Gradle"
    }
  ]
}
[/block]

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/6742f62-AndroidStuido-OneSignal-gradle-setup.png",
        "AndroidStuido-OneSignal-gradle-setup.png",
        1115,
        660,
        "#e7e8e5"
      ],
      "sizing": "smart"
    }
  ]
}
[/block]
<br>
### 2. Add Required Code

**2.1** Add the following to the `onCreate` method in your `Application` class.
[block:code]
{
  "codes": [
    {
      "code": "import com.onesignal.OneSignal;\n\npublic class YourAppClass extends Application {\n   @Override\n   public void onCreate() {\n      super.onCreate();\n      OneSignal.startInit(this)\n        .inFocusDisplaying(OneSignal.OSInFocusDisplayOption.Notification)\n        .unsubscribeWhenNotificationsAreDisabled(true)\n        .init();\n     \n      // Call syncHashedEmail anywhere in your app if you have the user's email.\n      // This improves the effectiveness of OneSignal's \"best-time\" notification scheduling feature.\n      // OneSignal.syncHashedEmail(userEmail);\n   }\n}",
      "language": "java"
    }
  ]
}
[/block]
*Don't have a class that extends Application in your project?
Follow [this tutorial](https://www.mobomo.com/2011/05/how-to-use-application-object-of-android/) to create one.*

### 3. Create a default notification icon
**3.1** Starting with Android Lollipop 5.0 a small notification icon is required for the icon to be visible in the status bar. Follow the [Customize Notification Icons](doc:customize-notification-icons) instructions to create a small notification icon.

### 4. Add Optional Notification Handlers
[NotificationOpenedHandler](doc:android-native-sdk#section--notificationopenedhandler-) - This will be called when a notification is tapped on.
See our [setNotificationOpenedHandler](doc:android-native-sdk#section--setnotificationopenedhandler-) documentation to add one.

[NotificationReceivedHandler](doc:android-native-sdk#section--notificationreceivedhandler-) - This will be called when a notification is received.
See our [setNotificationReceivedHandler](doc:android-native-sdk#section--setnotificationreceivedhandler-) documentation to add one.

**NotificationExtenderService** - This service can be setup to receive notifications no matter if your app is running or not. It can be used override how notifications are shown in the notification shade or to process data silently without showing a notification. See the [Background Data and Notification Overriding](doc:android-customizations#section-background-data-and-notification-overriding) section to set this up.

### Next Steps
<span class="label-all label-android">Android</span> - Setup is done! All `AndroidManifest.xml` entries are added by our SDK for you. Make sure you are testing push notifications on a device or emulator that has Google Play services installed and updated on it.
[block:callout]
{
  "type": "danger",
  "body": "If run into any issues please see our [Android troubleshooting guide](https://documentation.onesignal.com/docs/troubleshooting-android), or our general [Troubleshooting](doc:troubleshooting) section.",
  "title": "Troubleshooting"
}
[/block]

[block:callout]
{
  "type": "info",
  "body": "* To see all available methods for <span class=\"label-all label-android\">Android</span>, see our [Android Native SDK Reference](doc:android-native-sdk).\n* See our [example projects on Github](https://github.com/OneSignal/OneSignal-Android-SDK/tree/master/Examples) for a full example.",
  "title": "Additional Documentation"
}
[/block]
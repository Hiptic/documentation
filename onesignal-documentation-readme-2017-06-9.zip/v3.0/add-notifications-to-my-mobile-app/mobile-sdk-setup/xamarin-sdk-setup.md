---
title: "Xamarin SDK Setup"
excerpt: "OneSignal Xamarin SDK Reference. Works with <span class=\"label-all label-ios\">iOS</span> and <span class=\"label-all label-android\">Android</span> (and derivatives like <span class=\"label-all label-amazon\">Amazon</span>).\n<div class=\"tag-all tag-developers\">For Developers</div>"
---
### Generate Credentials
Before setting up the Xamarin SDK, you must generate the appropriate credentials for the platform(s) you are releasing on:

<span class="label-all label-ios">iOS</span> - [Generate an iOS Push Certificate](doc:generate-an-ios-push-certificate) 

<span class="label-all label-android">Android</span> - [Generate a Google Server API Key](doc:generate-a-google-server-api-key) 

<span class="label-all label-amazon">Amazon</span> - [Generate an Amazon API Key](doc:generate-an-amazon-api-key) 

---

The Xamarin OneSignal SDK works for both Xamarin Forms and Xamarin Single View projects.

----
## Setup SDK

### 1. Add NuGet Package

**1.1** Under your Droid and / or iOS targets right click on `Packages` then select `Add Packages...`.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/0603412-Xamarin_SDK_Setup_1.png",
        "Xamarin_SDK_Setup_1.png",
        340,
        374,
        "#eaeaef"
      ]
    }
  ]
}
[/block]
**1.2** Search for `OneSignalSDK` and press `Add Package`.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/8bbd585-Xamarin_SDK_Setup_2.png",
        "Xamarin_SDK_Setup_2.png",
        820,
        543,
        "#f0f0f1"
      ]
    }
  ]
}
[/block]
---

<br>
### 2. Add Code

#### Xamarin Forms Project
** 2.1A ** Add the following to your `App.xaml.cs`.
[block:code]
{
  "codes": [
    {
      "code": "using Com.OneSignal;\n\npublic App()\n{\n  InitializeComponent();\n  MainPage = new OneSignalXamarinFormsExamplePage();\n\n  OneSignal.Current.StartInit(\"YOUR_ONESIGNAL_APP_ID\")\n                  .EndInit();\n}",
      "language": "csharp"
    }
  ]
}
[/block]

#### Xamarin Single View App
** 2.1B ** - <span class="label-all label-android">Android</span> - Add OneSignal to your `MainActivity.cs` in your `OnCreate` method.
[block:code]
{
  "codes": [
    {
      "code": "using Com.OneSignal;\n\nprotected override void OnCreate(Bundle savedInstanceState)\n{\n  base.OnCreate(savedInstanceState);\n  SetContentView(Resource.Layout.Main);\n\n  OneSignal.Current.StartInit(\"YOUR_ONESIGNAL_APP_ID\")\n                  .EndInit();\n}",
      "language": "csharp"
    }
  ]
}
[/block]
** 2.1B ** - <span class="label-all label-ios">iOS</span> - Add OneSignal to your `AppDelegate.cs` in your `FinishedLaunching` method.
[block:code]
{
  "codes": [
    {
      "code": "using Com.OneSignal;\n\npublic override bool FinishedLaunching(UIApplication application, NSDictionary launchOptions)\n{\n\n  OneSignal.Current.StartInit(\"YOUR_ONESIGNAL_APP_ID\")\n                  .EndInit();\n  return true;\n}",
      "language": "csharp"
    }
  ]
}
[/block]
---

<br>
### 3. Android Setup

**3.1** Add the following permissions to `AndroidManifest.xml`.
[block:code]
{
  "codes": [
    {
      "code": "<permission android:name=\"${manifestApplicationId}.permission.C2D_MESSAGE\"\n            android:protectionLevel=\"signature\" />\n<uses-permission android:name=\"${manifestApplicationId}.permission.C2D_MESSAGE\" />",
      "language": "xml"
    }
  ]
}
[/block]
**3.2** In your application tag, add the following.
[block:code]
{
  "codes": [
    {
      "code": "<application ....>\n\n  <receiver android:name=\"com.onesignal.GcmBroadcastReceiver\"\n            android:permission=\"com.google.android.c2dm.permission.SEND\" >\n    <intent-filter>\n      <action android:name=\"com.google.android.c2dm.intent.RECEIVE\" />\n      <category android:name=\"${manifestApplicationId}\" />\n    </intent-filter>\n  </receiver>\n  \n</application>",
      "language": "xml"
    }
  ]
}
[/block]
**3.3** Replace all 3 of instances of `${manifestApplicationId}` with your package name in `AndroidManifest.xml`.

---

<br>
### 4. iOS Setup

**4.1** In your application's __Info.plist__, verify your _Bundle Identifier_ matches you App Settings' Bundle ID, _Enable Background Modes_, allow _Remote notifications_.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/KVAFqY9zSB2MUErANFrV_InfoPlist1.png",
        "InfoPlist1.png",
        "2574",
        "1448",
        "#1c3179",
        ""
      ]
    }
  ]
}
[/block]

### 5. iOS Optional - Only Required for iOS Simulator builds

The following is required to prevent crashes when using the iOS simulator.

**5.1** Right click on your iOS project and select `Options`.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/457438b-Xamarin_SDK_Setup_IOS_SIM.png",
        "Xamarin_SDK_Setup_IOS_SIM.png",
        538,
        651,
        "#ededf0"
      ]
    }
  ]
}
[/block]

**5.2** Select `Build` > `iOS Build`, then make sure `iPhoneSimulator` is selected under "Platform:" at the top.

**5.3** Under `Additional mtouch arguments:` enter `--registrar:static`.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/1ab4b13-Xamarin_SDK_Setup_IOS_SIM_2.png",
        "Xamarin_SDK_Setup_IOS_SIM_2.png",
        950,
        546,
        "#f0f0f0"
      ]
    }
  ]
}
[/block]
---
<br>
[block:callout]
{
  "type": "danger",
  "body": "If run into any issues please see our [Troubleshooting](doc:troubleshooting) section",
  "title": "Troubleshooting"
}
[/block]
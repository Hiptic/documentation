---
title: "iOS SDK Setup"
excerpt: "<div class=\"tag-all tag-developers\">For Developers</div>"
---
### Before proceeding, you must [generate an iOS Push Certificate](doc:generate-an-ios-push-certificate).


### 1. Add Notification Service Extension (Recommend)
***This step is optional but needed to use Notification Action Buttons and Media Attachments on iOS 10.***

**1.1** In Xcode Select `File` > `New` > `Target...`
**1.2** Select `Notification Service Extension` then press `Next`.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/74a6d44-Xcode_create_notification_service_extension_1.png",
        "Xcode_create_notification_service_extension_1.png",
        730,
        519,
        "#eff0f1"
      ]
    }
  ]
}
[/block]
**1.3** Enter the product name as `OneSignalNotificationServiceExtension` and press `Finish`.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/1abfb4e-Xcode_create_notification_service_extension_2.png",
        "Xcode_create_notification_service_extension_2.png",
        730,
        518,
        "#f0f0f0"
      ]
    }
  ]
}
[/block]
**1.4** Press Cancel on the Active scheme prompt.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/5c47cf5-Xcode_create_notification_service_extension_3.png",
        "Xcode_create_notification_service_extension_3.png",
        420,
        233,
        "#f2f2f2"
      ]
    }
  ]
}
[/block]
**1.5** Open `NotificationService.m` or `NotificationService.swift` and replace the whole file contents with the below code.
[block:code]
{
  "codes": [
    {
      "code": "#import <OneSignal/OneSignal.h>\n\n#import \"NotificationService.h\"\n\n@interface NotificationService ()\n\n@property (nonatomic, strong) void (^contentHandler)(UNNotificationContent *contentToDeliver);\n@property (nonatomic, strong) UNNotificationRequest *receivedRequest;\n@property (nonatomic, strong) UNMutableNotificationContent *bestAttemptContent;\n\n@end\n\n@implementation NotificationService\n\n- (void)didReceiveNotificationRequest:(UNNotificationRequest *)request withContentHandler:(void (^)(UNNotificationContent * _Nonnull))contentHandler {\n    self.receivedRequest = request;\n    self.contentHandler = contentHandler;\n    self.bestAttemptContent = [request.content mutableCopy];\n    \n    [OneSignal didReceiveNotificationExtensionRequest:self.receivedRequest withMutableNotificationContent:self.bestAttemptContent];\n    \n    self.contentHandler(self.bestAttemptContent);\n}\n\n- (void)serviceExtensionTimeWillExpire {\n    // Called just before the extension will be terminated by the system.\n    // Use this as an opportunity to deliver your \"best attempt\" at modified content, otherwise the original push payload will be used.\n    \n    [OneSignal serviceExtensionTimeWillExpireRequest:self.receivedRequest withMutableNotificationContent:self.bestAttemptContent];\n    \n    self.contentHandler(self.bestAttemptContent);\n}\n\n@end",
      "language": "objectivec"
    },
    {
      "code": "import UserNotifications\n\nimport OneSignal\n\nclass NotificationService: UNNotificationServiceExtension {\n    \n    var contentHandler: ((UNNotificationContent) -> Void)?\n    var receivedRequest: UNNotificationRequest!\n    var bestAttemptContent: UNMutableNotificationContent?\n    \n    override func didReceive(_ request: UNNotificationRequest, withContentHandler contentHandler: @escaping (UNNotificationContent) -> Void) {\n        self.receivedRequest = request;\n        self.contentHandler = contentHandler\n        bestAttemptContent = (request.content.mutableCopy() as? UNMutableNotificationContent)\n        \n        if let bestAttemptContent = bestAttemptContent {\n            OneSignal.didReceiveNotificationExtensionRequest(self.receivedRequest, with: self.bestAttemptContent)\n            contentHandler(bestAttemptContent)\n        }\n    }\n    \n    override func serviceExtensionTimeWillExpire() {\n        // Called just before the extension will be terminated by the system.\n        // Use this as an opportunity to deliver your \"best attempt\" at modified content, otherwise the original push payload will be used.\n        if let contentHandler = contentHandler, let bestAttemptContent =  bestAttemptContent {\n            OneSignal.serviceExtensionTimeWillExpireRequest(self.receivedRequest, with: self.bestAttemptContent)\n            contentHandler(bestAttemptContent)\n        }\n    }\n    \n}",
      "language": "swift"
    }
  ]
}
[/block]
*Ignore any build errors at this point, step 2 will import OneSignal which will resolve any errors.* 
<br>

----

### 2. Import OneSignal into your Xcode project
[Setup CocoaPods](http://guides.cocoapods.org/using/getting-started.html) on your system if you don't have it already.
   - Make sure you have version `1.1.0` or newer by running `pod --version` from the terminal.
   - Run the following to upgrade `sudo gem install cocoapods`
 
**2.1** Make sure your current Xcode project is closed.
**2.2** Run `pod init` from the terminal in your project directory.
**2.3** Open the newly created `Podfile` with your favorite code editor such as Sublime.
**2.4** Add `pod 'OneSignal', '>= 2.5.2', '< 3.0'` in your project name target as well as `OneSignalNotificationServiceExtension`.
[block:code]
{
  "codes": [
    {
      "code": "target 'project_name'\n  pod 'OneSignal', '>= 2.5.2', '< 3.0'\nend\n\ntarget 'OneSignalNotificationServiceExtension' do\n  pod 'OneSignal', '>= 2.5.2', '< 3.0'\nend",
      "language": "ruby",
      "name": "Podfile"
    }
  ]
}
[/block]
**2.5** Run the following from the terminal.
[block:code]
{
  "codes": [
    {
      "code": "pod repo update\npod install",
      "language": "c",
      "name": "Terminal"
    }
  ]
}
[/block]
**2.6** Open the newly created `.xcworkspace` file.<br>*Make sure to always open the workspace from now on.*
**2.7** Continue to Steps 3 and 4 below
<br>


Alternatively follow our [Carthage setup guide](doc:carthage-setup) instead if you can't use Cocoapods in your project.
<br>

----

### 3. Add Required Capabilities

**3.1** Select the root project and Under Capabilities Enable "Push Notifications".
**3.2** Next Enable "Background Modes" and check "Remote notifications".
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/VflTGOPzRDu2YmhiRgiV_Xcode%20capabilities.png",
        "Xcode capabilities.png",
        "961",
        "774",
        "#385e92",
        ""
      ],
      "sizing": "80"
    }
  ]
}
[/block]
----

### 4. Add Required Code
Add following OneSignal initialization code to your `AppDelegate`.
[block:code]
{
  "codes": [
    {
      "code": "import OneSignal\n\nfunc application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {\n\n   let onesignalInitSettings = [kOSSettingsKeyAutoPrompt: false]\n        \n   // Replace '11111111-2222-3333-4444-0123456789ab' with your OneSignal App ID.\n   OneSignal.initWithLaunchOptions(launchOptions,\n                                   appId: \"11111111-2222-3333-4444-0123456789ab\",\n                                   handleNotificationAction: nil, \n      \t\t\t\t\t\t\t\t\t\t\t\t\t\t settings: onesignalInitSettings)\n   \n   OneSignal.inFocusDisplayType = OSNotificationDisplayType.notification;\n   \n   // Recommend moving the below line to prompt for push after informing the user about\n   //   how your app will use them.\n   OneSignal.promptForPushNotifications(userResponse: { accepted in\n      print(\"User accepted notifications: \\(accepted)\")\n   })\n   \n  // Sync hashed email if you have a login system or collect it.\n  //   Will be used to reach the user at the most optimal time of day.\n  // OneSignal.syncHashedEmail(userEmail)\n   \n   return true\n}",
      "language": "swift",
      "name": "Swift (AppDelegate.swift)"
    },
    {
      "code": "#import <OneSignal/OneSignal.h>\n\n@implementation AppDelegate\n\n- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {\n    \n   // Replace '11111111-2222-3333-4444-0123456789ab' with your OneSignal App ID.\n   [OneSignal initWithLaunchOptions:launchOptions\n                              appId:@\"11111111-2222-3333-4444-0123456789ab\"\n   \t\t\t\t handleNotificationAction:nil\n                            settings:@{kOSSettingsKeyAutoPrompt: @false}];\n   OneSignal.inFocusDisplayType = OSNotificationDisplayTypeNotification;\n   \n   // Recommend moving the below line to prompt for push after informing the user about\n   //   how your app will use them.\n   [OneSignal promptForPushNotificationsWithUserResponse:^(BOOL accepted) {\n        NSLog(@\"User accepted notifications: %d\", accepted);\n   }];\n  \n  // Call syncHashedEmail anywhere in your iOS app if you have the user's email.\n  // This improves the effectiveness of OneSignal's \"best-time\" notification scheduling feature.\n  // [OneSignal syncHashedEmail:userEmail];\n    \n   return YES;\n}",
      "language": "objectivec",
      "name": "Objective-C (AppDelegate.m)"
    }
  ]
}
[/block]

[block:callout]
{
  "type": "warning",
  "body": "Make sure `OneSignal initWithLaunchOptions` is called from your `didFinishLaunchingWithOptions`."
}
[/block]

----

[block:callout]
{
  "type": "danger",
  "title": "Troubleshooting",
  "body": "* The Xcode simulator doesn't support push notifications so you must test on a real device.\n* If run into any issues please see our [iOS troubleshooting guide](https://documentation.onesignal.com/docs/troubleshooting-ios), or our general [Troubleshooting](doc:troubleshooting) section."
}
[/block]

----
## Optional: Callbacks

[OSHandleNotificationReceivedBlock](doc:ios-native-sdk#section--oshandlenotificationreceivedblock-) - Called when a notification is received while your app is in focus only.
[OSHandleNotificationActionBlock](doc:ios-native-sdk#section--oshandlenotificationactionblock-) - This will be called when a notification is tapped on.
See our [initWithLaunchOptions](doc:ios-native-sdk#section--initwithlaunchoptions-) documentation to add these.

----

## Optional: Custom notification sounds
Drag and drop the custom notification sounds you want available into the root of the XCode project.

Read more in [Customize Notification Sounds](doc:customize-notification-sounds) for information on file formats, differences between platforms, and how to send notifications with custom sounds.

----
[block:callout]
{
  "type": "info",
  "body": "* To see all available methods, see our [iOS Native SDK](doc:ios-native-sdk) documentation.\n* See our [example projects on Github](https://github.com/OneSignal/OneSignal-iOS-SDK/tree/master/Examples) for a full example.",
  "title": "Documentation"
}
[/block]
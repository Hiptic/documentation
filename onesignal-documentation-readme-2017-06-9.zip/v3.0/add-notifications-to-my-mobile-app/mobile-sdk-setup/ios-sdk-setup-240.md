---
title: "iOS SDK Setup 2.4.0"
excerpt: "<div class=\"tag-all tag-developers\">For Developers</div>"
---
### Before proceeding, you must [generate an iOS Push Certificate](doc:generate-an-ios-push-certificate).



### 1. Add Notification Service Extension
The following is required to support notifications with Action Buttons and Media attachments on iOS 10.

**1.1** Select `File` > `New` > `Target...`
**1.2** Select `Notification Service Extension` then press `Next`.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/74a6d44-Xcode_create_notification_service_extension_1.png",
        "Xcode_create_notification_service_extension_1.png",
        730,
        519,
        "#eff0f1"
      ]
    }
  ]
}
[/block]
**1.3** Enter the product name as `OneSignalNotificationServiceExtension` and press `Finish`.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/a99ed18-Xcode_create_notification_service_extension_2.png",
        "Xcode_create_notification_service_extension_2.png",
        730,
        518,
        "#f0f0f0"
      ]
    }
  ]
}
[/block]
**1.4** Open `NotificationService.m` or `NotificationService.swift` and replace the whole file contents with the below code.
[block:code]
{
  "codes": [
    {
      "code": "#import <OneSignal/OneSignal.h>\n\n#import \"NotificationService.h\"\n\n@interface NotificationService ()\n\n@property (nonatomic, strong) void (^contentHandler)(UNNotificationContent *contentToDeliver);\n@property (nonatomic, strong) UNNotificationRequest *recievedRequest;\n@property (nonatomic, strong) UNMutableNotificationContent *bestAttemptContent;\n\n@end\n\n@implementation NotificationService\n\n- (void)didReceiveNotificationRequest:(UNNotificationRequest *)request withContentHandler:(void (^)(UNNotificationContent * _Nonnull))contentHandler {\n    self.recievedRequest = request;\n    self.contentHandler = contentHandler;\n    self.bestAttemptContent = [request.content mutableCopy];\n    \n    [OneSignal didReceiveNotificatioExtensionnRequest:self.recievedRequest withMutableNotificationContent:self.bestAttemptContent];\n    \n    self.contentHandler(self.bestAttemptContent);\n}\n\n- (void)serviceExtensionTimeWillExpire {\n    // Called just before the extension will be terminated by the system.\n    // Use this as an opportunity to deliver your \"best attempt\" at modified content, otherwise the original push payload will be used.\n    \n    [OneSignal serviceExtensionTimeWillExpireRequest:self.recievedRequest withMutableNotificationContent:self.bestAttemptContent];\n    \n    self.contentHandler(self.bestAttemptContent);\n}\n\n@end",
      "language": "objectivec"
    },
    {
      "code": "import UserNotifications\n\nimport OneSignal\n\nclass NotificationService: UNNotificationServiceExtension {\n\n    var contentHandler: ((UNNotificationContent) -> Void)?\n    var recievedRequest: UNNotificationRequest!\n    var bestAttemptContent: UNMutableNotificationContent?\n\n    override func didReceive(_ request: UNNotificationRequest, withContentHandler contentHandler: @escaping (UNNotificationContent) -> Void) {\n        self.recievedRequest = request;\n        self.contentHandler = contentHandler\n        bestAttemptContent = (request.content.mutableCopy() as? UNMutableNotificationContent)\n        \n        if let bestAttemptContent = bestAttemptContent {\n            OneSignal.didReceiveNotificatioExtensionnRequest(self.recievedRequest, with: self.bestAttemptContent)\n            contentHandler(bestAttemptContent)\n        }\n    }\n    \n    override func serviceExtensionTimeWillExpire() {\n        // Called just before the extension will be terminated by the system.\n        // Use this as an opportunity to deliver your \"best attempt\" at modified content, otherwise the original push payload will be used.\n        if let contentHandler = contentHandler, let bestAttemptContent =  bestAttemptContent {\n            OneSignal.serviceExtensionTimeWillExpireRequest(self.recievedRequest, with: self.bestAttemptContent)\n            contentHandler(bestAttemptContent)\n        }\n    }\n\n}",
      "language": "swift"
    }
  ]
}
[/block]

----

### 2. Import OneSignal into your Xcode project

#### Option A: Use CocoaPods (Recommended)
[Setting up CocoaPods](http://guides.cocoapods.org/using/getting-started.html) on your system if you don't have it already.
   - Make sure you have version `1.1.0` or newer by running `pod --version` from the terminal.
   - Run the following to upgrade `sudo gem install cocoapods`
 
**2.1** Make sure your current Xcode project is closed.
**2.2** Run `pod init` from the terminal in your project directory.
**2.3** Open the newly created `Podfile` your favorite code editor such as Sublime.
**2.4** Under `target 'project_name' do` add `pod 'OneSignal', '~> 2.0'`. Example:
[block:code]
{
  "codes": [
    {
      "code": "target 'project_name' # Don't copy this line\n  # Add the line below.\n  pod 'OneSignal', '~> 2.0'\nend",
      "language": "ruby",
      "name": "Podfile"
    }
  ]
}
[/block]
**2.5** At the bottom of the `Podfile` add the following.
[block:code]
{
  "codes": [
    {
      "code": "target 'OneSignalNotificationServiceExtension' do\n  pod 'OneSignal', '~> 2.0'\nend",
      "language": "ruby",
      "name": "Podfile"
    }
  ]
}
[/block]
**2.6** Run the following from the terminal.
[block:code]
{
  "codes": [
    {
      "code": "pod repo update\npod install",
      "language": "c",
      "name": "Terminal"
    }
  ]
}
[/block]
**2.7** Open the newly created `.xcworkspace` file.<br>*Make sure to always open the workspace from now on.*
**2.8** Continue to Steps 3 and 4 below
<br>
 **-- OR --**
<br>
#### Option B: Use Carthage
You can also use [Carthage](https://github.com/Carthage/Carthage#installing-carthage) for setting up and upgrading the OneSignal SDK.

**2.1** Make sure your current Xcode project is closed.
**2.2** Run `echo 'github "OneSignal/OneSignal-iOS-SDK"' >> Cartfile`
**2.3** Run `carthage update`.
**2.4** Open your Xcode project.
**2.5** On your application targets’ “General” settings tab, in the “Linked Frameworks and Libraries” section, drag and drop `OneSignal.framework` from the `$(PROJECT_DIR)/Carthage/Build/iOS` folder on disk.
**2.6** On your application targets’ “Build Phases” settings tab, click the “+” icon and choose “New Run Script Phase”. Create a Run Script in which you specify your shell (ex: `bin/sh`), add the following contents to the script area below the shell:
`/usr/local/bin/carthage copy-frameworks`
**2.7** add the path to the `OneSignal` framework under “Input Files”:
`$(SRCROOT)/Carthage/Build/iOS/OneSignal.framework`
**2.8** Continue to Steps 2 and 3 below

----
### 3. Add Required Capabilities

**3.1** Select the root project and Under Capabilities Enable "Push Notifications".
**3.2** Next Enable "Background Modes" and check "Remote notifications".
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/VflTGOPzRDu2YmhiRgiV_Xcode%20capabilities.png",
        "Xcode capabilities.png",
        "961",
        "774",
        "#385e92",
        ""
      ],
      "sizing": "80"
    }
  ]
}
[/block]
----

### 4. Add Required Code
Add following OneSignal initialization code to your `AppDelegate`.
[block:code]
{
  "codes": [
    {
      "code": "#import <OneSignal/OneSignal.h>\n\n@implementation AppDelegate\n\n- (BOOL)application:(UIApplication*)application didFinishLaunchingWithOptions:(NSDictionary*)launchOptions {\n    \n  //Add this line. Replace '5eb5a37e-b458-11e3-ac11-000c2940e62c' with your OneSignal App ID.\n   [OneSignal initWithLaunchOptions:launchOptions\n                              appId:@\"5eb5a37e-b458-11e3-ac11-000c2940e62c\"];\n  \n  // Call syncHashedEmail anywhere in your iOS app if you have the user's email.\n  // This improves the effectiveness of OneSignal's \"best-time\" notification scheduling feature.\n  // [OneSignal syncHashedEmail:userEmail];\n    \n   return YES;\n}",
      "language": "objectivec",
      "name": "Objective-C (AppDelegate.m)"
    },
    {
      "code": "import OneSignal\n\nfunc application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {\n        \n   //Add this line. Replace '5eb5a37e-b458-11e3-ac11-000c2940e62c' with your OneSignal App ID.\n   OneSignal.initWithLaunchOptions(launchOptions, appId: \"5eb5a37e-b458-11e3-ac11-000c2940e62c\")\n   \n  // Sync hashed email if you have a login system or collect it.\n  //   Will be used to reach the user at the most optimal time of day.\n  // OneSignal.syncHashedEmail(userEmail)\n   \n   return true\n}",
      "language": "swift",
      "name": "Swift (AppDelegate.swift)"
    }
  ]
}
[/block]

[block:callout]
{
  "type": "warning",
  "body": "Make sure `OneSignal initWithLaunchOptions` is called from your `didFinishLaunchingWithOptions`."
}
[/block]

----

[block:callout]
{
  "type": "success",
  "title": "",
  "body": "Done! The Xcode simulator doesn't support push notifications so you must test on a real device."
}
[/block]

----
## Optional: Callbacks

[OSHandleNotificationReceivedBlock](doc:ios-native-sdk#section--oshandlenotificationreceivedblock-) - This will be called when a notification is tapped on.
See our [initWithLaunchOptions](doc:ios-native-sdk#section--initwithlaunchoptions-) documentation to add one.

[OSHandleNotificationActionBlock](doc:ios-native-sdk#section--oshandlenotificationactionblock-) - This will be called when a notification is received while your app is running.
See our [initWithLaunchOptions](doc:ios-native-sdk#section--initwithlaunchoptions-) documentation to add one.

----
## Optional: Custom notification sounds
Drag and drop the custom notification sounds you want available into the root of the XCode project.

Read more in [Customize Notification Sounds](doc:customize-notification-sounds) for information on file formats, differences between platforms, and how to send notifications with custom sounds.

----
[block:callout]
{
  "type": "danger",
  "title": "Troubleshooting",
  "body": "If run into any issues please see our [iOS troubleshooting guide](https://documentation.onesignal.com/docs/troubleshooting-ios), or our general [Troubleshooting](doc:troubleshooting) section."
}
[/block]

[block:callout]
{
  "type": "info",
  "body": "To see all available methods, see our [iOS Native SDK](doc:ios-native-sdk) documentation.",
  "title": "Additional Documentation"
}
[/block]
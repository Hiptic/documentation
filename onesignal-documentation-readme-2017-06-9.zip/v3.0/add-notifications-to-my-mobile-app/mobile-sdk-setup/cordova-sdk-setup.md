---
title: "Cordova SDK Setup"
excerpt: "OneSignal Cordova SDK Setup Guide. Works with <span class=\"label-all label-ios\">iOS</span>, <span class=\"label-all label-android\">Android</span> (and derivatives like <span class=\"label-all label-amazon\">Amazon</span>) and <span class=\"label-all label-windows\">Windows Phone 8.1</span>.\n<div class=\"tag-all tag-developers\">For Developers</div>"
---
## Update SDK
If you already have an app with the Cordova SDK, you can run this to ensure your SDK is on the latest version:
[block:code]
{
  "codes": [
    {
      "code": "cordova plugin update onesignal-cordova-plugin",
      "language": "shell"
    }
  ]
}
[/block]
If you have not set up an app yet, follow the instructions below.

----

## Setup SDK
### Generate Credentials
Before setting up the Cordova SDK, you must generate the appropriate credentials for the platform(s) you are releasing on:

<span class="label-all label-ios">iOS</span> - [Generate an iOS Push Certificate](doc:generate-an-ios-push-certificate) 

<span class="label-all label-android">Android</span> - [Generate a Google Server API Key](doc:generate-a-google-server-api-key) 

<span class="label-all label-amazon">Amazon</span> - [Generate an Amazon API Key](doc:generate-an-amazon-api-key) 

<span class="label-all label-windows">Windows Phone 8.1</span> - [Generate a Windows Phone Package SID and Secret](doc:generate-a-windows-phone-package-sid-and-secret) 

---

## iOS Requirements
**iOS Platform 4.3.0 or newer**
**[CocoaPods](https://cocoapods.org/)** - Install with the following from the terminal.

[block:code]
{
  "codes": [
    {
      "code": "sudo gem install cocoapods\npod repo update",
      "language": "shell"
    }
  ]
}
[/block]
---

### 1. Import OneSignal Plugin
***Requires Cordova 6.4.0 or newer***

*Please follow step 1A or 1B based how you build your app.*

You should also remove other Push SDKs that you are not using, otherwise you may see duplicate notifications.

#### 1A. Import from the Terminal
Run the following from your project directory.
[block:code]
{
  "codes": [
    {
      "code": "cordova plugin add onesignal-cordova-plugin --save",
      "language": "shell",
      "name": "Cordova"
    }
  ]
}
[/block]
*-- OR --*

#### 1B. Visual Studio

**1.** Open your project's `config.xml` and select Platforms. Make sure you have Cordova CLI 6.4.0 or higher.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/NJSVHqOoSdWLKoI7C1Vn_VSCordovaVersion.png",
        "VSCordovaVersion.png",
        "894",
        "224",
        "#2e537f",
        ""
      ]
    }
  ]
}
[/block]
**2.** Right click on `config.xml` and select "View Code".
**3.** Add the following to the file:
[block:code]
{
  "codes": [
    {
      "code": "  <vs:features>\n    <vs:feature>onesignal-cordova-plugin</vs:feature>\n  </vs:features>",
      "language": "xml"
    }
  ]
}
[/block]

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/PbYr1oAeTuS98pXIXgqW_VSCordovaAddOneSignal.png",
        "VSCordovaAddOneSignal.png",
        "838",
        "312",
        "#2f4d92",
        ""
      ]
    }
  ]
}
[/block]

### 2. Add required code
**2.1.** Add the following to the bottom of the first javascript file that loads with your app.
- This is `<project-dir>/www/js/index.js` for most Cordova projects.
[block:code]
{
  "codes": [
    {
      "code": "// Add to index.js or the first page that loads with your app.\n// For Intel XDK and please add this to your app.js.\n\ndocument.addEventListener('deviceready', function () {\n  // Enable to debug issues.\n  // window.plugins.OneSignal.setLogLevel({logLevel: 4, visualLevel: 4});\n  \n  var notificationOpenedCallback = function(jsonData) {\n    console.log('notificationOpenedCallback: ' + JSON.stringify(jsonData));\n  };\n\n  window.plugins.OneSignal\n    .startInit(\"YOUR_APPID\")\n    .handleNotificationOpened(notificationOpenedCallback)\n    .endInit();\n  \n  // Call syncHashedEmail anywhere in your app if you have the user's email.\n  // This improves the effectiveness of OneSignal's \"best-time\" notification scheduling feature.\n  // window.plugins.OneSignal.syncHashedEmail(userEmail);\n}, false);",
      "language": "javascript",
      "name": "Cordova"
    }
  ]
}
[/block]
**2.2 ** Update initialization parameters 

Replace `YOUR_APPID` with your OneSignal AppId, available in <a class="dash-link" href="/docs/accounts-and-keys#section-keys-ids">Keys & IDs</a>

### 3. Android

**3.1 ** Open the Android SDK Manager.

**3.2 ** Make sure to install and update the following under Extras:

- Android Support **Repository**
- Google **Repository**
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/cfbZBwxSmeToNEbZJoz0_AndroidSDKGoogleRepository.png",
        "AndroidSDKGoogleRepository.png",
        "600",
        "341",
        "#c7413e",
        ""
      ]
    }
  ]
}
[/block]

**3.3 ** Follow the [Customize Notification Icons](doc:customize-notification-icons) instructions to create a small notification icon required for Android 5.0+ devices.

### 4. Amazon ADM

Place your `api_key.txt` file into your `<project-dir>/platforms/android/assets/` folder.

*To create an `api_key.txt` for your app follow our [Generate an Amazon API Key](doc:generate-an-amazon-api-key)*

### 5. iOS - Part 1 (Required)

**5.0** Open `<project-root>/platform/ios/YourAppName.xcworkspace`
**5.1** Select the root project and Under Capabilities Enable "Push Notifications".
**5.2** Next Enable "Background Modes" and check "Remote notifications".
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/b80f76b-Xcode_capabilities.png",
        "Xcode capabilities.png",
        961,
        774,
        "#f0f0f0"
      ]
    }
  ]
}
[/block]
### 5. iOS - Part 2 (Recommend)

**5.3** To support Action Buttons and Media Attachments on iOS 10 please follow the [Notification Service Extension](doc:ios-sdk-setup#section-1-add-notification-service-extension-recommend-) guide (Only steps 1.1 to 1.5). Make sure to use Objective-C on this step then come back to this page and continue following the steps below.

**5.4** Select the new `OneSignalNotificationServiceExtension` Target, select "Build Settings" then search for `Code Signing Entitlements`.

**5.5** Delete both Debug and Release entries so they are blank.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/34e20b1-Cordova_-_iOS_-_Remove_Code_Signing_entitlements.png",
        "Cordova - iOS - Remove Code Signing entitlements.png",
        1310,
        453,
        "#ebebea"
      ]
    }
  ]
}
[/block]
**5.6** Select `Build Phases` and expanded the`"Link Binary With Libraries"` section.
**5.7** Press the `+` and add `SystemConfiguration.framework` and `UIKit.framework`.
**5.8** Drag and drop `Pods/Pods/OneSignal/Frameworks/OneSignal.framework` from the view on the left to this section as well.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/1892ef3-Cordova_-_iOS_-_Add_Frameworks_to_target.png",
        "Cordova - iOS - Add Frameworks to target.png",
        960,
        567,
        "#ebebea"
      ]
    }
  ]
}
[/block]
### 6. Windows Phone 8.1 (WP8.1)

*Your app does not have to be published however, you must have it created on the Windows Dev Center. Follow our [Windows Phone Project SID & Secret](generate-a-windows-phone-package-sid-and-secret) setup if you have not done this yet.*

**6.1** Run `cordova build windows` and open the .sln in <project-root>/platforms/windows/

**6.2** Under the Windows Phone 8.1 project double click on `Package.appxmanifest` then select the "Application" tab and scroll down to the "Notifications:" section. Change "Toast capable:" to Yes.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/0eX5aHISfWQhNWmLJGoJ_WindowPhone8.1_SDK_2.1.png",
        "WindowPhone8.1_SDK_2.1.png",
        "851",
        "282",
        "#384868",
        ""
      ]
    }
  ]
}
[/block]
**6.3** Right click on your VS project and select Store>Associate App with the Store...
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/tKhdtb2jQdSMnHskkysn_WindowPhone8.1__SDK_1.1.png",
        "WindowPhone8.1__SDK_1.1.png",
        "714",
        "510",
        "#2f4363",
        ""
      ]
    }
  ]
}
[/block]
**6.4** Click Next and sign into your Microsoft account.

**6.5** Select your app and press Next.

**6.6.** Lastly press Associate.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/mUHzdp7SlyXIpWn71Y6Q_WindowPhone8.1_SDK_4.3.png",
        "WindowPhone8.1_SDK_4.3.png",
        "786",
        "643",
        "#3489da",
        ""
      ]
    }
  ]
}
[/block]
----
[block:callout]
{
  "type": "danger",
  "title": "Troubleshooting",
  "body": "If you run into any errors see [Troubleshooting Cordova Variants](doc:troubleshooting-cordova-variants), our our general [Troubleshooting](doc:troubleshooting) section."
}
[/block]

[block:callout]
{
  "type": "warning",
  "title": "Push Notification Testing Requirements",
  "body": "* *iOS* - Must test on a real device, Simulator does not support Apple push notifications.\n* *Android*\n   * You **MUST** build and install your app's APK. \n   * You may use an emulator but it must have an updated version of Google Play services installed."
}
[/block]

[block:callout]
{
  "type": "info",
  "body": "* Check out our [Cordova SDK](doc:cordova-sdk) for more OneSignal functions.\n* See our [Cordova Example Project](https://github.com/OneSignal/OneSignal-Cordova-Example) for more help.",
  "title": "Documentation"
}
[/block]
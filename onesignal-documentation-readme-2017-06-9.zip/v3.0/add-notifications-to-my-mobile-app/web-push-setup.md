---
title: "Web Push Setup"
excerpt: "Getting started with web push notifications\n<div class=\"tag-all tag-developers\">For Developers</div> <div class=\"tag-all tag-marketers\">For Marketers</div>"
---
[block:html]
{
  "html": "<style>\n  #content-container .content-body.grid-75 { width:100%; }\n  #content-container #content-toc.grid-25 { width:0%; display:none; }\n</style>"
}
[/block]
### If you're already familiar with Web Push and want to dive right in, [click here to get started.](doc:web-push-setup#section-get-started)

----
##What are Web Push Notifications or Browser Push Notifications?

Web push notifications are messages that come from a website. You get them on your desktop or device even when the website is not open in your browser. It is a new marketing channel to re engage your site visitors without knowing their email or other contact details.

----
## Platform Support

Safari 7.0.3 (With a market share of 5-7%) was the first to provide support for web push. It was followed by Chrome 42 (market share 40-50% and growing) that provided support for both desktop and android. Mozilla Firefox (market share 16-20%) launched support for web push in January 26, 2016 starting with v44.

See the table below for a detailed list of browser support.
[block:parameters]
{
  "data": {
    "h-0": "Browser",
    "h-1": "Windows PC",
    "h-2": "macOS",
    "h-3": "Android",
    "h-4": "iPhone",
    "h-5": "Windows Phone 8.1",
    "h-6": "Other",
    "0-0": "Chrome",
    "3-0": "Firefox",
    "4-0": "Safari",
    "5-0": "Microsoft Edge",
    "6-0": "Opera",
    "8-0": "[Intel XDK](doc:intel-xdk-setup)",
    "9-0": "[React Native](doc:react-native-sdk-setup)",
    "11-0": "[Cocos2d-x](doc:cocos2d-x-sdk-setup)",
    "10-0": "[Corona](doc:corona-sdk-setup)",
    "12-0": "[Marmalade](doc:marmalade-sdk-setup)",
    "13-0": "[Adobe Air](doc:adobe-air-sdk-setup)",
    "14-0": "[Xamarin](doc:xamarin-sdk-setup)",
    "0-1": "<span class=\"label-all label-yes\">Yes</span>",
    "0-2": "<span class=\"label-all label-yes\">Yes</span>",
    "0-3": "<span class=\"label-all label-yes\">Yes</span>",
    "0-4": "<span class=\"label-all label-no\">No</span>",
    "0-5": "<span class=\"label-all label-yes\">[Yes](doc:windows-phone-sdk-setup)</span>",
    "3-1": "<span class=\"label-all label-yes\">Yes</span>",
    "3-2": "<span class=\"label-all label-yes\">Yes</span>",
    "3-3": "<span class=\"label-all label-yes\">Yes</span>",
    "4-1": "<span class=\"label-all label-no\">No</span>",
    "4-2": "<span class=\"label-all label-yes\">Yes</span>",
    "4-3": "<span class=\"label-all label-no\">N/A</span>",
    "5-1": "<span class=\"label-all label-yes\">Coming Soon**</span>",
    "5-2": "<span class=\"label-all label-no\">N/A</span>",
    "5-3": "<span class=\"label-all label-no\">N/A</span>",
    "6-3": "<span class=\"label-all label-yes\">Yes</span>",
    "6-2": "<span class=\"label-all label-yes\">Yes</span>",
    "6-1": "<span class=\"label-all label-yes\">Yes</span>",
    "8-1": "<span class=\"label-all label-yes\">Yes</span>",
    "8-2": "<span class=\"label-all label-yes\">Yes</span>",
    "8-3": "<span class=\"label-all label-yes\">Yes</span>",
    "9-1": "<span class=\"label-all label-yes\">Yes</span>",
    "9-2": "<span class=\"label-all label-yes\">Yes</span>",
    "9-3": "<span class=\"label-all label-yes\">Yes</span>",
    "10-1": "<span class=\"label-all label-yes\">Yes</span>",
    "10-2": "<span class=\"label-all label-yes\">Yes</span>",
    "4-5": "<span class=\"label-all label-yes\">Yes</span>",
    "5-5": "<span class=\"label-all label-yes\">Yes</span>",
    "6-5": "<span class=\"label-all label-yes\">Yes</span>",
    "8-5": "<span class=\"label-all label-yes\">Yes</span>",
    "10-3": "<span class=\"label-all label-yes\">Yes</span>",
    "11-1": "<span class=\"label-all label-yes\">Yes</span>",
    "11-2": "<span class=\"label-all label-yes\">Yes</span>",
    "12-1": "<span class=\"label-all label-yes\">Yes</span>",
    "12-2": "<span class=\"label-all label-yes\">Yes</span>",
    "11-3": "<span class=\"label-all label-yes\">Yes</span>",
    "12-3": "<span class=\"label-all label-yes\">Yes</span>",
    "13-1": "<span class=\"label-all label-yes\">Yes</span>",
    "13-2": "<span class=\"label-all label-yes\">Yes</span>",
    "14-2": "<span class=\"label-all label-yes\">Yes</span>",
    "14-3": "<span class=\"label-all label-yes\">Yes</span>",
    "14-1": "<span class=\"label-all label-yes\">Yes</span>",
    "3-5": "<span class=\"label-all label-yes\">Yes</span>",
    "3-4": "<span class=\"label-all label-no\">No</span>",
    "4-4": "<span class=\"label-all label-no\">No</span>",
    "5-4": "<span class=\"label-all label-no\">N/A</span>",
    "6-4": "<span class=\"label-all label-no\">No</span>",
    "8-4": "<span class=\"label-all label-no\">No</span>",
    "9-4": "<span class=\"label-all label-no\">No</span>",
    "10-4": "<span class=\"label-all label-no\">No</span>",
    "11-4": "<span class=\"label-all label-no\">No</span>",
    "12-4": "<span class=\"label-all label-yes\">Yes</span>",
    "13-4": "<span class=\"label-all label-no\">No</span>",
    "14-4": "<span class=\"label-all label-no\">No</span>",
    "9-5": "<span class=\"label-all label-no\">No</span>",
    "10-5": "<span class=\"label-all label-no\">No</span>",
    "11-5": "<span class=\"label-all label-no\">No</span>",
    "12-5": "<span class=\"label-all label-yes\">Yes</span>",
    "13-5": "<span class=\"label-all label-no\">No</span>",
    "14-5": "<span class=\"label-all label-no\">No</span>",
    "13-3": "<span class=\"label-all label-no\">No</span>",
    "7-0": "UC Browser",
    "7-1": "<span class=\"label-all label-no\">No</span>",
    "7-2": "<span class=\"label-all label-no\">N/A</span>",
    "7-3": "<span class=\"label-all label-no\">No</span>",
    "7-4": "<span class=\"label-all label-no\">No</span>",
    "1-0": "Yandex",
    "1-1": "<span class=\"label-all label-yes\">Yes</span>",
    "1-2": "<span class=\"label-all label-yes\">Yes</span>",
    "1-3": "<span class=\"label-all label-yes\">Yes</span>",
    "2-0": "Samsung Internet Browser",
    "2-1": "<span class=\"label-all label-no\">N/A</span>",
    "2-2": "<span class=\"label-all label-no\">N/A</span>",
    "2-3": "<span class=\"label-all label-yes\">Yes (4.0+)</span>",
    "2-4": "<span class=\"label-all label-no\">N/A</span>",
    "1-4": "<span class=\"label-all label-no\">N/A</span>"
  },
  "cols": 5,
  "rows": 8
}
[/block]
**Note**: Incognito / Private Browsing mode isn't supported in browsers.
**Note 2**: Edge supports local notifications but not Web Push. See their [progress status](https://developer.microsoft.com/en-us/microsoft-edge/platform/status/pushapi/)

----
### Why should you use Web Push Notifications – what are the advantages?

**No need to have a mobile app to get the benefit of mobile push notifications: **
*Web push notifications work exactly like the native mobile push. So, you don’t have to create a mobile app just to get the benefit of native push notifications on mobile.*

**Wider reach across browsers:** 
*Safari, Chrome and Firefox when combined have a market share of about 61-77%. With these browsers providing support for web push the reach of web push notifications is immense.
*
**Access to users who are not on your website:**
*Using web push notifications, you can reach out to those users who are not on your website*

**Ability to re-engage users without knowing their contact details:**
*Web push notifications don’t need a user’s email or other contact details.
*
**Higher opt-ins as compared to emails:**
*Since users don’t need to give their email id or other contact details and they also have the ability to unsubscribe from receiving notification easily whenever they want, the opt-ins for web push notifications are higher than emails.
*
**Lower unsubscribe / opt-out rates:**
*Studies have shown that less than 10% of the subscribers who opted for notifications from a site, unsubscribed in a year.*

**Prompt and assured content delivery:**
*The moment you click on “send notification now”, it will be delivered to the users immediately. Unlike emails that sometimes fail to deliver or go to spam folder, these notifications are for sure delivered to the user.*

**Higher conversion rates:**
*Studies have shown that web push notifications have 30 times higher conversion when compared with mail.*

**Greater mindshare of users:**
*Sending notifications even when the users are not on your website, helps you capture their mindshare and then as the saying goes market share follows!*

**Tech savvy user base:**
*Since this is a nascent technology, it is safe to assume that your content will reach to the most tech savvy user base.*

----
## Get Started
Follow select our SDK installation guide for your platform:
  - [Wordpress](doc:wordpress) 
  - [Weebly](doc:weebly)
  - [Blogger](doc:blogger) 
  - [Shopify](doc:shopify) 
  - [Drupal](doc:drupal) 
  - [Shopify](doc:shopify) 
  - [Squarespace](doc:squarespace) 
  - [Website on http:// URL](doc:web-push-sdk-setup-http) 
  - [Website on https:// URL](doc:web-push-sdk-setup-https). Website must be fully-HTTPS.

----
## Is my site fully HTTPS?
Which setup guide to follow depends on whether your site fully supports HTTPS or not. You can determine whether your site fully supports HTTPS by looking for the following:

- My site begins with `https://`, and display a green lock icon on the browser's address bar
- My site forcefully redirects all `http://` requests to `https://` requests. In other words, users accessing the site via HTTP will be redirected to the HTTPS version. 

<span class="label-all label-yes">My Site fully supports HTTPS</span> - follow the [Web Push SDK Setup (HTTPS)](doc:web-push-sdk-setup-https) guide.

<span class="label-all label-no">My site DOES NOT fully support HTTPS</span> - follow the [Web Push SDK Setup (HTTP)](doc:web-push-sdk-setup-http) guide.
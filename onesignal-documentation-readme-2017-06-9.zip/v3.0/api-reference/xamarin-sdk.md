---
title: "Xamarin SDK"
excerpt: ""
---
[block:callout]
{
  "type": "info",
  "title": "Just starting with Xamarin?",
  "body": "Check out our [Xamarin SDK Setup guide](doc:xamarin-sdk-setup)."
}
[/block]

[block:parameters]
{
  "data": {
    "0-0": "### Initialization",
    "0-1": "",
    "3-0": "[Settings](#section--settings-)",
    "3-1": "Method",
    "h-2": "",
    "0-2": "",
    "3-2": "<span class=\"label-all label-ios\">iOS</span> - Automatically Prompt Users to Enable Notifications and Open all URLs in In-App Safari Window",
    "h-0": "",
    "1-0": "[StartInit](#section--startinit-)",
    "1-1": "Method",
    "1-2": "Initialize OneSignal",
    "5-0": "### Registering Push",
    "6-0": "[RegisterForPushNotifications](#section--registerforpushnotifications-)",
    "7-0": "### User IDs",
    "8-0": "[IdsAvailable](#section--idsavailable-)",
    "8-1": "Method",
    "8-2": "Get the User ID of the device",
    "9-0": "[IdsAvailableCallback](#section--idsavailablecallback-)",
    "9-1": "Delegate",
    "9-2": "",
    "10-0": "### Tags",
    "11-0": "[getTags](#section--gettags-)",
    "11-1": "Method",
    "14-1": "Method",
    "15-1": "Method",
    "16-1": "Method",
    "11-2": "View Tags from a User",
    "14-2": "",
    "16-2": "",
    "15-2": "Delete a Tag from a User",
    "14-0": "[sendTags](#section--sendtags-)",
    "15-0": "[deleteTag](#section--deletetag-)",
    "16-0": "[deleteTags](#section--deletetags-)",
    "17-0": "### Data",
    "20-0": "### Sending Notifications",
    "25-0": "### Receiving Notifications",
    "21-0": "[postNotification](#section--postnotification-)",
    "22-0": "[cancelNotification](#section--cancelnotification-)",
    "23-0": "[clearOneSignalNotifications](#section--clearonesignalnotifications-)",
    "24-0": "[setSubscription](#section--setsubscription-)",
    "24-1": "Method",
    "23-1": "Method",
    "21-1": "Method",
    "22-1": "Method",
    "31-0": "[OSNotification](#section--osnotification-)",
    "31-1": "Class",
    "33-0": "[OSNotificationPayload](#section--osnotificationpayload-)",
    "33-1": "Class",
    "34-0": "### Appearance",
    "35-0": "[enableVibrate](#section--enablevibrate-)",
    "36-0": "[enableSound](#section--enablesound-)",
    "35-1": "Method",
    "36-1": "Method",
    "37-0": "### Debug",
    "38-0": "[setLogLevel](#section--setloglevel-)",
    "38-1": "Method",
    "19-1": "Method",
    "19-0": "[syncHashedEmail](#section--synchashedemail-)",
    "18-0": "[promptLocation](#section--promptlocation-)",
    "18-1": "Method",
    "18-2": "Prompt Users for Location",
    "19-2": "Sync Anonymized User Email",
    "21-2": "Send or schedule a notification to a user",
    "22-2": "Delete a single app notification",
    "24-2": "Opt users in or out of receiving notifications",
    "23-2": "Delete all app notifications",
    "33-2": "Data that comes with a notification",
    "31-2": "",
    "35-2": "<span class=\"label-all label-android\">Android</span> - When user receives notification, vibrate device less",
    "36-2": "<span class=\"label-all label-android\">Android</span> - When user receives notification, do not play a sound",
    "38-2": "Enable logging to help debug OneSignal implementation",
    "13-0": "[sendTag](#section--sendtag-)",
    "13-1": "Method",
    "13-2": "Add a Tag to a User",
    "12-0": "[TagsReceived](#section--tagsreceived-)",
    "12-1": "Delegate",
    "12-2": "",
    "32-0": "[OSNotificationAction](#section--osnotificationaction-)",
    "32-1": "Class",
    "32-2": "",
    "6-2": "Prompt Users to Enable Notifications",
    "26-0": "[NotificationReceived](#section--notificationreceived-)",
    "26-1": "Method",
    "29-0": "[HandleNotificationOpened](#section--handlenotificationopened-)",
    "29-1": "Delegate",
    "26-2": "When a notification is received by a device",
    "29-2": "",
    "27-0": "[HandleNotificationReceived](#section--handlenotificationreceived-)",
    "27-1": "Delegate",
    "28-0": "[NotificationOpened](#section--notificationopened-)",
    "28-1": "Method",
    "28-2": "When a user takes an action on a notification",
    "2-0": "[inFocusDisplaying](#section--infocusdisplaying-)",
    "2-1": "Method",
    "2-2": "<span class=\"label-all label-android\">Android</span>, <span class=\"label-all label-ios\">iOS</span> - Automatically Display Notifications when app is in focus",
    "6-1": "Method",
    "4-0": "[EndInit](#section--endinit-)",
    "4-1": "Method",
    "30-0": "[OSNotificationOpenedResult](#section--osnotificationopenedresult-)",
    "30-1": "Class",
    "30-2": "Information returned from a notification the user received."
  },
  "cols": 3,
  "rows": 39
}
[/block]
## Initialization

### `StartInit`
<div class="label-all label-type">Method</div>

Starts initialization of OneSignal, call this from your `FinishedLaunching`(iOS) or your `OnCreate`(Android) method.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`appId`",
    "0-1": "String",
    "0-2": "<p><span class=\"label-all label-required\">Required</span> Your OneSignal app id from <a class=\"dash-link\" href=\"/docs/accounts-and-keys#section-keys-ids\">Keys & IDs</a>.</p><p>Example: `b2f7f966-d8cc-11e4-bed1-df8f05be55ba`</p>"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.Current.StartInit(\"YOUR_APP_ID\").EndInit();",
      "language": "csharp"
    }
  ]
}
[/block]

### `inFocusDisplaying`
<div class="label-all label-type">Method - <span class="label-all label-android">Android</span> &middot; <span class="label-all label-ios">iOS</span></div>

Setting to control how OneSignal notifications will be shown when one is received while your app is in focus. 

`Notification` - <span class="label-all label-android">Android</span> <span class="label-all label-ios">iOS 10+</span> native notification display while user has app in focus (can be distracting).
`InAppAlert` (<span class="label-all label-default">Default</span>) - native alert dialog display, which can be helpful during development.
`None` - notification is silent.

If your app only sends `notification` and your deployment target is <span class="label-all label-ios">iOS 9 or below</span>, your app will default to `inAppAlert`.
[block:callout]
{
  "type": "warning",
  "body": "We recommend you set this to `none` prior to launching your app, so users do not get interrupted while using your app.",
  "title": "Disable Before Launch"
}
[/block]
### Settings
<div class="label-all label-type">Method</div>

Settings that can be passed into the initialization chaining method. 

Settings key options are:
- `IOSSettings.kOSSettingsKeyAutoPrompt` - Auto prompt user for notification permissions.
- `IOSSettings.kOSSettingsKeyInAppLaunchURL` - Launch notifications with a launch URL as an in app webview.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`settings`",
    "0-1": "Dictionary<string, bool>",
    "0-2": "Additional initialization settings. Set `true` or `false`."
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.Current.StartInit(\"b2f7f966-d8cc-11e4-bed1-df8f05be55ba\")\n  .Settings(new Dictionary<string, bool>() {\n    { IOSSettings.kOSSettingsKeyAutoPrompt, true },\n    { IOSSettings.kOSSettingsKeyInAppLaunchURL, true } })\n  .EndInit();",
      "language": "csharp"
    }
  ]
}
[/block]
### `EndInit`
Must be called after StartInit to complete initialization of OneSignal. See [StartInit](#section--startinit-) example above.


## Registering Push

### `RegisterForPushNotifications`
<div class="label-all label-type">Method - <span class="label-all label-ios">iOS</span></div>

Call this when you would like to prompt an iOS user to accept push notifications with the default system prompt. Only use if you passed false to autoRegister when calling Init.
[block:code]
{
  "codes": [
    {
      "code": "OneSignal.Current.RegisterForPushNotifications();",
      "language": "csharp"
    }
  ]
}
[/block]
## User IDs

### `IdsAvailableCallback`
<div class="label-all label-type">Delegate</div>

Delegate you can define to get the OneSignal userId and Google registration Id or an iOS push token.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "0-0": "`userId`",
    "1-0": "`pushToken`",
    "0-1": "String",
    "1-1": "String",
    "0-2": "OneSignal userId is a UUID formatted string. (_unique per device per app_)",
    "1-2": "Either a Google registration Id or an iOS push token identifier(_unique per device per app_). _NOTE:_ Might be blank if push notifications are not accepted on iOS, Google Play services are not installed, or from a connection issue.",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 2
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "private void IdsAvailable(string userID, string pushToken) {\n\t\tprint(\"UserID:\"  + userID);\n\t\tprint(\"pushToken:\" + pushToken);\n\t}",
      "language": "csharp"
    }
  ]
}
[/block]
### `IdsAvailable`
<div class="label-all label-type">Method</div>

Lets you retrieve the OneSignal player id and push token. Your delegate is called after the device is successfully registered with OneSignal. If the device has already successfully registered, the delegate will be called immediately.
[block:parameters]
{
  "data": {
    "0-0": "`inIdsAvailableDelegate`",
    "0-1": "IdsAvailableCallback",
    "0-2": "Calls the delegate when the player id is available.",
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "void SomeMethod() {\n\t\tOneSignal.Current.IdsAvailable(IdsAvailable);\n\t}\n\n\tprivate void IdsAvailable(string userID, string pushToken) {\n\t\tprint(\"UserID:\"  + userID);\n\t\tprint(\"pushToken:\" + pushToken);\n\t}",
      "language": "csharp"
    }
  ]
}
[/block]
## Tags

### `GetTags`
<div class="label-all label-type">Method</div>

Retrieve a list of tags that have been set on the player from the OneSignal server.
[block:parameters]
{
  "data": {
    "0-0": "`inTagsReceivedDelegate`",
    "0-1": "TagsReceived",
    "0-2": "Delegate gets called once the tags are available.",
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "void SomeMethod() {\n\t\tOneSignal.GetTags(TagsReceived);\n\t}\n\n\tprivate void TagsReceived(Dictionary<string, object> tags) {\n\t\tforeach (var tag in tags)\n\t\t\tprint(tag.Key + \":\" + tag.Value);\n\t}",
      "language": "csharp"
    }
  ]
}
[/block]
### `TagsReceived`
<div class="label-all label-type">Delegate</div>

Delegate you can define to get the all the tags set on a player from onesignal.com.
[block:parameters]
{
  "data": {
    "0-0": "`tags`",
    "0-1": "Dictionary<string, object>",
    "0-2": "Dictionary of key value pairs retrieved from the OneSignal server.",
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "private static void TagsReceived(Dictionary<string, object> tags) {\n\t\tforeach (var tag in tags)\n\t\t\tprint(tag.Key + \":\" + tag.Value);\n\t}",
      "language": "csharp"
    }
  ]
}
[/block]
### `SendTag`
<div class="label-all label-type">Method</div>

Tag a player based on a game event of your choosing so later you can create segments on [onesignal.com](https://onesignal.com) to target these players. If you need to set more than one key at a time please use `SendTags` instead.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "0-0": "`key`",
    "1-0": "`value`",
    "1-1": "String",
    "0-1": "String",
    "0-2": "Key of your choosing to create or update.",
    "1-2": "Value to set on the key. _NOTE:_ Passing in a blank String deletes the key, you can also call `DeleteTag` or `DeleteTags`.",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 2
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.Current.SendTag(\"key\", \"value\");",
      "language": "csharp"
    }
  ]
}
[/block]
### `SendTags`
<div class="label-all label-type">Method</div>

Set multiple tags on a player with one call.
[block:parameters]
{
  "data": {
    "0-0": "`tags`",
    "0-1": "Dictionary<string, string>",
    "0-2": "An IDictionary of key value pairs. _NOTE:_ Passing in a blank as a value deletes the key, you can also call `DeleteTag` or `DeleteTags`.",
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.Current.SendTags(new Dictionary<string, string>() { {\"TestKey2\", \"value2\"}, {\"TestKey3\", \"value3\"} });",
      "language": "csharp"
    }
  ]
}
[/block]
### `DeleteTag`
<div class="label-all label-type">Method</div>

Deletes a tag that was previously set on a player with `SendTag` or `SendTags`. Please use `DeleteTags` if you need to delete more than one tag.
[block:parameters]
{
  "data": {
    "0-0": "`key`",
    "0-1": "String",
    "0-2": "Key to remove.",
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.DeleteTag(\"key\");",
      "language": "csharp"
    }
  ]
}
[/block]
### `DeleteTags`
<div class="label-all label-type">Method</div>

Deletes tags that were previously set on a player with `SendTag` or `SendTags`.
[block:parameters]
{
  "data": {
    "0-0": "`keys`",
    "0-1": "IList<string>",
    "0-2": "Keys to remove.",
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.Current.DeleteTags(new List<string>() {\"TestKey2\", \"TestKey3\" })",
      "language": "csharp"
    }
  ]
}
[/block]
## Data

### `PromptLocation`
<div class="label-all label-type">Method</div>

Prompts the user for location permissions. This allows for geotagging so you can send notifications to users based on location.
[block:code]
{
  "codes": [
    {
      "code": "OneSignal.Current.PromptLocation();",
      "language": "csharp"
    }
  ]
}
[/block]

[block:html]
{
  "html": "<div class=\"platform-instruction\">\n  <h5 class=\"label-ios\">iOS INSTRUCTIONS</h5>\n  <p>You must add <strong>all</strong> of the following to your iOS plist settings:</p>\n  <p><code>NSLocationUsageDescription</code></p>\n  <p><code>NSLocationWhenInUseUsageDescription</code></p>\n</div>"
}
[/block]

[block:html]
{
  "html": "<div class=\"platform-instruction\">\n  <h5 class=\"label-android\">ANDROID INSTRUCTIONS</h5>\n  <p>You must add <strong>one</strong> of the following Android Permissions:</p>\n  <p><code>&lt;uses-permission android:name=&quot;android.permission.ACCESS_FINE_LOCATION&quot;/&gt;</code></p>\n  <p><code>&lt;uses-permission android:name=&quot;android.permission.ACCESS_COARSE_LOCATION&quot;/&gt;</code></p>\n</div>"
}
[/block]
### `syncHashedEmail`
<div class="label-all label-type">Method</div>

Sync hashed email if you have a login system or collect it. Will be used to reach the user at the most optimal time of day.
[block:code]
{
  "codes": [
    {
      "code": "OneSignal.Current.SyncHashedEmail(\"John.Smith@example.com\");",
      "language": "csharp"
    }
  ]
}
[/block]
## Sending Notifications

### `PostNotification`
<div class="label-all label-type">Method</div>

Allows you to send notifications from user to user or schedule ones in the future to be delivered to the current device.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`parameters`",
    "0-1": "Dictionary<string, object>",
    "0-2": "Dictionary of notification options, see our [Create notification](ref:create-notification) POST call for all options."
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:parameters]
{
  "data": {
    "h-0": "Returns",
    "0-0": "`onSuccess`",
    "0-1": "`OnPostNotificationSuccess` delegate fires when the notification was created on OneSignal's server.\n\n`Dictionary<string, object>` - Json response from OneSignal's server.",
    "1-0": "`onFailure`",
    "1-1": "`OnPostNotificationFailure` delegate fires when the notification failed to create\n\n`Dictionary<string, object>` - Json response from OneSignal's server.",
    "h-1": "Method"
  },
  "cols": 2,
  "rows": 2
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "using OneSignalPush.MiniJSON;\n\nprivate static string oneSignalDebugMessage;\n\nvoid someMethod() {\n// Just an example userId, use your own or get it the devices by calling OneSignal.GetIdsAvailable\nstring userId = \"b2f7f966-d8cc-11e4-bed1-df8f05be55ba\";\n\nvar notification = new Dictionary<string, object>();\nnotification[\"contents\"] = new Dictionary<string, string>() { {\"en\", \"Test Message\"} };\n\nnotification[\"include_player_ids\"] = new List<string>() { userId };\n// Example of scheduling a notification in the future.\nnotification[\"send_after\"] = System.DateTime.Now.ToUniversalTime().AddSeconds(30).ToString(\"U\");\n\nOneSignal.Current.PostNotification(notification, (responseSuccess) => {\n  oneSignalDebugMessage = \"Notification posted successful! Delayed by about 30 secounds to give you time to press the home button to see a notification vs an in-app alert.\\n\" + Json.Serialize(responseSuccess);\n}, (responseFailure) => {\n  oneSignalDebugMessage = \"Notification failed to post:\\n\" + Json.Serialize(responseFailure);\n});\n\n}",
      "language": "csharp"
    }
  ]
}
[/block]
See the [Create notification](ref:create-notification) REST API POST call for a list of all possible options. Note: You can only use `include_player_ids` as a targeting parameter from your app. Other target options such as `tags` and `included_segments` require your OneSignal App REST API key which can only be used from your server.

### `CancelNotification`
<div class="label-all label-type">Method - <span class="label-all label-android">Android</span> - *COMING SOON*</div>

Delete a single app notification

### `ClearOneSignalNotifications`
<div class="label-all label-type">Method</div>

Removes all OneSignal app notifications from the Notification Shade.
[block:code]
{
  "codes": [
    {
      "code": "OneSignal.Current.ClearOneSignalNotifications();",
      "language": "csharp",
      "name": "C#"
    }
  ]
}
[/block]
### `SetSubscription`
<div class="label-all label-type">Method</div>

You can call this method with false to opt users out of receiving all notifications through OneSignal. You can pass true later to opt users back into notifications.

[block:parameters]
{
  "data": {
    "0-0": "`enable`",
    "0-1": "Boolean",
    "0-2": "",
    "h-0": "Parameter",
    "h-1": "Type"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.SetSubscription(false);",
      "language": "csharp"
    }
  ]
}
[/block]
## Receiving Notifications
### `NotificationReceived`
<div class="label-all label-type">Method</div>

Use to process a OneSignal notification that was just received while the app was in focus.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`result`",
    "0-1": "[OSNotification](#section--osnotification-)",
    "0-2": "Object containing properties of the notification."
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "// Called when your app is in focus and a notificaiton is recieved.\n// The name of the method can be anything as long as the signature matches.\n// Method must be static or this object should be marked as DontDestroyOnLoad\nprivate static void HandleNotificationReceived(OSNotification notification) {\n  OSNotificationPayload payload = notification.payload;\n  string message = payload.body;\n\n  print(\"GameControllerExample:HandleNotificationReceived: \" + message);\n  print(\"displayType: \" + notification.displayType);\n  extraMessage = \"Notification received with text: \" + message;\n}",
      "language": "csharp"
    }
  ]
}
[/block]
### `HandleNotificationReceived`
<div class="label-all label-type">Delegate</div>

Sets a notification received handler. The delegate will be called when a notification is received whether it was displayed or not when your app is in focus.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`handler`",
    "0-1": "[NotificationReceivedHandler](#section--notificationreceivedhandler-)",
    "0-2": "A delegate to handle the received event."
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.Current.StartInit(\"b2f7f966-d8cc-11e4-bed1-df8f05be55ba\")\n  .HandleNotificationReceived(HandleNotificationReceived)\n  .EndInit();",
      "language": "csharp"
    }
  ]
}
[/block]
### `NotificationOpened`
<div class="label-all label-type">Method</div>

Use to process a OneSignal notification the user just tapped on.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`result`",
    "0-1": "[OSNotificationOpenedResult](#section--osnotificationopenedresult-)",
    "0-2": "Object containing both the user's response and properties of the notification."
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "// Called when a notification is opened.\n// The name of the method can be anything as long as the signature matches.\n// Method must be static or this object should be marked as DontDestroyOnLoad\nprivate static void HandleNotificationOpened(OSNotificationOpenedResult result) {\n  OSNotificationPayload payload = result.notification.payload;\n  Dictionary<string, string> additionalData = payload.additionalData;\n  string message = payload.body;\n  string actionID = result.action.actionID;\n\n  print(\"GameControllerExample:HandleNotificationOpened: \" + message);\n  extraMessage = \"Notification opened with text: \" + message;\n\n  if (additionalData != null) {\n    if (additionalData.ContainsKey(\"discount\")) {\n      extraMessage = (string)additionalData[\"discount\"];\n      // Take user to your store.\n    }\n  }\n  if (actionID != null) {\n    // actionSelected equals the id on the button the user pressed.\n    // actionSelected will equal \"__DEFAULT__\" when the notification itself was tapped when buttons were present.\n    extraMessage = \"Pressed ButtonId: \" + actionID;\n  }\n}",
      "language": "csharp"
    },
    {
      "code": "private static void HandleNotification(string message, Dictionary<string, object> additionalData, bool isActive) {\n  bool hasButtons = (additionalData != null && additionalData.ContainsKey(\"actionSelected\"));\n  if (hasButtons) {\n    if (additionalData[\"actionSelected\"].Equals(\"id1\"))\n      print(\"button id1 pressed\");\n    else if (additionalData[\"actionSelected\"].Equals(\"id2\"))\n      print(\"button id2 pressed\");\n    else if (additionalData[\"actionSelected\"].Equals(\"__DEFAULT__\"))\n      print(\"Buttons present but you tapped on the notificaiton instead.\");\n  }\n}",
      "language": "csharp",
      "name": "C# (handle buttons)"
    },
    {
      "code": "private static void HandleNotification(string message, Dictionary<string, object> additionalData, bool isActive) {\n    print(\"Notification opned with Message: \" + message);\n    \n    if (additionalData != null && additionalData.ContainsKey(\"stacked_notifications\")) {\n       var notificationsList = (List<object>)additionalData[\"stacked_notifications\"];\n       print(\"Stacked Sotification Opened, number on stack: \" + notificationsList.Count);\n       foreach (Dictionary<string, object> notifiAddData in notificationsList) {\n          foreach (KeyValuePair<string, object> kvp in notifiAddData)\n             print(\"Key = \" + kvp.Key + \", Value = \" + kvp.Value);\n       }\n    }\n}",
      "language": "csharp",
      "name": "C# (stacked notifications)"
    }
  ]
}
[/block]
### `HandleNotificationOpened`
<div class="label-all label-type">Delegate</div>

Delegate you can define to process information on the notification the user just opened.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "0-0": "`handler`",
    "0-1": "[NotificationReceivedHandler](#section--notificationreceivedhandler-)",
    "0-2": "A delegate to handle the open event.",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.Current.StartInit(\"b2f7f966-d8cc-11e4-bed1-df8f05be55ba\")\n  .HandleNotificationOpened(HandleNotificationOpened)\n  .EndInit();",
      "language": "csharp"
    }
  ]
}
[/block]
### `OSNotificationOpenedResult`
<div class="label-all label-type">Class</div>

The information returned from a notification the user received.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`notification`",
    "1-0": "`action`",
    "1-1": "[OSNotificationAction](#section--osnotificationaction-)",
    "0-1": "[OSNotification](#section--osnotification-)",
    "0-2": "Notification the user opened.",
    "1-2": "The action the user took on the notification."
  },
  "cols": 3,
  "rows": 2
}
[/block]
### `OSNotification`
<div class="label-all label-type">Class</div>

The notification the user opened.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`isAppInFocus`",
    "1-0": "`shown`",
    "0-1": "boolean",
    "1-1": "boolean",
    "2-1": "int",
    "3-1": "[OSNotificationPayload](#section--osnotificationpayload-)",
    "4-1": "[DisplayType](#section--displaytype-)",
    "5-1": "List<[OSNotificationPayload](#section--osnotificationpayload-)>",
    "0-2": "Was app in focus.",
    "1-2": "Was notification shown to the user. Will be false for silent notifications.",
    "2-0": "`androidNotificationId`",
    "2-2": "Android Notification assigned to the notification. Can be used to cancel or replace the notification.",
    "3-0": "`payload`",
    "3-2": "Payload received from OneSignal.",
    "4-0": "`displayType`",
    "4-2": "How the notification was displayed to the user.",
    "5-0": "`groupedNotifications`",
    "5-2": "Notification is a summary notification for a group this will contain all notification payloads it was created from."
  },
  "cols": 3,
  "rows": 6
}
[/block]
#### `displayType`
<div class="label-all label-type">Object</div>

How the notification was displayed to the user. Part of [OSNotification](#section--osnotification-). See [inFocusDisplaying](#section--infocusdisplaying-) for more information on how this is used. 

`Notification` - native notification display.
`InAppAlert` (<span class="label-all label-default">Default</span>) - native alert dialog display.
`None` - notification is silent, or [inFocusDisplaying](#section--infocusdisplaying-) is disabled.


### `OSNotificationAction`
<div class="label-all label-type">Class</div>

The action the user took on the notification.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-1": "ActionType",
    "1-1": "String",
    "1-0": "`actionID`",
    "0-0": "`type`",
    "0-2": "Was the notification opened normally (`Opened`) or was a button pressed on the notification (`ActionTaken`).",
    "1-2": "If `type` == `ActionTaken` then this will contain the id of the button pressed."
  },
  "cols": 3,
  "rows": 2
}
[/block]
### `OSNotificationPayload`
<div class="label-all label-type">Class</div>

Contents and settings of the notification the user received.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-1": "String",
    "1-1": "String",
    "2-1": "String",
    "3-1": "JSONObject",
    "4-1": "String",
    "5-1": "String",
    "6-1": "String",
    "7-1": "String",
    "8-1": "String",
    "9-1": "String",
    "0-0": "`notificationId`",
    "1-0": "`title`",
    "2-0": "`body`",
    "3-0": "`additionalData`",
    "4-0": "`smallIcon`",
    "5-0": "`largeIcon`",
    "6-0": "`bigPicture`",
    "7-0": "`smallIconAccentColor`",
    "8-0": "`launchUrl`",
    "9-0": "`sound`",
    "10-0": "`ledColor`",
    "10-1": "String",
    "11-0": "`lockScreenVisibility`",
    "11-1": "int",
    "12-0": "`groupKey`",
    "12-1": "String",
    "13-0": "`groupMessage`",
    "13-1": "string",
    "14-0": "`actionButtons`",
    "14-1": "List<[ActionButton](#section--actionbutton-)>",
    "16-1": "[BackgroundImageLayout](#section--backgroundimagelayout-)",
    "16-0": "`backgroundImageLayout`",
    "17-0": "`rawPayload`",
    "17-1": "String",
    "17-2": "Raw JSON payload string received from OneSignal.",
    "16-2": "If a background image was set this object will be available.",
    "14-2": "List of action buttons on the notification.",
    "13-2": "Summary text displayed in the summary notification.",
    "15-0": "`fromProjectNumber`",
    "15-1": "String",
    "15-2": "The Google project number the notification was sent under.",
    "12-2": "Notifications with this same key will be grouped together as a single summary notification.",
    "11-2": "Privacy setting for how the notification should be shown on the lockscreen of Android 5+ devices. 1 = Public (fully visible)(default), 0 = Private (Contents are hidden), -1 = Secret (not shown).",
    "10-2": "Devices that have a notification LED will blink in this color. ARGB format.",
    "9-2": "Sound resource to play when the notification is shown.",
    "8-2": "URL to open when opening the notification.",
    "7-2": "Accent color shown around small notification icon on Android 5+ devices. ARGB format.",
    "6-2": "Big picture image set on the notification.",
    "5-2": "Large icon set on the notification.",
    "4-2": "Small icon resource name set on the notification.",
    "3-2": "Custom additional data that was sent with the notification. Set on the dashboard under Options > Additional Data or with the 'data' field on the REST API.",
    "2-2": "Body of the notification.",
    "1-2": "Title of the notification.",
    "0-2": "OneSignal notification UUID."
  },
  "cols": 3,
  "rows": 18
}
[/block]
#### `ActionButton`
<div class="label-all label-type">Object</div>

List of action buttons on the notification. Part of [OSNotificationPayload](#section--osnotificationpayload-).
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-1": "String",
    "1-1": "String",
    "2-1": "String",
    "0-0": "`id`",
    "1-0": "`text`",
    "1-2": "Text show on the button to the user.",
    "2-0": "`icon`",
    "0-2": "Id assigned to the button.",
    "2-2": "Icon shown on the button."
  },
  "cols": 3,
  "rows": 3
}
[/block]
#### `BackgroundImageLayout`
<div class="label-all label-type">Object - <span class="label-all label-android">Android</span></div>

If a background image was set, this object will be available. Part of [OSNotificationPayload](#section--osnotificationpayload-).
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-1": "String",
    "1-1": "String",
    "2-1": "String",
    "0-0": "`image`",
    "0-2": "Image URL or name used as the background image.",
    "1-2": "Text color of the title on the notification. ARGB Format.",
    "2-2": "Text color of the body on the notification. ARGB Format.",
    "1-0": "`titleTextColor`",
    "2-0": "`bodyTextColor`"
  },
  "cols": 3,
  "rows": 3
}
[/block]
## Appearance
### `EnableVibrate`
<div class="label-all label-type">Method - <span class="label-android">Android</span></div>

By default OneSignal always vibrates the device when a notification is displayed unless the device is in a total silent mode. Passing false means that the device will only vibrate lightly when the device is in it's vibrate only mode.

*You can link this action to a UI button to give your user a vibration option for your notifications.*
[block:code]
{
  "codes": [
    {
      "code": "OneSignal.Current.EnableVibrate(false);",
      "language": "csharp"
    }
  ]
}
[/block]
### `EnableSound`
<div class="label-all label-type">Method - <span class="label-android">Android</span></div>

By default OneSignal plays the system's default notification sound when the device's notification system volume is turned on. Passing false means that the device will only vibrate unless the device is set to a total silent mode.

*You can link this action to a UI button to give your user a different sound option for your notifications.*
[block:code]
{
  "codes": [
    {
      "code": "OneSignal.Current.EnableSound(false);",
      "language": "csharp"
    }
  ]
}
[/block]
## Debug

### `SetLogLevel`
<div class="label-all label-type">Method</div>

Enable logging to help debug if you run into an issue setting up OneSignal. The following options are available with increasingly more information; `NONE`, `FATAL`, `ERROR`, `WARN`, `INFO`, `DEBUG`, `VERBOSE`
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "0-0": "`logLevel`",
    "1-0": "`visualLevel`",
    "1-1": "LOG_LEVEL",
    "0-1": "LOG_LEVEL",
    "0-2": "Sets the logging level to print the iOS Xcode log or the Android LogCat log.",
    "1-2": "Sets the logging level to show as alert dialogs.",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 2
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.Current.SetLogLevel(OneSignal.LOG_LEVEL.INFO, OneSignal.LOG_LEVEL.INFO);",
      "language": "csharp"
    }
  ]
}
[/block]
---
title: "Intel XDK"
excerpt: "OneSignal Intel XDK Reference. Works with <span class=\"label-all label-ios\">iOS</span>, <span class=\"label-all label-android\">Android</span> (and derivatives like <span class=\"label-all label-amazon\">Amazon</span>) and <span class=\"label-all label-windows\">Windows Phone 8.1</span>.\n<div class=\"tag-all tag-developers\">For Developers</div>"
---
[block:callout]
{
  "type": "info",
  "title": "Just starting with Intel XDK?",
  "body": "Check out our [Intel XDK Setup guide](doc:intel-xdk-setup)."
}
[/block]

[block:callout]
{
  "type": "warning",
  "title": "Upgrade to newest SDK",
  "body": "A number the methods and classes below are only available on our newest SDK. To upgrade to the latest Intel XDK, read the [Intel XDK Setup](doc:intel-xdk-setup)."
}
[/block]

### Intel XDK API Reference

See our [Cordova SDK](doc:cordova-sdk) reference.
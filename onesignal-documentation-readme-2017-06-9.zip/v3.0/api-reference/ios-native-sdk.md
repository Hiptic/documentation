---
title: "iOS Native SDK"
excerpt: "OneSignal <span class=\"label-all label-ios\">iOS</span> Native SDK Reference\n<div class=\"tag-all tag-developers\">For Developers</div>"
---
[block:callout]
{
  "type": "info",
  "title": "Just starting with iOS?",
  "body": "Check out our [iOS SDK Setup guide](doc:ios-sdk-setup)."
}
[/block]

[block:callout]
{
  "type": "warning",
  "title": "Upgrade to 2.5.1+",
  "body": "A number the methods and classes below were recently added in our 2.5.1 SDK. Make sure you have updated to this version."
}
[/block]

[block:parameters]
{
  "data": {
    "0-0": "### Initialization",
    "0-1": "",
    "3-0": "[kOSSettingsKeyAutoPrompt](#section--kossettingskeyautoprompt-)",
    "3-1": "Key",
    "h-2": "",
    "0-2": "",
    "3-2": "Automatically Prompt Users to Enable Notifications",
    "h-0": "",
    "1-0": "[initWithLaunchOptions](#section--initwithlaunchoptions-)",
    "1-1": "Method",
    "1-2": "Initialize OneSignal",
    "6-0": "### Prompting",
    "7-0": "[promptForPushNotificationsWithUserResponse](#section--promptforpushnotificationswithuserresponse-)",
    "8-0": "### Status",
    "9-0": "[getPermissionSubscriptionState](#section--getpermissionsubscriptionstate-)",
    "9-1": "Method",
    "9-2": "Current Permission and Subscription status",
    "12-0": "### Tags",
    "13-0": "[getTags](#section--gettags-)",
    "13-1": "Method",
    "15-1": "Method",
    "16-1": "Method",
    "17-1": "Method",
    "13-2": "View Tags from a User",
    "15-2": "",
    "17-2": "",
    "16-2": "Delete a Tag from a User",
    "15-0": "[sendTags](#section--sendtags-)",
    "16-0": "[deleteTag](#section--deletetag-)",
    "17-0": "[deleteTags](#section--deletetags-)",
    "18-0": "### Data",
    "22-0": "### Sending Notifications",
    "26-0": "### Notification Events",
    "23-0": "[postNotification](#section--postnotification-)",
    "24-0": "[clearOneSignalNotifications](#section--clearonesignalnotifications-)",
    "25-0": "[setSubscription](#section--setsubscription-)",
    "25-1": "Method",
    "24-1": "Method",
    "23-1": "Method",
    "31-0": "[OSNotification](#section--osnotification-)",
    "31-1": "Object",
    "35-0": "[OSNotificationPayload](#section--osnotificationpayload-)",
    "35-1": "Object",
    "36-0": "### Debug",
    "37-0": "[setLogLevel](#section--setloglevel-)",
    "37-1": "Method",
    "20-1": "Method",
    "20-0": "[syncHashedEmail](#section--synchashedemail-)",
    "19-0": "[promptLocation](#section--promptlocation-)",
    "19-1": "Method",
    "4-0": "[kOSSettingsKeyInAppLaunchURL](#section--kossettingskeyinapplaunchurl-)",
    "4-1": "Key",
    "4-2": "Open URLs in In-App Safari Window or Safari app",
    "19-2": "Prompt Users for Location",
    "20-2": "Sync Anonymized User Email",
    "23-2": "Send or schedule a notification to a user",
    "25-2": "Opt users in or out of receiving notifications",
    "24-2": "Delete all app notifications",
    "35-2": "Data that comes with a notification",
    "31-2": "",
    "37-2": "Enable logging to help debug OneSignal implementation",
    "14-0": "[sendTag](#section--sendtag-)",
    "14-1": "Method",
    "14-2": "Add a Tag to a User",
    "32-0": "[OSNotificationAction](#section--osnotificationaction-)",
    "32-1": "Object",
    "32-2": "How user opened notification",
    "7-1": "Method",
    "7-2": "Prompt Users to Enable Notifications",
    "33-0": "[OSNotificationActionType](#section--osnotificationactiontype-)",
    "33-1": "Object",
    "33-2": "",
    "34-0": "[OSNotificationDisplayType](#section--osnotificationdisplaytype-)",
    "34-1": "Object",
    "34-2": "Change how notifications are displayed to users",
    "21-2": "Get In-App Purchase Information",
    "21-0": "Automatic",
    "28-0": "[handleNotificationAction](#section--oshandlenotificationactionblock-)",
    "28-1": "Method",
    "30-0": "[OSNotificationOpenedResult](#section--osnotificationopenedresult-)",
    "30-1": "Object",
    "27-0": "[handleNotificationReceived](#section--oshandlenotificationreceivedblock-)",
    "26-1": "",
    "27-1": "Method",
    "29-0": "### Objects",
    "10-0": "[addPermissionObserver](#section--addpermissionobserver-)",
    "11-0": "[addSubscriptionObserver](#section--addsubscriptionobserver-)",
    "2-0": "### Settings",
    "10-2": "Permission status changes",
    "10-1": "Method",
    "11-1": "Method",
    "11-2": "Subscription status changes",
    "27-2": "When a notification is received by a device.",
    "28-2": "When a user takes an action on a notification",
    "5-0": "[inFocusDisplayType](#section--infocusdisplaytype-)",
    "5-2": "Changes how notifications display while in the app",
    "5-1": "Property"
  },
  "cols": 3,
  "rows": 38
}
[/block]

## Initialization

### `initWithLaunchOptions`
<div class="label-all label-type">Method</div>

Must be called from `didFinishLaunchingWithOptions` in `AppDelegate.m`.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-2": "<span class=\"label-all label-required\">Required</span> launchOptions that you received from `didFinishLaunchingWithOptions`",
    "0-1": "NSDictionary*",
    "0-0": "`launchOptions`",
    "1-1": "NSString*",
    "1-0": "`appId`",
    "1-2": "<span class=\"label-all label-required\">Required</span> Your OneSignal app id, available in <a class=\"dash-link\" href=\"/docs/accounts-and-keys#section-keys-ids\">Keys & IDs</a>",
    "2-1": "[OSHandleNotificationReceivedBlock](#section--oshandlenotificationreceivedblock-)",
    "2-0": "`callback`",
    "2-2": "Function to be called when a notification is received",
    "3-1": "[OSHandleNotificationActionBlock](#section--oshandlenotificationactionblock-)",
    "3-0": "`callback`",
    "3-2": "Function to be called when a user reacts to a notification received",
    "4-2": "Customization settings to change OneSignal's default behavior",
    "4-0": "`settings`",
    "4-1": "NSDictionary*"
  },
  "cols": 3,
  "rows": 5
}
[/block]

[block:callout]
{
  "type": "info",
  "body": "- `application:didRegisterForRemoteNotificationsWithDeviceToken:` will still fire even if `kOSSettingsKeyAutoPrompt` is set to `false`.\n- Replace any of your `isRegisteredForRemoteNotifications` calls with `currentUserNotificationSettings` or [getPermissionSubscriptionState](#section--getpermissionsubscriptionstate-).",
  "title": "iOS 8+ Notes"
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "- (BOOL)application:(UIApplication*)application didFinishLaunchingWithOptions:(NSDictionary*)launchOptions {\n \n  id notificationReceiverBlock = ^(OSNotification *notification) {\n    NSLog(@\"Received Notification - %@\", notification.payload.notificationID);\n  };\n  \n  id notificationOpenedBlock = ^(OSNotificationOpenedResult *result) {\n        // This block gets called when the user reacts to a notification received\n        OSNotificationPayload* payload = result.notification.payload;\n        \n        NSString* messageTitle = @\"OneSignal Example\";\n        NSString* fullMessage = [payload.body copy];\n        \n        if (payload.additionalData) {\n            \n            if(payload.title)\n                messageTitle = payload.title;\n            \n            NSDictionary* additionalData = payload.additionalData;\n            \n            if (additionalData[@\"actionSelected\"])\n                fullMessage = [fullMessage stringByAppendingString:[NSString stringWithFormat:@\"\\nPressed ButtonId:%@\", additionalData[@\"actionSelected\"]]];\n        }\n        \n        UIAlertView* alertView = [[UIAlertView alloc] initWithTitle:messageTitle\n                                                            message:fullMessage\n                                                           delegate:self\n                                                  cancelButtonTitle:@\"Close\"\n                                                  otherButtonTitles:nil, nil];\n        [alertView show];\n\n   };\n  \n   id onesignalInitSettings = @{kOSSettingsKeyAutoPrompt : @YES};\n  \n   [OneSignal initWithLaunchOptions:launchOptions\n                              appId:@\"YOUR_ONESIGNAL_APP_ID\"\n         handleNotificationReceived:notificationReceiverBlock\n           handleNotificationAction:notificationOpenedBlock\n                           settings:onesignalInitSettings];\n  \n}",
      "language": "objectivec"
    },
    {
      "code": "func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {\n\nOneSignal.initWithLaunchOptions(launchOptions, appId: \"YOUR_ONESIGNAL_APP_ID\", handleNotificationReceived: { (notification) in\n                print(\"Received Notification - \\(notification.payload.notificationID)\")\n            }, handleNotificationAction: { (result) in\n                \n                // This block gets called when the user reacts to a notification received\n                let payload = result.notification.payload\n                var fullMessage = payload.title\n                \n                //Try to fetch the action selected\n                if let additionalData = payload.additionalData, actionSelected = additionalData[\"actionSelected\"] as? String {\n                    fullMessage =  fullMessage + \"\\nPressed ButtonId:\\(actionSelected)\"\n                }\n                print(fullMessage)\n            }, settings: [kOSSettingsKeyAutoPrompt : true, kOSSettingsKeyInFocusDisplayOption : OSNotificationDisplayType.notification.rawValue])\n\n}",
      "language": "swift",
      "name": "Swift2.3"
    },
    {
      "code": "func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {\n\n   let notificationReceivedBlock: OSHandleNotificationReceivedBlock = { notification in\n\n      print(\"Received Notification: \\(notification!.payload.notificationID)\")\n   }\n\n   let notificationOpenedBlock: OSHandleNotificationActionBlock = { result in\n      // This block gets called when the user reacts to a notification received\n      let payload: OSNotificationPayload = result!.notification.payload\n\n      var fullMessage = payload.body\n      print(\"Message = \\(fullMessage)\")\n\n      if payload.additionalData != nil {\n         if payload.title != nil {\n            let messageTitle = payload.title\n               print(\"Message Title = \\(messageTitle!)\")\n         }\n\n         let additionalData = payload.additionalData\n         if additionalData?[\"actionSelected\"] != nil {\n            fullMessage = fullMessage! + \"\\nPressed ButtonID: \\(additionalData![\"actionSelected\"])\"\n         }\n      }\n   }\n\n   let onesignalInitSettings = [kOSSettingsKeyAutoPrompt: false,\n      kOSSettingsKeyInAppLaunchURL: true]\n\n   OneSignal.initWithLaunchOptions(launchOptions, \n      appId: \"YOUR_ONESIGNAL_APP_ID\", \n      handleNotificationReceived: notificationReceivedBlock, \n      handleNotificationAction: notificationOpenedBlock, \n      settings: onesignalInitSettings)\n\n   OneSignal.inFocusDisplayType = OSNotificationDisplayType.notification\n\n   return true\n}\n",
      "language": "swift",
      "name": "Swift3"
    }
  ]
}
[/block]
### `kOSSettingsKeyAutoPrompt`
<div class="label-all label-type">Key</div>

`true` (<span class="label-all label-default">Default</span>) - automatically prompts for notifications permissions.
`false` - disables auto prompt.

### `kOSSettingsKeyInAppLaunchURL`
<div class="label-all label-type">Key</div>

`true` (<span class="label-all label-default">Default</span>) - Open all URLs with a in-app WebView window.
`false` - Launches Safari with the URL OR other app (if deep linked or custom URL scheme passed).

### `inFocusDisplayType`
<div class="label-all label-type">Property</div>

Setting to control how OneSignal notifications will be shown when one is received while your app is in focus, for apps targeting.

`OSNotificationDisplayTypeNotification` - Native notification display
`OSNotificationDisplayTypeInAppAlert` (<span class="label-all label-default">Default</span>) - Alert dialog display.
`OSNotificationDisplayTypeNone` - Notification is silent and not shown

**Swift format:**
`OSNotificationDisplayType.notification`
`OSNotificationDisplayType.inAppAlert`
`OSNotificationDisplayType.none`
[block:code]
{
  "codes": [
    {
      "code": "OneSignal.inFocusDisplayType = OSNotificationDisplayTypeNotification;",
      "language": "objectivec"
    },
    {
      "code": "OneSignal.inFocusDisplayType = OSNotificationDisplayType.notification",
      "language": "swift"
    }
  ]
}
[/block]

[block:callout]
{
  "type": "warning",
  "body": "<span class=\"label-all label-ios\">iOS 9 AND BELOW</span> - the `Notification` setting will fall back to `InAppAlert` ."
}
[/block]

## Registering Push
### `promptForPushNotificationsWithUserResponse`
<div class="label-all label-type">Method</div>

Prompt the user for notification permissions. Callback fires as soon as the user accepts or declines notifications.

#### Requirements
Must set `kOSSettingsKeyAutoPrompt` to `false` when calling [initWithLaunchOptions](#section--initwithlaunchoptions-).

#### Recommendations
You can only prompt once so it is recommend to explain what benefits notifications will give the user.

#### Example
[block:code]
{
  "codes": [
    {
      "code": "[OneSignal promptForPushNotificationsWithUserResponse:^(BOOL accepted) {\n  NSLog(@\"Accepted Notifications?: %d\", accepted);\n}];",
      "language": "objectivec"
    },
    {
      "code": "// Call when you want to prompt the user to accept push notifications. \n// Only call once and only if you set kOSSettingsKeyAutoPrompt in AppDelegate to false.\nOneSignal.promptForPushNotifications(userResponse: { accepted in\n   print(\"User accepted notifications: \\(accepted)\")\n})",
      "language": "swift",
      "name": "Swift"
    }
  ]
}
[/block]

### `getPermissionSubscriptionState`
<div class="label-all label-type">Method</div>

Get the current notification and permission state. Returns a `OSPermissionSubscriptionState` type described below.

#### OSPermissionSubscriptionState
[block:parameters]
{
  "data": {
    "h-2": "Description",
    "h-1": "Type",
    "h-0": "Parameter",
    "0-0": "`permissionStatus`",
    "0-1": "`OSPermissionState*`",
    "1-0": "`subscriptionStatus`",
    "1-1": "`OSSubscriptionState*`",
    "0-2": "iOS Notification Permissions state",
    "1-2": "Apple and OneSignal subscription state"
  },
  "cols": 3,
  "rows": 2
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "",
      "language": "text"
    }
  ]
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OSPermissionSubscriptionState* status = [OneSignal getPermissionSubscriptionState];\nstatus.permissionStatus.hasPrompted;\nstatus.permissionStatus.status;\n    \nstatus.subscriptionStatus.subscribed;\nstatus.subscriptionStatus.userSubscriptionSetting;\nstatus.subscriptionStatus.userId;\nstatus.subscriptionStatus.pushToken;",
      "language": "objectivec"
    },
    {
      "code": "let status: OSPermissionSubscriptionState = OneSignal.getPermissionSubscriptionState()\n\nlet hasPrompted = status.permissionStatus.hasPrompted\nprint(\"hasPrompted = \\(hasPrompted)\")\nlet userStatus = status.permissionStatus.status\nprint(\"userStatus = \\(userStatus)\")\n\nlet isSubscribed = status.subscriptionStatus.subscribed\nprint(\"isSubscribed = \\(isSubscribed)\")\nlet userSubscriptionSetting = status.subscriptionStatus.userSubscriptionSetting\nprint(\"userSubscriptionSetting = \\(userSubscriptionSetting)\")\nlet userID = status.subscriptionStatus.userId\nprint(\"userID = \\(userID)\")\nlet pushToken = status.subscriptionStatus.pushToken\nprint(\"pushToken = \\(pushToken)\")",
      "language": "swift"
    }
  ]
}
[/block]
### `addPermissionObserver`
<div class="label-all label-type">Method</div>

The `onOSPermissionChanged` method will be fired on the passed in object when a notification permission setting changes.
This includes the following events: 
* Notification permission prompt shown
* The user accepting or declining the permission prompt
* Enabling/disabling notifications for your app in the iOS Settings after returning to your app.

#### Example
Example of setting up with your AppDelegate.
Output is showings the user accepting the notification permission prompt.
[block:code]
{
  "codes": [
    {
      "code": "// AppDelegate.h\n// Add OSPermissionObserver after UIApplicationDelegate\n@interface AppDelegate : UIResponder <UIApplicationDelegate, OSPermissionObserver>\n@end\n\n// AppDelegate.m\n@implementation AppDelegate\n  \n- (BOOL)application:(UIApplication*)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {\n  // Add your AppDelegate as an obsserver\n  [OneSignal addPermissionObserver:self];\n}\n\n// Add this new method\n- (void)onOSPermissionChanged:(OSPermissionStateChanges*)stateChanges {\n  \n    // Example of detecting anwsering the permission prompt\n    if (stateChanges.from.status == OSNotificationPermissionNotDetermined) {\n      if (stateChanges.to.status == OSNotificationPermissionAuthorized)\n         NSLog(@\"Thanks for accepting notifications!\");\n      else if (stateChanges.to.status == OSNotificationPermissionDenied)\n         NSLog(@\"Notifications not accepted. You can turn them on later under your iOS settings.\");\n    }\n    \n   // prints out all properties \n   NSLog(@\"PermissionStateChanges:\\n%@\", stateChanges);\n}\n\n// Output:\n/*\nThanks for accepting notifications!\nPermissionStateChanges:\n<OSSubscriptionStateChanges:\nfrom: <OSPermissionState: hasPrompted: 1, status: NotDetermined>,\nto:   <OSPermissionState: hasPrompted: 1, status: Authorized>\n>\n*/\n\n@end",
      "language": "objectivec"
    },
    {
      "code": "// AppDelegate.swift\n// Add OSPermissionObserver after UIApplicationDelegate\nclass AppDelegate: UIResponder, UIApplicationDelegate, OSPermissionObserver {\n\n   func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {\n      // Add your AppDelegate as an obsserver\n      OneSignal.add(self as OSPermissionObserver)\n   }\n\n   // Add this new method\n   func onOSPermissionChanged(_ stateChanges: OSPermissionStateChanges!) {\n      // Example of detecting answering the permission prompt\n      if stateChanges.from.status == OSNotificationPermission.notDetermined {\n         if stateChanges.to.status == OSNotificationPermission.authorized {\n            print(\"Thanks for accepting notifications!\")\n         } else if stateChanges.to.status == OSNotificationPermission.denied {\n            print(\"Notifications not accepted. You can turn them on later under your iOS settings.\")\n         }\n      }\n      // prints out all properties\n      print(\"PermissionStateChanges: \\n\\(stateChanges)\")\n   }\n\n   // Output:\n   /*\n   Thanks for accepting notifications!\n   PermissionStateChanges:\n   Optional(<OSSubscriptionStateChanges:\n   from: <OSPermissionState: hasPrompted: 0, status: NotDetermined>,\n   to:   <OSPermissionState: hasPrompted: 1, status: Authorized>\n   >\n   */\n}",
      "language": "swift"
    }
  ]
}
[/block]
### `addSubscriptionObserver`
<div class="label-all label-type">Method</div>

The `onOSSubscriptionChanged` method will be fired on the passed in object when a notification subscription property changes.

This includes the following events:
* Getting a push token from Apple
* Getting a player / user id from OneSignal
* `OneSignal.setSubscription` is called
* User disables or enables notifications

#### Example
Example of setting up with your AppDelegate. Output is showing the capture the device subscribing to OneSignal.
[block:code]
{
  "codes": [
    {
      "code": "// AppDelegate.h\n// Add OSSubscriptionObserver after UIApplicationDelegate\n@interface AppDelegate : UIResponder <UIApplicationDelegate, OSSubscriptionObserver>\n@end\n\n// AppDelegate.m\n@implementation AppDelegate\n  \n- (BOOL)application:(UIApplication*)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {\n  // Add your AppDelegate as an obsserver\n  [OneSignal addSubscriptionObserver:self];\n}\n\n// Add this new method\n- (void)onOSSubscriptionChanged:(OSSubscriptionStateChanges*)stateChanges {\n  \n    // Example of detecting subscribing to OneSignal\n    if (!stateChanges.from.subscribed && stateChanges.to.subscribed) {\n      NSLog(@\"Subscribed for OneSignal push notifications!\");\n    }\n    \n   // prints out all properties\n   NSLog(@\"SubscriptionStateChanges:\\n%@\", stateChanges);\n}\n\n// Output:\n/*\nSubscribed for OneSignal push notifications!\nPermissionStateChanges:\n<OSSubscriptionStateChanges:\nfrom: <OSSubscriptionState: userId: (null), pushToken: 0000000000000000000000000000000000000000000000000000000000000000 userSubscriptionSetting: 1, subscribed: 0>,\nto:   <OSSubscriptionState: userId: 11111111-222-333-444-555555555555, pushToken: 0000000000000000000000000000000000000000000000000000000000000000, userSubscriptionSetting: 1, subscribed: 1>\n>\n*/\n\n@end",
      "language": "objectivec"
    },
    {
      "code": "// AppDelegate.swift\n// Add OSSubscriptionObserver after UIApplicationDelegate\nclass AppDelegate: UIResponder, UIApplicationDelegate, OSSubscriptionObserver {\n\n   func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {\n      // Add your AppDelegate as an obsserver\n      OneSignal.add(self as OSSubscriptionObserver)\n   }\n\n   // Add this new method\n   func onOSSubscriptionChanged(_ stateChanges: OSSubscriptionStateChanges!) {\n      if !stateChanges.from.subscribed && stateChanges.to.subscribed {\n         print(\"Subscribed for OneSignal push notifications!\")\n      }\n      print(\"SubscriptionStateChange: \\n\\(stateChanges)\")\n   }\n\n   // Output:\n   /*\n   Subscribed for OneSignal push notifications!\n   PermissionStateChanges:\n   Optional(<OSSubscriptionStateChanges:\n   from: <OSSubscriptionState: userId: (null), pushToken: 0000000000000000000000000000000000000000000000000000000000000000 userSubscriptionSetting: 1, subscribed: 0>,\n   to:   <OSSubscriptionState: userId: 11111111-222-333-444-555555555555, pushToken: 0000000000000000000000000000000000000000000000000000000000000000, userSubscriptionSetting: 1, subscribed: 1>\n   >\n   */\n}",
      "language": "swift"
    }
  ]
}
[/block]
#### Advanced Observer Details
Any object implementing the `OSPermissionObserver` and/or the  `OSSubscriptionObserver` protocols can be added as an observer. You can call `removePermissionObserver` to remove any existing listeners.
OneSignal uses a weak reference to the observer to prevent leaks.


### `getTags`
<div class="label-all label-type">Method</div>

Retrieve a list of tags that have been set on the user from the OneSignal server.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-1": "OneSignalResultSuccessBlock",
    "0-0": "`successBlock`",
    "0-2": "Called when tags are received from OneSignal's server",
    "1-2": "Called if there was an error.",
    "1-0": "`onFailure(Optional)`",
    "1-1": "OneSignalFailureBlock"
  },
  "cols": 3,
  "rows": 2
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "[oneSignal getTags:^(NSDictionary* tags) {\n\tNSLog(@\"%@\", tags);\n}];",
      "language": "objectivec"
    },
    {
      "code": "oneSignal.getTags({ (tags) in\n\tprint(\"%@\", tags)\n}, { (error) in\n   print(\"Error getting tags - \\(error.localizedDescription)\")\n})",
      "language": "swift",
      "name": "Swift2.3"
    },
    {
      "code": "OneSignal.getTags({ tags in\n\tprint(\"tags - \\(tags!)\")\n}, onFailure: { error in\n\tprint(\"Error getting tags - \\(error?.localizedDescription)\")\n})",
      "language": "swift",
      "name": "Swift3"
    }
  ]
}
[/block]
### `sendTag`
<div class="label-all label-type">Method</div>

Tag a user based on an app event of your choosing so later you can create segments on [onesignal.com](https://onesignal.com) to target these users. Recommend using sendTags over sendTag if you need to set more than one tag on a user at a time.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-1": "NSString*",
    "1-1": "NSString*",
    "0-0": "`key`",
    "1-0": "`value`",
    "0-2": "Key of your choosing to create or update",
    "1-2": "Value to set on the key. _NOTE:_ Passing in a blank String deletes the key, you can also call `deleteTag` or `deleteTags`.",
    "2-0": "`onSuccess(Optional)`",
    "3-0": "`onFailure(Optional)`",
    "2-2": "Call if there were no errors sending the tag",
    "3-2": "Called if there was an error",
    "3-1": "OneSignalFailureBlock",
    "2-1": "OneSignalResultSuccessBlock"
  },
  "cols": 3,
  "rows": 4
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "[OneSignal sendTag:@\"key\" value:@\"value\"];",
      "language": "objectivec"
    },
    {
      "code": "OneSignal.sendTag(\"key\", value: \"value\")",
      "language": "swift",
      "name": "Swift"
    }
  ]
}
[/block]
### `sendTags`
<div class="label-all label-type">Method</div>

Tag a user based on an app event of your choosing so later you can create segments on [onesignal.com](https://onesignal.com) to target these users.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-1": "NSDictionary*",
    "0-0": "`keyValues`",
    "0-2": "Key value pairs of your choosing to create or update. _NOTE:_ Passing in a blank `NSString*` as a value deletes the key, you can also call `deleteTag` or `deleteTags`.",
    "1-1": "OneSignalResultSuccessBlock",
    "2-1": "OneSignalFailureBlock",
    "1-0": "`onSuccess(Optional)`",
    "2-0": "`onFailure(Optional)`",
    "1-2": "Call if there were no errors sending the tag",
    "2-2": "Called if there was an error"
  },
  "cols": 3,
  "rows": 3
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "[OneSignal sendTags:@{@\"key1\" : @\"value1\", @\"key2\" : @\"value2\"}];",
      "language": "objectivec"
    },
    {
      "code": "OneSignal.sendTags([\"key1\": \"value1\", \"key2\": \"value2\"])",
      "language": "swift",
      "name": "Swift"
    }
  ]
}
[/block]
### `deleteTag`
<div class="label-all label-type">Method</div>

Deletes a single tag that was previously set on a user with `sendTag` or `sendTags`. Use `deleteTags` if you need to delete more than one.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`key`",
    "1-0": "`onSuccess(Optional)`",
    "2-0": "`onFailure(Optional)`",
    "1-1": "OneSignalResultSuccessBlock",
    "2-1": "OneSignalFailureBlock",
    "0-1": "NSString*",
    "1-2": "Call if there were no errors",
    "2-2": "Called if there was an error",
    "0-2": "Key to remove"
  },
  "cols": 3,
  "rows": 3
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "[OneSignal deleteTag:@\"key\"];",
      "language": "objectivec"
    },
    {
      "code": "OneSignal.deleteTag(\"key\")",
      "language": "swift",
      "name": "Swift"
    }
  ]
}
[/block]
### `deleteTags`
<div class="label-all label-type">Method</div>

Deletes one or more tags that were previously set on a user with `sendTag` or `sendTags`.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`keys`",
    "1-1": "OneSignalResultSuccessBlock",
    "2-1": "OneSignalFailureBlock",
    "0-1": "NSArray*",
    "1-0": "`onSuccess(Optional)`",
    "2-0": "`onFailure(Optional)`",
    "2-2": "Called if there was an error",
    "1-2": "Call if there were no errors",
    "0-2": "Keys to remove"
  },
  "cols": 3,
  "rows": 3
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "[OneSignal deleteTags:@[@\"key1\", @\"key2\"]];",
      "language": "objectivec"
    },
    {
      "code": "OneSignal.deleteTags([\"key1\", \"key2\"])",
      "language": "swift",
      "name": "Swift"
    }
  ]
}
[/block]
## Data

### `promptLocation`
<div class="label-all label-type">Method</div>

Prompts the user for location permissions to allow geotagging from the OneSignal dashboard. This lets you send notifications based on the device's location.

Note: Requires the follow entries in your .plist file.
- `NSLocationUsageDescription`
- `NSLocationWhenInUseUsageDescription`
[block:code]
{
  "codes": [
    {
      "code": "[OneSignal promptLocation];",
      "language": "objectivec"
    },
    {
      "code": "OneSignal.promptLocation()",
      "language": "swift"
    }
  ]
}
[/block]
### `syncHashedEmail`
<div class="label-all label-type">Method</div>

Sync hashed email if you have a login system or collect it. Will be used to reach the user at the most optimal time of day.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-2": "the email address to hash and save with OneSignal",
    "0-0": "`email`",
    "0-1": "NSString"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "[OneSignal syncHashedEmail:@\"johndoe@example.com\"];",
      "language": "objectivec"
    },
    {
      "code": "OneSignal.syncHashedEmail(\"johndoe@example.com\")",
      "language": "swift"
    }
  ]
}
[/block]
## Sending Notifications
### `postNotification`
<div class="label-all label-type">Method</div>

Allows you to send notifications from user to user or schedule ones in the future to be delivered to the current device.

See the [Create notification](ref:create-notification) REST API POST call for a list of all possible options. Note: You can only use `include_player_ids` as a targeting parameter from your app. Other target options such as `tags` and `included_segments` require your OneSignal App REST API key which can only be used from your server.
[block:parameters]
{
  "data": {
    "2-0": "`onFailure(Optional)`",
    "1-0": "`onSuccess(Optional)`",
    "1-1": "OneSignalResultSuccessBlock",
    "2-1": "OneSignalFailureBlock",
    "0-1": "NSDictionary*",
    "0-0": "`parameters`",
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-2": "Dictionary of notification options, see our [Create notification](ref:create-notification) POST call for all options.",
    "1-2": "Called if there were no errors sending the notification",
    "2-2": "Called if there was an error"
  },
  "cols": 3,
  "rows": 3
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "[OneSignal postNotification:@{\n   @\"contents\" : @{@\"en\": @\"Test Message\"},\n   @\"include_player_ids\": @[@\"3009e210-3166-11e5-bc1b-db44eb02b120\"]\n}];",
      "language": "objectivec"
    },
    {
      "code": "OneSignal.postNotification([\"contents\": [\"en\": \"Test Message\"], \"include_player_ids\": [\"3009e210-3166-11e5-bc1b-db44eb02b120\"]])",
      "language": "swift"
    }
  ]
}
[/block]

### `ClearOneSignalNotifications`
<div class="label-all label-type">Method</div>

iOS provides a standard way to clear notifications by clearing badge count, thus there is no specific OneSignal API call for clearing notifications.


### `setSubscription`
<div class="label-all label-type">Method</div>

You can call this method with false to opt users out of receiving all notifications through OneSignal. You can pass true later to opt users back into notifications.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`enable`",
    "0-1": "BOOL"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "[OneSignal setSubscription:false];",
      "language": "objectivec"
    },
    {
      "code": "OneSignal.setSubscription(false)",
      "language": "swift"
    }
  ]
}
[/block]
## Receiving Notifications

### `OSHandleNotificationReceivedBlock`
<div class="label-all label-type">Callback</div>

Called when the app receives a notification while in focus only. *Note: If you need this to be called when your app is in the background, set `content_available` to `true` when you [create your notification](https://documentation.onesignal.com/reference#section-content-language). The "force-quit" state (i.e app was swiped away) is not currently supported.*
[block:parameters]
{
  "data": {
    "0-0": "`notification`",
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-1": "[OSNotification](#section--osnotification-)"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "^(OSNotification *notification) {\n\tNSLog(@\"Received Notification - %@ - %@\", notification.payload.notificationID, notification.payload.title);\n}",
      "language": "objectivec"
    },
    {
      "code": "{ notification in\n\tprint(\"Received Notification - \\(notification.payload.notificationID) - \\(notification.payload.title)\")\n}",
      "language": "swift"
    }
  ]
}
[/block]
### `OSHandleNotificationActionBlock`
<div class="label-all label-type">Callback</div>

Called when the user opens or taps an action on a notification.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`result`",
    "0-1": "[OSNotificationOpenedResult](#section--osnotificationopenedresult-)"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "^(OSNotificationOpenedResult *result) {\n        \n   // This block gets called when the user opens or taps an action on a notification\n   OSNotificationPayload* payload = result.notification.payload;\n        \n   NSString* messageTitle = @\"OneSignal Example\";\n   NSString* fullMessage = [payload.body copy];\n        \n   if (payload.additionalData) {\n      if (payload.title)\n         messageTitle = payload.title;\n            \n      NSDictionary* additionalData = payload.additionalData;\n            \n      if (additionalData[@\"actionSelected\"])\n         fullMessage = [fullMessage stringByAppendingString:[NSString stringWithFormat:@\"\\nPressed ButtonId:%@\", additionalData[@\"actionSelected\"]]];\n   }\n  \n   UIAlertView* alertView = [[UIAlertView alloc]\n                               initWithTitle:messageTitle\n                                     message:fullMessage\n                                    delegate:self\n                           cancelButtonTitle:@\"Close\"\n                          otherButtonTitles:nil, nil];\n   [alertView show];\n}",
      "language": "objectivec"
    },
    {
      "code": "{ result in\n                \n\t// This block gets called when the user reacts to a notification received\n\tlet payload: OSNotificationPayload = result!.notification.payload\n\tvar fullMessage = payload.body\n                \n\t//Try to fetch the action selected\n\tif let additionalData = payload.additionalData, actionSelected = additionalData[\"actionSelected\"] as? String {\n\t\tfullMessage =  fullMessage + \"\\nPressed ButtonId:\\(actionSelected)\"\n\t}\n\tprint(\"fullMessage = \\(fullMessage)\")\n}",
      "language": "swift",
      "name": "Swift"
    }
  ]
}
[/block]
### `OSNotificationOpenedResult`
<div class="label-all label-type">Interface Element</div>

The information returned from a notification the user received. Resulting class passed to [OSHandleNotificationActionBlock](#section--oshandlenotificationactionblock-).
[block:parameters]
{
  "data": {
    "0-0": "`notification`([OSNotification](#section--osnotification-));",
    "1-0": "`action`([OSNotificationAction](#section--osnotificationaction-));",
    "h-0": "Class Properties"
  },
  "cols": 1,
  "rows": 2
}
[/block]
### `OSNotification`
<div class="label-all label-type">Interface Element</div>

The notification the user received.
[block:parameters]
{
  "data": {
    "h-0": "Class Properties",
    "0-0": "`payload`([OSNotificationPayload](#section--osnotificationpayload-));",
    "0-1": "",
    "1-0": "`displayType`([OSNotificationDisplayType](#section--osnotificationdisplaytype-));",
    "1-1": "",
    "2-0": "`shown`(*BOOL*);",
    "2-1": "True when the user was able to see the notification. False when app is in focus and in-app alerts are disabled, or the remote notification is silent.",
    "3-1": "True when the received notification is silent. Silent means there is no alert, sound, or badge payload in the APS dictionary. Requires remote-notification within UIBackgroundModes array of the Info.plist",
    "3-0": "`silentNotification`(*BOOL*);"
  },
  "cols": 2,
  "rows": 4
}
[/block]
### `OSNotificationAction`
<div class="label-all label-type">Interface Element</div>

The action the user took on the notification.
[block:parameters]
{
  "data": {
    "0-0": "`actionID`(*NSString*);",
    "h-0": "Class Properties",
    "0-1": "The ID associated with the button tapped. NULL when the actionType is NotificationTapped or InAppAlertClosed.",
    "1-0": "`type`([OSNotificationActionType](#section--osnotificationactiontype-));",
    "1-1": "The type of the notification action."
  },
  "cols": 2,
  "rows": 2
}
[/block]
### `OSNotificationActionType`
<div class="label-all label-type">Interface Element</div>

The action type (*NSUInteger Enum*) associated to an OSNotificationAction object.
[block:parameters]
{
  "data": {
    "1-0": "`ActionTaken`",
    "0-0": "`Opened`",
    "h-0": "NSUInteger Enum Properties"
  },
  "cols": 1,
  "rows": 2
}
[/block]
### `OSNotificationDisplayType`
<div class="label-all label-type">Interface Element</div>

The way in which a notification was displayed to the user (*NSUInteger Enum*).
[block:parameters]
{
  "data": {
    "0-0": "`Notification`",
    "1-0": "`InAppAlert`",
    "2-0": "`None`",
    "2-1": "0",
    "1-1": "1",
    "0-1": "2",
    "h-0": "NSUInteger Enum Properties",
    "h-2": "",
    "0-2": "iOS native notification display.",
    "1-2": "Default UIAlertView display.",
    "2-2": "Notification is silent, or app is in focus but InAppAlertNotifications are disabled.",
    "h-1": "Raw Value"
  },
  "cols": 3,
  "rows": 3
}
[/block]
### `OSNotificationPayload`
<div class="label-all label-type">Interface Element</div>

Contents and settings of the notification the user received. 
[block:parameters]
{
  "data": {
    "h-0": "Class Properties",
    "0-0": "`notificationID` (*NSString*);",
    "1-0": "`contentAvailable`(*BOOL*);",
    "0-1": "OneSignal notification UUID",
    "1-1": "Provide this key with a value of 1 to indicate that new content is available. Including this key and value means that when your app is launched in the background or resumed `application:didReceiveRemoteNotification:fetchCompletionHandler:` is called.",
    "2-0": "`badge`(*NSInteger*);",
    "3-0": "`sound`(*NSString*);",
    "3-1": "The sound parameter passed to the notification. By default set to `UILocalNotificationDefaultSoundName`. [Read more about custom sounds](doc:customize-notification-sounds)",
    "2-1": "The badge number assigned to the application icon",
    "4-0": "`title`(*NSString*);",
    "4-1": "Title text of the notification",
    "5-1": "Body text of the notification",
    "6-1": "<span class=\"label-all label-ios\">iOS 10+</span> - subtitle text of the notification",
    "7-1": "Web address to launch within the app via a `UIWebView`",
    "8-1": "Additional Data add to the notification by you",
    "9-1": "<span class=\"label-all label-ios\">iOS 10+</span> - Attachments sent as part of the rich notification",
    "10-1": "Action buttons set on the notification",
    "11-1": "Holds the raw APS payload received",
    "5-0": "`body` (*NSString*);",
    "6-0": "`subtitle` (*NSString*);",
    "11-0": "`rawPayload`(*NSDictionary*);",
    "10-0": "`actionButtons`(*NSArray*);",
    "9-0": "`attachments`(*NSDictionary*);",
    "8-0": "`additionalData`(*NSDictionary*);",
    "7-0": "`launchURL`(*NSString*);"
  },
  "cols": 2,
  "rows": 12
}
[/block]
## Debug
### `setLogLevel`
<div class="label-all label-type">Method</div>

Enable logging to help debug if you run into an issue setting up OneSignal. This selector is static so you can call it before OneSignal init. The following options are available with increasingly more information; `ONE_S_LL_NONE`, `ONE_S_LL_FATAL`, `ONE_S_LL_ERROR`, `ONE_S_LL_WARN`, `ONE_S_LL_INFO`, `ONE_S_LL_DEBUG`, `ONE_S_LL_VERBOSE`.
[block:parameters]
{
  "data": {
    "h-0": "Parameters",
    "0-0": "`logLevel`",
    "1-0": "`visualLevel`",
    "1-1": "LOG_LEVEL",
    "0-1": "LOG_LEVEL",
    "0-2": "Sets the logging level to print to the Xcode log",
    "1-2": "Sets the logging level to show as alert dialogs.",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 2
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "[OneSignal setLogLevel:ONE_S_LL_DEBUG visualLevel:ONE_S_LL_DEBUG];",
      "language": "objectivec"
    },
    {
      "code": "OneSignal.setLogLevel(.LL_DEBUG, visualLevel: .LL_DEBUG)",
      "language": "swift"
    }
  ]
}
[/block]
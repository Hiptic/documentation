---
title: "Android Native SDK"
excerpt: "OneSignal <span class=\"label-all label-android\">Android</span> Native API Reference\n<div class=\"tag-all tag-developers\">For Developers</div>"
---
[block:callout]
{
  "type": "info",
  "title": "Just starting with Android?",
  "body": "Check out our [Android SDK Setup guide](doc:android-sdk-setup)."
}
[/block]

[block:callout]
{
  "type": "warning",
  "title": "Upgrade to 3.5.1+",
  "body": "A number the methods and classes below were recently added in our 3.5.1 SDK. Make sure you have updated to this version."
}
[/block]

[block:parameters]
{
  "data": {
    "0-0": "### Initialization",
    "0-1": "",
    "2-0": "[startInit](#section--startinit-)",
    "2-1": "Method",
    "h-2": "",
    "0-2": "",
    "2-2": "",
    "h-0": "",
    "1-0": "[init](#section--init-)",
    "1-1": "Builder Method",
    "1-2": "Initialize OneSignal",
    "10-0": "### Status",
    "11-0": "[getPermissionSubscriptionState](#section--getpermissionsubscriptionstate-)",
    "11-1": "Method",
    "11-2": "Current Permission and Subscription status",
    "14-0": "### Tags",
    "15-0": "[getTags](#section--gettags-)",
    "15-1": "Method",
    "18-1": "Method",
    "19-1": "Method",
    "20-1": "Method",
    "15-2": "View Tags from a User",
    "18-2": "",
    "20-2": "",
    "19-2": "Delete a Tag from a User",
    "18-0": "[sendTags](#section--sendtags-)",
    "19-0": "[deleteTag](#section--deletetag-)",
    "20-0": "[deleteTags](#section--deletetags-)",
    "21-0": "### Data",
    "24-0": "### Manage Notifications",
    "30-0": "### Notification Events",
    "25-0": "[postNotification](#section--postnotification-)",
    "26-0": "[cancelNotification](#section--cancelnotification-)",
    "27-0": "[clearOneSignalNotifications](#section--clearonesignalnotifications-)",
    "28-0": "[setSubscription](#section--setsubscription-)",
    "28-1": "Method",
    "27-1": "Method",
    "25-1": "Method",
    "26-1": "Method",
    "31-0": "[NotificationReceivedHandler](#section--notificationreceivedhandler-)",
    "31-1": "Handler",
    "39-0": "### Appearance",
    "41-0": "[enableVibrate](#section--enablevibrate-)",
    "42-0": "[enableSound](#section--enablesound-)",
    "41-1": "Method",
    "42-1": "Method",
    "43-0": "[Disable Badges](#section-disable-badges)",
    "43-1": "Android Manifest",
    "33-0": "[Opened Action](#section-opened-action)",
    "33-1": "Android Manifest",
    "44-0": "### Debug",
    "45-0": "[setLogLevel](#section--setloglevel-)",
    "45-1": "Method",
    "23-1": "Method",
    "23-0": "[syncHashedEmail](#section--synchashedemail-)",
    "22-0": "[promptLocation](#section--promptlocation-)",
    "22-1": "Method",
    "5-0": "[autoPromptLocation](#section--autopromptlocation-)",
    "5-1": "Builder Method",
    "6-1": "Builder Method",
    "6-0": "[disableGmsMissingPrompt](#section--disablegmsmissingprompt-)",
    "5-2": "Automatically Prompt Users for Location",
    "6-2": "Automatically Prompt User to update Google Play if out of date",
    "22-2": "Prompt Users for Location",
    "23-2": "Sync Anonymized User Email",
    "25-2": "Send or schedule a notification to a user",
    "26-2": "Delete a single app notification",
    "28-2": "Opt users in or out of receiving notifications",
    "27-2": "Delete all app notifications",
    "31-2": "When a notification is received by a device",
    "33-2": "Disable resuming launcher activity when notification is opened",
    "41-2": "When user receives notification, vibrate device less",
    "42-2": "When user receives notification, do not play a sound",
    "43-2": "Disable badge counts in your app",
    "45-2": "Enable logging to help debug OneSignal implementation",
    "17-0": "[sendTag](#section--sendtag-)",
    "17-1": "Method",
    "17-2": "Add a Tag to a User",
    "32-0": "[NotificationOpenedHandler](#section--notificationopenedhandler-)",
    "32-1": "Handler",
    "32-2": "When a user takes an action on a notification",
    "29-0": "[NotificationExtenderService](#section--notificationextenderservice-)",
    "29-1": "Method + Manifest",
    "29-2": "Add custom data to a notification, or override notification options",
    "3-0": "[setNotificationReceivedHandler](#section--setnotificationreceivedhandler-)",
    "4-0": "[setNotificationOpenedHandler](#section--setnotificationopenedhandler-)",
    "3-1": "Builder Method",
    "4-1": "Builder Method",
    "16-0": "[tagsAvailable](#section--tagsavailable-)",
    "16-1": "Method",
    "7-0": "[unsubscribeWhenNotificationsAreDisabled](#section--unsubscribewhennotificationsaredisabled-)",
    "7-1": "Builder Method",
    "7-2": "If notifications are disabled for your app unsubscribe them from OneSignal.",
    "12-0": "[addPermissionObserver](https://documentation.onesignal.com/docs/android-native-sdk#section--addpermissionobserver-)",
    "12-2": "Permission status changes",
    "12-1": "Method",
    "13-0": "[addSubscriptionObserver](#section--addsubscriptionobserver-)",
    "13-1": "Method",
    "13-2": "Subscription status changes",
    "34-0": "### Objects",
    "35-0": "[OSNotificationOpenResult](#section--osnotificationopenresult-)",
    "35-2": "Information returned from a notification the user received",
    "35-1": "Object",
    "36-0": "[OSNotification](#section--osnotification-)",
    "36-1": "Object",
    "36-2": "Notification the user received",
    "37-0": "[OSNotificationAction](#section--osnotificationaction-)",
    "37-2": "Action the user took on the notification",
    "38-0": "[OSNotificationPayload](#section--osnotificationpayload-)",
    "38-2": "Contents and settings of the notification the user received",
    "8-0": "[filterOtherGCMReceivers](#section--filterothergcmreceivers-)",
    "8-1": "Builder Method",
    "8-2": "Enable to prevent other broadcast receivers from receiving OneSignal FCM / GCM payloads.",
    "40-0": "[setInFocusDisplaying](#section--setinfocusdisplaying-)",
    "40-1": "Method",
    "40-2": "Change how the notification is displayed when your app is actively being used.",
    "9-0": "[setInFocusDisplaying](#section--setinfocusdisplaying-)",
    "9-1": "Method",
    "9-2": "Change how the notification is displayed when your app is actively being used."
  },
  "cols": 3,
  "rows": 46
}
[/block]

## Initialization

### `init`
<div class="label-all label-type">Builder Method</div>

Initializes OneSignal to register the device for push notifications. Should be called in the `onCreate` method of your Application class.
[block:code]
{
  "codes": [
    {
      "code": "OneSignal.startInit(this).init();",
      "language": "java"
    }
  ]
}
[/block]
### `startInit`
<div class="label-all label-type">Method</div>

Initializes OneSignal to register the device for push notifications. Should be call in the `onCreate` of your Application class.

[block:parameters]
{
  "data": {
    "0-0": "`context`",
    "0-1": "Context",
    "0-2": "Your Application context.",
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 1
}
[/block]
#### Returns
`OneSignal.Builder` - See below for a list of methods available.
[block:code]
{
  "codes": [
    {
      "code": "public class YourAppClass extends Application {\n   @Override\n   public void onCreate() {\n      super.onCreate();\n      OneSignal.startInit(this).init();\n   }\n}",
      "language": "java"
    }
  ]
}
[/block]
### `autoPromptLocation`
<div class="label-all label-type">Builder Method</div>

Prompts the user for location permissions. This allows for geotagging so you can send notifications to users based on location. See [promptLocation](#section--promptlocation-) for more details.
[block:parameters]
{
  "data": {
    "0-0": "`prompt`",
    "0-1": "boolean",
    "0-2": "<p>`false` (<span class=\"label-all label-default\">Default</span>) - do not prompt</p>\n<p>`true` - prompt users for location permissions when your app starts.</p>",
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.startInit(this)\n  .autoPromptLocation(true)\n  .init();",
      "language": "java"
    }
  ]
}
[/block]
### `setNotificationReceivedHandler`
<div class="label-all label-type">Builder Method</div>

Sets a notification received handler that will fire when a notification is received. It will be fired when your app is in focus or in the background.
[block:parameters]
{
  "data": {
    "0-0": "`handler`",
    "0-1": "[NotificationReceivedHandler](#section--notificationreceivedhandler-)",
    "0-2": "Instance to a class implementing this interference.",
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.startInit(this)   \n   .setNotificationReceivedHandler(new ExampleNotificationReceivedHandler())\n   .init();",
      "language": "java"
    }
  ]
}
[/block]
See the [NotificationReceivedHandler](#section--notificationreceivedhandler-) documentation for an example of the `ExampleNotificationReceivedHandler` class.


### `setNotificationOpenedHandler`
<div class="label-all label-type">Builder Method</div>

Sets a notification opened handler. The instance will be called when a notification is tapped on from the notification shade or when closing an Alert notification shown in the app.
[block:parameters]
{
  "data": {
    "0-0": "`handler`",
    "0-1": "[NotificationOpenedHandler](#section--notificationopenedhandler-)",
    "0-2": "Instance to a class implementing this interference.",
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.startInit(this)   \n   .setNotificationOpenedHandler(new ExampleNotificationOpenedHandler())\n   .init();",
      "language": "java"
    }
  ]
}
[/block]
See the [NotificationOpenedHandler](#section--notificationopenedhandler-) documentation for an example of the `ExampleNotificationOpenedHandler` class.


### `setInFocusDisplaying` 
<div class="label-all label-type">Method</div>

Setting to control how OneSignal notifications will be shown when one is received while your app is in focus.

`Notification` - native notification display while user has app in focus (can be distracting).
`InAppAlert` (<span class="label-all label-default">Default</span>) - native alert dialog display, which can be helpful during development.
`None` - notification is silent.
[block:code]
{
  "codes": [
    {
      "code": "OneSignal.setInFocusDisplaying(OneSignal.OSInFocusDisplayOption.Notification);",
      "language": "java"
    }
  ]
}
[/block]
### `disableGmsMissingPrompt`
<div class="label-all label-type">Builder Method</div>

Prompts the user to update/enable Google Play services if it's disabled on the device.
[block:parameters]
{
  "data": {
    "0-0": "`prompt`",
    "0-1": "boolean",
    "0-2": "<p>`false` (<span class=\"label-all label-default\">Default</span>) - prompt users</p>\n\n<p>`true` to never show the out of date prompt.</p>",
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.startInit(this)\n  .disableGmsMissingPrompt(true)\n  .init();",
      "language": "java"
    }
  ]
}
[/block]
### `unsubscribeWhenNotificationsAreDisabled`
<div class="label-all label-type">Builder Method</div>

If notifications are disabled for your app unsubscribe them from OneSignal. This will happen when your users goes to Settings > Apps and turns off notifications. Or long press and one of them and selects block notifications.
This is `false` by default.
[block:code]
{
  "codes": [
    {
      "code": "OneSignal.startInit(this)\n  .unsubscribeWhenNotificationsAreDisabled(true)\n  .init();",
      "language": "java"
    }
  ]
}
[/block]
### `filterOtherGCMReceivers`
<div class="label-all label-type">Builder Method</div>

Enable to prevent other broadcast receivers from receiving OneSignal FCM / GCM payloads. Prevent thrown exceptions or double notifications form other libraries / SDKs that implement notifications. Other non-OneSignal payloads will still be passed through so your app can handle FCM / GCM payloads from other back-ends. Note however you can't use multiple Google Project numbers / Sender IDs. They must be the same if you are using multiple provides otherwise there will be unexpected unsubscribes.

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.startInit(this)\n  .filterOtherGCMReceivers(true)\n  .init();",
      "language": "java"
    }
  ]
}
[/block]
## Status

### `getPermissionSubscriptionState`
<div class="label-all label-type">Method</div>

Get the current notification and permission state. Returns a `OSPermissionSubscriptionState` type described below.
[block:parameters]
{
  "data": {
    "0-0": "`permissionStatus`",
    "0-1": "`OSPermissionState`",
    "0-2": "Android Notification Permissions state",
    "1-0": "`subscriptionStatus`",
    "1-1": "`OSSubscriptionState`",
    "1-2": "Google and OneSignal subscription state"
  },
  "cols": 3,
  "rows": 2
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OSPermissionSubscriptionState status = OneSignal.getPermissionSubscriptionState();\nstatus.getPermissionStatus().getEnabled();\n    \nstatus.getSubscriptionStatus().getSubscribed();\nstatus.getSubscriptionStatus().getUserSubscriptionSetting();\nstatus.getSubscriptionStatus().getUserId();\nstatus.getSubscriptionStatus().getPushToken();",
      "language": "java"
    }
  ]
}
[/block]
#### OSPermissionSubscriptionState

### `addPermissionObserver`
<div class="label-all label-type">Handler</div>

The `onOSPermissionChanged` method will be fired on the passed in object when a notification permission setting changes. This happens when the user enables or disables notifications for your app from the system settings outside of your app. Disable detection is supported on Android 4.4+.
[block:code]
{
  "codes": [
    {
      "code": "public class MainActivity extends Activity implements OSPermissionObserver {\n  protected void onCreate(Bundle savedInstanceState) {\n    OneSignal.addPermissionObserver(this);\n  }\n  \n  public void onOSPermissionChanged(OSPermissionStateChanges stateChanges) {\n    if (stateChanges.getFrom().getEnabled() &&\n        !stateChanges.getTo().getEnabled()) {\n         new AlertDialog.Builder(this)\n             .setMessage(\"Notifications Disabled!\")\n             .show();\n      }\n   \n      Log.i(\"Debug\", \"onOSPermissionChanged: \" + stateChanges);\n  }\n}\n\n// Example Logcat entry - User disabling notifications then returning to your app.\n// onOSPermissionChanged{\"from\":{\"enabled\":true},\"to\":{\"enabled\":false}}",
      "language": "java"
    }
  ]
}
[/block]
### `addSubscriptionObserver`
<div class="label-all label-type">Method</div>

The `onOSSubscriptionChanged` method will be fired on the passed in object when a notification subscription property changes.

This includes the following events:
* Getting a Registration Id (push token) from Google
* Getting a player / user id from OneSignal
* `OneSignal.setSubscription` is called
* User disables or enables notifications

[block:code]
{
  "codes": [
    {
      "code": "public class MainActivity extends Activity implements OSSubscriptionObserver {\n  protected void onCreate(Bundle savedInstanceState) {\n    OneSignal.addSubscriptionObserver(this);\n  }\n  \n  public void onOSSubscriptionChanged(OSSubscriptionStateChanges stateChanges) {\n    if (!stateChanges.getFrom().getSubscribed() &&\n        stateChanges.getTo().getSubscribed()) {\n         new AlertDialog.Builder(this)\n             .setMessage(\"You've successfully subscribed to push notifications!\")\n             .show();\n      }\n   \n      Log.i(\"Debug\", \"onOSPermissionChanged: \" + stateChanges);\n  }\n}\n\n/*\nExample Logcat entry - User disabling notifications then returning to your app.\nonOSSubscriptionChanged:\n{\"from\":{\"pushToken\":\"APA91bG9cmZ262s5gJhr8jvbg1q7aiviEC6lcOCgAQliEzHKO3eOdX5cm7IQqMSWfy8Od7Ol3jSjFfvCfeO2UYUpanJCURJ8RdhgEuV8grYxOCwPNJr5GoqcWTQOaL9u-qE2PQcFlv4K\",\"userSubscriptionSetting\":true,\"subscribed\":false},\n \"to\":  {\"userId\":\"22712a53-9b5c-4eab-a828-f18f81167fef\",\"pushToken\":\"APA91bG9cmZ262s5gJhr8jvbg1q7aiviEC6lcOCgAQliEzHKO3eOdX5cm7IQqMSWfy8Od7Ol3jSjFfvCfeO2UYUpanJCURJ8RdhgEuV8grYxOCwPNJr5GoqcWTQOaL9u-qE2PQcFlv4K\",\"userSubscriptionSetting\":true,\"subscribed\":true}}",
      "language": "java"
    }
  ]
}
[/block]
## Tags

### `sendTag`
<div class="label-all label-type">Method</div>

Tag a user based on an app event of your choosing so later you can create segments in <a class="dash-link" href="segmentation">Segments</a> to target these users. Use `sendTags` if you need to set more than one tag on a user at a time.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "0-0": "`key`",
    "1-0": "`value`",
    "0-1": "String",
    "1-1": "String",
    "0-2": "Key of your choosing to create or update.",
    "1-2": "Value to set on the key. _NOTE:_ Passing in a blank String deletes the key, you can also call `deleteTag` or `deleteTags`.",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 2
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.sendTag(\"key\", \"value\");",
      "language": "java"
    }
  ]
}
[/block]
### `sendTags`
<div class="label-all label-type">Method</div>

Tag a user based on an app event of your choosing so later you can create segments in <a class="dash-link" href="segmentation">Segments</a> to target these users.
[block:parameters]
{
  "data": {
    "0-0": "`keyValues`",
    "0-1": "JSONObject",
    "0-2": "Key value pairs of your choosing to create or update. _NOTE:_ Passing in a blank String as a value deletes the key, you can also call `deleteTag` or `deleteTags`.",
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "\tJSONObject tags = new JSONObject();\n\ttags.put(\"key1\", \"value1\");\n\ttags.put(\"key2\", \"value2\");\n\tOneSignal.sendTags(tags);",
      "language": "java"
    }
  ]
}
[/block]
### `getTags`
<div class="label-all label-type">Method</div>

Retrieve a list of tags that have been set on the user from the OneSignal server.
[block:parameters]
{
  "data": {
    "0-0": "`handler`",
    "0-1": "GetTagsHandler",
    "0-2": "Calls `tagsAvailable` on the Object once the tags are available.",
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.getTags(new GetTagsHandler() {\n\t@Override\n\tpublic void tagsAvailable(JSONObject tags) {\n\t\tLog.d(\"debug\", tags.toString());\n\t}\n});",
      "language": "java",
      "name": null
    }
  ]
}
[/block]
### `GetTagsHandler`
<div class="label-all label-type">Handler</div>

Interface which you can implement and pass to `OneSignal.getTags` to get the all the tags set on a user from onesignal.com.


### `deleteTag`
<div class="label-all label-type">Method</div>

Deletes a single tag that was previously set on a user with `sendTag` or `sendTags`. Use `deleteTags` if you need to delete more than one.
[block:parameters]
{
  "data": {
    "0-0": "`key`",
    "0-1": "String",
    "0-2": "Key to remove.",
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.deleteTag(\"key\");",
      "language": "java"
    }
  ]
}
[/block]
### `deleteTags`
<div class="label-all label-type">Method</div>

Deletes one or more tags that were previously set on a user with `sendTag` or `sendTags`.
[block:parameters]
{
  "data": {
    "0-0": "`keys`",
    "0-1": "Collection<String>",
    "0-2": "Keys to remove.",
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "Collection<String> tempList = new ArrayList<String>();\ntempList.add(key);\nOneSignal.deleteTags(tempList);",
      "language": "java"
    }
  ]
}
[/block]
### `tagsAvailable`
<div class="label-all label-type">Method</div>
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "0-0": "`tags`",
    "0-1": "JSONObject",
    "0-2": "Contains key-value pairs retrieved from the OneSignal server",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.getTags(new GetTagsHandler() {\n  @Override\n\tpublic void tagsAvailable(JSONObject tags) {\n\t\tLog.d(\"debug\",\"Current Tags on User:\" + tags.toString());\n\t}\n});",
      "language": "java"
    }
  ]
}
[/block]



## Data
### `promptLocation`
<div class="label-all label-type">Method</div>

Prompts the user for location permissions. This allows for geotagging so you can send notifications to users based on location.
[block:code]
{
  "codes": [
    {
      "code": "OneSignal.promptLocation();",
      "language": "java"
    }
  ]
}
[/block]
Make sure you have one of the following permissions in your `AndroidManifest.xml` as well.
[block:code]
{
  "codes": [
    {
      "code": "<uses-permission android:name=\"android.permission.ACCESS_FINE_LOCATION\"/>\n<uses-permission android:name=\"android.permission.ACCESS_COARSE_LOCATION\"/>",
      "language": "xml"
    }
  ]
}
[/block]
### `syncHashedEmail`
<div class="label-all label-type">Method</div>

Sync hashed email if you have a login system or collect it. Will be used to reach the user at the most optimal time of day.
[block:code]
{
  "codes": [
    {
      "code": "OneSignal.syncHashedEmail(\"test@domain.com\");",
      "language": "java"
    }
  ]
}
[/block]




## Sending Notifications

### `postNotification`
<div class="label-all label-type">Method</div>

Allows you to send notifications from user to user or schedule ones in the future to be delivered to the current device.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "0-0": "`parameters`",
    "0-1": "JSONObject",
    "0-2": "Contains notification options, see [Create Notification](ref:create-notification) POST call for all options.",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 1
}
[/block]
#### `postNotificationResponseHandler`
Fires delegate when the notification was created or fails to be created.
[block:parameters]
{
  "data": {
    "h-0": "Response",
    "h-1": "Method",
    "h-2": "",
    "0-1": "`void onSuccess(JSONObject response)`",
    "0-0": "Success",
    "1-0": "Failure",
    "1-1": "`void onFailure(JSONObject response)`"
  },
  "cols": 2,
  "rows": 2
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "try {\n  OneSignal.postNotification(new JSONObject(\"{'contents': {'en':'Test Message'}, 'include_player_ids': ['\" + userId + \"']}\"), null);\n} catch (JSONException e) {\n  e.printStackTrace();\n}",
      "language": "java",
      "name": "Simple"
    },
    {
      "code": "try {\n  OneSignal.postNotification(new JSONObject(\"{'contents': {'en':'Test Message'}, 'include_player_ids': ['\" + \"userId\" + \"']}\"),\n     new OneSignal.PostNotificationResponseHandler() {\n       @Override\n       public void onSuccess(JSONObject response) {\n         Log.i(\"OneSignalExample\", \"postNotification Success: \" + response.toString());\n       }\n\n       @Override\n       public void onFailure(JSONObject response) {\n         Log.e(\"OneSignalExample\", \"postNotification Failure: \" + response.toString());\n       }\n     });\n} catch (JSONException e) {\n  e.printStackTrace();\n}",
      "language": "java",
      "name": "With Response Handler"
    }
  ]
}
[/block]
See the [Create Notification](ref:create-notification) REST API POST call for a list of all possible options. Note: You can only use `include_player_ids` as a targeting parameter from your app. Other target options such as `tags` and `included_segments` require your OneSignal App REST API key which can only be used from your server.


### `cancelNotification`
<div class="label-all label-type">Method</div>

Cancels a single OneSignal notification based on its Android notification integer id. Use instead of `NotificationManager.cancel(id);` otherwise the notification will be restored when your app is restarted.
[block:code]
{
  "codes": [
    {
      "code": "int id = 1234;\nOneSignal.cancelNotification(id);",
      "language": "java"
    }
  ]
}
[/block]
### `clearOneSignalNotifications`
<div class="label-all label-type">Method</div>

Removes all OneSignal notifications from the Notification Shade. If you just use `NotificationManager.cancelAll();` OneSignal notifications will be restored your app is restarted.
[block:code]
{
  "codes": [
    {
      "code": "OneSignal.clearOneSignalNotifications();",
      "language": "java"
    }
  ]
}
[/block]
### `setSubscription`
<div class="label-all label-type">Method</div>

You can call this method with false to opt users out of receiving all notifications through OneSignal. You can pass true later to opt users back into notifications.
[block:parameters]
{
  "data": {
    "0-0": "`enable`",
    "0-1": "boolean",
    "0-2": "",
    "h-0": "Parameter",
    "h-1": "Type"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.setSubscription(false);",
      "language": "java"
    }
  ]
}
[/block]
### `NotificationExtenderService`
<div class="label-all label-type">Method</div>

OneSignal supports sending additional data along with a notification as key value pairs. You can read this additional data when a notification is opened by adding a [NotificationOpenedHandler](#section--notificationopenedhandler-) instead.

However if you want to do one of the following continue with the instructions below.
* Receive data in the background with or without displaying a notification.
* Override specific notification settings depending on client side app logic such as custom accent color, vibration pattern, or other any other `NotificationCompat` options available.

**1.** Create a class that extents `NotificationExtenderService` and implement the `onNotificationProcessing` method.
[block:code]
{
  "codes": [
    {
      "code": "import com.onesignal.OSNotificationPayload;\nimport com.onesignal.NotificationExtenderService;\n\npublic class NotificationExtenderBareBonesExample extends NotificationExtenderService {\n   @Override\n   protected boolean onNotificationProcessing(OSNotificationReceivedResult receivedResult) {\n     \t// Read properties from result.\n     \n      // Return true to stop the notification from displaying.\n      return false;\n   }\n}",
      "language": "java"
    }
  ]
}
[/block]
**2.**  Add the following to your `AndroidManifest.xml`.
*Replace 'YOUR_CLASS_NAME' with the class name you used above.*
[block:code]
{
  "codes": [
    {
      "code": "<service\n   android:name=\".YOUR_CLASS_NAME\"\n   android:exported=\"false\">\n   <intent-filter>\n      <action android:name=\"com.onesignal.NotificationExtender\" />\n   </intent-filter>\n</service>",
      "language": "xml"
    }
  ]
}
[/block]
**3.** To override or extend specific notification properties call `displayNotification` with `OverrideSettings`.
[block:code]
{
  "codes": [
    {
      "code": "import android.support.v4.app.NotificationCompat;\n\nimport com.onesignal.OSNotificationPayload;\nimport com.onesignal.NotificationExtenderService;\n\nimport java.math.BigInteger;\n\npublic class NotificationExtenderExample extends NotificationExtenderService {\n   @Override\n   protected boolean onNotificationProcessing(OSNotificationReceivedResult receivedResult) {\n      OverrideSettings overrideSettings = new OverrideSettings();\n      overrideSettings.extender = new NotificationCompat.Extender() {\n         @Override\n         public NotificationCompat.Builder extend(NotificationCompat.Builder builder) {\n            // Sets the background notification color to Green on Android 5.0+ devices.\n            return builder.setColor(new BigInteger(\"FF00FF00\", 16).intValue());\n         }\n      };\n\n      OSNotificationDisplayedResult displayedResult = displayNotification(overrideSettings);\n\t\t\tLog.d(\"OneSignalExample\", \"Notification displayed with id: \" + displayedResult.androidNotificationId);\n\n      return true;\n   }\n}",
      "language": "java"
    }
  ]
}
[/block]
**Additional Notes**
`NotificationExtenderService` is an Android `IntentService` so please do all your work synchronously. A wake lock is obtained so the device will not sleep while you're processing the payload. 






## Receiving Notifications

### `NotificationReceivedHandler`
<div class="label-all label-type">Handler</div>

Fires when a notification is received. It will be fired when your app is in focus or in the background.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "0-0": "`notification`",
    "0-1": "[OSNotification](#section--osnotification-)",
    "0-2": "Contains both the user's response and properties of the notification.",
    "h-1": "Type",
    "h-2": "Description",
    "0-3": "",
    "h-3": ""
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:callout]
{
  "type": "warning",
  "body": "- If you will be displaying your own in app message when a notification is received make sure to call [inFocusDisplaying](#section--infocusdisplaying-) with `None` to disable OneSignal's in app AlertBox.\n- If want to change how a notification is displayed in the notification shade or process a silent notification when your app isn't running see our [Background Data and Notification Overriding](doc:android-customizations#section-background-data-and-notification-overriding) guide.",
  "title": "Important behavior notes"
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "class ExampleNotificationReceivedHandler implements OneSignal.NotificationReceivedHandler {\n  @Override\n  public void notificationReceived(OSNotification notification) {\n    JSONObject data = notification.payload.additionalData;\n    String customKey;\n\n    if (data != null) {\n      customKey = data.optString(\"customkey\", null);\n      if (customKey != null)\n        Log.i(\"OneSignalExample\", \"customkey set with value: \" + customKey);\n    }\n  }\n}",
      "language": "java"
    }
  ]
}
[/block]
### `NotificationOpenedHandler`
<div class="label-all label-type">Handler</div>

Use to process a OneSignal notification the user just tapped on.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "0-0": "`result`",
    "0-1": "[OSNotificationOpenResult](#section--osnotificationopenresult-)",
    "0-2": "Contains both the user's response and properties of the notification.",
    "h-2": "Description",
    "h-1": "Type",
    "0-3": "",
    "h-3": "Description"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "class ExampleNotificationOpenedHandler implements OneSignal.NotificationOpenedHandler {\n  // This fires when a notification is opened by tapping on it.\n  @Override\n  public void notificationOpened(OSNotificationOpenResult result) {\n    OSNotificationAction.ActionType actionType = result.action.type;\n    JSONObject data = result.notification.payload.additionalData;\n    String customKey;\n\n    if (data != null) {\n      customKey = data.optString(\"customkey\", null);\n      if (customKey != null)\n        Log.i(\"OneSignalExample\", \"customkey set with value: \" + customKey);\n    }\n\n    if (actionType == OSNotificationAction.ActionType.ActionTaken)\n      Log.i(\"OneSignalExample\", \"Button pressed with id: \" + result.action.actionID);\n\n    // The following can be used to open an Activity of your choice.\n    // Replace - getApplicationContext() - with any Android Context.\n    // Intent intent = new Intent(getApplicationContext(), YourActivity.class);\n    // intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT | Intent.FLAG_ACTIVITY_NEW_TASK);\n    // startActivity(intent);\n\n     // Add the following to your AndroidManifest.xml to prevent the launching of your main Activity\n     //   if you are calling startActivity above.\n     /* \n        <application ...>\n          <meta-data android:name=\"com.onesignal.NotificationOpened.DEFAULT\" android:value=\"DISABLE\" />\n        </application>\n     */\n  }\n}",
      "language": "java"
    }
  ]
}
[/block]
### `OSNotificationOpenResult`
<div class="label-all label-type">Class</div>

The information returned from a notification the user received.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`notification`",
    "1-0": "`action`",
    "1-1": "[OSNotificationAction](#section--osnotificationaction-)",
    "0-1": "[OSNotification](#section--osnotification-)",
    "0-2": "Notification the user received.",
    "1-2": "The action the user took on the notification."
  },
  "cols": 3,
  "rows": 2
}
[/block]
### `OSNotification`
<div class="label-all label-type">Class</div>

The notification the user received.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`isAppInFocus`",
    "1-0": "`shown`",
    "0-1": "boolean",
    "1-1": "boolean",
    "2-1": "int",
    "3-1": "[OSNotificationPayload](#section--osnotificationpayload-)",
    "4-1": "[DisplayType](#section--displaytype-)",
    "5-1": "List<[OSNotificationPayload](#section--osnotificationpayload-)>",
    "0-2": "Was app in focus.",
    "1-2": "Was notification shown to the user. Will be false for silent notifications.",
    "2-0": "`androidNotificationId`",
    "2-2": "Android Notification assigned to the notification. Can be used to cancel or replace the notification.",
    "3-0": "`payload`",
    "3-2": "Payload received from OneSignal.",
    "4-0": "`displayType`",
    "4-2": "How the notification was displayed to the user. Can be set to `Notification`, `InAppAlert`, or `None` if it was not displayed.",
    "5-0": "`groupedNotifications`",
    "5-2": "Notification is a summary notification for a group this will contain all notification payloads it was created from."
  },
  "cols": 3,
  "rows": 6
}
[/block]
#### `DisplayType`

How the notification was displayed to the user. Part of [OSNotification](#section--osnotification-). See [inFocusDisplaying](#section--infocusdisplaying-) for more information on how this is used. 

`Notification` - native notification display.
`InAppAlert` (<span class="label-all label-default">Default</span>) - native alert dialog display.
`None` - notification is silent, or [inFocusDisplaying](#section--infocusdisplaying-) is disabled.


### `OSNotificationAction`
<div class="label-all label-type">Class</div>

The action the user took on the notification.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-1": "ActionType",
    "1-1": "String",
    "1-0": "`actionID`",
    "0-0": "`type`",
    "0-2": "Was the notification opened normally (`Opened`) or was a button pressed on the notification (`ActionTaken`).",
    "1-2": "If `type` == `ActionTaken` then this will contain the id of the button pressed."
  },
  "cols": 3,
  "rows": 2
}
[/block]
### `OSNotificationPayload`
<div class="label-all label-type">Class</div>

Contents and settings of the notification the user received.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-1": "String",
    "1-1": "String",
    "2-1": "String",
    "3-1": "JSONObject",
    "4-1": "String",
    "5-1": "String",
    "6-1": "String",
    "7-1": "String",
    "8-1": "String",
    "9-1": "String",
    "0-0": "`notificationID`",
    "1-0": "`title`",
    "2-0": "`body`",
    "3-0": "`additionalData`",
    "4-0": "`smallIcon`",
    "5-0": "`largeIcon`",
    "6-0": "`bigPicture`",
    "7-0": "`smallIconAccentColor`",
    "8-0": "`launchUrl`",
    "9-0": "`sound`",
    "10-0": "`ledColor`",
    "10-1": "String",
    "11-0": "`lockScreenVisibility`",
    "11-1": "int",
    "12-0": "`groupKey`",
    "12-1": "String",
    "13-0": "`groupMessage`",
    "13-1": "string",
    "14-0": "`actionButtons`",
    "14-1": "List<[ActionButton](#section--actionbutton-)>",
    "16-1": "[BackgroundImageLayout](#section--backgroundimagelayout-)",
    "16-0": "`backgroundImageLayout`",
    "17-0": "`rawPayload`",
    "17-1": "String",
    "17-2": "Raw JSON payload string received from OneSignal.",
    "16-2": "If a background image was set this object will be available.",
    "14-2": "List of action buttons on the notification.",
    "13-2": "Summary text displayed in the summary notification.",
    "15-0": "`fromProjectNumber`",
    "15-1": "String",
    "15-2": "The Google project number the notification was sent under.",
    "12-2": "Notifications with this same key will be grouped together as a single summary notification.",
    "11-2": "Privacy setting for how the notification should be shown on the lockscreen of Android 5+ devices. \n\n`1` (<span class=\"label-all label-default\">Default</span>) - Public (fully visible)\n`0` - Private (Contents are hidden)\n`-1` - Secret (not shown).",
    "10-2": "Devices that have a notification LED will blink in this color. ARGB format.",
    "9-2": "Sound resource to play when the notification is shown. [Read more here](doc:customize-notification-sounds)",
    "8-2": "URL to open when opening the notification.",
    "7-2": "Accent color shown around small notification icon on Android 5+ devices. ARGB format.",
    "6-2": "Big picture image set on the notification.",
    "5-2": "Large icon set on the notification.",
    "4-2": "Small icon resource name set on the notification.",
    "3-2": "Custom additional data that was sent with the notification. Set on the dashboard under Options > Additional Data or with the 'data' field on the REST API.",
    "2-2": "Body of the notification.",
    "1-2": "Title of the notification.",
    "0-2": "OneSignal notification UUID."
  },
  "cols": 3,
  "rows": 18
}
[/block]
#### `ActionButton`
<div class="label-all label-type">Object</div>

List of action buttons on the notification. Part of [OSNotificationPayload](#section--osnotificationpayload-).
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-1": "String",
    "1-1": "String",
    "2-1": "String",
    "0-0": "`id`",
    "1-0": "`text`",
    "1-2": "Text show on the button to the user.",
    "2-0": "`icon`",
    "0-2": "Id assigned to the button.",
    "2-2": "Icon shown on the button."
  },
  "cols": 3,
  "rows": 3
}
[/block]
#### `BackgroundImageLayout`
<div class="label-all label-type">Object</div>

If a background image was set, this object will be available. Part of [OSNotificationPayload](#section--osnotificationpayload-).
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-1": "String",
    "1-1": "String",
    "2-1": "String",
    "0-0": "`image`",
    "0-2": "Image URL or name used as the background image.",
    "1-2": "Text color of the title on the notification. ARGB Format.",
    "2-2": "Text color of the body on the notification. ARGB Format.",
    "1-0": "`titleTextColor`",
    "2-0": "`bodyTextColor`"
  },
  "cols": 3,
  "rows": 3
}
[/block]
### Opened Action
<div class="label-all label-type">Android Manifest</div>

By default OneSignal will open or resume your launcher Activity when a notification is tapped on. You can disable this behavior by adding the meta-data tag `com.onesignal.NotificationOpened.DEFAULT` set to `DISABLE` inside your application tag in your `AndroidManifest.xml`.
[block:code]
{
  "codes": [
    {
      "code": "<application ...>\n   <meta-data android:name=\"com.onesignal.NotificationOpened.DEFAULT\" android:value=\"DISABLE\" />\n</application>",
      "language": "xml"
    }
  ]
}
[/block]
Make sure you are initializing `OneSignal` with [setNotificationOpenedHandler](#section--setnotificationopenedhandler-) in the `onCreate` method in your `Application` class. You will need to call `startActivity` from this callback.



## Appearance

### `enableVibrate`
<div class="label-all label-type">Method</div>

By default OneSignal always vibrates the device when a notification is displayed unless the device is in a total silent mode. Passing false means that the device will only vibrate lightly when the device is in it's vibrate only mode.

*You can link this action to a UI button to give your user a vibration option for your notifications.*
[block:code]
{
  "codes": [
    {
      "code": "OneSignal.enableVibrate(false);",
      "language": "java"
    }
  ]
}
[/block]
### `enableSound`
<div class="label-all label-type">Method</div>

By default OneSignal plays the system's default notification sound when the device's notification system volume is turned on. Passing false means that the device will only vibrate unless the device is set to a total silent mode.

*You can link this action to a UI button to give your user a different sound option for your notifications.*
[block:code]
{
  "codes": [
    {
      "code": "OneSignal.enableSound(false);",
      "language": "java"
    }
  ]
}
[/block]
### Disable Badges
<div class="label-all label-type">Android Manifest</div>

The OneSignal SDK automatically sets the badge count on your app to the number of notifications that are currently in the notification shade. If you want to disable this you can add the following to your `AndroidManifest.xml`.
[block:code]
{
  "codes": [
    {
      "code": "<application ...>\n   <meta-data android:name=\"com.onesignal.BadgeCount\" android:value=\"DISABLE\" />\n</application>",
      "language": "xml"
    }
  ]
}
[/block]
You can remove the badge permissions with the following entries.
[block:code]
{
  "codes": [
    {
      "code": "<uses-permission android:name=\"com.sec.android.provider.badge.permission.READ\" tools:node=\"remove\" />\n<uses-permission android:name=\"com.sec.android.provider.badge.permission.WRITE\" tools:node=\"remove\" />\n<uses-permission android:name=\"com.htc.launcher.permission.READ_SETTINGS\" tools:node=\"remove\" />\n<uses-permission android:name=\"com.htc.launcher.permission.UPDATE_SHORTCUT\" tools:node=\"remove\" />\n<uses-permission android:name=\"com.sonyericsson.home.permission.BROADCAST_BADGE\" tools:node=\"remove\" />\n<uses-permission android:name=\"com.sonymobile.home.permission.PROVIDER_INSERT_BADGE\" tools:node=\"remove\" />\n<uses-permission android:name=\"com.anddoes.launcher.permission.UPDATE_COUNT\" tools:node=\"remove\" />\n<uses-permission android:name=\"com.majeur.launcher.permission.UPDATE_BADGE\" tools:node=\"remove\" />\n<uses-permission android:name=\"com.huawei.android.launcher.permission.CHANGE_BADGE\" tools:node=\"remove\"/>\n<uses-permission android:name=\"com.huawei.android.launcher.permission.READ_SETTINGS\" tools:node=\"remove\" />\n<uses-permission android:name=\"com.huawei.android.launcher.permission.WRITE_SETTINGS\" tools:node=\"remove\" />",
      "language": "xml"
    }
  ]
}
[/block]
## Debug

### `setLogLevel`
<div class="label-all label-type">Method</div>

Enable logging to help debug if you run into an issue setting up OneSignal. The following options are available with increasingly more information; `NONE`, `FATAL`, `ERROR`, `WARN`, `INFO`, `DEBUG`, `VERBOSE`
[block:parameters]
{
  "data": {
    "h-0": "Parameters",
    "0-0": "`logLevel`",
    "1-0": "`visualLevel`",
    "1-1": "LOG_LEVEL",
    "0-1": "LOG_LEVEL",
    "0-2": "Sets the logging level to print to the Android LogCat log.",
    "1-2": "Sets the logging level to show as alert dialogs.",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 2
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.setLogLevel(OneSignal.LOG_LEVEL.DEBUG, OneSignal.LOG_LEVEL.DEBUG);",
      "language": "java"
    }
  ]
}
[/block]
---
title: "Ionic SDK"
excerpt: "OneSignal Ionic SDK Reference. Works with <span class=\"label-all label-ios\">iOS</span>, <span class=\"label-all label-android\">Android</span> (and derivatives like <span class=\"label-all label-amazon\">Amazon</span>) and <span class=\"label-all label-windows\">Windows Phone 8.1</span>.\n<div class=\"tag-all tag-developers\">For Developers</div>"
---
[block:callout]
{
  "type": "info",
  "title": "Just starting with Ionic?",
  "body": "Check out our [Ionic SDK Setup guide](doc:ionic-sdk-setup)."
}
[/block]

[block:callout]
{
  "type": "warning",
  "title": "Upgrade to newest SDK",
  "body": "A number the methods and classes below are only available on our newest SDK. To upgrade to the latest Ionic SDK, read the [Ionic SDK Setup](doc:ionic-sdk-setup)."
}
[/block]

### Ionic API Reference

See our [Cordova SDK](doc:cordova-sdk) reference.
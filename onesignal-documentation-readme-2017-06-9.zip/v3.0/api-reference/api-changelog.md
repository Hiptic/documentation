---
title: "Server API Changelog"
excerpt: "Changes to the OneSignal Server REST API"
---
Want to be notified of updates to this page? You can use [https://visualping.io](https://visualping.io).

## April 17, 2017

Upcoming API Change:

We will soon require notification URLs to begin with a protocol or be root-relative:

After our API change, the following URLs will be supported:

  - http://...
  - https://...
  - market://...
  - facebook://...
  - com.package.app://...
  - com-package-app://...
  - /folder...
  - mailto:xx
  - tel:+x

After our API change, these URLs will not be supported (an API error will be thrown):

  - www.site.com  (missing http:// or https://)
  - 1234  (not a valid URL)
  - xyz.com  (missing http:// or https://) 

## October 11, 2016
The [create app](https://documentation.onesignal.com/reference#create-an-app) end point now requires `android_gcm_sender_id` if you pass in `gcm_key`.

## October 7, 2016

The players/csv_export API endpoint now supports exporting location points and other detailed values that were previously missing.

## August 23, 2016

Deprecated tags, use the new filters field instead.

## June 6, 2016

The players/csv_export API will now compress the output file in GZip format.

## June 1, 2016

Deprecated `android_background_data`
  * This will continue working however you should migrate to using our `NotificationExtenderService` *(Added in version 2.4.0)* by following our [Background Data and Notification Overriding](doc:android-customizations#section-background-data-and-notification-overriding) instructions which no longer requires this flag.

## April 4, 2016
Creating and deleting queued notifications through the OneSignal API will now return the value 'True' (boolean) for the "success" JSON attribute. Previously these endpoints would return "true" (string) for this attribute.

## March 11, 2016
The amount_spent field on GET players and GET players/:id will now be returned as a number with two decimal places (dollars and cents), instead of as a string.

## March 9, 2016

Upcoming API Change:

We will soon begin deleting notifications sent through the OneSignal API that were delivered over 30 days ago.

## March 3, 2016

A client reported that an HTTP 400 status code was being returned when creating a notification with tag targeting and when no recipients were subscribed.

We've corrected this issue to return an HTTP 200 status code to match up with the behavior of using other targeting fields when no recipients are subscribed.
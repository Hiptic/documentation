---
title: "NativeScript SDK"
excerpt: "OneSignal NativeScript SDK. Works with <span class=\"label-all label-ios\">iOS</span> and <span class=\"label-all label-android\">Android</span> (and derivatives like <span class=\"label-all label-amazon\">Amazon</span>).\n<div class=\"tag-all tag-developers\">For Developers</div>"
---
[block:callout]
{
  "type": "info",
  "title": "Just starting with NativeScript?",
  "body": "Check out our [NativeScript SDK Setup guide](doc:nativescript-sdk-setup)."
}
[/block]

[block:callout]
{
  "type": "info",
  "body": "OneSignal does not have an official first-party NativeScript SDK. However, there is a [third party NativeScript library](https://www.npmjs.com/package/nativescript-onesignal) that several customers use.",
  "title": "Third Party Library"
}
[/block]
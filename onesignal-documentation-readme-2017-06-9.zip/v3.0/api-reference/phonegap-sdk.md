---
title: "PhoneGap SDK"
excerpt: "OneSignal PhoneGap SDK Reference. Works with <span class=\"label-all label-ios\">iOS</span>, <span class=\"label-all label-android\">Android</span> (and derivatives like <span class=\"label-all label-amazon\">Amazon</span>) and <span class=\"label-all label-windows\">Windows Phone 8.1</span>.\n<div class=\"tag-all tag-developers\">For Developers</div>"
---
[block:callout]
{
  "type": "info",
  "title": "Just starting with PhoneGap?",
  "body": "Check out our [PhoneGap SDK Setup guide](doc:phonegap-sdk-setup)."
}
[/block]

[block:callout]
{
  "type": "warning",
  "title": "Upgrade to newest SDK",
  "body": "A number the methods and classes below are only available on our newest SDK. To upgrade to the latest PhoneGap SDK, read the [PhoneGap SDK Setup](doc:phonegap-sdk-setup)."
}
[/block]


### PhoneGap API Reference

See our [Cordova SDK](doc:cordova-sdk) reference.
---
title: "Marmalade SDK"
excerpt: "OneSignal Marmalade SDK Reference. Works with <span class=\"label-all label-ios\">iOS</span>, <span class=\"label-all label-android\">Android</span> (and derivatives like <span class=\"label-all\">Amazon</span>), and <span class=\"label-all label-windows\">Windows Phone 8.0 & 8.1</span>.\n<div class=\"tag-all tag-developers\">For Developers</div>"
---
[block:callout]
{
  "type": "info",
  "title": "Just starting with Marmalade?",
  "body": "Check out our [Marmalade SDK Setup guide](doc:marmalade-sdk-setup)."
}
[/block]

[block:parameters]
{
  "data": {
    "0-0": "### Initialization",
    "0-1": "",
    "h-2": "",
    "0-2": "",
    "h-0": "",
    "1-0": "[OneSignalInitialize](#section--onesignalinitialize-)",
    "1-1": "Function",
    "1-2": "Initialize OneSignal",
    "2-0": "### Registering Push",
    "3-0": "[OneSignalRegisterForPushNotifications](#section--onesignalregisterforpushnotifications-)",
    "4-0": "### User IDs",
    "5-0": "[OneSignalGetIdsAvailable](#section--onesignalgetidsavailable-)",
    "5-1": "Function",
    "5-2": "Get the User ID of the device",
    "6-0": "[OneSignalIdsAvailableResult](#section--onesignalidsavailableresult-)",
    "6-1": "Callback Result",
    "6-2": "",
    "7-0": "### Tags",
    "8-0": "[OneSignalGetTags](#section--onesignalgettags-)",
    "8-1": "Function",
    "11-1": "Function",
    "8-2": "View Tags from a User",
    "11-2": "Delete a Tag from a User",
    "11-0": "[OneSignalDeleteTag](#section--onesignaldeletetag-)",
    "12-0": "### Sending Notifications",
    "14-0": "### Receiving Notifications",
    "13-0": "[OneSignalPostNotificationWithCallback](#section--onesignalpostnotificationwithcallback-)",
    "13-1": "Function",
    "15-0": "[OneSignalNotificationReceivedResult](#section--onesignalnotificationreceivedresult-)",
    "15-1": "Callback Result",
    "13-2": "Send or schedule a notification to a user",
    "15-2": "When a notification is received by a device",
    "10-0": "[OneSignalSendTag](#section--onesignalsendtag-)",
    "10-1": "Function",
    "10-2": "Add a Tag to a User",
    "9-0": "[OneSignalTagsReceivedResult](#section--onesignaltagsreceivedresult-)",
    "9-1": "Callback Result",
    "9-2": "",
    "3-2": "Prompt Users to Enable Notifications",
    "3-1": "Function"
  },
  "cols": 3,
  "rows": 16
}
[/block]
## Initialize
### `OneSignalInitialize`
Call this function at the top of your int main() method to setup push notifications for your game.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`appId`",
    "0-1": "const char*",
    "1-0": "`googleProjectNumber`",
    "1-1": "const char*",
    "1-2": "Your Google project number that is only required for Android FCM/GCM pushes.",
    "2-0": "`callbackFn`",
    "2-1": "OneSignalNotificationReceivedCallbackFn",
    "3-0": "`autoRegister`",
    "3-1": "s3eBool",
    "3-2": "<span class=\"label-all label-ios\">iOS</span> - Set `false` to delay the iOS accept notification system prompt. You can then call `OneSignalRegisterForPushNotifications` at a better point in your game to prompt them.",
    "2-2": "Calls this function when a notification is opened or one is received when the user is in your game.",
    "0-2": "<p>Your OneSignal app id from <a class=\"dash-link\" href=\"/docs/accounts-and-keys#section-keys-ids\">Keys & IDs</a>.</p><p>Example:\n`b2f7f966-d8cc-11e4-bed1-df8f05be55ba`</p>"
  },
  "cols": 3,
  "rows": 4
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignalInitialize(\"5eb5a37e-b458-11e3-ac11-000c2940e62c\", \"703322744261\", (OneSignalNotificationReceivedCallbackFn)HandleReceivedNotification, true);",
      "language": "cplusplus"
    }
  ]
}
[/block]
## Register for Push
### `OneSignalRegisterForPushNotifications`
Call this when you would like to prompt an iOS user to accept push notifications with the default system prompt. Only use if you passed false to autoRegister when calling OneSignalInitialize.
[block:code]
{
  "codes": [
    {
      "code": "OneSignalRegisterForPushNotifications();",
      "language": "cplusplus"
    }
  ]
}
[/block]
## User IDs
### `OneSignalGetIdsAvailable`
<div class="label-all label-type">Function</div>

Lets you retrieve the OneSignal user id and push token. Your function is called after the device is successfully registered with OneSignal. If the device has already successfully registered, the callback function will be called immediately.
[block:parameters]
{
  "data": {
    "0-0": "`callbackFn`",
    "0-1": "OneSignalIdsAvailableCallbackFn",
    "0-2": "Calls the function when the user id is available.",
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "static void IdsRecieved(OneSignalIdsAvailableResult* result) {\n\t\tchar buffer[1024];\n\t\tchar* nullChar = NULL;\n\t\tsprintf(buffer, \"IDS RECIEVED CALLBACK UserID: %s, PushToken: %s, NULL:%s\", result->m_UserID, result->m_PushToken, nullChar);\n\t\ts3eDebugOutputString(buffer);\n\t}\n\t\n\tOneSignalGetIdsAvailable((OneSignalIdsAvailableCallbackFn)IdsRecieved);",
      "language": "cplusplus"
    }
  ]
}
[/block]
### `OneSignalIdsAvailableResult`
<div class="label-all label-type">Callback Result</div>

Result struct you can read to get the OneSignal userId and Google registration Id or an iOS push token.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "1-0": "`m_PushToken`",
    "0-0": "`m_UserID`",
    "0-2": "OneSignal userId is a UUID formatted string. (_unique per device per app_)",
    "0-1": "const char*",
    "1-1": "const char*",
    "1-2": "Either a Google registration Id or an iOS push token identifier (_unique per device per app_)."
  },
  "cols": 3,
  "rows": 2
}
[/block]

[block:callout]
{
  "type": "warning",
  "title": "NOTE",
  "body": "Might be NULL if push notifications are not accepted on iOS, Google Play services are not installed, or from a connection issue."
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "\tstatic void IdsRecieved(OneSignalIdsAvailableResult* result) {\n\t\tchar buffer[1024];\n\t\tsprintf(buffer, \"IDS RECIEVED CALLBACK UserID: %s, PushToken: %s\", result->m_UserID, result->m_PushToken);\n\t\ts3eDebugOutputString(buffer);\n\t}",
      "language": "cplusplus"
    }
  ]
}
[/block]
## Tags
### `OneSignalGetTags`
<div class="label-all label-type">Function</div>

Retrieve a list of tags that have been set on the player from the OneSignal server.
[block:parameters]
{
  "data": {
    "0-0": "`callbackFn`",
    "0-1": "OneSignalTagsReceivedCallbackFn",
    "0-2": "Function gets called once the tags are available.",
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "static void TagsReceived(OneSignalTagsReceivedResult* result) {\n\t\tchar buffer[1024];\n\t\tsprintf(buffer, \"TAGS RECIEVED CALLBACK TAGS: %s\", result->m_Tags);\n\t\ts3eDebugOutputString(buffer);\n\t}\n\n    OneSignalGetTags((OneSignalTagsReceivedCallbackFn)TagsReceived);",
      "language": "cplusplus"
    }
  ]
}
[/block]
### `OneSignalTagsReceivedResult`
<div class="label-all label-type">Callback Result</div>

Result struct you can read to get the all the tags set on a player from onesignal.com.
[block:parameters]
{
  "data": {
    "0-0": "`m_Tags`",
    "0-1": "const char*",
    "0-2": "JSON string retrieved from the OneSignal server.",
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "\tstatic void TagsReceived(OneSignalTagsReceivedResult* result) {\n\t\tchar buffer[1024];\n\t\tsprintf(buffer, \"TAGS RECIEVED CALLBACK TAGS: %s\", result->m_Tags);\n\t\ts3eDebugOutputString(buffer);\n\t}",
      "language": "cplusplus"
    }
  ]
}
[/block]
### `OneSignalSendTag`
<div class="label-all label-type">Function</div>

Tag a player based on a game event of your choosing so later you can create segments on [onesignal.com](https://onesignal.com) to target these players.

[block:parameters]
{
  "data": {
    "0-1": "const char*",
    "1-1": "const char*",
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`key`",
    "1-0": "`value`",
    "1-2": "Value to set on the key.",
    "0-2": "Key of your choosing to create or update.\n_NOTE:_ Passing in a blank string deletes the key, you can also call `OneSignalDeleteTag`."
  },
  "cols": 3,
  "rows": 2
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignalSendTag(\"key\", \"value\");",
      "language": "text"
    }
  ]
}
[/block]
### `OneSignalDeleteTag`
<div class="label-all label-type">Function</div>

Deletes a tag that was previously set on a player with `sendTag`.
[block:parameters]
{
  "data": {
    "0-0": "`key`",
    "0-1": "const char*",
    "0-2": "Key to remove.",
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignalDeleteTag(\"key\");",
      "language": "cplusplus"
    }
  ]
}
[/block]
## Sending Notifications
### `OneSignalPostNotificationWithCallback`
<div class="label-all label-type">Function</div>

Allows you to send notifications from user to user or schedule ones in the future to be delivered to the current device.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`jsonStr`",
    "0-1": "const char*",
    "1-1": "OneSignalPostNotificationCallbackFn",
    "2-1": "OneSignalPostNotificationCallbackFn",
    "2-0": "`callbackFailureFn`",
    "1-0": "`callbackSuccessFn`",
    "2-2": "Called the notification could not be created.",
    "1-2": "Called when a success response is returned from OneSignal.",
    "0-2": "JSON string of notification options, see our [Create notification](ref:create-notification) POST call for all options."
  },
  "cols": 3,
  "rows": 3
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "static void postNotificationSuccess(OneSignalPostNotificationResult* result, void* userData) {\n    char buffer[1024];\n    sprintf(buffer, \"NOTIFICATION POST SUCCESS CALLBACK: %s\", result->m_response);\n    s3eDebugOutputString(buffer);\n}\n\nstatic void postNotificationFailure(OneSignalPostNotificationResult* result, void* userData) {\n    char buffer[1024];\n    sprintf(buffer, \"NOTIFICATION POST FAILURE CALLBACK: %s\", result->m_response);\n    s3eDebugOutputString(buffer);\n}\n\nOneSignalPostNotificationWithCallback(\"{\\\"app_id\\\" : \\\"b2f7f966-d8cc-11e4-bed1-df8f05be55ba\\\",\\\"contents\\\" : {\\\"en\\\" : \\\"Message 1\\\"}, \\\"include_player_ids\\\": [\\\"7fc57fae-fc45-451c-9f59-7e44d911b9cb\\\"]}\", (OneSignalPostNotificationCallbackFn)postNotificationSuccess, (OneSignalPostNotificationCallbackFn)postNotificationFailure);",
      "language": "c"
    }
  ]
}
[/block]
## Receiving notifications
### `OneSignalNotificationReceivedResult`
<div class="label-all label-type">Callback Result</div>

Result struct you can read from to get info on the notification the user just opened.

#### Values
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`m_Message`",
    "0-1": "const char*",
    "1-1": "const char*",
    "2-1": "s3eBool",
    "2-0": "`m_isActive`",
    "1-0": "`m_AdditionalData`",
    "0-2": "The message text the user seen in the notification.",
    "1-2": "JSON string that was set on the notification.",
    "2-2": "`true` if your app was currently being used when a notification came in."
  },
  "cols": 3,
  "rows": 3
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "\tstatic void HandleReceivedNotification(OneSignalNotificationReceivedResult* result, void* userData) {\n\t\tchar buffer[1024];\n\t\tsprintf(buffer, \"NOTIFICATION RECIEVED CALLBACK MESSAGE: %s\", result->m_Message);\n\t\ts3eDebugOutputString(buffer);\n\t\t\n\t\tif (result->m_AdditionalData != NULL) {\n\t\t\tchar buffer2[1024];\n\t\t\tsprintf(buffer2, \"NOTIFICATION RECIEVED CALLBACK ADDITIONALDATA: %s\", result->m_AdditionalData);\n\t\t\ts3eDebugOutputString(buffer2);\n\t\t}\n\t}",
      "language": "cplusplus"
    }
  ]
}
[/block]
---
title: "Notifications"
excerpt: "The features & functionality of notifications in OneSignal\n<div class=\"tag-all tag-developers\">For Developers</div> <div class=\"tag-all tag-marketers\">For Marketers</div>"
---
In this section
- [Sending Notifications](doc:sending-notifications) - how to use the OneSignal dashboard to send notifications
- [Appearance](doc:appearance) - how notifications look to users
- [Language & Localization](doc:language-localization) - what languages OneSignal supports
- [Permission Messages & Requests](doc:permission-requests) - how users are prompted to give push permissions
- [Rich Media](doc:rich-media) - media that can be attached with notifications
- [Content Length](doc:notification-content) - the length limits of notification content
- [Action Buttons](doc:action-buttons) - actions users can take on notifications
- [Links](doc:links) - internal and external links that notifications can take users to
- [Templates](doc:templates) - reusable notification designs
- [Tag & Variable Substitution](doc:tag-variable-substitution) - Per-user content customization based on tags
- [Run Code upon Receipt](doc:run-code) - Running custom code when a notification is received

## Tutorials
For tutorials on how to implement the above features, go to [Customizing Notifications](doc:branding)
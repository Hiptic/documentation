---
title: "Exporting Data"
excerpt: "OneSignal Features - Exporting User Data\n<div class=\"tag-all tag-developers\">For Developers</div> <div class=\"tag-all tag-marketers\">For Marketers</div>"
---
## Exporting User Data

OneSignal User Data can be exported using the following API endpoints:

[CSV export](https://documentation.onesignal.com/reference#csv-export) - Full CSV Export API 
[View devices](ref:view-devices) - User List API
[View device](ref:view-device) - Device Details API

## Exporting Notification Data

OneSignal Notification Data can be exported using the following API endpoint:

[View notifications](ref:view-notifications) - Notification List API
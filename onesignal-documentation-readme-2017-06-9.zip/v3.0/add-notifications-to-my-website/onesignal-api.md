---
title: "OneSignal API"
excerpt: "OneSignal Features - About the OneSignal Server REST API\n<div class=\"tag-all tag-developers\">For Developers</div>"
---
OneSignal's server API can be used to:

1. Programmatically deliver notifications from your server or device to another device.

2. Add, update, and fetch data for your users without using our mobile or web SDKs.

3. Export User or Notification data from OneSignal.

Our API covers:

1. **Apps**

2. **Players** (also known as *devices* or *users*)

3. **Notifications**

Our API can be accessed using any regular HTTP library of your choice.

The most commonly used methods are:
* [Create notification](ref:create-notification) - creates and sends a notification to any set of users you specify
* [Cancel notification](ref:cancel-notification) - cancel sending a notification
* [Edit device](ref:edit-device) - add/remove tags on a user or modify other properties. Normally handled automatically by our Client SDK.
* [View apps](ref:view-apps-apps)  - view the details of apps on your OneSignal account
* [CSV export](ref:csv-export) - export your user list

You can find our full API Reference [here](ref:create-notification).
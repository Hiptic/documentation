---
title: "Notification Delivery"
excerpt: "OneSignal Features - Notification Delivery\n<div class=\"tag-all tag-developers\">For Developers</div> <div class=\"tag-all tag-marketers\">For Marketers</div>"
---
## Sent Messages
The Sent Messages page shows a list of previous notifications your app has sent. From this page you can access [Message Reports](#section-message-report) for every notification you've sent.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/9ad4670-Group.png",
        "Group.png",
        1192,
        416,
        "#3c3c44"
      ]
    }
  ]
}
[/block]
Delivery status is presented on the left hand side in the table. The following are what each status means:
[block:parameters]
{
  "data": {
    "h-0": "Status",
    "h-1": "Description",
    "0-0": "Delivered",
    "0-1": "OneSignal has completed sending notifications to Google, Apple, Microsoft, etc push servers.",
    "4-0": "Canceled",
    "4-1": "You or someone else with access to your app has cancelled the delivery of this notification.",
    "2-0": "Sending",
    "2-1": "Notifications are currently sending",
    "1-0": "Queued",
    "1-1": "Notifications are queued up in OneSignal and will be sent shortly",
    "3-0": "Scheduled",
    "3-1": "Notifications are scheduled to be delivered at the time(s) selected"
  },
  "cols": 2,
  "rows": 5
}
[/block]
## Message Report
Clicking on a notification within the Sent Messages page opens the message report. This page shows the results of sending a notification. 
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/96a2211-Screen_Shot_2017-05-08_at_12.54.33_PM.png",
        "Screen Shot 2017-05-08 at 12.54.33 PM.png",
        2072,
        1106,
        "#7fa8c6"
      ]
    }
  ]
}
[/block]
## Message Report Definitions 
The following are what each term here means:
[block:parameters]
{
  "data": {
    "h-0": "Column",
    "h-1": "Description",
    "0-0": "**Total Users**",
    "1-0": "**Total Messages**",
    "2-0": "**Pending**",
    "3-0": "**Delivered**",
    "4-0": "**Unreachable**",
    "5-0": "**Clicked**",
    "6-0": "**Invalid**",
    "0-1": "The number of users that the notification was sent to",
    "1-1": "The number of notifications that OneSignal attempted to send",
    "2-1": "The number of notifications that are pending delivery, but not yet delivered",
    "3-1": "The number of notifications successfully sent to Google, Apple, Microsoft, etc server. *This does not necessarily mean the devices have received these notifications.*",
    "4-1": "If there user is no longer subscribed as they uninstalled the app we will report these as unreachable.",
    "5-1": "The number of clicks / taps on the notification sent",
    "6-1": "These errors are typically caused due to one of the following reasons:\n<p>- Your OneSignal Application Settings are incorrect.\n- These tokens belong to an app that does not match your OneSignal settings.\n- Some other backend error occured.\n</p>"
  },
  "cols": 2,
  "rows": 7
}
[/block]
## FAQ

#### What does the delivered status mean?
<div class="label-all label-type">Mobile Apps</div>

Delivered means that OneSignal has successfully sent the notification to Google, Apple, Microsoft, etc server. If there user is no longer subscribed as they uninstalled the app we will report these as failures instead. If the device does not power on and connect to the internet within 3 days the notification will be dropped from Google's and Apple's server. Most push services do not support confirmation of delivery so this is not tracked by OneSignal.

#### Do users receive web push notifications when the browser isn't running?
<div class="label-all label-type"><span class="label-web">Web Push</span></div>

<span class="label-all label-chrome">Chrome</span> - Chrome runs as a background process by default even when all the windows are closed. As long as the background process is running, notifications will still be received. If the Chrome background process is not running, notifications will not be received.

<span class="label-all label-firefox">Firefox</span> - On Mac OS X, the process still exists even if windows are closed, and a notification can be received if all windows are closed (as long as there is still a dot in the dock showing Firefox is still running). On Windows, the process exits after all windows are closed so notifications cannot be received unless a Firefox window is still open.

<span class="label-all label-safari">Safari</span> - Safari does not have to be running to receive notifications, as they are sent directly to the operating system. The user still has to sign up for Safari web notifications, but after that they will be received even when Safari is completely closed.

Users have up to 3 days to retrieve the last known missing notification before messages expire permanently. For example, suppose a user was supposed to receive a Firefox web push notification but Firefox was closed. If the user opens Firefox within 3 days, the user will receive only the last known web push notification that didn't expire. If the user opens Firefox after 3 days, the web push notification sent more than 3 days ago will not be received.


#### What happens to a notification if it is received while my app is being used?
<div class="label-type"><span class="label-all label-developers">For Developers</span></div>

<span class="label-all">Mobile Apps</span> - The `NotificationOpened` callback (passed to OneSignal init) is fired instead of showing a notification on the device. There are 3 options to handle displaying a message to your users.

1. **Alert dialog** -- you can display an alert dialog for in focus notifications by setting `inFocusDisplaying` to `InAppAlert`. `NotificationOpened` is still called so you can do additional processing.

2. **Display the notification** - you can display notifications for in focus notifications by setting `inFocusDisplaying` to `Notification`.

3. **Display your own in app notification** - In `NotificationOpened` you can read the message and title of the message and display your own with your own code. `isActive` will be `true` when they are using your app when the notification was received.
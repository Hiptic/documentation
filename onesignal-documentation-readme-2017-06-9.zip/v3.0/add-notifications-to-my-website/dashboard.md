---
title: "Dashboard"
excerpt: "OneSignal Features - OneSignal Dashboard\n<div class=\"tag-all tag-developers\">For Developers</div> <div class=\"tag-all tag-marketers\">For Marketers</div>"
---
The OneSignal Dashboard is the primary user interface for working with OneSignal. The dashboard exposes all the functionality of OneSignal in an easy-to-use interface for developers and marketers alike. 

The main pages of the dashboard are:
- [Accounts & Keys](doc:accounts-and-keys) - managing your account and your app keys
- [All Apps](doc:all-apps) - access multiple apps you've created
- [Users & Devices](doc:users-and-devices) - your app's users
- [Segmentation](doc:segmentation) - creating and using segments
- [Notifications](doc:notifications) - sending notifications

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/7173b40-Screen_Shot_2017-05-11_at_8.48.41_PM.png",
        "Screen Shot 2017-05-11 at 8.48.41 PM.png",
        1285,
        1042,
        "#3a3b45"
      ]
    }
  ]
}
[/block]
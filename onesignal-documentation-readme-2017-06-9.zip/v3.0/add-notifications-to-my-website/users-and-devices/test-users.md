---
title: "Test Users"
excerpt: "OneSignal Features - Test Users\n<div class=\"tag-all tag-developers\">For Developers</div> <div class=\"tag-all tag-marketers\">For Marketers</div>"
---
Test Users are a special group of user devices that you can manually manage in order to test delivery of notifications. Each user's device may be added to the list of Test Users. These are accessible from <a class="dash-link" href="/docs/users-and-devices">All Users</a>.

## Adding Test Users
To add a user to your list of test users, do the following

<ol><li><p>Load the app on the user's device</p></li><li><p>Go to <a class="dash-link" href="/docs/users-and-devices">All Users</a></p></li><li><p>Find the user in question. You may have to click the **First Session** column to sort by the date of the first session. They should be the first user in the list if they just opened the app.</p></li><li><p>Click 'Options' on this user, and then click 'Add to Test Users' (see below)</p></li></ol>
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/73f4725-Screen_Shot_2017-05-11_at_9.39.16_PM.png",
        "Screen Shot 2017-05-11 at 9.39.16 PM.png",
        1220,
        592,
        "#eff1f1"
      ]
    }
  ]
}
[/block]

[block:callout]
{
  "type": "success",
  "body": "You're all set! You can confirm the user has been added to test users by switching the view to Test Users by clicking 'Viewing: All Users' and selecting Test Users."
}
[/block]
## Create Test Users Segment
To create a segment with all your test users, do the following

<ol><li><p>Add Test Users by following the [above steps](doc:test-users#section-adding-test-users)</p></li><li><p>Go to <a class="dash-link" href="/docs/segmentation#section-accessing-segments">Segments</a></p></li><li><p>Click "New Segment" button at the bottom and name the segment "Test Users". Then click "Create"</p></li><li><p>Click "Add IF" on this empty segment, then click "Is Test User" and "Save" (see below)</p></li></ol>
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/9ea2495-Screen_Shot_2017-05-11_at_9.41.45_PM.png",
        "Screen Shot 2017-05-11 at 9.41.45 PM.png",
        2542,
        476,
        "#eaebea"
      ]
    }
  ]
}
[/block]
If you need more help creating segments, please see our page on [Creating Segments Using Filters](doc:segmentation#section-creating-segments-using-filters)
[block:callout]
{
  "type": "success",
  "body": "Now you can access ALL your Test Users by simply targeting the newly created \"Test Users\" segment!"
}
[/block]
---
title: "Importing Users & Devices"
excerpt: "OneSignal Features - Device Import\n<div class=\"tag-all tag-developers\">For Developers</div> <div class=\"tag-all tag-advanced\">Advanced Topic</div>"
---
## Importing Web Push Subscribers

Due to the way Web Push works, you cannot migrate data from one service to another. We suggest that you install the OneSignal website SDK onto your site. Then send a message to your existing subscribers to get them to come back and resubscribe with OneSignal on your site. 

If your site is HTTPS, then any user who subscribed before will be automatically resubscribed when they revisit your site with OneSignal installed. 

## Importing Mobile App Subscribers

Before migrating, we recommend updating your app to have the OneSignal SDK. This way no users will get lost between the time you migrate your current subscribers and the time you update your app.

<span class="label-all label-ios">iOS</span> - To migrate iOS devices, please ask your current service provider for a CSV export of your subscribers. Next, you can send this export file to us and we will import it for you within 24 hours or so. Note that some features like monitoring notification click rate wont work for devices with an old version of your app.

<span class="label-all label-android">Android</span> - In the case of Android devices, we can import these subscribers, but they will not be able to receive notifications until they update to a version of your app with the OneSignal SDK. Therefore it's usually not beneficial to import them since they would get added to OneSignal after they updated and opened your app anyway.

### Import from another Mobile Push Provider or your own Database
If you are using another Mobile Push vendor, please ask them for a CSV export of your subscribers. Next, you can <a href="" class="contact-support">contact support</a> and send this export file to us and we will import it for you within 24 hours or so.

If you are using your own hosted push delivery system, such as Parse-Server, you can import devices into OneSignal through our [add device API](ref:add-a-device), or by sending us a CSV file to import for you.

### Import from Urban Airship
OneSignal supports automatically importing devices from [Urban Airship](https://www.urbanairship.com).  To access the **Import Users** page, go to **App Settings** and select the **Import Users From Another Service** tab.

When Android devices are imported from Urban Airship they will not be able to receive notifications until they update to a version of your app with the OneSignal SDK. Therefore it's usually not beneficial to import them since they would get added to OneSignal after they updated and opened your app anyway.
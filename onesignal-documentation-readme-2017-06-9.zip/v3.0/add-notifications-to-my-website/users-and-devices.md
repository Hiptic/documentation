---
title: "Users & Devices"
excerpt: "OneSignal Features - All Users Page \n<div class=\"tag-all tag-developers\">For Developers</div> <div class=\"tag-all tag-marketers\">For Marketers</div>"
---
## All Users Page
The All Users page shows a list of every user's device in your app, and data attributes about each. To view all the data attributes, you may need to scroll the browser window to the right. 
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/194b40b-All_Users.png",
        "All Users.png",
        2162,
        1356,
        "#f1f2f2"
      ]
    }
  ]
}
[/block]
The All Users page allows filtering by All Users or just <a class="dash-link" href="/docs/test-users">Test Users</a>, and allows you to adjust which columns are visible. These columns contain the variety of data attributes about your users, as follows:
[block:parameters]
{
  "data": {
    "h-0": "Column",
    "h-1": "Description",
    "0-0": "**Actions**",
    "1-0": "**Subscribed**",
    "2-0": "**Last Active**",
    "3-0": "**First Session**",
    "4-0": "**Platform**",
    "5-0": "**Device**",
    "6-0": "**Sessions**",
    "7-0": "**Player ID**",
    "8-0": "**Segments**",
    "10-0": "**App Version**",
    "11-0": "**Country**",
    "12-0": "**Rooted**",
    "13-0": "**Location Point**",
    "14-0": "**Usage Duration**",
    "0-1": "Allows you to [Add to Test Users](doc:test-users) or [Delete the current user](#section-deleting-users)",
    "1-1": "Whether the user's device is currently subscribed to push notifications.",
    "2-1": "The last date/time the user's device communicated with OneSignal servers.\n\n\nFor Web Push: This value is updated anytime a user visits any OneSignal-enabled page of your site in a *new tab* or *new window*. Clicking links in the same page or refreshing the same page does not cause the value to be updated for performance reasons. If a user clicks a notification and the notification brings them back to a OneSignal-enabled page of your site in a new tab, the Last Active time will be updated.",
    "3-1": "The first date/time the user's device communicated with OneSignal servers.",
    "4-1": "Specific model of the user's device, including operating system version.",
    "5-1": "What the user's device or browser is.",
    "6-1": "Number of unique times the user's device has communicated with OneSignal servers.",
    "7-1": "The unique identifier of the user's device.",
    "8-1": "Segments the user's device belongs to. By default, OneSignal adds all subscribed users to the `All` segment.",
    "9-0": "**Tags**",
    "9-1": "The JSON output of any tags your app has added to the user.",
    "10-1": "The version of your app the device was running the last time it communicated with OneSignal servers.",
    "11-1": "Country the user's device was in the last time it communicated with OneSignal servers.",
    "12-1": "<span class=\"label-all label-android\">Android</span> - whether the device is rooted.",
    "13-1": "Geolocation (lat, long) of the user's device, sent if the user has granted location permissions to your app.",
    "14-1": "Number of seconds the user's device has had your app open."
  },
  "cols": 2,
  "rows": 15
}
[/block]

## Deleting Users
You can individually delete user's devices by clicking 'Actions' and then clicking 'Delete'. 
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/1899de8-Screen_Shot_2017-05-11_at_9.06.11_PM.png",
        "Screen Shot 2017-05-11 at 9.06.11 PM.png",
        767,
        590,
        "#edeeee"
      ]
    }
  ]
}
[/block]



### FAQ
<div class="label-type"><span class="label-all label-developers">For Developers</span></div>

#### How do I delete several unsubscribed users from the All Users Page?

Presently there is no way to bulk clear unsubscribed users, however you may [individually delete users](#section-deleting-users). We keep unsubscribed users around for a few reasons:

1. Users who are unsubscribed may later re-subscribe to notifications. Keeping this user data around allows our system to continue accurately tracking metrics such as session count, usage duration, and tags.

2. Our automatic notifications feature is designed to avoid delivering the same notification twice to users who have previously received it. Deleting users could interfere with this mechanism.

3. Clients often want to see data about unsubscribed users through our dashboard or API.

4. Deleting users who currently have your app installed may cause unexpected behavior when using certain OneSignal methods in your app, such as SendTags.

In general we recommend not deleting users except if the device was not configured correctly during development.


#### What does the Subscribed column on the All Users dashboard page mean?
For your specific app, a subscribed user is eligible to receive your app's push notifications. The user has opted to receive push notifications and has a valid push token.

For an unsubscribed user, one or more of the following is true:

- The user did not accept the notification permission prompt.
- There was an error subscribing to Apple or Google for push.
- The SDK function setSubscription was called with false.
- The user uninstalled the app (for mobile) or cleared their browser data (for web).


#### When does the OneSignal User / Player ID change?
It will stay the same as long as the user has your app installed or for web push as long as the user does not clear their browser data for your site. If the user hasn't opted out of the Google Ad id (Android) the ID will stay the same after full re-installs. On iOS, the IFV (Identifier For Vendor) is used to keep the ID the same after a full re-install, but only if the user has another one of your apps installed.

#### Can I track users that have uninstalled my app?
Yes and no. Mobile operating system providers make it intentionally difficult to reliability detect when a user has uninstalled an app.

OneSignal does detect the approximate time when a device stopped receiving notifications, and our API can be used for your system to be notified of this. This generally occurs once a device uninstalls your app, but it can also happen if the user disables notifications for your app.
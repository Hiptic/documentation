---
title: "Amplitude"
excerpt: "OneSignal Features - Integrating OneSignal with Amplitude\n<div class=\"tag-all tag-developers\">For Developers</div> <div class=\"tag-all tag-marketers\">For Marketers</div>"
---
## Notification Behavior Tracking in Amplitude

OneSignal supports tracking data when notifications are received and clicked on each platform, including sending this data to Amplitude so that it can analyized in the context of your other user data.

<span class="label-all label-ios">iOS</span> -
1. Send an event to your analytics system from the `OSHandleNotificationReceivedBlock` event handler when a notification is received.

2. Send another event to your analytics system from the `OSHandleNotificationActionBlock` event handler when a notification is clicked.

<span class="label-all label-android">Android</span> - Same to above, but use `NotificationReceivedHandler` and `NotificationOpenedHandler`.

<span class="label-all">Web Push</span> - Same as above, but use our [Webhooks](doc:webhooks) events

## Sending notifications to Amplitude Segments

Amplitude user properties can be synchronized to OneSignal using the SendTags method of each of our SDKs, or using our [Edit device](ref:edit-device) REST API endpoint. You can then send notifications based on these OneSignal tags through the OneSignal dashboard or [Create notification API](ref:create-notification).
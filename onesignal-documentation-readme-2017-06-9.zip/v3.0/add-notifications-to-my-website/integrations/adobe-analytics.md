---
title: "Adobe Analytics"
excerpt: "OneSignal Features - Integrating OneSignal with Adobe Analytics\n<div class=\"tag-all tag-developers\">For Developers</div> <div class=\"tag-all tag-marketers\">For Marketers</div>"
---
## Notification Behavior Tracking in Adobe Analytics
OneSignal supports tracking data when notifications are received and clicked on each platform, including sending this data to Adobe Analytics so that it can analyized in the context of your other user data.

<span class="label-all label-ios">iOS</span> -
1. Send an event to your analytics system from the `OSHandleNotificationReceivedBlock` event handler when a notification is received.

2. Send another event to your analytics system from the `OSHandleNotificationActionBlock` event handler when a notification is clicked.

<span class="label-all label-android">Android</span> - Same to above, but use `NotificationReceivedHandler` and `NotificationOpenedHandler`.

<span class="label-all">Web Push</span> - Same as above, but use our [Webhooks](doc:webhooks) events

In each case, you can attach additional metadata to each notification such as `type=cart abandonment` or `type=reengagement` and then pass this metadata to your analytics system as well.

Next, you will be able to analyze the behavior funnels of users who receive and click on various notifications you send through OneSignal in your analytics system

For Adobe Audience Manager / Adobe Target you can link OneSignal data with 3rd party data via [our API](ref:create-notification), including [CSV exports](ref:csv-export). Read more on [Exporting Data](doc:exporting-data).
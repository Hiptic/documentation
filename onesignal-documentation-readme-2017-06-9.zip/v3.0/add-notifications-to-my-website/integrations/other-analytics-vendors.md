---
title: "Other Analytics Vendors"
excerpt: "OneSignal Features - Integrating OneSignal with any Analytics vendor\n<div class=\"tag-all tag-developers\">For Developers</div> <div class=\"tag-all tag-marketers\">For Marketers</div>"
---
## Notification Behavior Tracking 

OneSignal supports tracking data when notifications are **received** and **clicked** on each platform, including sending this data to any analytics vendor so that it can analyzed in the context of your other user data.


<span class="label-all label-ios">iOS</span> -
1. Send an event to your analytics system from the `OSHandleNotificationReceivedBlock` [iOS SDK Notification Received](ios-native-sdk#section--oshandlenotificationreceivedblock-) event handler when a notification is received.

2. Send another event to your analytics system from the `OSHandleNotificationActionBlock` [iOS SDK Notification Clicked](ios-native-sdk#section--oshandlenotificationactionblock-) event handler when a notification is clicked.

<span class="label-all label-android">Android</span> - Same to above, but use `NotificationReceivedHandler` [Android SDK Notification Received](android-native-sdk#section--notificationreceivedhandler-) and `NotificationOpenedHandler` [Android SDK Notification Clicked](android-native-sdk#section--notificationopenedhandler-).

<span class="label-all">Web Push</span> -

**Tracking Notification Clicks, and post-click behavior**
The easiest way to track notification clicks is to add Google Analytics UTM parameters to the end of the URL for the notification. Here's an overview on UTM parameters: http://blog.rafflecopter.com/2014/04/utm-parameters-best-practices/

**Tracking notification permission opt-in**
You can use the [subscriptionChange](https://documentation.onesignal.com/docs/web-push-sdk#section-callback-event-parameters) event of the OneSignal Javascript SDK to detect when a user subscribes to notifications or unsubscribes from notifications on your site.
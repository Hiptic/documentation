---
title: "All Apps"
excerpt: "OneSignal Features - All Apps Page \n<div class=\"tag-all tag-developers\">For Developers</div> <div class=\"tag-all tag-marketers\">For Marketers</div>"
---
Your OneSignal account supports one or more applications. The All Apps page provides an overview of each application in your account, including the stage of setup it is in, and an overview of users in each app. Clicking on an app brings you to the app's [Dashboard](doc:dashboard).
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/0eacd71-Screen_Shot_2017-05-11_at_8.58.53_PM.png",
        "Screen Shot 2017-05-11 at 8.58.53 PM.png",
        2634,
        1594,
        "#1e262e"
      ]
    }
  ]
}
[/block]
## Renaming and Deleting
Clicking on the options menu (the three dots in the top right corner) brings up a menu allowing you to rename or delete your application. 
[block:callout]
{
  "type": "danger",
  "title": "Deletion is Permanent",
  "body": "If you delete your app, there is no way to restore it!"
}
[/block]

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/daba208-Screen_Shot_2017-05-11_at_9.00.12_PM.png",
        "Screen Shot 2017-05-11 at 9.00.12 PM.png",
        631,
        291,
        "#eff8fa"
      ]
    }
  ]
}
[/block]
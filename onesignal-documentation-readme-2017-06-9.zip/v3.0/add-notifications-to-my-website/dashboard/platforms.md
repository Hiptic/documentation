---
title: "Platforms"
excerpt: ""
---
## App Settings
The App Settings page is where you configure the platforms associated with your app. 
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/682035e-Screen_Shot_2017-05-11_at_9.02.10_PM.png",
        "Screen Shot 2017-05-11 at 9.02.10 PM.png",
        1404,
        825,
        "#3a3a44"
      ]
    }
  ]
}
[/block]
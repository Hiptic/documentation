---
title: "Accounts & Keys"
excerpt: "OneSignal Features - Accounts and Keys\n<div class=\"tag-all tag-developers\">For Developers</div> <div class=\"tag-all tag-marketers\">For Marketers</div>"
---
## Administrators
<div class="label-type">[All Apps](doc:all-apps) > **App Settings** > **Administrators** (tab)</div>

Each separate OneSignal app can have multiple administrators added to the app. Each administrator you add has full access and control over your app, including the ability to delete the app or even remove you as an administrator. 
[block:callout]
{
  "type": "warning",
  "body": "We do not currently support a permission system or log what actions other administrators take. Please be sure to only add administrators you trust."
}
[/block]
Administrators are added *per-app* and not *per-user*. The app administrator can only access the app(s) they have been added to, and not the other apps you have access to. This means if you have multiple apps that you want another person to access, you will have to invite them within each app.

### Adding Administrators
You can view, add, and remove administrators from the OneSignal Dashboard by going to **App Settings** and selecting the **Administrators** tab. Administrators are invited to join your app via their email address.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/763998e-Screen_Shot_2017-05-11_at_8.50.36_PM.png",
        "Screen Shot 2017-05-11 at 8.50.36 PM.png",
        914,
        361,
        "#83abcd"
      ]
    }
  ]
}
[/block]
----

## Keys & IDs
<div class="label-type">[All Apps](doc:all-apps) > **App Settings** > **Keys & IDs** (tab)</div>

### App Auth Key

Your App Auth Key, which is your REST API key for app-specific operations (getting users of an app, modifying users, getting notifications, sending notifications) listed in the **Keys & IDs** section, add an HTTP header with the key `Authorization` and the value `Basic REST_API_KEY`, where you should replace `REST_API_KEY` with your actual APP REST API key.

#### Resetting your REST API Key

Click *Reset your REST API key?* below the REST API key textbox.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/e615438-Screen_Shot_2017-05-11_at_8.52.39_PM.png",
        "Screen Shot 2017-05-11 at 8.52.39 PM.png",
        1087,
        302,
        "#84abd1"
      ]
    }
  ]
}
[/block]
The keys for all your apps are also available all together within the Account section.

----

## Account
<div class="label-type">**Account** > **Account & API Keys**</div>

Your account details are available from the account menu, available by clicking your profile image in the lower left corner of the dashboard. This is where you can update your Organization name, email, and password. 
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/0bd953e-Screen_Shot_2017-05-11_at_8.54.15_PM.png",
        "Screen Shot 2017-05-11 at 8.54.15 PM.png",
        310,
        277,
        "#414146"
      ]
    }
  ]
}
[/block]
### User Auth Key
The Account section is also where you can find your **User Auth Key**, available at the bottom of the page below the REST API keys for each of your OneSignal apps. 

The User Auth Key can be used by by adding an HTTP header with the key `Authorization` and the value `Basic USER_AUTH_API_KEY`, where you should replace `USER_AUTH_API_KEY` with your key.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/8c32cdb-Screen_Shot_2017-05-11_at_8.56.29_PM.png",
        "Screen Shot 2017-05-11 at 8.56.29 PM.png",
        1951,
        1276,
        "#f0f3f4"
      ]
    }
  ]
}
[/block]
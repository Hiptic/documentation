---
title: "Appearance"
excerpt: "OneSignal Features - Changing how notifications appear\n<div class=\"tag-all tag-developers\">For Developers</div> <div class=\"tag-all tag-marketers\">For Marketers</div>"
---
## Images
<span class="label-all label-ios">iOS</span> - OneSignal supports all iOS notification features, including those for the just-released iOS 10. [Read more here.](doc:rich-media) 

<span class="label-all label-android">Android</span> - See [Android Customizations](doc:android-customizations)

<span class="label-all label-web">Web Push</span> - Web Notifications support JPG, PNG, GIF, WebP, ICO/CUR and BMP URLs. SVG images are not supported. You can set both an icon and a large image (in Chrome 56+ only). Please see [Web Push Notification Icons](doc:web-push-notification-icons).

## Sounds
OneSignal supports adding custom sounds for any notification sent. To learn more, read our guide on [Customizing Notification Sounds](doc:customize-notification-sounds).


## Badges

### Setting and Clearing Badge Numbers

<span class="label-all label-ios">iOS</span> - Set either "Increase" or "Set To" and enter a number under Options>iOS when creating a new message. The badge icon number is cleared automatically when the app is resumed or opened. Setting the count to 0 with a notification will also clear the value.

If you want to prevent our SDK from automatically clearing badges set `OneSignal_disable_badge_clearing` to `YES` as a `Boolean` type in your `.plist` in Xcode.

<span class="label-all label-android">Android</span> - The badge number always shows the number of notifications sent for your app in the notification shade. As notifications are opened and/or dismissed the badge count will go down until it is cleared when there are no more notifications.

If you want to prevent our SDK from automatically setting badges see our [Android badge settings guide](android-customizations#section-app-icon-badge-counts).
[block:callout]
{
  "type": "warning",
  "body": "Note: Android badges are only supported by our latest SDK and only on the following Android Launchers: Sony, Samsung, LG, HTC, Xiaomi, Huawei, ASUS, ZUK, OPPO, ADW, APEX, and NOVA."
}
[/block]
---
title: "Templates"
excerpt: "OneSignal Features - Templates"
---
**Templates** are reusable designs for notifications. Providing the same options from <a class="dash-link" href="/docs/sending-notifications">New Message</a>, templates let you specify a unique look and functionality of notifications, including adding [Action Buttons](doc:action-buttons), [Custom Sounds](doc:customize-notification-sounds), [Icons](doc:android-customizations#section-small-notification-icons) (<span class="label-all label-android">Android</span>), and functionality changes such as collapsing and grouping notifications.

The Templates page shows the list of templates you have created, and basic statistics on their performance (notifications opened and sent). 
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/959db21-Screen_Shot_2017-05-12_at_8.44.48_PM.png",
        "Screen Shot 2017-05-12 at 8.44.48 PM.png",
        1734,
        846,
        "#78a5ca"
      ]
    }
  ]
}
[/block]
## Create Templates
To create a new template, click the **New Template** button on the Templates page. This brings you to a page identical to the <a class="dash-link" href="/docs/sending-notifications">New Message</a> page, but instead of sending a message, you are modifying options to create a template. Click **Create** to create the template and confirm the options you've just set.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/70b499a-Screen_Shot_2017-05-12_at_8.46.43_PM.png",
        "Screen Shot 2017-05-12 at 8.46.43 PM.png",
        1354,
        1329,
        "#3c3b43"
      ]
    }
  ]
}
[/block]
Templates may also be created by duplicating previous templates from the Templates page:
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/dbcd887-Screen_Shot_2017-05-12_at_8.47.49_PM.png",
        "Screen Shot 2017-05-12 at 8.47.49 PM.png",
        214,
        217,
        "#f2f3f2"
      ]
    }
  ]
}
[/block]
## Sending Notifications using Templates
Once you've created a template, to send a notification using that template click the **Options** button and click **New Message**. 
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/b341ed8-Screen_Shot_2017-05-12_at_8.47.49_PM_copy.png",
        "Screen Shot 2017-05-12 at 8.47.49 PM copy.png",
        214,
        217,
        "#f2f3f2"
      ]
    }
  ]
}
[/block]
This will pre-populate the template options you've set into a new message. You can override these options (such as changing text, an icon, etc) when creating a message, by simply filling in different options. For details on these options, see <a class="dash-link" href="/docs/sending-notifications">New Message</a>.
---
title: "Automated Messages"
excerpt: ""
---
Automatic Messages are used to automatically send a push notification to users once they become part of a segment. For example, this can be used to automatically send a message to inactive users or to congratulate players on reaching a certain level.

You can create a New Automated Message you must use [Templates](doc:templates) 

Once you create the Automated Message you can target it to a specific segment. 

Every hour, OneSignal will deliver this message to users in the selected segments that have not received it yet. However users who have not been active for over 3 months will be excluded from all automated notifications.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/499b65c-Screen_Shot_2017-05-12_at_8.50.22_PM.png",
        "Screen Shot 2017-05-12 at 8.50.22 PM.png",
        1355,
        879,
        "#e0e7ed"
      ]
    }
  ]
}
[/block]
##Example Automated Messages

**Re-Engagment Notification:**
Create segment: Last Active is greater than 48 hours ago, but less than 72 hours ago

Check the box:
*Deliver only once to a user, unless:
The user returns to the app.* 
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/9714547-Screenshot_2017-01-03_16.43.29.png",
        "Screenshot 2017-01-03 16.43.29.png",
        1124,
        328,
        "#e9e9e8"
      ]
    }
  ]
}
[/block]
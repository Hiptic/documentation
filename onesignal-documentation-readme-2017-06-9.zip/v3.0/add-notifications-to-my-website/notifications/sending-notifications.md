---
title: "Sending Notifications"
excerpt: "OneSignal Features - Sending Notifications\n<div class=\"tag-all tag-developers\">For Developers</div> <div class=\"tag-all tag-marketers\">For Marketers</div>"
---
Notifications can be sent via the dashboard on the **New Messages Page**.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/add5b87-Screen_Shot_2017-05-12_at_7.37.15_PM.png",
        "Screen Shot 2017-05-12 at 7.37.15 PM.png",
        1806,
        631,
        "#3c3d46"
      ]
    }
  ]
}
[/block]
### Multiple Languages

The default notification title and contents are sent to:

- All English users
- All other users you do not specify a language-specific title and content for

You can click *Add another language* to add a language-specific title and content:
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/7f664b4-Screen_Shot_2017-05-12_at_7.39.29_PM.png",
        "Screen Shot 2017-05-12 at 7.39.29 PM.png",
        1804,
        694,
        "#f7f7f7"
      ]
    }
  ]
}
[/block]
For example, to target Spanish, Turkish, and Finnish users:

1. Fill in the default Title and Content. This is *always* required, and is sent to any users who *are not* Spanish, Turkish, or Finnish (e.g. English or other users).

2. Click *Add another language* and select Spanish, Turkish, and Finnish. [Supported Languages](doc:language-localization#section-supported-languages) 

3. Fill in the Title and Content for each of your three new languages.

### Selecting Users
There are three options to select which users receive your messages
[block:parameters]
{
  "data": {
    "h-0": "Option",
    "h-1": "Description",
    "0-0": "**Send to Everyone**",
    "1-0": "**Send by Segment**",
    "2-0": "**Send to Test Users**",
    "2-1": "Allows you to select which [Test Users](doc:test-users) to send to. Useful when you're testing new notifications and what to see how they look on devices.",
    "1-1": "If you've set up [User Segments](doc:segmentation), you can both include and exclude segments to send to.",
    "0-1": "Sends to all users."
  },
  "cols": 2,
  "rows": 3
}
[/block]
### Selecting Platforms
The **Platforms & Options** link expands to show you options to send notifications to specific platforms, and customize the presentation and features of those notifications. These features are explained by hovering over the question mark next to each option. 
[block:parameters]
{
  "data": {
    "h-0": "Platform / Option",
    "h-1": "Description",
    "0-0": "Send to iOS Subscribers?",
    "0-1": "Send to <span class=\"label-all label-ios\">iOS</span> devices.",
    "2-0": "Send to Amazon Fire Subscribers?",
    "1-0": "Send to Android Subscribers?",
    "1-1": "Send to <span class=\"label-all label-android\">Android</span> devices.",
    "2-1": "Send to <span class=\"label-all label-amazon\">Amazon</span> devices.",
    "3-0": "Send to Windows Phone 8.0 (MPNS) Subscribers?",
    "4-0": "Send to Windows Phone 8.1 (WNS) Subscribers?",
    "5-0": "Send to macOS Subscribers?",
    "6-0": "Send to Chrome App Subscribers?",
    "7-0": "Send to Chrome Web Subscribers?",
    "8-0": "Send to Safari Web Subscribers?",
    "9-0": "Send to Firefox Web Subscribers?",
    "10-0": "Include Additional Data?",
    "11-0": "Launch URL?",
    "12-0": "Include Android / iOS Action Buttons?",
    "13-0": "Include Chrome Web Push Action Buttons?",
    "3-1": "Send to <span class=\"label-all label-windows\">Windows Phone 8.0</span> devices.",
    "4-1": "Send to <span class=\"label-all label-windows\">Windows Phone 8.1</span> devices.",
    "5-1": "Send to <span class=\"label-all\">macOS</span> devices.",
    "6-1": "Send to <span class=\"label-all\">Chrome Apps & Extensions</span>. <span class=\"label-all label-notrec\">This is not Web Push</span>",
    "7-1": "Send to <span class=\"label-all label-chrome\">Chrome</span> browsers (<span class=\"label-all\">Web Push</span>).",
    "9-1": "Send to <span class=\"label-all label-firefox\">Firefox</span> browsers (<span class=\"label-all\">Web Push</span>).",
    "8-1": "Send to <span class=\"label-all label-safari\">Safari</span> browsers (<span class=\"label-all\">Web Push</span>).",
    "10-1": "<span class=\"label-all label-default\">Default is OFF</span>\n\nCustom key values pairs sent to your app when the notification is opened. See our [SDK API documentation](ref:create-notification) for details on how to read the data in your app.",
    "11-1": "<span class=\"label-all label-default\">Default is OFF</span>\n\nOpens a web browser to the URL when the user taps on the notification.",
    "12-1": "<span class=\"label-all label-default\">Default is OFF</span>\n\nButtons show on the notification itself. Works on <span class=\"label-all label-ios\">iOS 8.0+</span>, <span class=\"label-all label-android\">Android 4.1+</span>, and ChromeApps using our official SDKs.",
    "13-1": "<span class=\"label-all label-default\">Default is OFF</span>\n\n<span class=\"label-all label-chrome\">Chrome 48+</span>: Up to two actions buttons can be shown on a web push notification. Action button icons are only supported on <span class=\"label-all label-chrome\">Chrome 50+</span>."
  },
  "cols": 2,
  "rows": 14
}
[/block]
By default, all device platforms are enabled. You can choose whether to send your notification to individual platforms by toggling the switch next to the platform name:
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/ea7b331-Screen_Shot_2017-05-12_at_7.40.54_PM.png",
        "Screen Shot 2017-05-12 at 7.40.54 PM.png",
        777,
        715,
        "#f2f2f2"
      ]
    }
  ]
}
[/block]
This collapses the section and does not send to devices on selected platform. For example, iOS users will **not** receive notifications when the menu looks like this:

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/5e7a9d6-Screen_Shot_2017-05-12_at_7.46.29_PM.png",
        "Screen Shot 2017-05-12 at 7.46.29 PM.png",
        783,
        100,
        "#f3f3f3"
      ]
    }
  ]
}
[/block]
### Selecting Options

#### Links
To send a link, find the **Launch URL** option and type in the link. Be sure to include the full URL including `http://` or `https://`. This will open an external link when the notification is tapped. To learn more about links, including deep linking, take a look at [our Links documentation](doc:links) 

<span class="label-all label-ios">iOS</span> - To have links open in an in-app browser, take a look at the key settings in the [iOS Native SDK](doc:ios-native-sdk#section--kossettingskeyinapplaunchurl-).
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/fae511f-Screen_Shot_2017-05-12_at_7.47.19_PM.png",
        "Screen Shot 2017-05-12 at 7.47.19 PM.png",
        773,
        147,
        "#f3f3f2"
      ]
    }
  ]
}
[/block]
### Scheduling
Clicking the **Schedule** item lets you select among different notification delivery scheduling options:
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/3eb5210-Screen_Shot_2017-05-12_at_7.49.37_PM.png",
        "Screen Shot 2017-05-12 at 7.49.37 PM.png",
        1673,
        396,
        "#f6f7f7"
      ]
    }
  ]
}
[/block]
----

## FAQ

#### How do I send a notification to a single user?
<div class="label-type"><span class="label-all label-developers">For Developers</span></div>

If you're looking to send notifications to a specific user device:

<ol><li><p>Get the user's userId/playerId with the `getIdsAvailable` or `getIds` SDK method. See the [SDK reference](doc:sdk-reference) to find example code. </p><p>For testing you can use the 'Player ID' shown in <a class="dash-link" href="/docs/users-and-devices">All Users</a> (*you can force kill your app and open it again to bring your device to the top of the list.*)</p></li><li><p>Send the userId from getIdsAvailable or getIds if the pushToken is not null or blank to your server.</p></li><li><p>Set `include_player_ids` to the userId on the PostNotification SDK method or on the [Create notification](ref:create-notification) POST REST API call.</p></li></ol>

This method can be used for User-to-User notifications.
---
title: "Tag & Variable Substitution"
excerpt: ""
---
Notification contents such as message body, title, subtitle and launch URL support place holders inline. They can be substituted with tag values for each user. These can be set on the user with the sendTag(s) functions on our SDKs.

Let says for example you want to send a notification with their name and current stage they are on in your game. Example:
***Hello Josh! We just improved our controls, come back and see if you can beat level 10!***

Add `{{ tag_key | default: "default_value" }}` inline with your message text. Replacing `tag_key` with your own key, as well as the required default value. Example let say you have the following 3 users.
**User 1:** `tags: {name: "Josh", current_stage: 10}`
**User 2:** `tags: {name: "George", current_stage: 9}`
**User 3:** `tags: {}`

Send a notification with the following contents:
```
Hello {{ name | default: "there"}}!
We just improved our controls, come back and see if you can beat level {{ current_stage | default: "1" }}!
```

This will result in the following notifications going out to each user.

**User 1:** ***Hello Josh! We just improved our controls, come back and see if you can beat level 10!***
**User 2:** ***Hello George! We just improved our controls, come back and see if you can beat level 9!***
**User 3:** ***Hello there! We just improved our controls, come back and see if you can beat level 1!***

---
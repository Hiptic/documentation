---
title: "Action Buttons"
excerpt: "OneSignal Features - Action Buttons\n<div class=\"tag-all tag-developers\">For Developers</div> <div class=\"tag-all tag-marketers\">For Marketers</div>"
---
Typically when a user receives a notification, there is only a single action available - tapping on the notification. **Action Buttons** allow more than one action to be taken on a notification, allowing for greater interactivity within notifications. 


## Action Button Examples

Calendar events - Accept, Maybe, Decline

New content posted - Open, Like

Task management - Complete, Snooze, Ignore


## What Action Buttons look like
<span class="label-all label-chrome">Chrome</span> - A notification with a Like action and a URL open action:
<img src="http://i.imgur.com/nyVvl3L.png" style="background: url(http://i.imgur.com/nyVvl3L.png) no-repeat 0 0; background-size: contain;	height: auto; max-width: 50%; margin: 0 auto; display: block;"/>

<span class="label-all label-ios">iOS</span> - A [Rich Media](doc:rich-media) notification with three Action Buttons:
<img src="https://files.readme.io/c3b7c18-iOSActionButtonExample.png" width="250"/>


 ## Platforms Supported
[block:parameters]
{
  "data": {
    "h-0": "Platform",
    "h-1": "Support Notes",
    "h-2": "Support Notes",
    "0-0": "<span class=\"label-all label-ios\">iOS</span>",
    "2-0": "<span class=\"label-all label-chrome\">Chrome</span>",
    "3-0": "<span class=\"label-all label-firefox\">Firefox</span>, <span class=\"label-all label-safari\">Safari</span>",
    "2-1": "Supports **2** buttons (Chrome 48+)\n\nChrome 48+: You can use emojis for the button text to simulate an icon.\n\nChrome 50+: action button icon supported.",
    "3-1": "Buttons **not** supported",
    "1-0": "<span class=\"label-all label-android\">Android</span>, <span class=\"label-all label-amazon\">Amazon</span>",
    "1-1": "Supports up to **3** buttons.",
    "0-1": "Supports up to **4** buttons with [Rich Notifications](doc:rich-media#section-rich-notifications)",
    "2-2": ""
  },
  "cols": 2,
  "rows": 4
}
[/block]

## OneSignal Dashboard
Action Button options are available within <a class="dash-link" href="/docs/sending-notifications">New Message</a> under **Options**. By default, action buttons are **disabled**. 

## Tutorial: Customizing Action Buttons
If you're ready to create notifications with action buttons, follow our [Customize Action Buttons tutorial](doc:customize-action-buttons).

## Further Reading
[iOS Human Interface Guidelines: Notifications](https://developer.apple.com/ios/human-interface-guidelines/features/notifications/)

[Android Notification Guide](https://developer.android.com/guide/topics/ui/notifiers/notifications.html)
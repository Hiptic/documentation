---
title: "Content Length"
excerpt: "Notification Content Length\n<div class=\"tag-all tag-developers\">For Developers</div>  <div class=\"tag-all tag-marketers\">For Marketers</div>"
---
The limit of how much content can be sent in a notification is based on the body, title, customURL or any custom data you add. This is roughly 3500 characters for both <span class="label-all label-android">Android</span> (GCM) and <span class="label-all label-ios">iOS</span> (APNS).

For <span class="label-all label-all">Web Push</span>, the limit is between 100 and 190 characters, depending on whether a long title is used. 
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/r1gHlN8OQjOeFU0GKdvR_push-1.jpg",
        "push-1.jpg",
        "350",
        "137",
        "#ac8c7c",
        ""
      ]
    }
  ]
}
[/block]

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/BwQdcUxUQEunGfatZ7ET_push-2.jpg",
        "push-2.jpg",
        "350",
        "137",
        "#5d5f63",
        ""
      ]
    }
  ]
}
[/block]

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/axST2hOFTvCTP6LH9sbx_push-3.jpg",
        "push-3.jpg",
        "350",
        "137",
        "#94775d",
        ""
      ]
    }
  ]
}
[/block]
---
title: "Run Code upon Receipt"
excerpt: "<div class=\"tag-all tag-developers\">For Developers</div>"
---
To run custom code when a notification is received, do the following:

<span class="label-all label-ios">iOS</span> - Setup a [OSHandleNotificationReceivedBlock](doc:ios-native-sdk#section--oshandlenotificationreceivedblock-) with the OneSignal [initWithLaunchOptions](doc:ios-native-sdk#section--initwithlaunchoptions-). When sending a notification enable "Content Available" under Options > iOS on the New Message page from theOneSignal dashboard. Or set `content_available` to `true` if your are sending the notification through the OneSignal REST API.

*Note: The block will not be called if the user has force closed your app by double tapping the home button and swiping it away.*


<span class="label-all label-android">Android</span>  - See our [Background Data and Notification Overriding](doc:android-customizations#section-background-data-and-notification-overriding) guide for details on receiving and processing the event.

*Note: If your app is in a "Force Stopped" state all Intents including FCM / GCM will not be able to wake your app up.

See [Notifications show successful but are not being shown](doc:notifications-show-successful-but-are-not-being-shown)  for more details on this app state.*
---
title: "Links"
excerpt: "OneSignal Features - Linking to internal and external URIs\n<div class=\"tag-all tag-developers\">For Developers</div>"
---
To send links via the dashboard, read [Sending Notifications](doc:sending-notifications#section-links). 

## Deep Links
<span class="label-all label-ios">iOS</span>, <span class="label-all label-android">Android</span>

Deep linking into a specific location within the app is a very common thing when sending a push notification. There are two options below, the first being easier to setup and the second registers the deep link at the mobile OS level to which can be used for more than notifications.

#### With additional data *(Recommended)*
Whenever you need to direct users to a specific location in your app, make sure to send all the relevant information as part of additional data. It can set under New Message > Options > Additional Data from the OneSignal Dashboard or 'data' on the create notification REST API call. 

The value can be read in your app from `result.notification.payload.additionalData` ([iOS](ios-native-sdk#section--osnotificationpayload-), [Android](doc:android-native-sdk#section--osnotificationpayload-)) and handle the direction within the notification event([iOS: OSNotificationHandleActionBlock](ios-native-sdk#section--oshandlenotificationactionblock-) OR [Android: NotificationOpenedHandler](android-native-sdk#section--notificationopenedhandler-)).
[block:callout]
{
  "type": "info",
  "title": "Github Examples",
  "body": "Please see our [iOS Swift Example](https://github.com/OneSignal/OneSignal-iOS-SDK/tree/master/Examples/SwiftExample) on Github or our [Android Example](https://github.com/OneSignal/OneSignal-Android-SDK) in the Examples folder labeled AndroidStudio."
}
[/block]
#### OS level deep links
If deep linking into another app, then you should send the deep link as part of the regular URL field of the posted notification. See iOS's documentation on [UniversalLinks](https://developer.apple.com/library/content/documentation/General/Conceptual/AppSearch/UniversalLinks.html) and Android [Deep Linking](https://developer.android.com/training/app-indexing/deep-linking.html).

**Note** - Support for 3rd party SDKs such as [Branch](https://dev.branch.io/getting-started/sdk-integration-guide/guide/ios/) is limited. Sending a deep link as `Example: @{ @"branch" : @"https://[branchsubdomain]/ALMc/e03OVEJLUq" }` may lead to undefined behavior.



## URLs

### How do I open a URL in my app instead of the web browser?

<span class="label-all label-android">Android</span> - The Launch URL feature on the dashboard or the `url` field on the REST API automatically opens the web browser on the mobile device when the notification is tapped on. If you would like to open the URL inside your app instead of the browser, you need to send your notification with custom data that can read by your app's SDK. If you're using our dashboard to send notifications, the sending notification options allows you to include additional data to be sent with your notification. If you're using our API to send notifications, you can set the 'data' field to a JSON object hash of extra custom data. For example, you could set `targetUrl` for the key and `https://google.com` as the value. Then in your app's code read the `targetUrl` value from additionalData in the NotificationOpened callback (name depends on the OneSignal SDK used). [Github Android Example](https://github.com/OneSignal/OneSignal-Android-SDK)

<span class="label-all label-ios">iOS</span> - Setting launch URL will open the page as a WebView inside your app by default. If need more control follow the Android note above. [Github iOS Swift Example](https://github.com/OneSignal/OneSignal-iOS-SDK/tree/master/Examples/SwiftExample)

<span class="label-all">Cordova variants</span> - See the "Open Page in App" example code for your particular SDK: [PhoneGap SDK](doc:phonegap-sdk#section--notificationopenedcallback-), [Cordova SDK](doc:cordova-sdk#section--notificationopenedcallback-), [Ionic SDK](doc:ionic-sdk#section--notificationopenedcallback-), [Intel XDK](doc:intel-xdk#section--notificationopenedcallback-).

## Dynamic URLs

Using variables to write your URL is not currently supported. Use these two alternate methods instead:

1. Deliver notifications individually to each user through [our REST API](ref:create-notification), with a different URL for each.

2. Provide a [notificationOpenedCallback](http://documentation.onesignal.com/docs/website-sdk-api#section-notificationopenedcallback). In that callback, fetch the user's OneSignal details using `getIdsAvailable` or `getTags` and redirect them to the page of your choice.
---
title: "New session"
excerpt: "Update a device's session information"
---
This method should be called when a device opens your app after they are already registered. This method will automatically increment the player's `session_count`, and should also be used to update any fields that may have changed (such as language or timezone).
[block:callout]
{
  "type": "warning",
  "title": "Requires Authentication Key",
  "body": "Requires your OneSignal User Auth Key, available in <a class=\"dash-link\" href=\"/docs/accounts-and-keys#section-keys-ids\">Keys & IDs</a>."
}
[/block]
## Body Parameters - New session
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`identifier`",
    "0-1": "String",
    "0-2": "<span class=\"label-all label-recommended\">Recommended</span> Push notification identifier from Google or Apple. For Apple push identifiers, you must strip all non alphanumeric characters. Example: `ce777617da7f548fe7a9ab6febb56`",
    "1-1": "String",
    "2-1": "Int",
    "3-1": "String",
    "4-1": "String",
    "5-1": "String",
    "6-1": "String",
    "7-1": "Object",
    "1-0": "`language`",
    "2-0": "`timezone`",
    "3-0": "`game_version`",
    "4-0": "`device_os`",
    "4-2": "<span class=\"label-all label-recommended\">Recommended</span> Device operating system version. Example: `7.0.4`",
    "5-0": "`ad_id`",
    "6-0": "`sdk`",
    "7-0": "`tags`",
    "6-2": "<span class=\"label-all label-recommended\">Recommended</span> Name and version of sdk/plugin that's calling this method.",
    "7-2": "Custom tags for the player. Only support string key value pairs. Does not support arrays or other nested objects. Example: `{\"foo\":\"bar\",\"this\":\"that\"}`",
    "5-2": "<span class=\"label-all label-recommended\">Recommended</span> The ad id for the device's platform:\nAndroid = `Advertising Id`\niOS = `identifierForVendor`\nWP8.0 = `DeviceUniqueId`\nWP8.1 = `AdvertisingId`",
    "3-2": "<span class=\"label-all label-recommended\">Recommended</span> Version of your app. Example: `1.1`",
    "2-2": "<span class=\"label-all label-recommended\">Recommended</span> Number of seconds away from UTC. Example: `-28800`",
    "1-2": "<span class=\"label-all label-recommended\">Recommended</span> Language code. Typically lower case two letters, except for Chinese where it must be one of `zh-Hans` or `zh-Hant`. Example: `en`"
  },
  "cols": 3,
  "rows": 8
}
[/block]
## Example Code - New session
[block:code]
{
  "codes": [
    {
      "code": "curl --include \\\n     --request POST \\\n     --header \"Content-Type: application/json\" \\\n     --data-binary \"{\\\"language\\\":\\\"es\\\",\n\\\"timezone\\\":-28800,\n\\\"game_version\\\":\\\"1.0\\\",\n\\\"device_os\\\":\\\"7.0.4\\\"}\" \\\n     https://onesignal.com/api/v1/players/:id/on_session",
      "language": "shell"
    }
  ]
}
[/block]
## Result Format - New session
[block:code]
{
  "codes": [
    {
      "code": "{\"success\": true }",
      "language": "json",
      "name": "200 OK"
    }
  ]
}
[/block]
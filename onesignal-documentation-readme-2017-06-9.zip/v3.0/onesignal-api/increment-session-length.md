---
title: "Increment session length"
excerpt: "Update a device's session length upon app resuming"
---
Call this method when the app is resumed or placed into from standby.

The active_time field should be set to the duration between the last on_focus call since the app was opened. If no previous on_focus was called, then the duration should be either the time since POST `/players/:id/on_session` or POST `/players` were called.

## Body Parameters - Increment session length
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`state`",
    "0-1": "String",
    "1-0": "`active_time`",
    "1-1": "Int",
    "1-2": "<span class=\"label-all label-required\">Required</span> The lesser of: The number of seconds since either: 1. on_focus was last called OR 2.  on_session or the device first registered (POST /players)",
    "0-2": "<span class=\"label-all label-required\">Required</span> Set to \"ping\""
  },
  "cols": 3,
  "rows": 2
}
[/block]
## Example Code - Increment session length
[block:code]
{
  "codes": [
    {
      "code": "curl --include \\\n     --request POST \\\n     --header \"Content-Type: application/json\" \\\n     --data-binary \"{\\\"state\\\": \\\"ping\\\",\n \\\"active_time\\\": 60}\" \\\n     https://onesignal.com/api/v1/players/:id/on_focus",
      "language": "shell"
    }
  ]
}
[/block]
## Result Format - Increment session length
[block:code]
{
  "codes": [
    {
      "code": "{\"success\": true }",
      "language": "json",
      "name": "200 OK"
    }
  ]
}
[/block]
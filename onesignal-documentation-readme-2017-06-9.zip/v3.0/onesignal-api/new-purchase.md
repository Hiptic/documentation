---
title: "New purchase"
excerpt: "Track a new purchase in your app"
---
This will increment the player's `amount_spent`.

## Body Parameters - New purchase
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`purchases`",
    "0-1": "Array",
    "0-2": "<span class=\"label-all label-required\">Required</span> An array of purchases, each with the properties listed below.",
    "1-0": "`purchases[sku]`",
    "2-0": "`purchases[amount]`",
    "3-0": "`purchases[iso]`",
    "4-0": "`existing`",
    "1-1": "String",
    "2-1": "Double",
    "3-1": "String",
    "4-1": "Boolean",
    "1-2": "<span class=\"label-all label-required\">Required</span> The unique identifier of the purchased item.",
    "2-2": "<span class=\"label-all label-required\">Required</span> The amount, in USD, spent purchasing the item.",
    "3-2": "<span class=\"label-all label-required\">Required</span> The 3-letter [ISO 4217](http://www.currency-iso.org/dam/downloads/lists/list_one.xml) currency code. Required for correct storage and conversion of amount.",
    "4-2": "Pass true on the first run of your app if you're tracking existing non-consumable purchases. This prevents tracking the same purchases more than once if the user re-installs your app."
  },
  "cols": 3,
  "rows": 5
}
[/block]
## Example Code - New purchase
[block:code]
{
  "codes": [
    {
      "code": "curl --include \\\n     --request POST \\\n     --header \"Content-Type: application/json\" \\\n     --data-binary \"{\\\"purchases\\\": [{\\\"sku\\\": \\\"SKU123\\\", \\\"iso\\\": \\\"USD\\\", \\\"amount\\\": \\\"0.99\\\"}]}\" \\\n     https://onesignal.com/api/v1/players/:id/on_purchase",
      "language": "curl"
    },
    {
      "code": "{\n  \"purchases\": \n    [{\"sku\": \"SKU123\",\n    \"iso\": \"USD\",\n    \"amount\": \"0.99\"}]\n}",
      "language": "json",
      "name": "Purchase Format"
    }
  ]
}
[/block]
## Result Format - New purchase
[block:code]
{
  "codes": [
    {
      "code": "{\"success\": true }",
      "language": "json",
      "name": "200 OK"
    }
  ]
}
[/block]
---
title: "View notification"
excerpt: "View the details of a single notification"
---
[block:callout]
{
  "type": "warning",
  "title": "Requires Authentication Key",
  "body": "Requires your OneSignal User Auth Key, available in <a class=\"dash-link\" href=\"/docs/accounts-and-keys#section-keys-ids\">Keys & IDs</a>."
}
[/block]
## Path Parameters
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-2": "<span class=\"label-all label-required\">Required</span> Notification ID",
    "1-2": "<span class=\"label-all label-required\">Required</span> App ID",
    "0-0": "`id`",
    "0-1": "String",
    "1-0": "`app_id`",
    "1-1": "String"
  },
  "cols": 3,
  "rows": 2
}
[/block]
## Example Code - View notification
[block:code]
{
  "codes": [
    {
      "code": "curl --include \\\n     --header \"Authorization: Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\" \\\n https://onesignal.com/api/v1/notifications/{notificationId}?app_id={appId}",
      "language": "shell",
      "name": "Shell"
    },
    {
      "code": "<?PHP\n\t\t$ch = curl_init();\n    curl_setopt($ch, CURLOPT_URL, \"https://onesignal.com/api/v1/notifications/YOUR_NOTIFICATION_ID?app_id=YOUR_APP_ID\");\n    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json',\n                           'Authorization: Basic AUTH_KEY'));\n    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);\n    curl_setopt($ch, CURLOPT_HEADER, FALSE);\n    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);\n\n    $response = curl_exec($ch);\n    curl_close($ch);\n\t\t$return[\"allresponses\"] = $response;\n  \t$return = json_encode( $return);\n  \n\t  print(\"\\n\\nJSON received:\\n\");\n\t  print($return);\n\t  print(\"\\n\");\n?>",
      "language": "php",
      "name": "PHP"
    }
  ]
}
[/block]
### Returned Fields
- `remaining` - Number of notifications that have not been sent out yet. This can mean either our system is still processing the notification or you have delayed options set.
- `failed` - Number of notifications that could not be delivered due to an error. You can find more information by viewing the notification in the dashboard.
- `converted` - Number of users who have clicked / tapped on your notification.

## Result Format - View notification
[block:code]
{
  "codes": [
    {
      "code": "{\n  \"id\":\"481a2734-6b7d-11e4-a6ea-4b53294fa671\",\n  \"successful\":15,\n  \"failed\":1,\n  \"converted\":3,\n  \"remaining\":0,\n  \"queued_at\":1415914655,\n  \"send_after\":1415914655,  \n  \"url\": \"https://yourWebsiteToOpen.com\",\n  \"data\":{\n    \"foo\":\"bar\",\n   \t\"your\":\"custom metadata\"\n  },\n  \"canceled\": false,\n  \"headings\":{\n      \"en\":\"English and default langauge heading\",\n      \"es\":\"Spanish language heading\"\n  },\n  \"contents\":{\n    \"en\":\"English language content\",\n    \"es\":\"Hola\"\n  }\n}",
      "language": "json",
      "name": "200 OK"
    }
  ]
}
[/block]
---
title: "Create notification"
excerpt: "Sends notifications to your users"
---
The Create Notification method is used when you want your server to programmatically send notifications to a segment or individual users. You may target users in one of three ways using this method: by **Segment**, by **Filter**, or by **Device**. At least one targeting parameter must be specified. 
[block:callout]
{
  "type": "warning",
  "title": "You may only use one method of targeting users",
  "body": "If a targeting parameter of one type is used, then targeting parameters from other types may not be used. For instance, you cannot use the `included_segments` parameter (from segments) with the `filters`."
}
[/block]
## Send to Segments
[Segments](doc:segmentation) are the most common way developers send notifications via OneSignal. Sending to segments is easy: you simply specify which segments you want to send to, and, optionally, which ones you don't. 
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "0-0": "`included_segments`",
    "1-0": "`excluded_segments`",
    "1-1": "array_string",
    "0-1": "array_string",
    "h-2": "Description",
    "0-2": "<p><span class=\"label-all label-required\">Required</span> The segment names you want to target. Users in these segments *will* receive a notification. This targeting parameter is *only compatible with* `excluded_segments`.</p>\n<p>Example: `[\"Active Users\", \"Inactive Users\"]`</p>",
    "1-2": "<p>Segment that will be excluded when sending. Users in these segments *will not* receive a notification, even if they were included in `included_segments`. This targeting parameter is *only compatible with* `included_segments`.</p>\n<p>Example: `[\"Active Users\", \"Inactive Users\"]`</p>"
  },
  "cols": 3,
  "rows": 2
}
[/block]

[block:callout]
{
  "type": "warning",
  "title": "Requires Authentication Key",
  "body": "Requires your OneSignal App Auth Key, available in <a class=\"dash-link\" href=\"/docs/accounts-and-keys#section-keys-ids\">Keys & IDs</a>."
}
[/block]
### Segments Usage
- Tip: If you want to send to all your users, just send to the `All Users` segment, which is available in every app you create in OneSignal. 

[See below for example code](#section-example-code-create-notification)


## Send to Users Based on Filters
[Filters](doc:segmentation#section-creating-segments-using-filters) are a powerful way to target users, allowing you to use both data that OneSignal has about a user and any [Tags](doc:data-tags) your app may send OneSignal. Filters can be combined together to form advanced, highly precise user targeting. OneSignal customers use all sorts of filters to send notifications, including language, location, user activity, and more.

The `filters` parameter targets notification recipients using an array of JSON objects containing field conditions to check. The following are filter field options:
[block:parameters]
{
  "data": {
    "h-0": "Option",
    "h-1": "Description",
    "0-0": "`last_session`",
    "0-1": "`relation` = `\">\"` or `\"<\"`\n`hours_ago` = number of hours before or after the users last session. Example: `\"1.1\"`",
    "1-0": "`first_session`",
    "1-1": "`relation` = `\">\"` or `\"<\"`\n`hours_ago` = number of hours before or after the users first session. Example: `\"1.1\"`",
    "2-0": "`session_count`",
    "2-1": "`relation` = `\">\"`, `\"<\"`, `\"=\"` or `\"!=\"`\n`value` = number sessions. Example: `\"1\"`",
    "3-0": "`session_time`",
    "3-1": "`relation` = `\">\"` or `\"<\"` \n`value` = Time in seconds the user has been in your app. Example: `\"3600\"`",
    "4-0": "`amount_spent`",
    "4-1": "`relation` = `\">\"`, `\"<\"`, or `\"=\"`\n`value` = Amount in USD a user has spent on IAP (In App Purchases). Example: `\"0.99\"`",
    "5-0": "`bought_sku`",
    "5-1": "`relation` = `\">\"`, `\"<\"` or `\"=\"`\n`key` = SKU purchased in your app as an IAP (In App Purchases). Example: `\"com.domain.100coinpack\"`\n`value` = value of SKU to compare to. Example: `\"0.99\"`",
    "6-0": "`tag`",
    "6-1": "`relation` = `\">\"`, `\"<\"`, `\"=\"`, `\"!=\"`, `\"exists\"` or `\"not_exists\"`\n`key` = Tag key to compare.\n`value` = Tag value to compare. Not required for `\"exists\"` or `\"not_exists\"`. Example: See [Formatting Filters](#section-formatting-filters)",
    "7-0": "`language`",
    "7-1": "`relation` = `\"=\"` or `\"!=\"`\n`value` = 2 character language code. Example: `\"en\"`. For a list of all language codes [go here](doc:language-localization)",
    "8-0": "`app_version`",
    "8-1": "`relation` = `\">\"`, `\"<\"`, `\"=\"` or `\"!=\"`\n`value` = app version. Example: `\"1.0.0\"`",
    "9-0": "`location`",
    "9-1": "`radius` = in meters\n`lat` = latitude\n`long` = longitude",
    "10-0": "`email`",
    "10-1": "`value` = email address"
  },
  "cols": 2,
  "rows": 11
}
[/block]

[block:callout]
{
  "type": "warning",
  "title": "Requires Authentication Key",
  "body": "Requires your OneSignal App Auth Key, available in <a class=\"dash-link\" href=\"/docs/accounts-and-keys#section-keys-ids\">Keys & IDs</a>."
}
[/block]
### Filter Usage
- Filter entries use `AND` by default; insert `{"operator": "OR"}` between entries to `OR` the parameters together.
- For performance reasons, a *maximum of 200 entries* can be used at a time. The 200 entries limit includes the "relation" entry and "field" entry -- each entry contributes to the 200 limit.
- This filter targeting parameter cannot be combined with any other targeting parameters.

### Formatting Filters
The power of filters comes from combining several fields and operators to precisely target your users. The following are examples of filters and how to format them:

1. A user *is* level 10 *and* purchased an item

2. A user *is* level 10 *or* 20

3. A user *is not* VIP *or* is admin

4. User's tags include key username *and* the user is not banned.
[block:code]
{
  "codes": [
    {
      "code": "[\n  {\"field\": \"tag\", \"key\": \"level\", \"relation\": \">\", \"value\": \"10\"},\n  {\"field\": \"amount_spent\", \"relation\": \">\",\"value\": \"0\"}\n]",
      "language": "json",
      "name": "Formatting Example 1"
    },
    {
      "code": "[\n  {\"field\": \"tag\", \"key\": \"level\", \"relation\": \"=\", \"value\": \"10\"}, \n  {\"operator\": \"OR\"}, {\"field\": \"tag\", \"key\": \"level\", \"relation\": \"=\", \"value\": \"20\"}\n]",
      "language": "json",
      "name": "Formatting Example 2"
    },
    {
      "code": "[\n  {\"field\": \"tag\", \"key\": \"is_vip\", \"relation\": \"!=\", \"value\": \"true\"},\n  {\"operator\": \"OR\"}, {\"field\": \"tag\",\"key\": \"is_admin\", \"relation\": \"=\", \"value\": \"true\"}\n]",
      "language": "json",
      "name": "Formatting Example 3"
    },
    {
      "code": "[\n  {\"field\": \"tag\", \"key\": \"username\", \"relation\": \"exists\"},\n  {\"field\": \"tag\", \"key\": \"banned\", \"relation\": \"!=\", \"value\": \"true\"}\n]",
      "language": "json",
      "name": "Formatting Example 4"
    }
  ]
}
[/block]
[See below for example code](#section-example-code-create-notification)

*Note: ANDs have priority over ORs.*

## Send to Specific Devices
Finally, you may also target specific devices with the create notification method. Targeting devices is typically used in two ways:

1. For notifications that target individual users, such as if they've received a message from someone. 

2. For apps that wish to manage their own segments, such as tracking a user's followers and sending notifications to them when that user posts.

When targeting specific devices, you may use any of the following parameters together:
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "0-0": "`include_player_ids`",
    "1-0": "`include_ios_tokens`",
    "2-0": "`include_wp_urls`",
    "3-0": "`include_wp_wns_uris`",
    "4-0": "`include_amazon_reg_ids`",
    "5-0": "`include_chrome_reg_ids`",
    "6-0": "`include_chrome_web_reg_ids`",
    "0-1": "array_string",
    "1-1": "array_string",
    "2-1": "array_string",
    "3-1": "array_string",
    "4-1": "array_string",
    "5-1": "array_string",
    "6-1": "array_string",
    "7-0": "`include_android_reg_ids`",
    "7-1": "array_string",
    "h-2": "Description",
    "0-2": "<p><span class=\"label-all label-recommended\">Recommended</span> - Specific players to send your notification to. _Does not require API Auth Key._</p>\n<p>Do not combine with other targeting parameters. Not compatible with any other targeting parameters. Example: `[\"1dd608f2-c6a1-11e3-851d-000c2940e62c\"]`\n*Limit of 2,000 entries per REST API call*",
    "1-2": "<p><span class=\"label-all label-notrec\">Not Recommended</span> - Please consider using `include_player_ids` instead.</p>\n<p>Target using iOS device tokens. **Warning:** Only works with *Production* tokens.</p>\n<p>All non-alphanumeric characters must be removed from each token. If a token does not correspond to an existing user, a new user will be created. Example: `ce777617da7f548fe7a9ab6febb56cf39fba6d38203...`</p>\n*Limit of 2,000 entries per REST API call*",
    "2-2": "<p><span class=\"label-all label-notrec\">Not Recommended</span> Please consider using `include_player_ids` instead.</p>\n<p>Target using Windows Phone 8.0 URIs. If a token does not correspond to an existing user, a new user will be created. Example: `http://s.notify.live.net/u/1/bn1/HmQAAACPaLDr-...`</p>\n*Limit of 2,000 entries per REST API call*",
    "3-2": "<p><span class=\"label-all label-notrec\">Not Recommended</span> Please consider using `include_player_ids` instead.</p>\n<p>Target using Windows Phone 8.1 URIs. If a token does not correspond to an existing user, a new user will be created. Example: `http://s.notify.live.net/u/1/bn1/HmQAAACPaLDr-...`</p>\n*Limit of 2,000 entries per REST API call*",
    "4-2": "<p><span class=\"label-all label-notrec\">Not Recommended</span> Please consider using `include_player_ids` instead.</p>\n<p>Target using Amazon ADM registration IDs. If a token does not correspond to an existing user, a new user will be created. Example: `amzn1.adm-registration.v1.XpvSSUk0Rc3hTVVV...`</p>\n*Limit of 2,000 entries per REST API call*",
    "5-2": "<p><span class=\"label-all label-notrec\">Not Recommended</span> Please consider using `include_player_ids` instead.</p>\n<p>Target using Chrome App registration IDs. If a token does not correspond to an existing user, a new user will be created. Example: `APA91bEeiUeSukAAUdnw3O2RB45FWlSpgJ7Ji_...`</p>\n*Limit of 2,000 entries per REST API call*",
    "6-2": "<p><span class=\"label-all label-notrec\">Not Recommended</span> Please consider using `include_player_ids` instead, as web push registration IDs can vary over time where OneSignal player IDs remain constant.</p>\n<p>Target using Chrome Web Push registration IDs. If a token does not correspond to an existing user, a new user will be created. Example: `APA91bEeiUeSukAAUdnw3O2RB45FWlSpgJ7Ji_...`</p>\n*Limit of 2,000 entries per REST API call*",
    "7-2": "<p><span class=\"label-all label-notrec\">Not Recommended</span> Please consider using `include_player_ids` instead, as android tokens occasionally change, which causes devices to become invalid and limits your audience.</p>\n<p>Target using Android device registration IDs. If a token does not correspond to an existing user, a new user will be created. Example: `APA91bEeiUeSukAAUdnw3O2RB45FWlSpgJ7Ji_...`</p>\n*Limit of 2,000 entries per REST API call*"
  },
  "cols": 3,
  "rows": 8
}
[/block]
### Specific Devices Usage
[block:callout]
{
  "type": "warning",
  "title": "Requires Authentication Key",
  "body": "This method requires an application 'REST API Key' when using `include_segments` or `filters`, which is available in <a class=\"dash-link\" href=\"/docs/accounts-and-keys#section-keys-ids\">Keys & IDs</a>.\n\n**NEVER** use your 'REST API key' in client code, it is intended for use on your system or server only. Add the REST API Key to the HTTP 'Authorization' header as basic authentication. Check out the examples above (except the JSON example) for some tips."
}
[/block]
[See below for example code](#section-example-code-create-notification)

## Common Parameters
The following are parameters in Create Notifications common to all methods of targeting users. 

### App
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "0-0": "`app_id`",
    "0-1": "string",
    "h-1": "Type",
    "0-2": "<span class=\"label-all\">All</span>",
    "h-2": "Platform",
    "1-0": "`app_ids`",
    "1-1": "array of strings",
    "1-2": "<span class=\"label-all label-android\">Android</span>, <span class=\"label-all label-ios\">iOS</span>",
    "h-3": "",
    "0-3": "<span class=\"label-all label-required\">Required</span> Your OneSignal application ID, which can be found in <a class=\"dash-link\" href=\"/docs/accounts-and-keys#section-keys-ids\">Keys & IDs</a>. It is a UUID and looks similar to `8250eaf6-1a58-489e-b136-7c74a864b434`.",
    "1-3": "<p><span class=\"label-all label-required\">Required</span> Your User Auth Key, which can be found in <a class=\"dash-link\" href=\"/docs/accounts-and-keys#section-user-auth-key\">Account</a>.</p>\n<p>`app_ids` contains an array of OneSignal app IDs. All users within these apps will receive at most one notification.</p>\n<p>Example: `[\"2dd608f2-a6a1-11e3-251d-400c2940e62b\", \"2dd608f2-a6a1-11e3-251d-500f2950e61c\"]`</p>\n<span class=\"label-all label-notrec\">Important Node:</span> No targeting parameters may be used when using the `app_ids` parameter. All subscribed users will receive the notification",
    "0-4": "",
    "1-4": "",
    "h-4": "Description"
  },
  "cols": 4,
  "rows": 2
}
[/block]
### Content & Language
The content you want to send in notifications. [Read more: supported languages.](doc:language-localization#section-supported-languages)
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Platform",
    "h-3": "Description",
    "0-0": "`contents`",
    "0-1": "object",
    "0-2": "<span class=\"label-all\">All</span>",
    "0-3": "<p><span class=\"label-all label-required\">Required</span> unless `content_available=true` or `template_id` is set.</p>\n<p>The notification's content (excluding the title), a map of language codes to text for each language.</p>\n<p>Each hash must have a language code string for a key, mapped to the localized text you would like users to receive for that language. \n**This field supports [inline substitutions](doc:tag-variable-substitution).**\n**English must be included in the hash**.</p>\n<p>Example: `{\"en\": \"English Message\", \"es\": \"Spanish Message\"}`</p>",
    "4-3": "Sending `true` wakes your app from background to run custom native code (Apple interprets this as `content-available=1`). *Note: Not applicable if the app is in the \"force-quit\" state (i.e app was swiped away).* Omit the `contents` field to prevent displaying a visible notification.",
    "4-2": "<span class=\"label-all label-ios\">iOS</span>",
    "4-1": "boolean",
    "4-0": "`content_available`",
    "5-0": "`mutable_content`",
    "5-1": "boolean",
    "5-2": "<span class=\"label-all label-ios\">iOS 10+</span>",
    "5-3": "Sending `true` allows you to change the notification content in your app before it is displayed. Triggers `didReceive(_:withContentHandler:)` on your [UNNotificationServiceExtension](https://developer.apple.com/reference/usernotifications/unnotificationserviceextension).",
    "3-0": "`template_id`",
    "3-1": "string",
    "3-2": "<span class=\"label-all\">All</span>",
    "3-3": "<p>Use a template you setup on our dashboard. You can override the template values by sending other parameters with the request. The template_id is the UUID found in the URL when viewing a template on our dashboard.</p>\n<p>Example: `be4a8044-bbd6-11e4-a581-000c2940e62c`</p>",
    "1-0": "`headings`",
    "1-1": "object",
    "1-2": "<span class=\"label-all\">All</span>",
    "1-3": "<p>The notification's title, a map of language codes to text for each language. Each hash must have a language code string for a key, mapped to the localized text you would like users to receive for that language. A default title may be displayed if a title is not provided.\n**This field supports [inline substitutions](doc:tag-variable-substitution).**</p>\n<p>Example: `{\"en\": \"English Title\", \"es\": \"Spanish Title\"}`</p>",
    "2-0": "`subtitle`",
    "2-1": "object",
    "2-2": "<span class=\"label-all label-ios\">iOS 10+</span>",
    "2-3": "<p>The notification's subtitle, a map of language codes to text for each language. Each hash must have a language code string for a key, mapped to the localized text you would like users to receive for that language. A default title may be displayed if a title is not provided.\n**This field supports [inline substitutions](doc:tag-variable-substitution).**</p>\n<p>Example: `{\"en\": \"English Subtitle\", \"es\": \"Spanish Subtitle\"}`</p>"
  },
  "cols": 4,
  "rows": 6
}
[/block]
### Attachments
These are additional content attached to notifications, primarily images.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Platform",
    "h-3": "Description",
    "0-0": "`data`",
    "0-3": "<p>A custom map of data that is passed back to your app.</p> \n<p>Example: `{\"abc\": \"123\", \"foo\": \"bar\"}`</p>",
    "0-1": "object",
    "0-2": "<span class=\"label-all\">All</span>",
    "2-0": "`ios_attachments`",
    "2-1": "object",
    "2-2": "<span class=\"label-all label-ios\">iOS 10+</span>",
    "2-3": "<p>Adds media attachments to notifications. Set as JSON object, key as a media id of your choice and the value as a valid local filename or URL. User must press and hold on the notification to view.</p>\n<p>Do not set `mutable_content` to download attachments. The OneSignal SDK does this automatically</p>\n<p>Example: `{\"id1\": \"https://domain.com/image.jpg\"}`</p>",
    "3-0": "`big_picture`",
    "3-1": "string",
    "3-2": "<span class=\"label-all label-android\">Android</span>",
    "3-3": "Picture to display in the expanded view. Can be a drawable resource name or a URL.",
    "4-3": "Picture to display in the expanded view. Can be a drawable resource name or a URL.",
    "4-0": "`adm_big_picture`",
    "4-1": "string",
    "4-2": "<span class=\"label-all label-amazon\">Amazon</span>",
    "5-0": "`chrome_big_picture`",
    "5-1": "string",
    "5-2": "<span class=\"label-all\">ChromeApp</span>",
    "5-3": "Large picture to display below the notification text. Must be a local URL.",
    "1-0": "`url`",
    "1-1": "string",
    "1-2": "<span class=\"label-all\">All</span>",
    "1-3": "<p>The URL to open in the browser when a user clicks on the notification.</p> <p>Example: `http://www.google.com`</p>\n<p>Note: iOS needs https or updated NSAppTransportSecurity in plist</p>\n<p>**This field supports [inline substitutions](doc:tag-variable-substitution).**</p>"
  },
  "cols": 4,
  "rows": 6
}
[/block]
### Action Buttons
These add buttons to notifications, allowing the user to take more than one action on a notification. [Learn more about Action Buttons](doc:action-buttons).
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Platform",
    "h-3": "Description",
    "0-1": "array_object",
    "0-0": "`buttons`",
    "0-2": "<span class=\"label-all label-ios\">iOS 8.0+</span>, <span class=\"label-all label-android\">Android 4.1+</span> (and derivatives like <span class=\"label-all label-amazon\">Amazon</span>)",
    "0-3": "<p>Buttons to add to the notification. Icon only works for Android.</p>\n<p>Example: `[{\"id\": \"id1\", \"text\": \"button1\", \"icon\": \"ic_menu_share\"}, {\"id\": \"id2\", \"text\": \"button2\", \"icon\": \"ic_menu_send\"}]`</p>\n\n<p>Swift Example:  `[[\"id\": \"id1\", \"text\": \"button1\"], [\"id\": \"id2\", \"text\": \"button2\"]]`</p>",
    "2-0": "`ios_category`",
    "2-3": "[Category APS](https://developer.apple.com/library/ios/documentation/UIKit/Reference/UIUserNotificationCategory_class/index.html#//apple_ref/occ/cl/UIUserNotificationCategory) payload, use with `registerUserNotificationSettings:categories` in your Objective-C / Swift code.</p>\n\n<p>Example: `calendar` category which contains actions like `accept` and `decline`</p>\n\n<p><span class=\"label-all label-ios\">iOS 10+</span> This will trigger your [UNNotificationContentExtension](https://developer.apple.com/reference/usernotificationsui/unnotificationcontentextension) whose ID matches this category.",
    "2-2": "<span class=\"label-all label-ios\">iOS</span>",
    "2-1": "string",
    "1-0": "`web_buttons`",
    "1-1": "array_object",
    "1-3": "Add action buttons to the notification. The `id` field is required.</p>\n\n<p>Example: `[{\"id\": \"like-button\", \"text\": \"Like\", \"icon\": \"http://i.imgur.com/N8SN8ZS.png\", \"url\": \"https://yoursite.com\"}, {\"id\": \"read-more-button\", \"text\": \"Read more\", \"icon\": \"http://i.imgur.com/MIxJp1L.png\", \"url\": \"https://yoursite.com\"}]`</p>",
    "1-2": "<span class=\"label-all label-chrome\">Chrome 48+</span>"
  },
  "cols": 4,
  "rows": 3
}
[/block]
### Appearance
These parameters let you adjust notification icons, sounds, badges, and other appearance changes to your notifications.

**Icons** - Different platforms handle icons differently.
 - Android - Our SDK shows a bell icon by default. See our [Android Notification Icons](doc:customize-notification-icons) guide to change this.
 - iOS - The icon will always be your app icon. Apple does not allow this to be configured.

**Sounds** - By default, the device notification sound plays when a new notification arrives. You may alter this by specifying a different sound asset.

**Badges** - shows the number of notifications outstanding. Note: Android badges are automatically handled by OneSignal.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Platform",
    "h-3": "Description",
    "0-0": "`android_background_layout`",
    "0-1": "object",
    "0-2": "<span class=\"label-all label-android\">Android</span>",
    "0-3": "<p>Allowing setting a background image for the notification. This is a JSON object containing the following keys. See our [Background Image](doc:android-customizations#section-background-images) documentation for image sizes.</p>\n\n<p>`image` - Asset file, android resource name, or URL to remote image.</p>\n\n<p>`headings_color` - Title text color ARGB Hex format. Example(Blue): `\"FF0000FF\"`.</p>\n\n<p>`contents_color` - Body text color ARGB Hex format. Example(Red): `\"FFFF0000\"`</p>\n\n<p>Example: `{\"image\": \"https://domain.com/background_image.jpg\", \"headings_color\": \"FFFF0000\", \"contents_color\": \"FF00FF00\"}`",
    "2-0": "`large_icon`",
    "2-1": "string",
    "2-2": "<span class=\"label-all label-android\">Android</span>",
    "2-3": "If blank the `small_icon` is used. Can be a drawable resource name or a URL.\nSee: [How to create large icons](doc:android-customizations#section-large-notification-icons)",
    "17-0": "`ios_badgeType`",
    "17-1": "string",
    "17-2": "<span class=\"label-all label-ios\">iOS</span>",
    "17-3": "<p>Describes whether to *set* or *increase/decrease* your app's iOS badge count by the `ios_badgeCount` specified count. Can specify `None`, `SetTo`, or `Increase`.</p>\n\n<p>`None` leaves the count unaffected.</p>\n\n<p>`SetTo` directly sets the badge count to the number specified in `ios_badgeCount`.</p>\n\n<p>`Increase` adds the number specified in `ios_badgeCount` to the total. Use a negative number to decrease the badge count.</p>",
    "18-3": "<p>Used with `ios_badgeType`, describes the value to *set* or amount to *increase/decrease* your app's iOS badge count by.</p> <p>You can use a negative number to decrease the badge count when used with an `ios_badgeType` of `Increase`.</p>",
    "18-0": "`ios_badgeCount`",
    "18-1": "integer",
    "18-2": "<span class=\"label-all label-ios\">iOS</span>",
    "5-0": "`chrome_web_icon`",
    "7-0": "`firefox_icon`",
    "8-0": "`chrome_icon`",
    "5-1": "string",
    "7-1": "string",
    "8-1": "string",
    "5-3": "Sets the web push notification's icon. An image URL linking to a valid image. Common image types are supported; GIF will not animate. We recommend 256x256 (at least 80x80) to display well on high DPI devices. Firefox will also use this icon, unless you specify `firefox_icon`.",
    "5-2": "<span class=\"label-all label-chrome\">Chrome</span>",
    "8-2": "<span class=\"label-all\">ChromeApp</span>",
    "7-3": "<span class=\"label-all label-notrec\">Not recommended</span> Few people need to set Firefox-specific icons. We recommend setting `chrome_web_icon` instead, which Firefox will also use.\n\nSets the web push notification's icon for Firefox. An image URL linking to a valid image. Common image types are supported; GIF will not animate. We recommend 256x256 (at least 80x80) to display well on high DPI devices.",
    "7-2": "<span class=\"label-all label-firefox\">Firefox</span>",
    "8-3": "<p><span class=\"label-all label-notrec\">This flag is not used for web push</span> For web push, please see `chrome_web_icon` instead.</p>\n<p>The local URL to an icon to use. If blank, the app icon will be used.</p>",
    "1-0": "`small_icon`",
    "1-1": "string",
    "1-2": "<span class=\"label-all label-android\">Android</span>",
    "1-3": "If not set a bell icon will be used or `ic_stat_onesignal_default` if you have set this resource name.\nSee: [How to create small icons](doc:android-customizations#section-small-notification-icons)",
    "9-0": "`ios_sound`",
    "10-0": "`android_sound`",
    "10-1": "string",
    "9-1": "string",
    "11-1": "string",
    "12-1": "string",
    "13-1": "string",
    "14-1": "string",
    "11-0": "`adm_sound`",
    "12-0": "`wp_sound`",
    "13-0": "`wp_wns_sound`",
    "10-3": "<p>Sound file that is included in your app to play instead of the default device notification sound. NOTE: Leave off file extension for Android.</p>\n<p>Example: `\"notification\"`",
    "10-2": "<span class=\"label-all label-android\">Android</span>",
    "9-2": "<span class=\"label-all label-ios\">iOS</span>",
    "11-2": "<span class=\"label-all label-amazon\">Amazon</span>",
    "12-2": "<span class=\"label-all label-windows\">Windows 8.0</span>",
    "13-2": "<span class=\"label-all label-windows\">Windows 8.1</span>",
    "9-3": "<p>Sound file that is included in your app to play instead of the default device notification sound. Pass \"nil\" to disable vibration and sound for the notification.</p>\n<p>Example: `\"notification.wav\"`</p>",
    "11-3": "<p>Sound file that is included in your app to play instead of the default device notification sound.</p><p>NOTE: Leave off file extension for Android.</p>\n<p>Example: `\"notification\"`</p>",
    "12-3": "<p>Sound file that is included in your app to play instead of the default device notification sound.</p><p>Example: `\"notification.wav\"`</p>",
    "13-3": "<p>Sound file that is included in your app to play instead of the default device notification sound.</p><p>Example: `\"notification.wav\"`</p>",
    "14-0": "`android_led_color`",
    "15-0": "`android_accent_color`",
    "15-1": "string",
    "15-3": "<p>Sets the background color of the notification circle to the left of the notification text. Only applies to apps targeting Android API level 21+ on Android 5.0+ devices.</p><p>Example(Red): `\"FFFF0000\"`</p>",
    "15-2": "<span class=\"label-all label-android\">Android</span>",
    "14-2": "<span class=\"label-all label-android\">Android</span>",
    "14-3": "<p>Sets the devices LED notification light if the device has one. ARGB Hex format.</p><p>Example(Blue): `\"FF0000FF\"`</p>",
    "16-0": "`android_visibility`",
    "16-1": "int",
    "16-2": "<span class=\"label-all label-android\">Android 5.0+</span>",
    "16-3": "<p>Sets the lock screen visibility for apps targeting Android API level 21+ running on Android 5.0+ devices.</p>\n<p>`1` = Public (_default_) (Shows the full message on the lock screen unless the user has disabled all notifications from showing on the lock screen. Please consider the user and mark private if the contents are.)</p>\n<p>`0` = Private (Hides message contents on lock screen if the user set \"Hide sensitive notification content\" in the system settings)</p>\n<p>`-1` = Secret (Notification does not show on the lock screen at all)</p>",
    "19-0": "`collapse_id`",
    "19-1": "string",
    "19-2": "<span class=\"label-all label-ios\">iOS 10+</span> <span class=\"label-all label-android\">Android</span>",
    "19-3": "Only one notification with the same id will be shown on the device. Use the same id to update an existing notification instead of showing a new one.",
    "3-0": "`adm_small_icon`",
    "3-1": "string",
    "4-1": "string",
    "3-2": "<span class=\"label-all label-amazon\">Amazon</span>",
    "4-2": "<span class=\"label-all label-amazon\">Amazon</span>",
    "3-3": "If not set a bell icon will be used or `ic_stat_onesignal_default` if you have set this resource name.\nSee: [How to create small icons](doc:android-customizations#section-small-notification-icons)",
    "4-3": "If blank the `small_icon` is used. Can be a drawable resource name or a URL.\nSee: [How to create large icons](doc:android-customizations#section-large-notification-icons)",
    "4-0": "`adm_large_icon`",
    "6-0": "`chrome_web_image`",
    "6-1": "string",
    "6-2": "<span class=\"label-all label-chrome\">Chrome 56+ Only</span>",
    "6-3": "Sets the web push notification's large image to be shown below the notification's title and text. Please see [Web Push Notification Icons](doc:web-push-notification-icons)."
  },
  "cols": 4,
  "rows": 20
}
[/block]
### Delivery
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Platform",
    "0-0": "`send_after`",
    "0-1": "string",
    "0-2": "<span class=\"label-all\">All</span>",
    "1-0": "`delayed_option`",
    "1-1": "string",
    "1-2": "<span class=\"label-all\">All</span>",
    "2-0": "`delivery_time_of_day`",
    "2-1": "string",
    "2-2": "<span class=\"label-all\">All</span>",
    "h-3": "Description",
    "0-3": "<p>Schedule notification for future delivery.</p><p>Examples: *All examples are the exact same date & time.*</p>\n<p>`\"Thu Sep 24 2015 14:00:00 GMT-0700 (PDT)\"`</p>\n<p>`\"September 24th 2015, 2:00:00 pm UTC-07:00\"`</p>\n<p>`\"2015-09-24 14:00:00 GMT-0700\"`</p>\n<p>`\"Sept 24 2015 14:00:00 GMT-0700\"`</p>\n<p>`\"Thu Sep 24 2015 14:00:00 GMT-0700 (Pacific Daylight Time)\"`</p>",
    "1-3": "<p>Possible values are:</p>\n<p>`timezone` (Deliver at a specific time-of-day in each users own timezone)</p>\n<p>`last-active` Same as Intelligent Delivery. (Deliver at the same time of day as each user last used your app).</p>\n<p>If `send_after` is used, this takes effect after the `send_after` time has elapsed.</p>",
    "2-3": "<p>Use with `delayed_option=timezone`.</p>\n<p>Example: `\"9:00AM\"`</p>",
    "3-0": "`ttl`",
    "3-1": "integer",
    "3-2": "<span class=\"label-all label-ios\">iOS</span>, <span class=\"label-all label-android\">Android</span>, <span class=\"label-all label-chrome\">Chrome</span>, <span class=\"label-all label-chrome\">ChromeWeb</span>",
    "3-3": "Time To Live - In seconds. The notification will be expired if the device does not come back online within this time. The default is 259,200 seconds (3 days).",
    "4-0": "`priority`",
    "4-1": "integer",
    "4-2": "<span class=\"label-all label-android\">Android</span>, <span class=\"label-all label-chrome\">Chrome</span>, <span class=\"label-all label-chrome\">ChromeWeb</span>",
    "4-3": "Delivery priority through the push server (example GCM/FCM). Pass `10` for high priority. Defaults to normal priority for Android and high for iOS. For Android 6.0+ devices setting priority to high will wake the device out of doze mode."
  },
  "cols": 4,
  "rows": 5
}
[/block]
### Grouping & Collapsing
Grouping lets you combine multiple notifications into a single notification to improve the user experience. Collapsing lets you dismiss old notifications in favor of newer ones. 
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Platform",
    "h-3": "Description",
    "0-0": "`android_group`",
    "0-1": "string",
    "0-2": "<span class=\"label-all label-android\">Android</span>",
    "0-3": "All notifications with the same group will be stacked together using Android's [Notification Stacking](https://developer.android.com/training/wearables/notifications/stacks.html) feature.",
    "1-3": "<p>Summary message to display when 2+ notifications are stacked together. Default is \"# new messages\". Include `$[notif_count]` in your message and it will be replaced with the current number.</p>\n<p>**Languages** - The value of each key is the message that will be sent to users for that language. `\"en\"` (English) is required. The key of each hash is either a a 2 character language code or one of zh-Hans/zh-Hant for Simplified or Traditional Chinese. [Read more: supported languages.](doc:language-localization#section-supported-languages) </p>\n<p>Example: `{\"en\": \"You have $[notif_count] new messages\"}`</p>",
    "1-2": "<span class=\"label-all label-android\">Android</span>",
    "1-1": "object",
    "1-0": "`android_group_message`",
    "2-3": "All notifications with the same group will be stacked together using Android's [Notification Stacking](https://developer.android.com/training/wearables/notifications/stacks.html) feature.",
    "2-2": "<span class=\"label-all label-amazon\">Amazon</span>",
    "2-1": "string",
    "2-0": "`adm_group`",
    "3-0": "`adm_group_message`",
    "3-1": "object",
    "3-2": "<span class=\"label-all label-amazon\">Amazon</span>",
    "3-3": "<p>Summary message to display when 2+ notifications are stacked together. Default is \"# new messages\". Include $[notif_count] in your message and it will be replaced with the current number.  \"en\" (English) is required. The key of each hash is either a a 2 character language code or one of zh-Hans/zh-Hant for Simplified or Traditional Chinese. The value of each key is the message that will be sent to users for that language.</p>\n<p>Example: `{\"en\": \"You have $[notif_count] new messages\"}`</p>"
  },
  "cols": 4,
  "rows": 4
}
[/block]
### Platform to Deliver To
By default, OneSignal will send to every platform (each of these is `true`). 

To only send to specific platforms, you may pass in `true` on one or more of these parameters corresponding to the platform you wish to send to. If you do so, all other platforms will be set to `false` and will not be delivered to.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Platform",
    "h-3": "Description",
    "0-0": "`isIos`",
    "0-1": "boolean",
    "1-1": "boolean",
    "2-1": "boolean",
    "6-1": "boolean",
    "7-1": "boolean",
    "8-1": "boolean",
    "9-1": "boolean",
    "1-0": "`isAndroid`",
    "2-0": "`isAnyWeb`",
    "6-0": "`isWP`",
    "7-0": "`isWP_WNS`",
    "8-0": "`isAdm`",
    "9-0": "`isChrome`",
    "0-2": "<span class=\"label-all label-ios\">iOS</span>",
    "1-2": "<span class=\"label-all label-android\">Android</span>",
    "2-2": "<span class=\"label-all\">Web</span>",
    "9-2": "<span class=\"label-all\">ChromeApp</span>",
    "8-2": "<span class=\"label-all label-amazon\">Amazon</span>",
    "7-2": "<span class=\"label-all label-windows\">Windows Phone 8.1</span>",
    "6-2": "<span class=\"label-all label-windows\">Windows Phone 8.0</span>",
    "0-3": "Indicates whether to send to all devices registered under your app's Apple iOS platform.",
    "1-3": "Indicates whether to send to all devices registered under your app's Google Android platform.",
    "2-3": "<p>Indicates whether to send to all subscribed web browser users, including Chrome, Firefox, and Safari.</p>\n\n<p>You may use this instead as a combined flag instead of separately enabling `isChromeWeb`, `isFirefox`, and `isSafari`, though the three options are equivalent to this one.</p>",
    "6-3": "Indicates whether to send to all devices registered under your app's Windows Phone 8.0 platform.",
    "7-3": "Indicates whether to send to all devices registered under your app's Windows Phone 8.1+ platform.",
    "8-3": "Indicates whether to send to all devices registered under your app's Amazon Fire platform.",
    "9-3": "<p><span class=\"label-all label-notrec\">This flag is not used for web push</span> Please see `isChromeWeb` for sending to web push users. This flag only applies to Google Chrome Apps & Extensions.</p>\n<p>Indicates whether to send to all devices registered under your app's Google Chrome Apps & Extension platform.</p>",
    "3-0": "`isChromeWeb`",
    "4-0": "`isFirefox`",
    "3-1": "boolean",
    "4-1": "boolean",
    "5-1": "boolean",
    "3-2": "<span class=\"label-all\">Web</span>",
    "4-2": "<span class=\"label-all\">Web</span>",
    "5-2": "<span class=\"label-all\">Web</span>",
    "5-0": "`isSafari`",
    "3-3": "Indicates whether to send to all Google Chrome, Chrome on Android, and Mozilla Firefox users registered under your Chrome & Firefox web push platform.",
    "4-3": "Indicates whether to send to all Mozilla Firefox desktop users registered under your Firefox web push platform.",
    "5-3": "<span class=\"label-all label-notrec\">Does not support iOS Safari</span> Indicates whether to send to all Apple's Safari desktop users registered under your Safari web push platform. [Read more: iOS Safari](doc:why-doesnt-web-push-work-with-ios)"
  },
  "cols": 4,
  "rows": 10
}
[/block]
## Example Code - Create notification 

### Send to all subscribers - Create notification 
[block:code]
{
  "codes": [
    {
      "code": "curl --include \\\n     --request POST \\\n     --header \"Content-Type: application/json; charset=utf-8\" \\\n     --header \"Authorization: Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\" \\\n     --data-binary \"{\\\"app_id\\\": \\\"5eb5a37e-b458-11e3-ac11-000c2940e62c\\\",\n\\\"contents\\\": {\\\"en\\\": \\\"English Message\\\"},\n\\\"included_segments\\\": [\\\"All\\\"]}\" \\\n     https://onesignal.com/api/v1/notifications",
      "language": "shell"
    },
    {
      "code": "{\n  \"app_id\": \"5eb5a37e-b458-11e3-ac11-000c2940e62c\",\n  \"included_segments\": [\"All\"],\n  \"data\": {\"foo\": \"bar\"},\n  \"contents\": {\"en\": \"English Message\"}\n}",
      "language": "json"
    },
    {
      "code": "<?PHP\n\tfunction sendMessage(){\n\t\t$content = array(\n\t\t\t\"en\" => 'English Message'\n\t\t\t);\n\t\t\n\t\t$fields = array(\n\t\t\t'app_id' => \"5eb5a37e-b458-11e3-ac11-000c2940e62c\",\n\t\t\t'included_segments' => array('All'),\n      'data' => array(\"foo\" => \"bar\"),\n\t\t\t'contents' => $content\n\t\t);\n\t\t\n\t\t$fields = json_encode($fields);\n    print(\"\\nJSON sent:\\n\");\n    print($fields);\n\t\t\n\t\t$ch = curl_init();\n\t\tcurl_setopt($ch, CURLOPT_URL, \"https://onesignal.com/api/v1/notifications\");\n\t\tcurl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json; charset=utf-8',\n\t\t\t\t\t\t\t\t\t\t\t\t   'Authorization: Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj'));\n\t\tcurl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);\n\t\tcurl_setopt($ch, CURLOPT_HEADER, FALSE);\n\t\tcurl_setopt($ch, CURLOPT_POST, TRUE);\n\t\tcurl_setopt($ch, CURLOPT_POSTFIELDS, $fields);\n\t\tcurl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);\n\n\t\t$response = curl_exec($ch);\n\t\tcurl_close($ch);\n\t\t\n\t\treturn $response;\n\t}\n\t\n\t$response = sendMessage();\n\t$return[\"allresponses\"] = $response;\n\t$return = json_encode( $return);\n\t\n  print(\"\\n\\nJSON received:\\n\");\n\tprint($return);\n  print(\"\\n\");\n?>",
      "language": "csharp",
      "name": "PHP"
    },
    {
      "code": "using System.IO;\nusing System.Net;\nusing System.Text;\n\nvar request = WebRequest.Create(\"https://onesignal.com/api/v1/notifications\") as HttpWebRequest;\n\nrequest.KeepAlive = true;\nrequest.Method = \"POST\";\nrequest.ContentType = \"application/json; charset=utf-8\";\n\nrequest.Headers.Add(\"authorization\", \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\");\n\nbyte[] byteArray = Encoding.UTF8.GetBytes(\"{\"\n                                        + \"\\\"app_id\\\": \\\"5eb5a37e-b458-11e3-ac11-000c2940e62c\\\",\"\n                                        + \"\\\"contents\\\": {\\\"en\\\": \\\"English Message\\\"},\"\n                                        + \"\\\"included_segments\\\": [\\\"All\\\"]}\");\n\nstring responseContent = null;\n\ntry {\n    using (var writer = request.GetRequestStream()) {\n        writer.Write(byteArray, 0, byteArray.Length);\n    }\n\n    using (var response = request.GetResponse() as HttpWebResponse) {\n        using (var reader = new StreamReader(response.GetResponseStream())) {\n            responseContent = reader.ReadToEnd();\n        }\n    }\n}\ncatch (WebException ex) {\n    System.Diagnostics.Debug.WriteLine(ex.Message);\n    System.Diagnostics.Debug.WriteLine(new StreamReader(ex.Response.GetResponseStream()).ReadToEnd());\n}\n\nSystem.Diagnostics.Debug.WriteLine(responseContent);",
      "language": "csharp",
      "name": "C# (.NET standard)"
    },
    {
      "code": "using System.IO;\nusing System.Net;\nusing System.Text;\n\nvar request = WebRequest.Create(\"https://onesignal.com/api/v1/notifications\") as HttpWebRequest;\n\nrequest.KeepAlive = true;\nrequest.Method = \"POST\";\nrequest.ContentType = \"application/json; charset=utf-8\";\n\nrequest.Headers.Add(\"authorization\", \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\");\n\nvar serializer = new JavaScriptSerializer();\nvar obj = new { app_id = \"5eb5a37e-b458-11e3-ac11-000c2940e62c\",\n               contents = new { en = \"English Message\" },\n               included_segments = new string[] {\"All\"} };\nvar param = serializer.Serialize(obj);\nbyte[] byteArray = Encoding.UTF8.GetBytes(param);\n\nstring responseContent = null;\n\ntry {\n    using (var writer = request.GetRequestStream()) {\n        writer.Write(byteArray, 0, byteArray.Length);\n    }\n\n    using (var response = request.GetResponse() as HttpWebResponse) {\n        using (var reader = new StreamReader(response.GetResponseStream())) {\n            responseContent = reader.ReadToEnd();\n        }\n    }\n}\ncatch (WebException ex) {\n    System.Diagnostics.Debug.WriteLine(ex.Message);\n    System.Diagnostics.Debug.WriteLine(new StreamReader(ex.Response.GetResponseStream()).ReadToEnd());\n}\n\nSystem.Diagnostics.Debug.WriteLine(responseContent);",
      "language": "csharp",
      "name": "C# (ASP.NET)"
    },
    {
      "code": "params = {\"app_id\" => \"5eb5a37e-b458-11e3-ac11-000c2940e62c\", \n          \"contents\" => {\"en\" => \"English Message\"},\n          \"included_segments\" => [\"All\"]}\nuri = URI.parse('https://onesignal.com/api/v1/notifications')\nhttp = Net::HTTP.new(uri.host, uri.port)\nhttp.use_ssl = true\n\nrequest = Net::HTTP::Post.new(uri.path,\n                              'Content-Type'  => 'application/json;charset=utf-8',\n                              'Authorization' => \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\")\nrequest.body = params.as_json.to_json\nresponse = http.request(request) \nputs response.body",
      "language": "ruby",
      "name": "Ruby (Rails)"
    },
    {
      "code": "import requests\nimport json\n\nheader = {\"Content-Type\": \"application/json; charset=utf-8\",\n          \"Authorization\": \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\"}\n\npayload = {\"app_id\": \"5eb5a37e-b458-11e3-ac11-000c2940e62c\",\n           \"included_segments\": [\"All\"],\n           \"contents\": {\"en\": \"English Message\"}}\n \nreq = requests.post(\"https://onesignal.com/api/v1/notifications\", headers=header, data=json.dumps(payload))\n \nprint(req.status_code, req.reason)",
      "language": "python",
      "name": null
    },
    {
      "code": "var sendNotification = function(data) {\n  var headers = {\n    \"Content-Type\": \"application/json; charset=utf-8\",\n    \"Authorization\": \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\"\n  };\n  \n  var options = {\n    host: \"onesignal.com\",\n    port: 443,\n    path: \"/api/v1/notifications\",\n    method: \"POST\",\n    headers: headers\n  };\n  \n  var https = require('https');\n  var req = https.request(options, function(res) {  \n    res.on('data', function(data) {\n      console.log(\"Response:\");\n      console.log(JSON.parse(data));\n    });\n  });\n  \n  req.on('error', function(e) {\n    console.log(\"ERROR:\");\n    console.log(e);\n  });\n  \n  req.write(JSON.stringify(data));\n  req.end();\n};\n\nvar message = { \n  app_id: \"5eb5a37e-b458-11e3-ac11-000c2940e62c\",\n  contents: {\"en\": \"English Message\"},\n  included_segments: [\"All\"]\n};\n\nsendNotification(message);",
      "language": "javascript",
      "name": "NodeJS"
    },
    {
      "code": "#!/usr/bin/perl -w\n \nuse strict;\nuse warnings;\nuse Net::Curl::Easy qw(/^CURLOPT_.*/);;\nuse JSON;\nuse Data::Dumper;\n \nsub SendNotification\n{\n    my ($url , $authorisation , $app_id , $contents) = @_;\n    my $curl = Net::Curl::Easy->new;\n    my $json = JSON->new();\n    my $response_body;\n \n    my $json_string = $json->encode({ app_id => $app_id ,\n                                      included_segments => [\"All\"] ,\n                                      data => { \"key1\" => \"Value 1\" } ,\n                                      ios_badgeType => \"Increase\" ,\n                                      ios_badgeCount => 1 ,\n                                      contents => { en => $contents}\n                                    });\n \n    $curl->setopt( CURLOPT_URL, $url);\n    $curl->setopt( CURLOPT_SSL_VERIFYHOST , 0);\n    $curl->setopt( CURLOPT_SSL_VERIFYPEER , 0);\n \n    $curl->setopt( CURLOPT_HTTPHEADER, ['Content-Type: application/json; charset=utf-8' ,\n                                        \"Authorization: Basic $authorisation\"]);\n    $curl->setopt( CURLOPT_POST , 1);\n    $curl->setopt( CURLOPT_POSTFIELDS , $json_string);\n \n    $curl->setopt( CURLOPT_WRITEDATA , \\$response_body);\n \n    $curl->perform;\n    print Dumper($response_body);\n}\n \nSendNotification(\"https://onesignal.com/api/v1/notifications\" ,\n                 \"<< PUT YOUR REST API KEY HERE>>\" ,\n                 \"<< PUT YOUR APP ID KEY HERE >>\" ,\n                 \"Hello World\");\n \nexit(0);",
      "language": "perl"
    },
    {
      "code": "send = function(params) {\n\nvar promise = new Parse.Promise();\n\nvar jsonBody = { \n  app_id: \"5eb5a37e-b458-11e3-ac11-000c2940e62c\", \n  included_segments: [\"All\"],\n  contents: {en: \"English Message\"},\n  data: {foo: \"bar\"}\n};\n\nParse.Cloud.httpRequest({\n    method: \"POST\",\n    url: \"https://onesignal.com/api/v1/notifications\",\n    headers: {\n      \"Content-Type\": \"application/json;charset=utf-8\",\n      \"Authorization\": \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\"\n    },\n    body: JSON.stringify(jsonBody)\n  }).then(function (httpResponse) {\n    promise.resolve(httpResponse)\n  },\n  function (httpResponse) {\n    promise.reject(httpResponse);\n});\n\nreturn promise;\n};\n\nexports.send = send;",
      "language": "javascript",
      "name": "Parse Cloud"
    },
    {
      "code": "function SendNewNotification() {\n\n  var jsonBody = {\n\n    app_id: \"5eb5a37e-b458-11e3-ac11-000c2940e62c\",\n\n    included_segments: [\"All\"],\n\n    contents: {en: \"English Message\"},\n\n  };\n\n  var promise = Spark.getHttp(\"https://onesignal.com/api/v1/notifications\").setHeaders({\n\n    \"Content-Type\": \"application/json;charset=utf-8\",\n\n    \"Authorization\": \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\"\n\n  }).postJson(jsonBody);\n  \n\n  return promise;\n\n}\n\nvar response = SendNewNotification().getResponseJson();\n\nSpark.setScriptData(\"response\", response)",
      "language": "javascript",
      "name": "GameSparks"
    },
    {
      "code": "try {\n   String jsonResponse;\n   \n   URL url = new URL(\"https://onesignal.com/api/v1/notifications\");\n   HttpURLConnection con = (HttpURLConnection)url.openConnection();\n   con.setUseCaches(false);\n   con.setDoOutput(true);\n   con.setDoInput(true);\n\n   con.setRequestProperty(\"Content-Type\", \"application/json; charset=UTF-8\");\n   con.setRequestProperty(\"Authorization\", \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\");\n   con.setRequestMethod(\"POST\");\n\n   String strJsonBody = \"{\"\n                      +   \"\\\"app_id\\\": \\\"5eb5a37e-b458-11e3-ac11-000c2940e62c\\\",\"\n                      +   \"\\\"included_segments\\\": [\\\"All\\\"],\"\n                      +   \"\\\"data\\\": {\\\"foo\\\": \\\"bar\\\"},\"\n                      +   \"\\\"contents\\\": {\\\"en\\\": \\\"English Message\\\"}\"\n                      + \"}\";\n         \n   \n   System.out.println(\"strJsonBody:\\n\" + strJsonBody);\n\n   byte[] sendBytes = strJsonBody.getBytes(\"UTF-8\");\n   con.setFixedLengthStreamingMode(sendBytes.length);\n\n   OutputStream outputStream = con.getOutputStream();\n   outputStream.write(sendBytes);\n\n   int httpResponse = con.getResponseCode();\n   System.out.println(\"httpResponse: \" + httpResponse);\n\n   if (  httpResponse >= HttpURLConnection.HTTP_OK\n      && httpResponse < HttpURLConnection.HTTP_BAD_REQUEST) {\n      Scanner scanner = new Scanner(con.getInputStream(), \"UTF-8\");\n      jsonResponse = scanner.useDelimiter(\"\\\\A\").hasNext() ? scanner.next() : \"\";\n      scanner.close();\n   }\n   else {\n      Scanner scanner = new Scanner(con.getErrorStream(), \"UTF-8\");\n      jsonResponse = scanner.useDelimiter(\"\\\\A\").hasNext() ? scanner.next() : \"\";\n      scanner.close();\n   }\n   System.out.println(\"jsonResponse:\\n\" + jsonResponse);\n   \n} catch(Throwable t) {\n   t.printStackTrace();\n}\n",
      "language": "java"
    }
  ]
}
[/block]
### Send to a specific segment - Create notification 
[block:code]
{
  "codes": [
    {
      "code": "curl --include \\\n     --request POST \\\n     --header \"Content-Type: application/json; charset=utf-8\" \\\n     --header \"Authorization: Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\" \\\n     --data-binary \"{\\\"app_id\\\": \\\"5eb5a37e-b458-11e3-ac11-000c2940e62c\\\",\n\\\"contents\\\": {\\\"en\\\": \\\"English Message\\\"},\n\\\"included_segments\\\": [\\\"Active Users\\\"]}\" \\\n     https://onesignal.com/api/v1/notifications",
      "language": "shell"
    },
    {
      "code": "{\n  \"app_id\": \"5eb5a37e-b458-11e3-ac11-000c2940e62c\",\n  \"included_segments\": [\"Active Users\"],\n  \"data\": {\"foo\": \"bar\"},\n  \"contents\": {\"en\": \"English Message\"}\n}",
      "language": "json"
    },
    {
      "code": "<?PHP\n\tfunction sendMessage(){\n\t\t$content = array(\n\t\t\t\"en\" => 'English Message'\n\t\t\t);\n\t\t\n\t\t$fields = array(\n\t\t\t'app_id' => \"5eb5a37e-b458-11e3-ac11-000c2940e62c\",\n\t\t\t'included_segments' => array('Active Users'),\n\t\t\t'data' => array(\"foo\" => \"bar\"),\n\t\t\t'contents' => $content\n\t\t);\n\t\t\n\t\t$fields = json_encode($fields);\n    \tprint(\"\\nJSON sent:\\n\");\n    \tprint($fields);\n\t\t\n\t\t$ch = curl_init();\n\t\tcurl_setopt($ch, CURLOPT_URL, \"https://onesignal.com/api/v1/notifications\");\n\t\tcurl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json; charset=utf-8',\n\t\t\t\t\t\t\t\t\t\t\t\t   'Authorization: Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj'));\n\t\tcurl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);\n\t\tcurl_setopt($ch, CURLOPT_HEADER, FALSE);\n\t\tcurl_setopt($ch, CURLOPT_POST, TRUE);\n\t\tcurl_setopt($ch, CURLOPT_POSTFIELDS, $fields);\n\t\tcurl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);\n\n\t\t$response = curl_exec($ch);\n\t\tcurl_close($ch);\n\t\t\n\t\treturn $response;\n\t}\n\t\n\t$response = sendMessage();\n\t$return[\"allresponses\"] = $response;\n\t$return = json_encode( $return);\n\t\n\tprint(\"\\n\\nJSON received:\\n\");\n\tprint($return);\n\tprint(\"\\n\");\n?>",
      "language": "csharp",
      "name": "PHP"
    },
    {
      "code": "using System.IO;\nusing System.Net;\nusing System.Text;\n\nvar request = WebRequest.Create(\"https://onesignal.com/api/v1/notifications\") as HttpWebRequest;\n\nrequest.KeepAlive = true;\nrequest.Method = \"POST\";\nrequest.ContentType = \"application/json; charset=utf-8\";\n\nrequest.Headers.Add(\"authorization\", \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\");\n\nbyte[] byteArray = Encoding.UTF8.GetBytes(\"{\"\n                                        + \"\\\"app_id\\\": \\\"5eb5a37e-b458-11e3-ac11-000c2940e62c\\\",\"\n                                        + \"\\\"contents\\\": {\\\"en\\\": \\\"English Message\\\"},\"\n                                        + \"\\\"included_segments\\\": [\\\"Active Users\\\"]}\");\n\nstring responseContent = null;\n\ntry {\n    using (var writer = request.GetRequestStream()) {\n        writer.Write(byteArray, 0, byteArray.Length);\n    }\n\n    using (var response = request.GetResponse() as HttpWebResponse) {\n        using (var reader = new StreamReader(response.GetResponseStream())) {\n            responseContent = reader.ReadToEnd();\n        }\n    }\n}\ncatch (WebException ex) {\n    System.Diagnostics.Debug.WriteLine(ex.Message);\n    System.Diagnostics.Debug.WriteLine(new StreamReader(ex.Response.GetResponseStream()).ReadToEnd());\n}\n\nSystem.Diagnostics.Debug.WriteLine(responseContent);",
      "language": "csharp",
      "name": "C# (.NET standard)"
    },
    {
      "code": "using System.IO;\nusing System.Net;\nusing System.Text;\n\nvar request = WebRequest.Create(\"https://onesignal.com/api/v1/notifications\") as HttpWebRequest;\n\nrequest.KeepAlive = true;\nrequest.Method = \"POST\";\nrequest.ContentType = \"application/json; charset=utf-8\";\n\nrequest.Headers.Add(\"authorization\", \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\");\n\nvar serializer = new JavaScriptSerializer();\nvar obj = new { app_id = \"5eb5a37e-b458-11e3-ac11-000c2940e62c\",\n               contents = new { en = \"English Message\" },\n               included_segments = new string[] {\"Active Users\"} };\nvar param = serializer.Serialize(obj);\nbyte[] byteArray = Encoding.UTF8.GetBytes(param);\n\nstring responseContent = null;\n\ntry {\n    using (var writer = request.GetRequestStream()) {\n        writer.Write(byteArray, 0, byteArray.Length);\n    }\n\n    using (var response = request.GetResponse() as HttpWebResponse) {\n        using (var reader = new StreamReader(response.GetResponseStream())) {\n            responseContent = reader.ReadToEnd();\n        }\n    }\n}\ncatch (WebException ex) {\n    System.Diagnostics.Debug.WriteLine(ex.Message);\n    System.Diagnostics.Debug.WriteLine(new StreamReader(ex.Response.GetResponseStream()).ReadToEnd());\n}\n\nSystem.Diagnostics.Debug.WriteLine(responseContent);",
      "language": "csharp",
      "name": "C# (ASP.NET)"
    },
    {
      "code": "params = {\"app_id\" => \"5eb5a37e-b458-11e3-ac11-000c2940e62c\", \n          \"contents\" => {\"en\" => \"English Message\"},\n          \"included_segments\" => [\"Active Users\"]}\nuri = URI.parse('https://onesignal.com/api/v1/notifications')\nhttp = Net::HTTP.new(uri.host, uri.port)\nhttp.use_ssl = true\n\nrequest = Net::HTTP::Post.new(uri.path,\n                              'Content-Type'  => 'application/json;charset=utf-8',\n                              'Authorization' => \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\")\nrequest.body = params.as_json.to_json\nresponse = http.request(request) \nputs response.body",
      "language": "ruby",
      "name": "Ruby (Rails)"
    },
    {
      "code": "import requests\nimport json\n\nheader = {\"Content-Type\": \"application/json; charset=utf-8\",\n          \"Authorization\": \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\"}\n\npayload = {\"app_id\": \"5eb5a37e-b458-11e3-ac11-000c2940e62c\",\n           \"included_segments\": [\"Active Users\"],\n           \"contents\": {\"en\": \"English Message\"}}\n \nreq = requests.post(\"https://onesignal.com/api/v1/notifications\", headers=header, data=json.dumps(payload))\n \nprint(req.status_code, req.reason)",
      "language": "python",
      "name": null
    },
    {
      "code": "var sendNotification = function(data) {\n  var headers = {\n    \"Content-Type\": \"application/json; charset=utf-8\",\n    \"Authorization\": \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\"\n  };\n  \n  var options = {\n    host: \"onesignal.com\",\n    port: 443,\n    path: \"/api/v1/notifications\",\n    method: \"POST\",\n    headers: headers\n  };\n  \n  var https = require('https');\n  var req = https.request(options, function(res) {  \n    res.on('data', function(data) {\n      console.log(\"Response:\");\n      console.log(JSON.parse(data));\n    });\n  });\n  \n  req.on('error', function(e) {\n    console.log(\"ERROR:\");\n    console.log(e);\n  });\n  \n  req.write(JSON.stringify(data));\n  req.end();\n};\n\nvar message = { \n  app_id: \"5eb5a37e-b458-11e3-ac11-000c2940e62c\",\n  contents: {\"en\": \"English Message\"},\n  included_segments: [\"Active Users\"]\n};\n\nsendNotification(message);",
      "language": "javascript",
      "name": "NodeJS"
    },
    {
      "code": "#!/usr/bin/perl -w\n \nuse strict;\nuse warnings;\nuse Net::Curl::Easy qw(/^CURLOPT_.*/);;\nuse JSON;\nuse Data::Dumper;\n \nsub SendNotification\n{\n    my ($url , $authorisation , $app_id , $contents) = @_;\n    my $curl = Net::Curl::Easy->new;\n    my $json = JSON->new();\n    my $response_body;\n \n    my $json_string = $json->encode({ app_id => $app_id ,\n                                      included_segments => [\"Active Users\"] ,\n                                      contents => { en => $contents}\n                                    });\n \n    $curl->setopt( CURLOPT_URL, $url);\n    $curl->setopt( CURLOPT_SSL_VERIFYHOST , 0);\n    $curl->setopt( CURLOPT_SSL_VERIFYPEER , 0);\n \n    $curl->setopt( CURLOPT_HTTPHEADER, ['Content-Type: application/json; charset=utf-8' ,\n                                        \"Authorization: Basic $authorisation\"]);\n    $curl->setopt( CURLOPT_POST , 1);\n    $curl->setopt( CURLOPT_POSTFIELDS , $json_string);\n \n    $curl->setopt( CURLOPT_WRITEDATA , \\$response_body);\n \n    $curl->perform;\n    print Dumper($response_body);\n}\n \nSendNotification(\"https://onesignal.com/api/v1/notifications\" ,\n                 \"<< PUT YOUR REST API KEY HERE>>\" ,\n                 \"<< PUT YOUR APP ID KEY HERE >>\" ,\n                 \"Hello World\");\n \nexit(0);",
      "language": "perl"
    },
    {
      "code": "send = function(params) {\n\nvar promise = new Parse.Promise();\n\nvar jsonBody = { \n  app_id: \"5eb5a37e-b458-11e3-ac11-000c2940e62c\", \n  included_segments: [\"Active Users\"],\n  contents: {en: \"English Message\"},\n  data: {foo: \"bar\"}\n};\n\nParse.Cloud.httpRequest({\n    method: \"POST\",\n    url: \"https://onesignal.com/api/v1/notifications\",\n    headers: {\n      \"Content-Type\": \"application/json;charset=utf-8\",\n      \"Authorization\": \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\"\n    },\n    body: JSON.stringify(jsonBody)\n  }).then(function (httpResponse) {\n    promise.resolve(httpResponse)\n  },\n  function (httpResponse) {\n    promise.reject(httpResponse);\n});\n\nreturn promise;\n};\n\nexports.send = send;",
      "language": "javascript",
      "name": "Parse Cloud"
    },
    {
      "code": "function SendNewNotification() {\n\n  var jsonBody = {\n\n    app_id: \"5eb5a37e-b458-11e3-ac11-000c2940e62c\",\n\n    included_segments: [\"Active Users\"],\n\n    contents: {en: \"English Message\"},\n\n  };\n\n  var promise = Spark.getHttp(\"https://onesignal.com/api/v1/notifications\").setHeaders({\n\n    \"Content-Type\": \"application/json;charset=utf-8\",\n\n    \"Authorization\": \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\"\n\n  }).postJson(jsonBody);\n  \n\n  return promise;\n\n}\n\nvar response = SendNewNotification().getResponseJson();\n\nSpark.setScriptData(\"response\", response)",
      "language": "javascript",
      "name": "GameSparks"
    },
    {
      "code": "try {\n   String jsonResponse;\n   \n   URL url = new URL(\"https://onesignal.com/api/v1/notifications\");\n   HttpURLConnection con = (HttpURLConnection)url.openConnection();\n   con.setUseCaches(false);\n   con.setDoOutput(true);\n   con.setDoInput(true);\n\n   con.setRequestProperty(\"Content-Type\", \"application/json; charset=UTF-8\");\n   con.setRequestProperty(\"Authorization\", \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\");\n   con.setRequestMethod(\"POST\");\n\n   String strJsonBody = \"{\"\n                      +   \"\\\"app_id\\\": \\\"5eb5a37e-b458-11e3-ac11-000c2940e62c\\\",\"\n                      +   \"\\\"included_segments\\\": [\\\"Active Users\\\"],\"\n                      +   \"\\\"data\\\": {\\\"foo\\\": \\\"bar\\\"},\"\n                      +   \"\\\"contents\\\": {\\\"en\\\": \\\"English Message\\\"}\"\n                      + \"}\";\n         \n   \n   System.out.println(\"strJsonBody:\\n\" + strJsonBody);\n\n   byte[] sendBytes = strJsonBody.getBytes(\"UTF-8\");\n   con.setFixedLengthStreamingMode(sendBytes.length);\n\n   OutputStream outputStream = con.getOutputStream();\n   outputStream.write(sendBytes);\n\n   int httpResponse = con.getResponseCode();\n   System.out.println(\"httpResponse: \" + httpResponse);\n\n   if (  httpResponse >= HttpURLConnection.HTTP_OK\n      && httpResponse < HttpURLConnection.HTTP_BAD_REQUEST) {\n      Scanner scanner = new Scanner(con.getInputStream(), \"UTF-8\");\n      jsonResponse = scanner.useDelimiter(\"\\\\A\").hasNext() ? scanner.next() : \"\";\n      scanner.close();\n   }\n   else {\n      Scanner scanner = new Scanner(con.getErrorStream(), \"UTF-8\");\n      jsonResponse = scanner.useDelimiter(\"\\\\A\").hasNext() ? scanner.next() : \"\";\n      scanner.close();\n   }\n   System.out.println(\"jsonResponse:\\n\" + jsonResponse);\n   \n} catch(Throwable t) {\n   t.printStackTrace();\n}",
      "language": "java"
    }
  ]
}
[/block]
### Send based on filters/tags - Create notification 
[block:code]
{
  "codes": [
    {
      "code": "curl --include \\\n     --request POST \\\n     --header \"Content-Type: application/json; charset=utf-8\" \\\n     --header \"Authorization: Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\" \\\n     --data-binary \"{\\\"app_id\\\": \\\"5eb5a37e-b458-11e3-ac11-000c2940e62c\\\",\n\\\"contents\\\": {\\\"en\\\": \\\"English Message\\\"},\n\\\"filters\\\": [{\\\"field\\\": \"\\tag\\\", \\\"key\\\": \\\"level\\\", \\\"relation\\\": \\\">\\\", \\\"value\\\": \\\"10\\\"},{\\\"operator\\\": \\\"OR\\\"},{\\\"field\\\": \\\"amount_spent\\\", \\\"relation\\\": \\\">\\\",\\\"value\\\": \\\"0\\\"}]}\" \\\n     https://onesignal.com/api/v1/notifications",
      "language": "shell"
    },
    {
      "code": "{\n  \"app_id\": \"5eb5a37e-b458-11e3-ac11-000c2940e62c\",\n  \"filters\": [\n  \t{\"field\": \"tag\", \"key\": \"level\", \"relation\": \"=\", \"value\": \"10\"}, \n  \t{\"operator\": \"OR\"}, {\"field\": \"amount_spent\", \"relation\": \">\", \"value\": \"0\"}\n  ],\n  \"data\": {\"foo\": \"bar\"},\n  \"contents\": {\"en\": \"English Message\"}\n}",
      "language": "json"
    },
    {
      "code": "<?PHP\n\tfunction sendMessage(){\n\t\t$content = array(\n\t\t\t\"en\" => 'English Message'\n\t\t\t);\n\t\t\n\t\t$fields = array(\n\t\t\t'app_id' => \"5eb5a37e-b458-11e3-ac11-000c2940e62c\",\n\t\t\t'filters' => array(array(\"field\" => \"tag\", \"key\" => \"level\", \"relation\" => \"=\", \"value\" => \"10\"),array(\"operator\" => \"OR\"),array(\"field\" => \"amount_spent\", \"relation\" => \"=\", \"value\" => \"0\")),\n\t\t\t'data' => array(\"foo\" => \"bar\"),\n\t\t\t'contents' => $content\n\t\t);\n\t\t\n\t\t$fields = json_encode($fields);\n    \tprint(\"\\nJSON sent:\\n\");\n    \tprint($fields);\n\t\t\n\t\t$ch = curl_init();\n\t\tcurl_setopt($ch, CURLOPT_URL, \"https://onesignal.com/api/v1/notifications\");\n\t\tcurl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json; charset=utf-8',\n\t\t\t\t\t\t\t\t\t\t\t\t   'Authorization: Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj'));\n\t\tcurl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);\n\t\tcurl_setopt($ch, CURLOPT_HEADER, FALSE);\n\t\tcurl_setopt($ch, CURLOPT_POST, TRUE);\n\t\tcurl_setopt($ch, CURLOPT_POSTFIELDS, $fields);\n\t\tcurl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);\n\n\t\t$response = curl_exec($ch);\n\t\tcurl_close($ch);\n\t\t\n\t\treturn $response;\n\t}\n\t\n\t$response = sendMessage();\n\t$return[\"allresponses\"] = $response;\n\t$return = json_encode( $return);\n\t\n\tprint(\"\\n\\nJSON received:\\n\");\n\tprint($return);\n\tprint(\"\\n\");\n?>",
      "language": "csharp",
      "name": "PHP"
    },
    {
      "code": "using System.IO;\nusing System.Net;\nusing System.Text;\n\nvar request = WebRequest.Create(\"https://onesignal.com/api/v1/notifications\") as HttpWebRequest;\n\nrequest.KeepAlive = true;\nrequest.Method = \"POST\";\nrequest.ContentType = \"application/json; charset=utf-8\";\n\nrequest.Headers.Add(\"authorization\", \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\");\n\nbyte[] byteArray = Encoding.UTF8.GetBytes(\"{\"\n                                        + \"\\\"app_id\\\": \\\"5eb5a37e-b458-11e3-ac11-000c2940e62c\\\",\"\n                                        + \"\\\"contents\\\": {\\\"en\\\": \\\"English Message\\\"},\"\n                                        + \"\\\"filters\\\": [{\\\"field\\\": \\\"tag\\\", \\\"key\\\": \\\"level\\\", \\\"relation\\\": \\\">\\\", \\\"value\\\": \\\"10\\\"},{\\\"operator\\\": \\\"OR\\\"},{\\\"field\\\": \\\"amount_spent\\\", \\\"relation\\\": \\\">\\\",\\\"value\\\": \\\"0\\\"}]}\");\n\nstring responseContent = null;\n\ntry {\n    using (var writer = request.GetRequestStream()) {\n        writer.Write(byteArray, 0, byteArray.Length);\n    }\n\n    using (var response = request.GetResponse() as HttpWebResponse) {\n        using (var reader = new StreamReader(response.GetResponseStream())) {\n            responseContent = reader.ReadToEnd();\n        }\n    }\n}\ncatch (WebException ex) {\n    System.Diagnostics.Debug.WriteLine(ex.Message);\n    System.Diagnostics.Debug.WriteLine(new StreamReader(ex.Response.GetResponseStream()).ReadToEnd());\n}\n\nSystem.Diagnostics.Debug.WriteLine(responseContent);",
      "language": "csharp",
      "name": "C# (.NET standard)"
    },
    {
      "code": "using System.IO;\nusing System.Net;\nusing System.Text;\n\nvar request = WebRequest.Create(\"https://onesignal.com/api/v1/notifications\") as HttpWebRequest;\n\nrequest.KeepAlive = true;\nrequest.Method = \"POST\";\nrequest.ContentType = \"application/json; charset=utf-8\";\n\nrequest.Headers.Add(\"authorization\", \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\");\n\nvar serializer = new JavaScriptSerializer();\nvar obj = new { app_id = \"5eb5a37e-b458-11e3-ac11-000c2940e62c\",\n               contents = new { en = \"English Message\" },\n               filters = new object[] { new { field = \"tag\", key = \"level\", value = \"10\" }, new { @operator = \"OR\" }, new { field = \"amount_spent\", relation = \">\", value = \"0\" } } };\n\n                 \n\nvar param = serializer.Serialize(obj);\nbyte[] byteArray = Encoding.UTF8.GetBytes(param);\n\nstring responseContent = null;\n\ntry {\n    using (var writer = request.GetRequestStream()) {\n        writer.Write(byteArray, 0, byteArray.Length);\n    }\n\n    using (var response = request.GetResponse() as HttpWebResponse) {\n        using (var reader = new StreamReader(response.GetResponseStream())) {\n            responseContent = reader.ReadToEnd();\n        }\n    }\n}\ncatch (WebException ex) {\n    System.Diagnostics.Debug.WriteLine(ex.Message);\n    System.Diagnostics.Debug.WriteLine(new StreamReader(ex.Response.GetResponseStream()).ReadToEnd());\n}\n\nSystem.Diagnostics.Debug.WriteLine(responseContent);",
      "language": "csharp",
      "name": "C# (ASP.NET)"
    },
    {
      "code": "params = {\"app_id\" => \"5eb5a37e-b458-11e3-ac11-000c2940e62c\", \n          \"contents\" => {\"en\" => \"English Message\"},\n          \"filters\" => [\n\t\t\t\t\t  \t{\"field\": \"tag\", \"key\": \"level\", \"relation\": \"=\", \"value\": \"10\"}, \n\t\t\t\t\t  \t{\"operator\": \"OR\"}, {\"field\": \"amount_spent\", \"relation\": \">\", \"value\": \"0\"}\n\t\t\t\t\t  ]\n\t\t}\nuri = URI.parse('https://onesignal.com/api/v1/notifications')\nhttp = Net::HTTP.new(uri.host, uri.port)\nhttp.use_ssl = true\n\nrequest = Net::HTTP::Post.new(uri.path,\n                              'Content-Type'  => 'application/json;charset=utf-8',\n                              'Authorization' => \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\")\nrequest.body = params.as_json.to_json\nresponse = http.request(request) \nputs response.body",
      "language": "ruby",
      "name": "Ruby (Rails)"
    },
    {
      "code": "import requests\nimport json\n\nheader = {\"Content-Type\": \"application/json; charset=utf-8\",\n          \"Authorization\": \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\"}\n\npayload = {\"app_id\": \"5eb5a37e-b458-11e3-ac11-000c2940e62c\",\n           \"filters\": [\n\t\t\t  \t{\"field\": \"tag\", \"key\": \"level\", \"relation\": \"=\", \"value\": \"10\"}, \n\t\t\t  \t{\"operator\": \"OR\"}, {\"field\": \"amount_spent\", \"relation\": \">\", \"value\": \"0\"}\n\t\t\t],\n           \"contents\": {\"en\": \"English Message\"}}\n \nreq = requests.post(\"https://onesignal.com/api/v1/notifications\", headers=header, data=json.dumps(payload))\n \nprint(req.status_code, req.reason)",
      "language": "python",
      "name": null
    },
    {
      "code": "var sendNotification = function(data) {\n  var headers = {\n    \"Content-Type\": \"application/json; charset=utf-8\",\n    \"Authorization\": \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\"\n  };\n  \n  var options = {\n    host: \"onesignal.com\",\n    port: 443,\n    path: \"/api/v1/notifications\",\n    method: \"POST\",\n    headers: headers\n  };\n  \n  var https = require('https');\n  var req = https.request(options, function(res) {  \n    res.on('data', function(data) {\n      console.log(\"Response:\");\n      console.log(JSON.parse(data));\n    });\n  });\n  \n  req.on('error', function(e) {\n    console.log(\"ERROR:\");\n    console.log(e);\n  });\n  \n  req.write(JSON.stringify(data));\n  req.end();\n};\n\nvar message = { \n  app_id: \"5eb5a37e-b458-11e3-ac11-000c2940e62c\",\n  contents: {\"en\": \"English Message\"},\n  filters: [\n\t  \t{\"field\": \"tag\", \"key\": \"level\", \"relation\": \"=\", \"value\": \"10\"}, \n\t  \t{\"operator\": \"OR\"}, {\"field\": \"amount_spent\", \"relation\": \">\", \"value\": \"0\"}\n\t]\n};\n\nsendNotification(message);",
      "language": "javascript",
      "name": "NodeJS"
    },
    {
      "code": "#!/usr/bin/perl -w\n \nuse strict;\nuse warnings;\nuse Net::Curl::Easy qw(/^CURLOPT_.*/);;\nuse JSON;\nuse Data::Dumper;\n \nsub SendNotification\n{\n    my ($url , $authorisation , $app_id , $contents) = @_;\n    my $curl = Net::Curl::Easy->new;\n    my $json = JSON->new();\n    my $response_body;\n \n    my $json_string = $json->encode({ app_id => $app_id ,\n                                      filters => [\n\t\t\t\t\t\t\t\t\t\t  \t{\"field\": \"tag\", \"key\": \"level\", \"relation\": \"=\", \"value\": \"10\"}, \n\t\t\t\t\t\t\t\t\t\t  \t{\"operator\": \"OR\"}, {\"field\": \"amount_spent\", \"relation\": \">\", \"value\": \"0\"}\n\t\t\t\t\t\t\t\t\t\t],\n                                      contents => { en => $contents}\n                                    });\n \n    $curl->setopt( CURLOPT_URL, $url);\n    $curl->setopt( CURLOPT_SSL_VERIFYHOST , 0);\n    $curl->setopt( CURLOPT_SSL_VERIFYPEER , 0);\n \n    $curl->setopt( CURLOPT_HTTPHEADER, ['Content-Type: application/json; charset=utf-8' ,\n                                        \"Authorization: Basic $authorisation\"]);\n    $curl->setopt( CURLOPT_POST , 1);\n    $curl->setopt( CURLOPT_POSTFIELDS , $json_string);\n \n    $curl->setopt( CURLOPT_WRITEDATA , \\$response_body);\n \n    $curl->perform;\n    print Dumper($response_body);\n}\n \nSendNotification(\"https://onesignal.com/api/v1/notifications\" ,\n                 \"<< PUT YOUR REST API KEY HERE>>\" ,\n                 \"<< PUT YOUR APP ID KEY HERE >>\" ,\n                 \"Hello World\");\n \nexit(0);",
      "language": "perl"
    },
    {
      "code": "send = function(params) {\n\nvar promise = new Parse.Promise();\n\nvar jsonBody = { \n  app_id: \"5eb5a37e-b458-11e3-ac11-000c2940e62c\", \n  filters: [\n  \t{\"field\": \"tag\", \"key\": \"level\", \"relation\": \"=\", \"value\": \"10\"}, \n  \t{\"operator\": \"OR\"}, {\"field\": \"amount_spent\", \"relation\": \">\", \"value\": \"0\"}\n  ],\n  contents: {en: \"English Message\"},\n  data: {foo: \"bar\"}\n};\n\nParse.Cloud.httpRequest({\n    method: \"POST\",\n    url: \"https://onesignal.com/api/v1/notifications\",\n    headers: {\n      \"Content-Type\": \"application/json;charset=utf-8\",\n      \"Authorization\": \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\"\n    },\n    body: JSON.stringify(jsonBody)\n  }).then(function (httpResponse) {\n    promise.resolve(httpResponse)\n  },\n  function (httpResponse) {\n    promise.reject(httpResponse);\n});\n\nreturn promise;\n};\n\nexports.send = send;",
      "language": "javascript",
      "name": "Parse Cloud"
    },
    {
      "code": "function SendNewNotification() {\n\n  var jsonBody = {\n\n    app_id: \"5eb5a37e-b458-11e3-ac11-000c2940e62c\",\n\n    filters: [\n\n  \t  {\"field\": \"tag\", \"key\": \"level\", \"relation\": \"=\", \"value\": \"10\"}, \n\n  \t  {\"operator\": \"OR\"}, {\"field\": \"amount_spent\", \"relation\": \">\", \"value\": \"0\"}\n\n    ],\n\n    contents: {en: \"English Message\"},\n\n  };\n\n  var promise = Spark.getHttp(\"https://onesignal.com/api/v1/notifications\").setHeaders({\n\n    \"Content-Type\": \"application/json;charset=utf-8\",\n\n    \"Authorization\": \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\"\n\n  }).postJson(jsonBody);\n  \n\n  return promise;\n\n}\n\nvar response = SendNewNotification().getResponseJson();\n\nSpark.setScriptData(\"response\", response)",
      "language": "javascript",
      "name": "GameSparks"
    },
    {
      "code": "try {\n   String jsonResponse;\n   \n   URL url = new URL(\"https://onesignal.com/api/v1/notifications\");\n   HttpURLConnection con = (HttpURLConnection)url.openConnection();\n   con.setUseCaches(false);\n   con.setDoOutput(true);\n   con.setDoInput(true);\n\n   con.setRequestProperty(\"Content-Type\", \"application/json; charset=UTF-8\");\n   con.setRequestProperty(\"Authorization\", \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\");\n   con.setRequestMethod(\"POST\");\n\n   String strJsonBody = \"{\"\n                      +   \"\\\"app_id\\\": \\\"5eb5a37e-b458-11e3-ac11-000c2940e62c\\\",\"\n                      +   \"\\\"filters\\\": [{\\\"field\\\": \\\"tag\\\", \\\"key\\\": \\\"level\\\", \\\"relation\\\": \\\">\\\", \\\"value\\\": \\\"10\\\"},{\\\"operator\\\": \\\"OR\\\"},{\\\"field\\\": \\\"amount_spent\\\", \\\"relation\\\": \\\">\\\",\\\"value\\\": \\\"0\\\"}],\"\n                      +   \"\\\"data\\\": {\\\"foo\\\": \\\"bar\\\"},\"\n                      +   \"\\\"contents\\\": {\\\"en\\\": \\\"English Message\\\"}\"\n                      + \"}\";\n         \n   \n   System.out.println(\"strJsonBody:\\n\" + strJsonBody);\n\n   byte[] sendBytes = strJsonBody.getBytes(\"UTF-8\");\n   con.setFixedLengthStreamingMode(sendBytes.length);\n\n   OutputStream outputStream = con.getOutputStream();\n   outputStream.write(sendBytes);\n\n   int httpResponse = con.getResponseCode();\n   System.out.println(\"httpResponse: \" + httpResponse);\n\n   if (  httpResponse >= HttpURLConnection.HTTP_OK\n      && httpResponse < HttpURLConnection.HTTP_BAD_REQUEST) {\n      Scanner scanner = new Scanner(con.getInputStream(), \"UTF-8\");\n      jsonResponse = scanner.useDelimiter(\"\\\\A\").hasNext() ? scanner.next() : \"\";\n      scanner.close();\n   }\n   else {\n      Scanner scanner = new Scanner(con.getErrorStream(), \"UTF-8\");\n      jsonResponse = scanner.useDelimiter(\"\\\\A\").hasNext() ? scanner.next() : \"\";\n      scanner.close();\n   }\n   System.out.println(\"jsonResponse:\\n\" + jsonResponse);\n   \n} catch(Throwable t) {\n   t.printStackTrace();\n}",
      "language": "java"
    }
  ]
}
[/block]

### Send based on OneSignal PlayerIds - Create notification 
[block:code]
{
  "codes": [
    {
      "code": "curl --include \\\n     --request POST \\\n     --header \"Content-Type: application/json; charset=utf-8\" \\\n     --header \"Authorization: Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\" \\\n     --data-binary \"{\\\"app_id\\\": \\\"5eb5a37e-b458-11e3-ac11-000c2940e62c\\\",\n\\\"contents\\\": {\\\"en\\\": \\\"English Message\\\"},\n\\\"include_player_ids\\\": [\\\"6392d91a-b206-4b7b-a620-cd68e32c3a76\\\",\\\"76ece62b-bcfe-468c-8a78-839aeaa8c5fa\\\",\\\"8e0f21fa-9a5a-4ae7-a9a6-ca1f24294b86\\\"]}\" \\\n     https://onesignal.com/api/v1/notifications",
      "language": "shell"
    },
    {
      "code": "{\n  \"app_id\": \"5eb5a37e-b458-11e3-ac11-000c2940e62c\",\n  \"include_player_ids\": [\"6392d91a-b206-4b7b-a620-cd68e32c3a76\",\"76ece62b-bcfe-468c-8a78-839aeaa8c5fa\",\"8e0f21fa-9a5a-4ae7-a9a6-ca1f24294b86\"],\n  \"data\": {\"foo\": \"bar\"},\n  \"contents\": {\"en\": \"English Message\"}\n}\n",
      "language": "json"
    },
    {
      "code": "<?PHP\n\tfunction sendMessage(){\n\t\t$content = array(\n\t\t\t\"en\" => 'English Message'\n\t\t\t);\n\t\t\n\t\t$fields = array(\n\t\t\t'app_id' => \"5eb5a37e-b458-11e3-ac11-000c2940e62c\",\n\t\t\t'include_player_ids' => array(\"6392d91a-b206-4b7b-a620-cd68e32c3a76\",\"76ece62b-bcfe-468c-8a78-839aeaa8c5fa\",\"8e0f21fa-9a5a-4ae7-a9a6-ca1f24294b86\"),\n\t\t\t'data' => array(\"foo\" => \"bar\"),\n\t\t\t'contents' => $content\n\t\t);\n\t\t\n\t\t$fields = json_encode($fields);\n    \tprint(\"\\nJSON sent:\\n\");\n    \tprint($fields);\n\t\t\n\t\t$ch = curl_init();\n\t\tcurl_setopt($ch, CURLOPT_URL, \"https://onesignal.com/api/v1/notifications\");\n\t\tcurl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json; charset=utf-8',\n\t\t\t\t\t\t\t\t\t\t\t\t   'Authorization: Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj'));\n\t\tcurl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);\n\t\tcurl_setopt($ch, CURLOPT_HEADER, FALSE);\n\t\tcurl_setopt($ch, CURLOPT_POST, TRUE);\n\t\tcurl_setopt($ch, CURLOPT_POSTFIELDS, $fields);\n\t\tcurl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);\n\n\t\t$response = curl_exec($ch);\n\t\tcurl_close($ch);\n\t\t\n\t\treturn $response;\n\t}\n\t\n\t$response = sendMessage();\n\t$return[\"allresponses\"] = $response;\n\t$return = json_encode( $return);\n\t\n\tprint(\"\\n\\nJSON received:\\n\");\n\tprint($return);\n\tprint(\"\\n\");\n?>\n",
      "language": "csharp",
      "name": "PHP"
    },
    {
      "code": "using System.IO;\nusing System.Net;\nusing System.Text;\n\nvar request = WebRequest.Create(\"https://onesignal.com/api/v1/notifications\") as HttpWebRequest;\n\nrequest.KeepAlive = true;\nrequest.Method = \"POST\";\nrequest.ContentType = \"application/json; charset=utf-8\";\n\nrequest.Headers.Add(\"authorization\", \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\");\n\nbyte[] byteArray = Encoding.UTF8.GetBytes(\"{\"\n                                        + \"\\\"app_id\\\": \\\"5eb5a37e-b458-11e3-ac11-000c2940e62c\\\",\"\n                                        + \"\\\"contents\\\": {\\\"en\\\": \\\"English Message\\\"},\"\n                                        + \"\\\"include_player_ids\\\": [\\\"6392d91a-b206-4b7b-a620-cd68e32c3a76\\\",\\\"76ece62b-bcfe-468c-8a78-839aeaa8c5fa\\\",\\\"8e0f21fa-9a5a-4ae7-a9a6-ca1f24294b86\\\"]}\");\n\nstring responseContent = null;\n\ntry {\n    using (var writer = request.GetRequestStream()) {\n        writer.Write(byteArray, 0, byteArray.Length);\n    }\n\n    using (var response = request.GetResponse() as HttpWebResponse) {\n        using (var reader = new StreamReader(response.GetResponseStream())) {\n            responseContent = reader.ReadToEnd();\n        }\n    }\n}\ncatch (WebException ex) {\n    System.Diagnostics.Debug.WriteLine(ex.Message);\n    System.Diagnostics.Debug.WriteLine(new StreamReader(ex.Response.GetResponseStream()).ReadToEnd());\n}\n\nSystem.Diagnostics.Debug.WriteLine(responseContent);",
      "language": "csharp",
      "name": "C# (.NET standard)"
    },
    {
      "code": "using System.IO;\nusing System.Net;\nusing System.Text;\n\nvar request = WebRequest.Create(\"https://onesignal.com/api/v1/notifications\") as HttpWebRequest;\n\nrequest.KeepAlive = true;\nrequest.Method = \"POST\";\nrequest.ContentType = \"application/json; charset=utf-8\";\n\nrequest.Headers.Add(\"authorization\", \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\");\n\nvar serializer = new JavaScriptSerializer();\nvar obj = new { app_id = \"5eb5a37e-b458-11e3-ac11-000c2940e62c\",\n               contents = new { en = \"English Message\" },\n               include_player_ids = new string[] {\"6392d91a-b206-4b7b-a620-cd68e32c3a76\",\"76ece62b-bcfe-468c-8a78-839aeaa8c5fa\",\"8e0f21fa-9a5a-4ae7-a9a6-ca1f24294b86\"} };\n\n                 \n\nvar param = serializer.Serialize(obj);\nbyte[] byteArray = Encoding.UTF8.GetBytes(param);\n\nstring responseContent = null;\n\ntry {\n    using (var writer = request.GetRequestStream()) {\n        writer.Write(byteArray, 0, byteArray.Length);\n    }\n\n    using (var response = request.GetResponse() as HttpWebResponse) {\n        using (var reader = new StreamReader(response.GetResponseStream())) {\n            responseContent = reader.ReadToEnd();\n        }\n    }\n}\ncatch (WebException ex) {\n    System.Diagnostics.Debug.WriteLine(ex.Message);\n    System.Diagnostics.Debug.WriteLine(new StreamReader(ex.Response.GetResponseStream()).ReadToEnd());\n}\n\nSystem.Diagnostics.Debug.WriteLine(responseContent);",
      "language": "csharp",
      "name": "C# (ASP.NET)"
    },
    {
      "code": "params = {\"app_id\" => \"5eb5a37e-b458-11e3-ac11-000c2940e62c\", \n          \"contents\" => {\"en\" => \"English Message\"},\n          \"include_player_ids\" => [\"6392d91a-b206-4b7b-a620-cd68e32c3a76\",\"76ece62b-bcfe-468c-8a78-839aeaa8c5fa\",\"8e0f21fa-9a5a-4ae7-a9a6-ca1f24294b86\"]\n\t\t}\nuri = URI.parse('https://onesignal.com/api/v1/notifications')\nhttp = Net::HTTP.new(uri.host, uri.port)\nhttp.use_ssl = true\n\nrequest = Net::HTTP::Post.new(uri.path,\n                              'Content-Type'  => 'application/json;charset=utf-8',\n                              'Authorization' => \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\")\nrequest.body = params.as_json.to_json\nresponse = http.request(request) \nputs response.body",
      "language": "ruby",
      "name": "Ruby (Rails)"
    },
    {
      "code": "import requests\nimport json\n\nheader = {\"Content-Type\": \"application/json; charset=utf-8\",\n          \"Authorization\": \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\"}\n\npayload = {\"app_id\": \"5eb5a37e-b458-11e3-ac11-000c2940e62c\",\n           \"include_player_ids\": [\"6392d91a-b206-4b7b-a620-cd68e32c3a76\",\"76ece62b-bcfe-468c-8a78-839aeaa8c5fa\",\"8e0f21fa-9a5a-4ae7-a9a6-ca1f24294b86\"],\n           \"contents\": {\"en\": \"English Message\"}}\n \nreq = requests.post(\"https://onesignal.com/api/v1/notifications\", headers=header, data=json.dumps(payload))\n \nprint(req.status_code, req.reason)\n",
      "language": "python",
      "name": null
    },
    {
      "code": "var sendNotification = function(data) {\n  var headers = {\n    \"Content-Type\": \"application/json; charset=utf-8\",\n    \"Authorization\": \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\"\n  };\n  \n  var options = {\n    host: \"onesignal.com\",\n    port: 443,\n    path: \"/api/v1/notifications\",\n    method: \"POST\",\n    headers: headers\n  };\n  \n  var https = require('https');\n  var req = https.request(options, function(res) {  \n    res.on('data', function(data) {\n      console.log(\"Response:\");\n      console.log(JSON.parse(data));\n    });\n  });\n  \n  req.on('error', function(e) {\n    console.log(\"ERROR:\");\n    console.log(e);\n  });\n  \n  req.write(JSON.stringify(data));\n  req.end();\n};\n\nvar message = { \n  app_id: \"5eb5a37e-b458-11e3-ac11-000c2940e62c\",\n  contents: {\"en\": \"English Message\"},\n  include_player_ids: [\"6392d91a-b206-4b7b-a620-cd68e32c3a76\",\"76ece62b-bcfe-468c-8a78-839aeaa8c5fa\",\"8e0f21fa-9a5a-4ae7-a9a6-ca1f24294b86\"]\n};\n\nsendNotification(message);",
      "language": "javascript",
      "name": "NodeJS"
    },
    {
      "code": "#!/usr/bin/perl -w\n \nuse strict;\nuse warnings;\nuse Net::Curl::Easy qw(/^CURLOPT_.*/);;\nuse JSON;\nuse Data::Dumper;\n \nsub SendNotification\n{\n    my ($url , $authorisation , $app_id , $contents) = @_;\n    my $curl = Net::Curl::Easy->new;\n    my $json = JSON->new();\n    my $response_body;\n \n    my $json_string = $json->encode({ app_id => $app_id ,\n                                      include_player_ids => [\"6392d91a-b206-4b7b-a620-cd68e32c3a76\",\"76ece62b-bcfe-468c-8a78-839aeaa8c5fa\",\"8e0f21fa-9a5a-4ae7-a9a6-ca1f24294b86\"],\n                                      contents => { en => $contents}\n                                    });\n \n    $curl->setopt( CURLOPT_URL, $url);\n    $curl->setopt( CURLOPT_SSL_VERIFYHOST , 0);\n    $curl->setopt( CURLOPT_SSL_VERIFYPEER , 0);\n \n    $curl->setopt( CURLOPT_HTTPHEADER, ['Content-Type: application/json; charset=utf-8' ,\n                                        \"Authorization: Basic $authorisation\"]);\n    $curl->setopt( CURLOPT_POST , 1);\n    $curl->setopt( CURLOPT_POSTFIELDS , $json_string);\n \n    $curl->setopt( CURLOPT_WRITEDATA , \\$response_body);\n \n    $curl->perform;\n    print Dumper($response_body);\n}\n \nSendNotification(\"https://onesignal.com/api/v1/notifications\" ,\n                 \"<< PUT YOUR REST API KEY HERE>>\" ,\n                 \"<< PUT YOUR APP ID KEY HERE >>\" ,\n                 \"Hello World\");\n \nexit(0);",
      "language": "perl"
    },
    {
      "code": "send = function(params) {\n\nvar promise = new Parse.Promise();\n\nvar jsonBody = { \n  app_id: \"5eb5a37e-b458-11e3-ac11-000c2940e62c\", \n  include_player_ids: [\"6392d91a-b206-4b7b-a620-cd68e32c3a76\",\"76ece62b-bcfe-468c-8a78-839aeaa8c5fa\",\"8e0f21fa-9a5a-4ae7-a9a6-ca1f24294b86\"],\n  contents: {en: \"English Message\"},\n  data: {foo: \"bar\"}\n};\n\nParse.Cloud.httpRequest({\n    method: \"POST\",\n    url: \"https://onesignal.com/api/v1/notifications\",\n    headers: {\n      \"Content-Type\": \"application/json;charset=utf-8\",\n      \"Authorization\": \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\"\n    },\n    body: JSON.stringify(jsonBody)\n  }).then(function (httpResponse) {\n    promise.resolve(httpResponse)\n  },\n  function (httpResponse) {\n    promise.reject(httpResponse);\n});\n\nreturn promise;\n};\n\nexports.send = send;\n\n",
      "language": "javascript",
      "name": "Parse Cloud"
    },
    {
      "code": "function SendNewNotification() {\n\n  var jsonBody = {\n\n    app_id: \"5eb5a37e-b458-11e3-ac11-000c2940e62c\",\n\n    include_player_ids: [\"6392d91a-b206-4b7b-a620-cd68e32c3a76\",\"76ece62b-bcfe-468c-8a78-839aeaa8c5fa\",\"8e0f21fa-9a5a-4ae7-a9a6-ca1f24294b86\"],\n\n    contents: {en: \"English Message\"},\n\n  };\n\n  var promise = Spark.getHttp(\"https://onesignal.com/api/v1/notifications\").setHeaders({\n\n    \"Content-Type\": \"application/json;charset=utf-8\",\n\n    \"Authorization\": \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\"\n\n  }).postJson(jsonBody);\n  \n\n  return promise;\n\n}\n\nvar response = SendNewNotification().getResponseJson();\n\nSpark.setScriptData(\"response\", response)\n",
      "language": "javascript",
      "name": "GameSparks"
    },
    {
      "code": "try {\n   String jsonResponse;\n   \n   URL url = new URL(\"https://onesignal.com/api/v1/notifications\");\n   HttpURLConnection con = (HttpURLConnection)url.openConnection();\n   con.setUseCaches(false);\n   con.setDoOutput(true);\n   con.setDoInput(true);\n\n   con.setRequestProperty(\"Content-Type\", \"application/json; charset=UTF-8\");\n   con.setRequestProperty(\"Authorization\", \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\");\n   con.setRequestMethod(\"POST\");\n\n   String strJsonBody = \"{\"\n                      +   \"\\\"app_id\\\": \\\"5eb5a37e-b458-11e3-ac11-000c2940e62c\\\",\"\n                      +   \"\\\"include_player_ids\\\": [\\\"6392d91a-b206-4b7b-a620-cd68e32c3a76\\\",\\\"76ece62b-bcfe-468c-8a78-839aeaa8c5fa\\\",\\\"8e0f21fa-9a5a-4ae7-a9a6-ca1f24294b86\\\"],\"\n                      +   \"\\\"data\\\": {\\\"foo\\\": \\\"bar\\\"},\"\n                      +   \"\\\"contents\\\": {\\\"en\\\": \\\"English Message\\\"}\"\n                      + \"}\";\n         \n   \n   System.out.println(\"strJsonBody:\\n\" + strJsonBody);\n\n   byte[] sendBytes = strJsonBody.getBytes(\"UTF-8\");\n   con.setFixedLengthStreamingMode(sendBytes.length);\n\n   OutputStream outputStream = con.getOutputStream();\n   outputStream.write(sendBytes);\n\n   int httpResponse = con.getResponseCode();\n   System.out.println(\"httpResponse: \" + httpResponse);\n\n   if (  httpResponse >= HttpURLConnection.HTTP_OK\n      && httpResponse < HttpURLConnection.HTTP_BAD_REQUEST) {\n      Scanner scanner = new Scanner(con.getInputStream(), \"UTF-8\");\n      jsonResponse = scanner.useDelimiter(\"\\\\A\").hasNext() ? scanner.next() : \"\";\n      scanner.close();\n   }\n   else {\n      Scanner scanner = new Scanner(con.getErrorStream(), \"UTF-8\");\n      jsonResponse = scanner.useDelimiter(\"\\\\A\").hasNext() ? scanner.next() : \"\";\n      scanner.close();\n   }\n   System.out.println(\"jsonResponse:\\n\" + jsonResponse);\n   \n} catch(Throwable t) {\n   t.printStackTrace();\n}",
      "language": "java"
    }
  ]
}
[/block]

## Results - Create notification 
[block:code]
{
  "codes": [
    {
      "code": "{\n  \"id\": \"458dcec4-cf53-11e3-add2-000c2940e62c\",\n  \"recipients\": 3\n}",
      "language": "json",
      "name": "200 OK"
    },
    {
      "code": "{\n  \"errors\": [\"Notification content must not be null for any languages.\"]\n}",
      "language": "json",
      "name": "400 Bad Request"
    },
    {
      "code": "// Returned if using include_player_ids and some were valid and others were not.\n// Please process theses on your server and removing them from your database if your tracking them.\n\n{\n  \"errors\": {\n    \"invalid_player_ids\" : [\"5fdc92b2-3b2a-11e5-ac13-8fdccfe4d986\", \"00cb73f8-5815-11e5-ba69-f75522da5528\"]\n  }\n}",
      "language": "javascript",
      "name": "200 invalid_player_ids"
    },
    {
      "code": "{\"id\": \"\", \"recipients\": 0, \"errors\": [\"All included players are not subscribed\"]}",
      "language": "json",
      "name": "200 No Subscribed Players"
    }
  ]
}
[/block]
[Go here for Postman examples](doc:using-postman)
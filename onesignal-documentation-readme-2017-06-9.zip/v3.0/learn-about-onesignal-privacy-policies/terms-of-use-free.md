---
title: "Terms of Use"
excerpt: ""
---
[Terms of Use OneSignal Free](https://onesignal.com/tos)
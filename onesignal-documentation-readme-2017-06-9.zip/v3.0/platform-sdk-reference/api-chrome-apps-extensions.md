---
title: "Chrome Apps / Extensions"
excerpt: "OneSignal Chrome Apps / Extensions API Reference. Works with <span class=\"label-all\">Chrome Apps / Extensions</span>.\n<div class=\"tag-all tag-developers\">For Developers</div>"
---
[block:callout]
{
  "type": "warning",
  "title": "Not for Chrome Web Push",
  "body": "Chrome Apps & Extensions are **not** web push, which is available [here](docs:api-web-push). In other words, this is probably not what you want."
}
[/block]

[block:parameters]
{
  "data": {
    "0-0": "### Initialization",
    "0-1": "",
    "h-2": "",
    "0-2": "",
    "h-0": "",
    "2-0": "### User IDs",
    "3-0": "[IdsAvailable](#IdsAvailable)",
    "3-1": "Function",
    "3-2": "Get the User ID of the device",
    "5-0": "### Tags",
    "6-0": "[GetTags](#section- -gettags-)",
    "6-1": "Function",
    "9-1": "Function",
    "10-1": "Function",
    "11-1": "Function",
    "6-2": "View Tags from a User",
    "9-2": "",
    "11-2": "",
    "10-2": "Delete a Tag from a User",
    "9-0": "[SendTags](#section- -sendtags-)",
    "10-0": "[DeleteTag](#section- -deletetag-)",
    "11-0": "[DeleteTags](#section- -deletetags-)",
    "12-0": "### Receiving Notifications",
    "13-0": "[addListenerForNotificationOpened](#addListenerForNotificationOpened)",
    "13-1": "Function",
    "13-2": "When a user takes an action on a notification",
    "8-0": "[SendTag](#section- -sendtag-)",
    "8-1": "Function",
    "8-2": "Add a Tag to a User",
    "14-0": "[notificationOpenedCallBack](#notificationOpenedCallBack)",
    "14-1": "Callback",
    "14-2": "",
    "7-0": "[tagsReceivedCallBack](#tagsReceivedCallBack)",
    "7-1": "Callback",
    "1-0": "[init](#section- -init-)",
    "1-1": "Function",
    "1-2": "Initialize OneSignal",
    "4-0": "[IdsAvailableCallBack](#idsAvailableCallBack)"
  },
  "cols": 3,
  "rows": 15
}
[/block]
## Initialization
### `init`
<div class="label-all label-type">Function</div>

Only required method you need to call to setup OneSignal to receive push notifications. Call this from your background.js file outside of any other functions.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`appId`",
    "0-1": "String",
    "0-2": "<span class=\"label-all label-required\">Required</span> Your OneSignal App Id, found in <a class=\\\"dash-link\\\">Keys & Ids</a>",
    "1-0": "`googleProjectNumber`",
    "1-1": "String",
    "1-2": "<span class=\"label-all label-required\">Required</span> Your Google Project number."
  },
  "cols": 3,
  "rows": 2
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.init({appId: \"5eb5a37e-b458-11e3-ac11-000c2940e62c\",\n                 googleProjectNumber: \"703322744261\"});",
      "language": "javascript"
    }
  ]
}
[/block]
## Tags
### `sendTag`
<div class="label-all label-type">Function</div>

Tag a user based on an app event of your choosing so later you can create segments in <a class=\"dash-link\">Segments</a> to target these users. Recommend using `sendTags` over `sendTag` if you need to set more than one tag on a user at a time.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`key`",
    "0-1": "String",
    "0-2": "Key of your choosing to create or update.",
    "1-0": "`value`",
    "1-1": "String",
    "1-2": "Value to set on the key.\n_NOTE:_ Passing in a blank String deletes the key, you can also call `deleteTag`."
  },
  "cols": 3,
  "rows": 2
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.sendTag(\"level\", \"64\");",
      "language": "javascript"
    }
  ]
}
[/block]
## User IDs
### `getIdsAvailable`
<div class="label-all label-type">Function</div>

Lets you retrieve the OneSignal User ID and the Google Registration ID. Your handler is called after the device is successfully registered with OneSignal.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`idsAvailableCallBack`",
    "0-1": "Function",
    "0-2": "Passed in function which will receive one parameter containing JSON with userId and registrationId."
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.getIdsAvailable(function(ids) {\n\tconsole.log(\"getIdsAvailable:\"\n\t\t\t\t\t+ \"\\nUserID: \" + ids.userId\n\t\t\t\t\t+ \"\\nRegistration ID: \" + ids.registrationId);\n  });",
      "language": "javascript"
    }
  ]
}
[/block]

### `idsAvailableCallBack`
<div class="label-all label-type">Callback</div>

Get the OneSignal userId and the Google Registration ID.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`userId`",
    "0-1": "String",
    "0-2": "OneSignal userId is a UUID formatted string.(_unique to a Chrome user per device per app_)",
    "1-0": "`registrationId`",
    "1-1": "String",
    "1-2": "Google assigned identifier(_unique to a Chrome user per device per app and changes on every reinstall_).\n\n_NOTE:_ Might be blank if there was a connection issue."
  },
  "cols": 3,
  "rows": 2
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.getIdsAvailable(function(ids) {\n\tconsole.log(\"getIdsAvailable:\"\n\t\t\t\t\t+ \"\\nUserID: \" + ids.userId\n\t\t\t\t\t+ \"\\nRegistration ID: \" + ids.registrationId);\n  });",
      "language": "javascript"
    }
  ]
}
[/block]
## Tags
### `getTags`
<div class="label-all label-type">Function</div>

Retrieve a list of tags that have been set on the user from the OneSignal server.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`tagsReceivedCallBack`",
    "0-1": "Function",
    "0-2": "Passed in function which will receive one parameter containing JSON."
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.getTags(function(tags) {\n\t\tconsole.log(\"OneSignal getTags:\");\n\t\tconsole.log(tags);\n\t});",
      "language": "javascript"
    }
  ]
}
[/block]
### `tagsReceivedCallBack`
<div class="label-all label-type">Callback</div>

Gets all the tags set on a user from onesignal.com.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`tags`",
    "0-1": "JSON",
    "0-2": "JSON object of key value pairs retrieved from the OneSignal server."
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.getTags(function(tags) {\n\t\tconsole.log(\"OneSignal getTags:\");\n\t\tconsole.log(tags);\n\t});",
      "language": "javascript"
    }
  ]
}
[/block]
### `sendTags`
<div class="label-all label-type">Function</div>

Tag a user based on an app event of your choosing so later you can create segments on [onesignal.com](https://onesignal.com) to target these users.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`keyValues`",
    "0-1": "JSON",
    "0-2": "Key value pairs of your choosing to create or update. _NOTE:_ Passing in a blank String as a value deletes the key, you can also call deleteTag or deleteTags."
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.sendTags({level: \"64\", coins: \"101\"});",
      "language": "javascript"
    }
  ]
}
[/block]
### `deleteTag`
<div class="label-all label-type">Function</div>

Deletes a tag that was previously set on a user with `sendTag` or `sendTags`. Use `deleteTags` if you need to delete more than one.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`key`",
    "0-1": "String",
    "0-2": "Key to remove."
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.deleteTag(\"key\");",
      "language": "javascript"
    }
  ]
}
[/block]
### `deleteTags`
<div class="label-all label-type">Function</div>

Deletes tags that were previously set on a user with `sendTag` or `sendTags`.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`keys`",
    "0-1": "Array",
    "0-2": "Keys to remove."
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.deleteTags([\"key1\", \"key2\"]);",
      "language": "javascript"
    }
  ]
}
[/block]
## Receiving Notifications
### `addListenerForNotificationOpened`
<div class="label-all label-type">Function</div>

Passed in callback that fires when the user clicks on a OneSignal notification.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`notificationOpenedCallBack`",
    "0-1": "Function",
    "0-2": "Passed in function which will receive one parameter containing JSON with data about the notification that was clicked."
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.addListenerForNotificationOpened(function(data) {\n\tconsole.log(\"Received NotificationOpened:\");\n\tconsole.log(data);\n});",
      "language": "javascript"
    }
  ]
}
[/block]
### `notificationOpenedCallBack`
<div class="label-all label-type">Callback</div>

Function that gets called when a OneSignal notification is opened. Function will receive one parameter with JSON about the notification.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`title`",
    "0-1": "String",
    "0-2": "Keys to remove.",
    "1-0": "`message`",
    "1-1": "String",
    "2-1": "String",
    "5-1": "String",
    "4-1": "Array",
    "3-1": "JSON",
    "2-0": "`icon`",
    "3-0": "`additionalData`",
    "4-0": "`actionButtons`",
    "5-0": "`actionSelected`",
    "5-2": "Id of the button on the notification that was clicked.",
    "4-2": "Any buttons that were present on the notification.",
    "3-2": "Key value pairs that were set on the notification.",
    "2-2": "Icon set on the notification.",
    "1-2": "The message text the user seen in the notification."
  },
  "cols": 3,
  "rows": 6
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.addListenerForNotificationOpened(function(data) {\n\tconsole.log(\"Received NotificationOpened:\");\n\tconsole.log(data);\n});",
      "language": "javascript"
    }
  ]
}
[/block]
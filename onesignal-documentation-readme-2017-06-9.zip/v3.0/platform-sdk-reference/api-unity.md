---
title: "Unity"
excerpt: "OneSignal Unity API Reference. Works with <span class=\"label-all label-ios\">iOS</span>, <span class=\"label-all label-android\">Android</span> (and derivatives like <span class=\"label-all\">Amazon</span>), and <span class=\"label-all label-windows\">Windows Phone 8.0 &amp; 8.1</span>.\n<div class=\"tag-all tag-developers\">For Developers</div>"
---
[block:parameters]
{
  "data": {
    "0-0": "### Initialization",
    "0-1": "",
    "2-0": "[kOSSettingsKeyAutoPrompt](#section)",
    "2-1": "Method",
    "h-2": "",
    "0-2": "",
    "2-2": "<span class=\"label-all label-ios\">iOS</span> - Automatically Prompt Users to Enable Notifications",
    "h-0": "",
    "1-0": "[init](#section--init-)",
    "1-1": "Method",
    "1-2": "Initialize OneSignal",
    "5-0": "### Registering Push",
    "6-0": "[RegisterForPushNotifications](#section)",
    "7-0": "### User IDs",
    "8-0": "[idsAvailable](#section--idsavailable-)",
    "8-1": "Delegate",
    "8-2": "Get the User ID of the device",
    "9-0": "[GetIdsAvailable](#section)",
    "9-1": "Method",
    "9-2": "",
    "10-0": "### Tags",
    "11-0": "[getTags](#section--gettags-)",
    "11-1": "Method",
    "14-1": "Method",
    "15-1": "Method",
    "16-1": "Method",
    "11-2": "View Tags from a User",
    "14-2": "",
    "16-2": "",
    "15-2": "Delete a Tag from a User",
    "14-0": "[sendTags](#section--sendtags-)",
    "15-0": "[deleteTag](#section--deletetag-)",
    "16-0": "[deleteTags](#section--deletetags-)",
    "17-0": "### Data",
    "20-0": "### Sending Notifications",
    "25-0": "### Receiving Notifications",
    "21-0": "[postNotification](#section--postnotification-)",
    "22-0": "[cancelNotification](#section--cancelnotification-)",
    "23-0": "[clearOneSignalNotifications](#section--clearonesignalnotifications-)",
    "24-0": "[setSubscription](#section--setsubscription-)",
    "24-1": "Method",
    "23-1": "Method",
    "21-1": "Method",
    "22-1": "Method",
    "26-0": "[OSNotification](#section--osnotification-)",
    "26-1": "Method",
    "33-0": "[OSNotificationPayload](#section--osnotificationpayload-)",
    "33-1": "Method",
    "34-0": "### Appearance",
    "35-0": "[enableVibrate](#section--enablevibrate-)",
    "36-0": "[enableSound](#section--enablesound-)",
    "35-1": "Method",
    "36-1": "Method",
    "37-0": "### Debug",
    "38-0": "[setLogLevel](#section--setloglevel-)",
    "38-1": "Method",
    "19-1": "Method",
    "19-0": "[syncHashedEmail](#section--synchashedemail-)",
    "18-0": "[promptLocation](#section--promptlocation-)",
    "18-1": "Method",
    "18-2": "Prompt Users for Location",
    "19-2": "Sync Anonymized User Email",
    "21-2": "Send or schedule a notification to a user",
    "22-2": "Delete a single app notification",
    "24-2": "Opt users in or out of receiving notifications",
    "23-2": "Delete all app notifications",
    "33-2": "Data that comes with a notification",
    "26-2": "When a notification is received by a device",
    "35-2": "<span class=\"label-all label-android\">Android</span> - When user receives notification, vibrate device less",
    "36-2": "<span class=\"label-all label-android\">Android</span> - When user receives notification, do not play a sound",
    "38-2": "Enable logging to help debug OneSignal implementation",
    "13-0": "[sendTag](#section--sendtag-)",
    "13-1": "Method",
    "13-2": "Add a Tag to a User",
    "12-0": "[TagsReceived](#section)",
    "12-1": "Delegate",
    "12-2": "",
    "28-0": "[OSNotificationAction](#section--osnotificationaction-)",
    "28-1": "Method",
    "28-2": "When a user takes an action on a notification",
    "3-0": "[kOSSettingsKeyInAppAlerts](#section)",
    "4-0": "[kOSSettingsKeyInAppLaunchURL](#section)",
    "3-1": "Method",
    "4-1": "Method",
    "6-2": "Prompt Users to Enable Notifications",
    "30-0": "[OSNotificationOpenedResult](#section--osnotificationopenedresult-)",
    "30-1": "Method",
    "4-2": "<span class=\"label-all label-ios\">iOS</span> - Open all URLs in In-App Safari Window",
    "3-2": "<span class=\"label-all label-android\">Android</span>, <span class=\"label-all label-ios\">iOS</span> - Automatically Display Notifications when app is in focus",
    "27-0": "[NotificationReceivedHandler](#section-notificationreceivedhandler)",
    "29-0": "[OSNotificationActionType](#section--osnotificationaction-)",
    "31-0": "[HandleNotification](#section-handlenotification)",
    "31-1": "Delegate",
    "32-0": "[OSNotificationDisplayType](#section--osnotificationdisplaytype-)",
    "32-2": "Change how notifications are displayed to users",
    "27-1": "Method",
    "29-1": "Method",
    "32-1": "Method"
  },
  "cols": 3,
  "rows": 39
}
[/block]
## Initialization

### Init
<div class="label-all label-type">Method</div>

Only required method you need to call to setup OneSignal to receive push notifications.. Call this on the first scene that is loaded.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`appId`",
    "0-1": "String",
    "1-1": "String",
    "1-0": "`googleProjectNumber`",
    "1-2": "<span class=\"label-all label-optional\">Optional</span> Your Google project number that is only required for Android GCM pushes.",
    "0-2": "<span class=\"label-all label-required\">Required</span> Your OneSignal app id from <a class=\"dash-link\">Keys &amp; IDs</a>",
    "2-2": "Calls this delegate when a notification is opened or one is received when the user is in your game.",
    "3-2": "Set false to delay the iOS accept notification system prompt. Defaults true. You can then call `OneSignal.RegisterForPushNotifications` at a better point in your game to prompt them.",
    "3-1": "Boolean",
    "3-0": "`autoRegister`",
    "2-0": "`inNotificationDelegate`",
    "2-1": "NotificationReceived"
  },
  "cols": 3,
  "rows": 4
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.Init(\"5eb5a37e-b458-11e3-ac11-000c2940e62c\", \"703322744261\", HandleNotification);",
      "language": "csharp"
    }
  ]
}
[/block]
### kOSSettingsKeyAutoPrompt
<div class="label-all label-type">Method - <span class="label-all label-ios">iOS</span> - *Coming Soon*</div>

Automatically Prompt Users to Enable Notifications

### kOSSettingsKeyInAppAlerts
<div class="label-all label-type">Method - <span class="label-all label-android">Android</span> &middot; <span class="label-all label-ios">iOS</span> - *Coming Soon*</div>

Automatically Display Notifications when app is in focus

### kOSSettingsKeyInAppLaunchURL
<div class="label-all label-type">Method - <span class="label-all label-ios">iOS</span> - *Coming Soon*</div>

Open all URLs in In-App Safari Window


## Registering Push

### RegisterForPushNotifications
<div class="label-all label-type">Method - <span class="label-all label-ios">iOS</span></div>

Call this when you would like to prompt an iOS user to accept push notifications with the default system prompt. Only use if you passed false to autoRegister when calling Init.
[block:code]
{
  "codes": [
    {
      "code": "OneSignal.RegisterForPushNotifications();",
      "language": "csharp"
    }
  ]
}
[/block]
## User IDs

### IdsAvailable
<div class="label-all label-type">Delegate</div>

Delegate you can define to get the OneSignal userId and Google registration Id or an iOS push token.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "0-0": "`userId`",
    "1-0": "`pushToken`",
    "0-1": "String",
    "1-1": "String",
    "0-2": "OneSignal userId is a UUID formatted string. (_unique per device per app_)",
    "1-2": "Either a Google registration Id or an iOS push token identifier(_unique per device per app_). _NOTE:_ Might be blank if push notifications are not accepted on iOS, Google Play services are not installed, or from a connection issue.",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 2
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "private void IdsAvailable(string userID, string pushToken) {\n\t\tprint(\"UserID:\"  + userID);\n\t\tprint(\"pushToken:\" + pushToken);\n\t}",
      "language": "csharp"
    }
  ]
}
[/block]
### GetIdsAvailable
<div class="label-all label-type">Method</div>

Lets you retrieve the OneSignal player id and push token. Your delegate is called after the device is successfully registered with OneSignal. If the device has already successfully registered, the delegate will be called immediately.
[block:parameters]
{
  "data": {
    "0-0": "`inIdsAvailableDelegate`",
    "0-1": "IdsAvailable",
    "0-2": "Calls the delegate when the player id is available.",
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "void SomeMethod() {\n\t\tOneSignal.GetIdsAvailable(IdsAvailable);\n\t}\n\n\tprivate void IdsAvailable(string userID, string pushToken) {\n\t\tprint(\"UserID:\"  + userID);\n\t\tprint(\"pushToken:\" + pushToken);\n\t}",
      "language": "csharp"
    },
    {
      "code": "function SomeMethod() {\n\t\tOneSignal.GetIdsAvailable(IdsAvailable);\n\t}\n\n\tprivate function IdsAvailable(userID : String, pushToken :String) : void {\n\t\tprint(\"UserID:\"  + userID);\n\t\tprint(\"pushToken:\" + pushToken);\n\t}",
      "language": "javascript"
    }
  ]
}
[/block]
## Tags

### GetTags
<div class="label-all label-type">Method</div>

Retrieve a list of tags that have been set on the player from the OneSignal server.
[block:parameters]
{
  "data": {
    "0-0": "`inTagsReceivedDelegate`",
    "0-1": "TagsReceived",
    "0-2": "Delegate gets called once the tags are available.",
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "void SomeMethod() {\n\t\tOneSignal.GetTags(TagsReceived);\n\t}\n\n\tprivate void TagsReceived(Dictionary<string, object> tags) {\n\t\tforeach (var tag in tags)\n\t\t\tprint(tag.Key + \":\" + tag.Value);\n\t}",
      "language": "csharp"
    }
  ]
}
[/block]
### TagsReceived
<div class="label-all label-type">Delegate</div>

Delegate you can define to get the all the tags set on a player from onesignal.com.
[block:parameters]
{
  "data": {
    "0-0": "`tags`",
    "0-1": "Dictionary<string, object>",
    "0-2": "Dictionary of key value pairs retrieved from the OneSignal server.",
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "private static void TagsReceived(Dictionary<string, object> tags) {\n\t\tforeach (var tag in tags)\n\t\t\tprint(tag.Key + \":\" + tag.Value);\n\t}",
      "language": "csharp"
    }
  ]
}
[/block]
### SendTag
<div class="label-all label-type">Method</div>

Tag a player based on a game event of your choosing so later you can create segments on [onesignal.com](https://onesignal.com) to target these players. If you need to set more than one key at a time please use `SendTags` instead.
[block:parameters]
{
  "data": {
    "h-0": "Parameters",
    "0-0": "`key`",
    "1-0": "`value`",
    "1-1": "String",
    "0-1": "String",
    "0-2": "Key of your choosing to create or update.",
    "1-2": "Value to set on the key. _NOTE:_ Passing in a blank String deletes the key, you can also call `DeleteTag` or `DeleteTags`.",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 2
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.SendTag(\"key\", \"value\");",
      "language": "csharp"
    }
  ]
}
[/block]
### SendTags
<div class="label-all label-type">Method</div>

Set multiple tags on a player with one call.
[block:parameters]
{
  "data": {
    "0-0": "`tags`",
    "0-1": "Dictionary<string, string>",
    "0-2": "An IDictionary of key value pairs. _NOTE:_ Passing in a blank as a value deletes the key, you can also call `DeleteTag` or `DeleteTags`.",
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.SendTags(new Dictionary<string, string>() { {\"UnityTestKey2\", \"value2\"}, {\"UnityTestKey3\", \"value3\"} });",
      "language": "csharp"
    }
  ]
}
[/block]
### DeleteTag
<div class="label-all label-type">Method</div>

Deletes a tag that was previously set on a player with `SendTag` or `SendTags`. Please use `DeleteTags` if you need to delete more than one tag.
[block:parameters]
{
  "data": {
    "0-0": "`key`",
    "0-1": "String",
    "0-2": "Key to remove.",
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.DeleteTag(\"key\");",
      "language": "csharp"
    }
  ]
}
[/block]
### DeleteTags
<div class="label-all label-type">Method</div>

Deletes tags that were previously set on a player with `SendTag` or `SendTags`.
[block:parameters]
{
  "data": {
    "0-0": "`keys`",
    "0-1": "IList<string>",
    "0-2": "Keys to remove.",
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.DeleteTags(new List<string>() {\"UnityTestKey2\", \"UnityTestKey3\" })",
      "language": "csharp"
    }
  ]
}
[/block]
## Data

### PromptLocation
<div class="label-all label-type">Method</div>

Prompts the user for location permissions. This allows for geotagging so you can send notifications to users based on location.
[block:code]
{
  "codes": [
    {
      "code": "OneSignal.PromptLocation();",
      "language": "csharp"
    }
  ]
}
[/block]

[block:html]
{
  "html": "<div class=\"platform-instruction\">\n  <h5 class=\"label-ios\"\">iOS Instructions</h5>\n  <p>You must add <strong>all</strong> of the following to your iOS plist settings:</p>\n  <p><code>NSLocationUsageDescription</code></p>\n  <p><code>NSLocationWhenInUseUsageDescription</code></p>\n</div>"
}
[/block]

[block:html]
{
  "html": "<div class=\"platform-instruction\">\n  <h5 class=\"label-android\"\">Android Instructions</h5>\n  <p>You must add <strong>one</strong> of the following Android Permissions:</p>\n  <p><code>&lt;uses-permission android:name=&quot;android.permission.ACCESS_FINE_LOCATION&quot;/&gt;</code></p>\n  <p><code>&lt;uses-permission android:name=&quot;android.permission.ACCESS_COARSE_LOCATION&quot;/&gt;</code></p>\n</div>"
}
[/block]
### syncHashedEmail
<div class="label-all label-type">Method - *Coming Soon*</div>

Sends the user's email as an anonymized hash to prevent duplicated users.

## Sending Notifications

### PostNotification
<div class="label-all label-type">Method</div>

Allows you to send notifications from user to user or schedule ones in the future to be delivered to the current device.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`parameters`",
    "0-1": "Dictionary<string, object>",
    "0-2": "Dictionary of notification options, see our [Create notification](ref:create-notification) POST call for all options."
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:parameters]
{
  "data": {
    "h-0": "Returns",
    "0-0": "`onSuccess`",
    "0-1": "`OnPostNotificationSuccess` delegate fires when the notification was created on OneSignal's server.\n\n`Dictionary<string, object>` - Json response from OneSignal's server.",
    "1-0": "`onFailure`",
    "1-1": "`OnPostNotificationFailure` delegate fires when the notification failed to create\n\n`Dictionary<string, object>` - Json response from OneSignal's server.",
    "h-1": "Method"
  },
  "cols": 2,
  "rows": 2
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "using OneSignalPush.MiniJSON;\n\nprivate static string oneSignalDebugMessage;\n\nvoid someMethod() {\n// Just an example userId, use your own or get it the devices by calling OneSignal.GetIdsAvailable\nstring userId = \"b2f7f966-d8cc-11e4-bed1-df8f05be55ba\";\n\nvar notification = new Dictionary<string, object>();\nnotification[\"contents\"] = new Dictionary<string, string>() { {\"en\", \"Test Message\"} };\n\nnotification[\"include_player_ids\"] = new List<string>() { userId };\n// Example of scheduling a notification in the future.\nnotification[\"send_after\"] = System.DateTime.Now.ToUniversalTime().AddSeconds(30).ToString(\"U\");\n\nOneSignal.PostNotification(notification, (responseSuccess) => {\n  oneSignalDebugMessage = \"Notification posted successful! Delayed by about 30 secounds to give you time to press the home button to see a notification vs an in-app alert.\\n\" + Json.Serialize(responseSuccess);\n}, (responseFailure) => {\n  oneSignalDebugMessage = \"Notification failed to post:\\n\" + Json.Serialize(responseFailure);\n});\n\n}",
      "language": "csharp"
    },
    {
      "code": "import OneSignalPush.MiniJSON;\n\nprivate static var oneSignalDebugMessage : String;\n\nfunction someFunction() {\n// Just an example userId, use your own or get it the devices by calling OneSignal.GetIdsAvailable\nvar userId = \"b2f7f966-d8cc-11e4-bed1-df8f05be55ba\";\nvar notification = new Dictionary.<String, Object>();\nnotification[\"contents\"] = {\"en\": \"Test Message\" };\n\nnotification[\"include_player_ids\"] = [userId];\n// Example of scheduling a notification in the future.\nnotification[\"send_after\"] = System.DateTime.Now.ToUniversalTime().AddSeconds(30).ToString(\"U\");\n\nOneSignal.PostNotification(notification, function(responseSuccess) {\n  oneSignalDebugMessage = \"Notification posted successful! Delayed by about 30 secounds to give you time to press the home button to see a notification vs an in-app alert.\\n\" + Json.Serialize(responseSuccess);\n}, function(responseFailure) {\n  oneSignalDebugMessage = \"Notification failed to post:\\n\" + Json.Serialize(responseFailure);\n});\n\n}",
      "language": "javascript"
    }
  ]
}
[/block]
See the [Create notification](ref:create-notification) REST API POST call for a list of all possible options. Note: You can only use `include_player_ids` as a targeting parameter from your app. Other target options such as `tags` and `included_segments` require your OneSignal App REST API key which can only be used from your server.

### cancelNotification
<div class="label-all label-type">Method - <span class="label-all label-android">Android</span> - *Coming Soon*</div>

Delete a single app notification

### ClearOneSignalNotifications
<div class="label-all label-type">Method</div>

Removes all OneSignal app notifications from the Notification Shade.
[block:code]
{
  "codes": [
    {
      "code": "OneSignal.ClearOneSignalNotifications();",
      "language": "csharp",
      "name": "C#"
    }
  ]
}
[/block]
### SetSubscription
<div class="label-all label-type">Method</div>

You can call this method with false to opt users out of receiving all notifications through OneSignal. You can pass true later to opt users back into notifications.

[block:parameters]
{
  "data": {
    "0-0": "`enable`",
    "0-1": "Boolean",
    "0-2": "",
    "h-0": "Parameter",
    "h-1": "Type"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.SetSubscription(false);",
      "language": "csharp"
    }
  ]
}
[/block]
## Receiving Notifications

### OSNotification
<div class="label-all label-type">Method - *Coming Soon*</div>

### OSHandleNotificationReceivedBlock
<div class="label-all label-type">Method - *Coming Soon*</div>

### OSNotificationAction
<div class="label-all label-type">Method - *Coming Soon*</div>

### OSNotificationActionType
<div class="label-all label-type">Method - *Coming Soon*</div>

### OSNotificationOpenedResult
<div class="label-all label-type">Method - *Coming Soon*</div>

### HandleNotification
<div class="label-all label-type">Delegate</div>

Delegate you can define to process information on the notification the user just opened.
[block:parameters]
{
  "data": {
    "h-0": "Parameters",
    "0-0": "`message`",
    "1-0": "`additionalData`",
    "1-1": "String",
    "0-1": "Dictionary<string, object>",
    "0-2": "The message text the user seen in the notification.",
    "1-2": "Key value pairs that were set on the notification.",
    "h-1": "Type",
    "h-2": "Description",
    "2-0": "`isActive`",
    "2-1": "Boolean",
    "2-2": "True if your app was currently being used when a notification came in."
  },
  "cols": 3,
  "rows": 3
}
[/block]
`additionalData` parameters:
[block:parameters]
{
  "data": {
    "h-0": "Parameters",
    "0-0": "`actionSelected`",
    "1-0": "`stacked_notifications`",
    "1-1": "String",
    "0-1": "Dictionary<string, object>",
    "0-2": "Id of the button pressed if present on notification. `__DEFAULT__` will be set if buttons were present but the notification itself was tapped on.",
    "1-2": "Contains a Dictionary for each notification that exists in the stack. `message` as well as keys listed above and ones you set with additional data will be available.",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 2
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "private static void HandleNotification(string message, Dictionary<string, object> additionalData, bool isActive) {\n  print(message);\n\n  // When isActive is true this means the player is currently in your game.\n  // Use isActive and your own game logic so you don't interupt the player with a popup or menu when they are in the middle of playing your game.\n  if (additionalData != null) {\n    if (additionalData.ContainsKey(\"discount\")) {\n      extraMessage = \"DISCOUNT!\";\n      // Take player to your store.\n    }\n    else if (additionalData.ContainsKey(\"bonusCredits\")) {\n      extraMessage = \"BONUS CREDITS!\";\n      // Take player to your store.\n    }\n  }\n}",
      "language": "csharp"
    },
    {
      "code": "private static function HandleNotification(message : String, additionalData : Dictionary.<String, Object>, isActive : boolean) : void {\n  print(message);\n\n  // When isActive is true this means the player is currently in your game.\n  // Use isActive and your own game logic so you don't interupt the player with a popup or menu when they are in the middle of playing your game.\n  if (additionalData != null) {\n    if (additionalData.ContainsKey(\"discount\")) {\n      extraMessage = \"DISCOUNT!\";\n      // Take player to your store.\n    }\n    else if (additionalData.ContainsKey(\"bonusCredits\")) {\n      extraMessage = \"BONUS CREDITS!\";\n      // Take player to your store.\n    }\n  }\n}",
      "language": "javascript"
    },
    {
      "code": "private static void HandleNotification(string message, Dictionary<string, object> additionalData, bool isActive) {\n  bool hasButtons = (additionalData != null && additionalData.ContainsKey(\"actionSelected\"));\n  if (hasButtons) {\n    if (additionalData[\"actionSelected\"].Equals(\"id1\"))\n      print(\"button id1 pressed\");\n    else if (additionalData[\"actionSelected\"].Equals(\"id2\"))\n      print(\"button id2 pressed\");\n    else if (additionalData[\"actionSelected\"].Equals(\"__DEFAULT__\"))\n      print(\"Buttons present but you tapped on the notificaiton instead.\");\n  }\n}",
      "language": "csharp",
      "name": "C# (handle buttons)"
    },
    {
      "code": "private static void HandleNotification(string message, Dictionary<string, object> additionalData, bool isActive) {\n  print(\"Notification opned with Message: \" + message);\n\t\t\n  if (additionalData != null && additionalData.ContainsKey(\"stacked_notifications\")) {\n    var notificationsList = (List<object>)additionalData[\"stacked_notifications\"];\n    print(\"Stacked Sotification Opened, number on stack: \" + notificationsList.Count);\n    foreach (Dictionary<string, object> notifiAddData in notificationsList) {\n      foreach (KeyValuePair<string, object> kvp in notifiAddData)\n        print(\"Key = \" + kvp.Key + \", Value = \" + kvp.Value);\n    }\n  }\n}",
      "language": "csharp",
      "name": "C#(Stacked Notifications)"
    }
  ]
}
[/block]
### OSNotificationDisplayType
<div class="label-all label-type">Method - *Coming Soon*</div>

Change how notifications are displayed to users

### OSNotificationPayload
<div class="label-all label-type">Method - *Coming Soon*</div>

Data that comes with a notification

## Appearance

### EnableVibrate
<div class="label-all label-type">Method - <span class="label-android">Android</span></div>

*You can call this from your UI from a button press for example to give your user's options for your notifications.*

By default OneSignal always vibrates the device when a notification is displayed unless the device is in a total silent mode. Passing false means that the device will only vibrate lightly when the device is in it's vibrate only mode.
[block:code]
{
  "codes": [
    {
      "code": "OneSignal.EnableVibrate(false);",
      "language": "csharp"
    }
  ]
}
[/block]
### EnableSound
<div class="label-all label-type">Method - <span class="label-android">Android</span></div>

*You can call this from your UI from a button press for example to give your user's options for your notifications.*

By default OneSignal plays the system's default notification sound when the device's notification system volume is turned on. Passing false means that the device will only vibrate unless the device is set to a total silent mode.
[block:code]
{
  "codes": [
    {
      "code": "OneSignal.EnableSound(false);",
      "language": "csharp"
    }
  ]
}
[/block]
## Debug

### SetLogLevel
<div class="label-all label-type">Method</div>

Enable logging to help debug if you run into an issue setting up OneSignal. The following options are available with increasingly more information; `NONE`, `FATAL`, `ERROR`, `WARN`, `INFO`, `DEBUG`, `VERBOSE`
[block:parameters]
{
  "data": {
    "h-0": "Parameters",
    "0-0": "`logLevel`",
    "1-0": "`visualLevel`",
    "1-1": "LOG_LEVEL",
    "0-1": "LOG_LEVEL",
    "0-2": "Sets the logging level to print the iOS Xcode log or the Android LogCat log.",
    "1-2": "Sets the logging level to show as alert dialogs.",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 2
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.SetLogLevel(OneSignal.LOG_LEVEL.INFO, OneSignal.LOG_LEVEL.INFO);",
      "language": "csharp"
    }
  ]
}
[/block]
---
title: "Free vs Enterprise"
excerpt: ""
---
OneSignal makes it simple for developers to add free personalized in app push notifications to their iOS and Android mobile app(s) and/or add browser web push notification to their website. 

We offer two ways to work with OneSignal - Free and Enterprise. 
##Free

For our free product we offer unlimited push notifications to an unlimited number of users for all developers of commercial and private apps. In terms of the product feature set, there is no difference between a free and an enterprise client with regards to our push notifications service. We do however provide incremental support, consulting and a negotiated contract along with keeping their data private for our enterprise clients. 

In exchange for our free product we do monetize the data that is passed to us via the SDK to allow us to give the product away for Free. Our business model is based on using the wide distribution of our SDKs to help advertisers, ad technology companies and research companies better target, build audiences and understand mobile user behavior, similar to other services which leverage their large data footprint to monetize the data. 

To get started simply create an account with OneSignal and start using the service. Please feel free to reach out to us anytime with questions. 

[Privacy Policy Free](doc:privacy-policy-free) 
[Terms of Use Free](doc:terms-of-use-free) 
##Enterprise

In terms of the product it is the same for Enterprise and Free. Most client who choose enterprise want or need to keep their data private. We priced the Enterprise offering to be as scalable as possible and to scale along with our our costs of infrastructure which we focused on scaling from the beginning. In addition, we offer incremental fees for support, onboarding as well as discounts for annual payments. 

For our enterprise product pricing is based on tiers of total users (SDK Installs on iOS, SDK Installs on Android and Subscribed users via Web Push). 

We do have an enterprise pricing plan that start at $40 for up to 500,000 total users.

##Enterprise Pricing Tiers
[block:parameters]
{
  "data": {
    "0-0": "##Price Tiers",
    "0-1": "##Monthly Price",
    "1-0": "Up to 500,000 Users",
    "2-0": "500K - 1M Users",
    "3-0": "1M - 5M Users",
    "4-0": "5M -10M Users",
    "5-0": "10M - 20M Users",
    "6-0": "20M -40M Users",
    "7-0": "40M -100M Users",
    "8-0": "100M+ Users",
    "8-1": "$5000 +$45/Million",
    "7-1": "$5,000",
    "6-1": "$2,200",
    "5-1": "$1,200",
    "4-1": "$650",
    "3-1": "$350",
    "2-1": "$75",
    "1-1": "$40"
  },
  "cols": 2,
  "rows": 9
}
[/block]
##Enterprise Pricing Comparison 
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/1d64784-Screenshot_2016-12-30_12.37.59.png",
        "Screenshot 2016-12-30 12.37.59.png",
        500,
        384,
        "#eb6363"
      ]
    }
  ]
}
[/block]
##Additional Enterprise Options 
[block:parameters]
{
  "data": {
    "0-0": "##Optional Add on",
    "0-1": "##Price",
    "1-0": "Annual Payment",
    "1-1": "1 Month Free / 8.3% Discount paid Annually",
    "2-0": "Monthly Premium Enterprise Support",
    "2-1": "$1,000 / month",
    "3-0": "Premium Onboarding and Setup Fee",
    "3-1": "$2,000 / one time fee",
    "4-0": "Standard Payment Term",
    "4-1": "1 Year",
    "5-0": "Standard Payment Term",
    "5-1": "Net 15 from Invoice"
  },
  "cols": 2,
  "rows": 6
}
[/block]
[Privacy Policy Enterprise](doc:privacy-policy-enterprise) 
[Terms of Use Enterprise](doc:terms-of-use-enterprise) 

If you're still interested in our paid enterprise service please email us [sales@onesignal.com](mailto:sales@onesignal.com?subject=Enterprise) and tell a bit more about your company and/or needs when it comes to our enterprise service.

[Sample Standard Contract](https://docsend.com/view/r5ehhvw) 
[Contact Form](https://goo.gl/forms/UilsAiyFPDPfAnlv10)
---
title: "Firebase Cloud Messaging (FCM)"
excerpt: "Differences between Google Cloud Messaging (GCM) and Firebase Cloud Messaging (FCM), used with <span class=\"label-all label-android\">Android</span> and <span class=\"label-all label-amazon\">Amazon</span>.\n<div class=\"tag-all tag-developers\">For Developers</div>"
---
## FCM & GCM
Firebase Cloud Messaging (FCM) and Google Cloud Messaging (GCM) projects are both compatible with OneSignal.
We recommend following our [Generate a Google Server API Key guide](doc:generate-a-google-server-api-key) as this is quicker and easier to setup than FCM.
*You can always migrate your GCM project to FCM at a later time.*


## Sender ID & Server key
If you already have a FCM project you would like to use with OneSignal, you will need to retrieve your "Sender ID" and "Firebase Cloud Messaging token".

1. Go to the [Firebase console](https://console.firebase.google.com/) and select your project.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/a59354f-FCM_console_1.png",
        "FCM_console_1.png",
        651,
        608,
        "#1182c1"
      ]
    }
  ]
}
[/block]
2. Click the gear in the top left. Then select "Project Settings".

3. Select the "CLOUD MESSAGING" tab and copy the "Firebase Cloud Messaging token" and "Sender ID".
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/e4db1e7-fcm_firebase_cloud_messaging_token.png",
        "fcm_firebase_cloud_messaging_token.png",
        981,
        579,
        "#e5e6ec"
      ]
    }
  ]
}
[/block]
4. Continue to step [3. Configure your OneSignal app's Android platform settings](generate-a-google-server-api-key#section-3-configure-your-onesignal-app-s-android-platform-settings) to add the Server Key and Google project number to your OneSignal account.
[block:callout]
{
  "type": "info",
  "body": "Must still use `com.google.android.gms:play-services-gcm` even if your using a Firebase key.",
  "title": "Android Studio"
}
[/block]
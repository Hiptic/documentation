---
title: "Upgrading to Android SDK 3.0"
excerpt: "Keeping your SDK up to date on <span class=\"label-all label-android\">Android</span> and <span class=\"label-all label-amazon\">Amazon</span>.\n<div class=\"tag-all tag-developers\">For Developers</div>"
---
## Update to 3.0 in your project
1A. If you are using Android Studio open your build.gradle (Module: app) and update the OneSignal compile line to 3.0.
[block:code]
{
  "codes": [
    {
      "code": "dependencies {\n    compile 'com.onesignal:OneSignal:3.+@aar'\n}",
      "language": "c",
      "name": "Gradle"
    }
  ]
}
[/block]
1B. For Eclipse download the latest .jar from the [release section](https://github.com/OneSignal/OneSignal-Android-SDK/releases).

## NotificationOpenedHandler
Update your `notificationOpened` method from:
[block:code]
{
  "codes": [
    {
      "code": "import com.onesignal.OneSignal.NotificationOpenedHandler;\n\nprivate class ExampleNotificationOpenedHandler implements NotificationOpenedHandler {\n  @Override\n  public void notificationOpened(String message, JSONObject additionalData, boolean isActive) {\n    try {\n      if (additionalData != null) {\n        if (additionalData.has(\"actionSelected\"))\n          Log.d(\"OneSignalExample\", \"OneSignal notification button with id \" + additionalData.getString(\"actionSelected\") + \" pressed\");\n\n        Log.d(\"OneSignalExample\", \"Full additionalData:\\n\" + additionalData.toString());\n        Log.d(\"OneSignalExample\", \"App in focus: \" + isActive);\n      }\n    } catch (Throwable t) {\n      t.printStackTrace();\n    }\n  }\n}",
      "language": "java"
    }
  ]
}
[/block]
To the following:
[block:code]
{
  "codes": [
    {
      "code": "import com.onesignal.OneSignal.NotificationOpenedHandler;\n\nprivate class ExampleNotificationOpenedHandler implements NotificationOpenedHandler {\n  @Override\n  public void notificationOpened(OSNotificationOpenResult openedResult) {\n    OSNotification notification = openedResult.notification;\n    JSONObject data = notification.payload.additionalData;\n    OSNotificationAction.ActionType actionType = openedResult.action.type;\n\t\t\n    String customKey = data.optString(\"customkey\", null);\n    if (actionType == OSNotificationAction.ActionType.ActionTaken)\n      Log.i(\"OneSignalExample\", \"Button pressed with id: \" + openedResult.action.actionID);\n    \n    if (data != null)\n    \tLog.d(\"OneSignalExample\", \"Full additionalData:\\n\" + data.toString());\n    \n    Log.d(\"OneSignalExample\", \"App in focus: \" + notification.isAppInFocus);\n  }\n}",
      "language": "java"
    }
  ]
}
[/block]
See the [NotificationOpenedHandler](doc:android-native-sdk#section--notificationopenedhandler-) documentation for a list of all the new properties.

## enableInAppAlertNotification & enableNotificationsWhenActive
`enableInAppAlertNotification` and `enableNotificationsWhenActive` have been combined into `inFocusDisplaying` which is set from the `OneSignal.Builder`. `InAppAlert` is now the default so notifications are now shown as Alerts when your app is in focus.
[block:code]
{
  "codes": [
    {
      "code": "OneSignal.startInit(this)\n  .inFocusDisplaying(OneSignal.OSInFocusDisplayOption.Notification)\n  .init();",
      "language": "java"
    }
  ]
}
[/block]

## com.onesignal.BackgroundBroadcast.RECEIVE
The `com.onesignal.BackgroundBroadcast.RECEIVE` action intent was deprecated in our 2.4.0 SDK and removed in 3.0.0. It has been replaced with a `NotificationExtenderService` which can be setup by following our [Background Data and Notification Overriding](android-notification-customizations#background-data-and-notification-overriding) instructions.
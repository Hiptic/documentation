---
title: "Generate an Amazon API Key"
excerpt: "Required for all <span class=\"label-all label-amazon\">Amazon</span> apps.\n<div class=\"tag-all tag-developers\">For Developers</div>"
---
## 1. Creating Security Profile for your app

**1.1** [Login to your Amazon Developer account](https://developer.amazon.com/login.html) and select your app.
 
**1.2** Click on "Device Messaging" tab and press the "Create a New Security Profile".
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/92REq7thRFiW728xOiNS_AmazonSecurityProfile1.png",
        "AmazonSecurityProfile1.png",
        "976",
        "573",
        "#a94042",
        ""
      ]
    }
  ]
}
[/block]
**1.3** Give your profile a required name and description, then press Save.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/aIDGySBrR7iFANxPak1L_AmazonSecurityProfile2.png",
        "AmazonSecurityProfile2.png",
        "927",
        "394",
        "",
        ""
      ]
    }
  ]
}
[/block]
**1.4** You should get a successfully message then, press "View Security Profile" to continue.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/D4frRRzJQue8WZufNbDr_AmazonSecurityProfile3.png",
        "AmazonSecurityProfile3.png",
        "865",
        "366",
        "",
        ""
      ]
    }
  ]
}
[/block]
** 1.5 ** You will see the following page.
*Leave this tab open as you will continue from here on step 2.*
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/06k5hfGR5OtUjHqSvzHp_AmazonSecurityProfile4.png",
        "AmazonSecurityProfile4.png",
        "912",
        "341",
        "",
        ""
      ]
    }
  ]
}
[/block]
** 1.6 ** Login to [onesignal.com](https://onesignal.com), select "Application Settings", press "Configure" to the right of Amazon (ADM), copy in the "Client ID" and "Client Secret" from the Amazon page to here, and press Save.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/c76a7a6-Screen_Shot_2017-05-16_at_7.40.48_PM.png",
        "Screen Shot 2017-05-16 at 7.40.48 PM.png",
        1393,
        885,
        "#7d868e"
      ]
    }
  ]
}
[/block]



## 2. Creating Amazon API Key

*The following steps are required to test push notifications before publishing your app to the Amazon store.*

**2.1 ** Go back to the Amazon Security Profile page for your app and select the "Android/Kindle Settings" tab.

**2.2 ** Enter any name you like for the "API Key Name".

**2.3 ** Enter your Android package name. *(**NOTE**: Case Sensitive)*

**2.4 ** Enter the MD5 signature of your Android Keystore you used to sign the APK file with.
    [See Amazon instructions to get this value](https://developer.amazon.com/public/apis/engage/login-with-amazon/docs/android_app_signatures.html)
   - We recommend not using the default debugging keystore but if you do make sure you redo this again with your production keystore or let Amazon sign your app for you. 
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/QmpjKGuXTnqb9BSTNyPA_AmazonSecurityProfile6.png",
        "AmazonSecurityProfile6.png",
        "906",
        "399",
        "",
        ""
      ]
    }
  ]
}
[/block]


** 2.5 ** Copy the Key shown here and save it into file named `api_key.txt`. *When your app is built it needs to be located in /assets/ in the root of your apk. More details on the placement of this file in SDK installation documentation.*
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/vFkWzWcASaSyBzMlF6ps_AmazonSecurityProfile7.png",
        "AmazonSecurityProfile7.png",
        "910",
        "612",
        "#c32d29",
        ""
      ]
    }
  ]
}
[/block]
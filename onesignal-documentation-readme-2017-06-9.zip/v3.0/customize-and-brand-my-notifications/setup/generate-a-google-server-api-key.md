---
title: "Generate a Google Server API Key"
excerpt: "Required for all <span class=\"label-all label-android\">Android</span> apps and <span class=\"label-all\">Chrome Apps & Extensions</span>, and optional for <span class=\"label-all label-amazon\">Amazon</span>.\n<div class=\"tag-all tag-developers\">For Developers</div>"
---
Your **Google Server API Key** and **Google Project Number** are used to send push notifications to <span class="label-all label-android">Android</span> devices.

To begin, we'll obtain a Google Server API Key and Google Project Number. These keys allow OneSignal to use Google's web push services for your notifications.

<div id="web-push-warning"><img src="https://onesignal.com/assets/common/platform-icons/browsers.png"><div class="text"><strong>Do not follow this guide if</strong> you are integrating web push for a website or WordPress blog.

Android platforms are for native mobile apps only, not for websites.</div></div>

## 1. Create a Firebase project

**1.1** Visit the [Firebase Console](https://firebase.google.com) and sign in with your Google account.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/1a62b77-FireBase-1.1-go-to-console.png",
        "FireBase-1.1-go-to-console.png",
        1007,
        505,
        "#079ce3"
      ]
    }
  ]
}
[/block]
**1.2** Press "CREATE NEW PROJECT" or select an existing one below.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/ef03430-FireBase-1.2-create-new-project.png",
        "FireBase-1.2-create-new-project.png",
        1007,
        449,
        "#e3e6ed"
      ]
    }
  ]
}
[/block]
**1.3** Enter a project name and press "CREATE PROJECT".
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/3fdb533-FireBase-1.3-create-project.png",
        "FireBase-1.3-create-project.png",
        708,
        477,
        "#f9f9f9"
      ]
    }
  ]
}
[/block]

---

## 2. Getting your Firebase Cloud Messaging token and Sender ID

**2.1** Click the Gear icon in the top left and select "Project settings".

**2.2**  Select the "CLOUD MESSAGING" tab.

**2.3** Save the two values listed:

- You'll need your **Server key**, also known as the **Google Server API key**.
- You'll need your **Sender ID**, also known as the **Google Project Number**, later as well
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/992ce63-FCM_Project_keys.png",
        "FCM_Project_keys.png",
        950,
        564,
        "#e8e9ed"
      ],
      "sizing": "smart"
    }
  ]
}
[/block]

---

## 3. Configure your OneSignal app's Android platform settings

**3.1** Go to <a class="dash-link">App Settings</a> and press the _Configure_ button to the right of _Google Android_.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/2dbbdd7-Screen_Shot_2017-05-16_at_7.19.14_PM.png",
        "Screen Shot 2017-05-16 at 7.19.14 PM.png",
        1159,
        725,
        "#393a43"
      ]
    }
  ]
}
[/block]
**3.2** Paste your Google Server API Key and Google Project Number in here and press Save.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/2860ef8-Screen_Shot_2017-05-16_at_7.21.59_PM.png",
        "Screen Shot 2017-05-16 at 7.21.59 PM.png",
        1234,
        935,
        "#7d878f"
      ]
    }
  ]
}
[/block]

[block:callout]
{
  "type": "success",
  "title": "Configuration Complete",
  "body": "- The next step is to setup up the [Android SDK](doc:android-sdk-setup) or [Amazon SDK](doc:amazon-sdk-setup) !"
}
[/block]
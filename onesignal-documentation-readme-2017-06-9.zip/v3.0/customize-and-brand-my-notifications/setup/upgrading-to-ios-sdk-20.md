---
title: "Upgrading to iOS SDK 2.0"
excerpt: "Keeping your SDK up to date on <span class=\"label-all label-ios\">iOS</span>.\n<div class=\"tag-all tag-developers\">For Developers</div>"
---
The 2.0 SDK changes all selectors to static methods as well as provides new `OSNotificationOpenedResult` object signature for handling the notification open event.


### Update the framework

#### Carthage
Run `carthage update`

#### CocoaPods
Run `pod update 'OneSignal'`

#### Manually Imported
See our [new setup guide](ios-sdk-setup#section-1-import-onesignal-into-your-xcode-project).

[block:callout]
{
  "type": "danger",
  "title": "Important - XCode 8",
  "body": "You **MUST** follow the Capabilities steps below if you are using Xcode 8!\n- *If you miss this step users will not get a push token or have mismatch environment issues.*\n- *Requirement is specific to Xcode 8, applies to both 1.X and 2.X SDKs*"
}
[/block]
### Xcode - Add Required Capabilities

**1** Select the root project and Under Capabilities Enable "Push Notifications".
**2** Next Enable "Background Modes" and check "Remote notifications".

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/0934af8-Xcode_capabilities.png",
        "Xcode capabilities.png",
        961,
        774,
        "#f0f0f0"
      ]
    }
  ]
}
[/block]
## 1. Update OneSignal InitWithLaunchOptions
Finding the following OneSignal `initWithLaunchOptions` call:
[block:code]
{
  "codes": [
    {
      "code": "self.oneSignal = [[OneSignal alloc] initWithLaunchOptions:launchOptions\n                                        appId:@\"5eb5a37e-b458-11e3-ac11-000c2940e62c\"\n                                        handleNotification:nil];",
      "language": "objectivec"
    },
    {
      "code": "_ = OneSignal(launchOptions: launchOptions, appId: \"b2f7f966-d8cc-11e4-bed1-df8f05be55ba\", handleNotification: nil)",
      "language": "swift"
    }
  ]
}
[/block]
Change it to the following:
[block:code]
{
  "codes": [
    {
      "code": "[OneSignal initWithLaunchOptions:launchOptions appId:@\"5eb5a37e-b458-11e3-ac11-000c2940e62c\"];",
      "language": "objectivec"
    },
    {
      "code": "OneSignal.initWithLaunchOptions(launchOptions, appId: \"5eb5a37e-b458-11e3-ac11-000c2940e62c\")",
      "language": "swift"
    }
  ]
}
[/block]
If you setup a `handleNotification` block, find the following:
[block:code]
{
  "codes": [
    {
      "code": "self.oneSignal = [[OneSignal alloc] initWithLaunchOptions:launchOptions\n                                                         appId:@\"b2f7f966-d8cc-11e4-bed1-df8f05be55ba\"\n                                            handleNotification:^(NSString* message, NSDictionary* additionalData, BOOL isActive) {\n        // This function gets call when a notification is tapped on or one is received while the app is in focus.\n        NSString* messageTitle = @\"OneSignal Example\";\n        NSString* fullMessage = [message copy];\n        \n        if (additionalData) {\n            if (additionalData[@\"inAppTitle\"])\n                messageTitle = additionalData[@\"inAppTitle\"];\n            \n            if (additionalData[@\"actionSelected\"])\n                fullMessage = [fullMessage stringByAppendingString:[NSString stringWithFormat:@\"\\nPressed ButtonId:%@\", additionalData[@\"actionSelected\"]]];\n        }\n        \n        UIAlertView* alertView = [[UIAlertView alloc] initWithTitle:messageTitle\n                                                            message:fullMessage\n                                                           delegate:self\n                                                  cancelButtonTitle:@\"Close\"\n                                                  otherButtonTitles:nil, nil];\n        [alertView show];\n\n    }];",
      "language": "objectivec"
    },
    {
      "code": "_ = OneSignal(launchOptions: launchOptions, appId: \"b2f7f966-d8cc-11e4-bed1-df8f05be55ba\", handleNotification: { (message, additionalData, isActive) in\n                var fullMessage = message\n                //Try to fetch the action selected\n                if let actionSelected = additionalData[\"actionSelected\"] as? String {\n                    fullMessage =  fullMessage + \"\\nPressed ButtonId:\\(actionSelected)\"\n                }\n                \n                print(fullMessage)\n                \n            })",
      "language": "swift"
    }
  ]
}
[/block]
Change it to the following:
[block:code]
{
  "codes": [
    {
      "code": "[OneSignal initWithLaunchOptions:launchOptions appId:@\"b2f7f966-d8cc-11e4-bed1-df8f05be55ba\" handleNotificationAction:^(OSNotificationOpenedResult *result) {\n        \n        // This block gets called when the user reacts to a notification received\n        OSNotificationPayload* payload = result.notification.payload;\n        \n        NSString* messageTitle = @\"OneSignal Example\";\n        NSString* fullMessage = [payload.body copy];\n        \n        if (payload.additionalData) {\n            \n            if(payload.title)\n                messageTitle = payload.title;\n            \n            NSDictionary* additionalData = payload.additionalData;\n            \n            if (result.action.actionID)\n                fullMessage = [fullMessage stringByAppendingString:[NSString stringWithFormat:@\"\\nPressed ButtonId:%@\", result.action.actionID]];\n        }\n        \n        UIAlertView* alertView = [[UIAlertView alloc] initWithTitle:messageTitle\n                                                            message:fullMessage\n                                                           delegate:self\n                                                  cancelButtonTitle:@\"Close\"\n                                                  otherButtonTitles:nil, nil];\n        [alertView show];\n\n    }];",
      "language": "objectivec"
    },
    {
      "code": "OneSignal.initWithLaunchOptions(launchOptions, appId: \"b2f7f966-d8cc-11e4-bed1-df8f05be55ba\", handleNotificationAction: { (result) in\n                \n                // This block gets called when the user reacts to a notification received\n                let payload = result.notification.payload\n                var fullMessage = payload.title\n                \n                //Try to fetch the action selected\n                if let actionSelected = result.action.actionID {\n                    fullMessage =  fullMessage + \"\\nPressed ButtonId:\\(actionSelected)\"\n                }\n                \n                print(fullMessage)\n                \n            })",
      "language": "swift"
    }
  ]
}
[/block]
## 2. Update all OneSignal calls to static methods
OneSignal is now a singleton. Update all instance calls from `oneSignal` and `OneSignal defaultClient` to static `OneSignal` calls. As such, you should **avoid** creating an instance of the OneSignal class.

Find the following:
[block:code]
{
  "codes": [
    {
      "code": "[[OneSignal defaultClient] sendTag:@\"key\" value:@\"value\"];",
      "language": "objectivec"
    },
    {
      "code": "OneSignal.defaultClient().sendTag(\"key\", value: \"value\")",
      "language": "swift"
    }
  ]
}
[/block]
Change it to the following:
[block:code]
{
  "codes": [
    {
      "code": "// Note, OneSignal is case sensitive.\n[OneSignal sendTag:@\"key\" value:@\"value\"];",
      "language": "objectivec"
    },
    {
      "code": "// Note, OneSignal is case sensitive.\nOneSignal.sendTag(\"key\", value: \"value\")",
      "language": "swift"
    }
  ]
}
[/block]
## 3. autoRegister and enableInAppAlertNotification
`autoRegister` moved into the init call's optional `settings` dictionary parameter, by including an `NSNumber` boolean value for the `kOSSettingsKeyAutoPrompt` key.
The `enableInAppAlertNotification` is now part a static property named [`inFocusDisplayType`](doc:ios-native-sdk#section--infocusdisplaytype-) as an emu.
See the below example that set both these options.
[block:code]
{
  "codes": [
    {
      "code": "[OneSignal initWithLaunchOptions:launchOptions appId:@\"b2f7f966-d8cc-11e4-bed1-df8f05be55ba\" handleNotificationReceived:nil handleNotificationAction:nil settings:@{kOSSettingsKeyAutoPrompt: @YES}];\nOneSignal.inFocusDisplayType = OSNotificationDisplayTypeNotification;",
      "language": "objectivec"
    },
    {
      "code": "OneSignal.initWithLaunchOptions(launchOptions, appId: \"b2f7f966-d8cc-11e4-bed1-df8f05be55ba\", handleNotificationReceived:nil, handleNotificationAction:nil, settings: [kOSSettingsKeyAutoPrompt: true])\nOneSignal.inFocusDisplayType = OSNotificationDisplayType.notification;",
      "language": "swift",
      "name": null
    }
  ]
}
[/block]
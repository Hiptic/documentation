---
title: "Generate a Windows Phone Package SID and Secret"
excerpt: "Required for all <span class=\"label-all label-windows\">Windows Phone 8.1</span> apps.\n<div class=\"tag-all tag-developers\">For Developers</div>"
---
## 1. Create your app on Windows Dev Center
*Skip to step 2 if you already created your app here.*

**1.1** Login in to the [Windows Dev Center](https://dev.windows.com/overview?from=UHF) and click on "Create a new app".
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/CJwXv7YOQlKUgMrvpfRJ_WindowPhone8.1_1.1.png",
        "WindowPhone8.1_1.1.png",
        "375",
        "393",
        "#047bd3",
        ""
      ]
    }
  ]
}
[/block]
**1.2** Enter the name of your app. *(This name is used publicly on the Windows Store)*
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/ZLuYStFPQbCdG05JbL25_WindowPhone8.1_1.2.png",
        "WindowPhone8.1_1.2.png",
        "773",
        "299",
        "#0a4f90",
        ""
      ]
    }
  ]
}
[/block]
## 2. Get your App's Package SID and Client Secret
**2.1** Go to the [Microsoft account Developer Center](https://account.live.com/developers/applications/) and select your app by click on its name.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/ZWPcoAAHQpW8C5mIA5qB_WNS_app_select_2.1.png",
        "WNS_app_select_2.1.png",
        "656",
        "440",
        "#1c638e",
        ""
      ]
    }
  ]
}
[/block]
**2.2** Go to the "Application Secrets" section and copy the "Current" secret. If you don't have one press the "Generate New Password". This will be entered in the "Client Secret" field on your OneSignal app.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/fu5P4u6S2OKQ16bd4F1w_WNS_app_select_2.2.png",
        "WNS_app_select_2.2.png",
        "754",
        "344",
        "#1f5e8f",
        ""
      ]
    }
  ]
}
[/block]
**2.3** Scroll down to the "Windows Store" section and copy your "Package SID".
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/1N4A696hScCYrlxYBhEw_WNS_app_select_2.3.png",
        "WNS_app_select_2.3.png",
        "1130",
        "366",
        "#2e648f",
        ""
      ]
    }
  ]
}
[/block]
## 3. Enter your Project SID and Secret into OneSignal
**3.1** Login into [onesignal.com](https://onesignal.com) and select your app.
**3.2** Go to Application Settings and press Configure on Windows Phone 8.1+ (WNS). Enter your Project SID and Client Secret then press Save.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/d14e484-Screen_Shot_2017-05-16_at_7.37.34_PM.png",
        "Screen Shot 2017-05-16 at 7.37.34 PM.png",
        1397,
        861,
        "#7c868e"
      ]
    }
  ]
}
[/block]
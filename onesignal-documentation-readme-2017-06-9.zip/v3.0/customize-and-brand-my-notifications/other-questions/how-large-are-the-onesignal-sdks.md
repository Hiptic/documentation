---
title: "How large are the OneSignal SDKs?"
excerpt: ""
---
Our Native Android SDK is currently 190KB and, like most Android SDKs/Plugins, it depends on the Android Support Library v4 and Google Play services library which may add 1 to 2 MB if they are not in your project already. However, if you use Proguard on your project this size will be reduced.

Our Native iOS SDK is a 3MB download. However, if you build your app with bit code turned on, it will only add around 500KB to your app's size.

Our [Web SDK](https://cdn.onesignal.com/sdks/OneSignalSDK.js) is 55 KB minified and gzipped. It is loaded asynchronously from our worldwide CDN with a long browser-expiry.
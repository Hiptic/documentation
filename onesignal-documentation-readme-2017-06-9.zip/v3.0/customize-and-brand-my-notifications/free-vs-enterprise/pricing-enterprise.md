---
title: "Enterprise Pricing"
excerpt: ""
---
##Enterprise

In terms of the product it is the same for Enterprise and Free. Most client who choose enterprise want or need to keep their data private. We priced the Enterprise offering to be as scalable as possible and to scale along with our our costs of infrastructure which we focused on scaling from the beginning. In addition, we offer incremental fees for support, onboarding as well as discounts for annual payments. 

For our enterprise product pricing is based on tiers of total users (SDK Installs on iOS, SDK Installs on Android and Subscribed users via Web Push). 

We do have an enterprise pricing plan that start at $40 for up to 500,000 total users.

##Enterprise Pricing Tiers
[block:parameters]
{
  "data": {},
  "cols": 3,
  "rows": 1
}
[/block]

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/0f3b8ba-Screenshot_2016-12-30_12.37.59.png",
        "Screenshot 2016-12-30 12.37.59.png",
        500,
        384,
        "#eb6363"
      ]
    }
  ]
}
[/block]
[Privacy Policy Enterprise](doc:privacy-policy-enterprise) 
[Terms of Use Enterprise](doc:terms-of-use-enterprise) 

If you're still interested in our paid enterprise service please email us [sales@onesignal.com](mailto:sales@onesignal.com?subject=Enterprise) and tell a bit more about your company and/or needs when it comes to our enterprise service.
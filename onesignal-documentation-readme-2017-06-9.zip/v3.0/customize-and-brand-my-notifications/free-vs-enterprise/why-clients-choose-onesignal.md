---
title: "Why clients choose OneSignal"
excerpt: ""
---
Most clients choose to work with us because of our free or highly competitive pricing, easy to integrate open source SDKs, advanced features including APIs and world class support.

Enterprise Push across multiple platforms. Single enterprise platform to build anything the need to support their users including Localization, Full API Support & A|B Testing

Message Automation. Custom build Segments, Automated Messages, Schedule Messages in Advance and Send Messaged via our API 

Flexible Pricing. Focused on providing a world class free push platform or paid platform based on developer’s needs. Unlimited Devices, Unlimited Notifications. 

Support of all the Platforms you use. Always working on support push across all the platforms that you build apps or websites for push 

Reporting. Get real time Analytics on Message Performance. Reports on the data you need & review performance each message and across all of your applications. 

Analytics. Build custom Integrations to allow OneSignal to pass ALL push related data into your existing Analytics partner on a per user basis or via our API
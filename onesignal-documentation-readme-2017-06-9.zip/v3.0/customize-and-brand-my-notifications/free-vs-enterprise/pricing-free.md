---
title: "Free Pricing"
excerpt: ""
---
For our free product we offer unlimited push notifications to an unlimited number of users for all developers of commercial and private apps. In terms of the product feature set, there is no difference between a free and an enterprise client with regards to our push notifications service. We do however provide incremental support, consulting and a negotiated contract along with keeping their data private for our enterprise clients. 

In exchange for our free product we do monetize the data that is passed to us via the SDK to allow us to give the product away for Free. Our business model is based on using the wide distribution of our SDKs to help advertisers, ad technology companies and research companies better target, build audiences and understand mobile user behavior, similar to other services which leverage their large data footprint to monetize the data. 

To get started simply create an account with OneSignal and start using the service. Please feel free to reach out to us anytime with questions. 

[Privacy Policy Free](doc:privacy-policy-free) 
[Terms of Use Free](doc:terms-of-use-free)
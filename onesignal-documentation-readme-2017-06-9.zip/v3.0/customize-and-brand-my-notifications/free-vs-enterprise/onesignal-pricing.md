---
title: "OneSignal Pricing"
excerpt: ""
---
Our service is 100% free for an unlimited amount of users for all developers of commercial and private apps. In our product, there is no difference between a free and an enterprise client with regards to our Push Notifications service for all supported platforms including iOS, Android and Web Push.

For our Free service, our business model is based on monetizing the wide distribution of our SDK to help advertisers and research companies better understand mobile user behavior, similar to services like AppAnnie and Flurry Analytics. 

For clients who would like to pay us and not allow us to keep their the data private we offer Enterprise paid pricing based on the number of users. 
[block:parameters]
{
  "data": {
    "0-0": "Up to 500,000 Users ",
    "0-1": "$40",
    "0-2": "$80",
    "1-0": "500K - 1M Users",
    "1-1": "$75",
    "1-2": "$75",
    "2-0": "1M - 5M Users",
    "2-1": "$350",
    "2-2": "$70",
    "3-0": "5M -10M Users",
    "4-0": "10M - 20M Users",
    "5-0": "20M -40M Users",
    "6-0": "40M -100M Users",
    "7-0": "100M+ Users",
    "3-1": "$650",
    "3-2": "$65",
    "4-1": "$1,200",
    "4-2": "$60",
    "5-1": "$2,200",
    "5-2": "$55",
    "6-1": "$5,000",
    "6-2": "$50",
    "7-1": "$5000 +$45/Million",
    "7-2": "$45",
    "h-0": "Price Tiers",
    "h-1": "Monthly Price",
    "h-2": "Per Million Users"
  },
  "cols": 3,
  "rows": 8
}
[/block]

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/aab7d5a-Screenshot_2016-10-12_14.08.35.png",
        "Screenshot 2016-10-12 14.08.35.png",
        739,
        570,
        "#eb6363"
      ]
    }
  ]
}
[/block]
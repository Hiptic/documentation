---
title: "Troubleshooting Cordova Variants"
excerpt: "Common setup issues with <span class=\"label-all label-default\">PhoneGap</span>, <span class=\"label-all label-default\">Cordova</span>, <span class=\"label-all label-default\">Ionic</span>, and <span class=\"label-all label-default\">Intel XDK</span>\n<div class=\"tag-all tag-troubleshooting\">Troubleshooting</div> <div class=\"tag-all tag-developers\">For Developers</div>"
---
## Clean Build
<div class="label-all label-type"><span class="label-android">Android</span>, <span class="label-amazon">Amazon</span>, <span class="label-ios">iOS</span></div>

Cordova variants (PhoneGap CLI, Cordova, Ionic, and Intel XDK) are known to have issues with plugins not fully getting added to your project in some cases. If you see an error in LogCat or Xcode like `call to unknown plugin: OneSignalPush` or having issues seeing users on our dashboard please follow these step to do a clean build of your project:
[block:code]
{
  "codes": [
    {
      "code": "phonegap plugins list\nphonegap plugin rm onesignal-cordova-plugin\n\t+ Remove any other plugins one at a time from the list command.\nrm -rf platforms/android\nrm -rf platforms/ios\n\nphonegap platform add android\nphonegap platform add ios\nphonegap plugin add onesignal-cordova-plugin\nphonegap plugin add cordova-plugin-whitelist (# required for android)\n\t+ Add back any other plugins you had.",
      "language": "curl",
      "name": "PhoneGap"
    },
    {
      "code": "cordova plugins list\ncordova plugin rm onesignal-cordova-plugin\n\t+ Remove any other plugins one at a time from the list command.\nrm -rf platforms/android\nrm -rf platforms/ios\n\ncordova platform add android\ncordova platform add ios\ncordova plugin add onesignal-cordova-plugin\ncordova plugin add cordova-plugin-whitelist (# required for android)\n\t+ Add back any other plugins you had.",
      "language": "curl",
      "name": "Cordova"
    },
    {
      "code": "ionic plugins list\nionic plugin rm onesignal-cordova-plugin\n\t+ Remove any other plugins one at a time from the list command.\nrm -rf platforms/android\nrm -rf platforms/ios\n\nionic platform add android\nionic platform add ios\nionic plugin add onesignal-cordova-plugin\nionic plugin add cordova-plugin-whitelist (# required for android)\n\t+ Add back any other plugins you had.",
      "language": "curl",
      "name": "Ionic"
    }
  ]
}
[/block]
----

## Plugin Install Failure
<div class="label-all label-type"><span class="label-ios">iOS</span></div>

The following error will happen if CocoaPods is not installed when adding the OneSignal plugin.
```
Installing "onesignal-cordova-plugin" for iOS
        Failed to install 'onesignal-cordova-plugin': Error: pod: Command failed with exit code 31
            at ChildProcess.whenDone (/Users/vagrant/git/platforms/ios/cordova/node_modules/cordova-common/src/superspawn.js:169:23)
            at emitTwo (events.js:106:13)
            at ChildProcess.emit (events.js:194:7)
            at maybeClose (internal/child_process.js:899:16)
            at Socket.<anonymous> (internal/child_process.js:342:11)
            at emitOne (events.js:96:13)
            at Socket.emit (events.js:191:7)
            at Pipe._handle.close [as _onclose] (net.js:511:12)
        Failed to restore plugin "onesignal-cordova-plugin" from config.xml. You might need to try adding it again. Error: Error: pod: Command failed with exit code 31
```

You will need to install CocoaPods with the following commands from the terminal.

[block:code]
{
  "codes": [
    {
      "code": "sudo gem install cocoapods\npod repo update\n\ncordova plugin rm onesignal-cordova-plugin\ncordova plugin add onesignal-cordova-plugin --save",
      "language": "shell"
    }
  ]
}
[/block]
----

## Compatibility With Other Android Plugins
<div class="label-all label-type"><span class="label-android">Android</span>, <span class="label-amazon">Amazon</span></div>

If you get a compile error when building for Android about the "Android Support Library" or "Google Play services" (gms) please double check that you have both of them install show in step 3 of [PhoneGap SDK Setup](doc:phonegap-sdk-setup), [Cordova SDK Setup](doc:cordova-sdk-setup), [Ionic SDK Setup](doc:ionic-sdk-setup), [Intel XDK Setup](doc:intel-xdk-setup).

### Facebook
`com.phonegap.plugins.facebookconnect` or `phonegap-facebook-plugin` - Remove and this and use `cordova-plugin-facebook4` instead.

### Google Maps
`plugin.google.maps` - Make sure you are using version 1.2.8 of Google Map plugin or newer which is compatible with `onesignal-cordova-plugin`.

### Google Analytics
`cordova-plugin-google-analytics` - If you're using version 0.7.1 you can update to 0.8.1 to fix the build compatibility issue. If you need to stay on version 0.7.1 you can remove `onesignal-cordova-plugin` and add `onesignal-cordova-plugin-pgb-compat` instead.

`com.adobe.plugins.GAPlugin` - This plugin hasn't been updated since 2014 and conflicts with many plugins. You will need to switch a more compatible plugin such as `cordova-plugin-google-analytics`.

If you are using any other push notification plugins please remove them as having multiple push plugins can create issues like duplicate notifications and subscribing issues.

If you had to make any plugin changes above you may need to follow our [Clean Build](#section-clean-build) instructions above to get the project compiling if you're still seeing errors.

----

## PhoneGap Build (PGB) - Compatibility With Other Android Plugins
<div class="label-all label-type"><span class="label-android">Android</span>, <span class="label-amazon">Amazon</span></div>

If you're using Adobe's PhoneGap Build Cloud service to build your app and using another plugin that references "Google Play services" or the "Android Support library" (v4 or v13) you will need to remove the duplicate libraries. This includes dex errors such as `com.android.dex.DexException: Multiple dex files define Landroid/support/annotation/AnimRes;` Please check if you have any of the plugins below in your `config.xml` and follow the instructions for them below.

When using `'com.phonegap.plugins.facebookconnect'` remove the following.
[block:code]
{
  "codes": [
    {
      "code": "<gap:plugin name=\"cordova-plugin-android-support-v4\" source=\"npm\" />",
      "language": "xml"
    }
  ]
}
[/block]
When using `'com.admob.google'` remove the following 2 lines.
[block:code]
{
  "codes": [
    {
      "code": "<gap:plugin name=\"cordova-plugin-googleplayservices\" source=\"npm\" />\n<gap:plugin name=\"cordova-plugin-android-support-v4\" source=\"npm\" />",
      "language": "xml"
    }
  ]
}
[/block]
If using `'de.appplant.cordova.plugin.local-notification'` replace it with the following:
[block:code]
{
  "codes": [
    {
      "code": "<gap:plugin name=\"cordova-plugin-local-notifications\" source=\"npm\" />",
      "language": "xml"
    }
  ]
}
[/block]
If you have `com.phonegap.plugins.pushplugin` we recommend remove this as having 2 push notification providers can create issues. If you must have this plugin along side OneSignal you will to use the new `phonegap-plugin-push` plugin which replaced it.
**NOTE:** The `phonegap-plugin-push` will cause no push token issue with OneSignal on iOS so you must remove it if you need iOS support.
[block:code]
{
  "codes": [
    {
      "code": "<gap:plugin name=\"phonegap-plugin-push\" source=\"npm\" version=\"1.5.2\" />",
      "language": "xml"
    }
  ]
}
[/block]
If you are using any other push notification plugins please remove them as having multiple push plugins can create a number of issues.

If you having issues with any other plugins try find the latest version of [npmjs](https://www.npmjs.com/) as PhoneGap Build's plugin directories are deprecated and can no longer be updated by developers.

----

## Uncaught TypeError: Cannot read property 'OneSignal' of undefined
<div class="label-all label-type"><span class="label-android">Android</span>, <span class="label-amazon">Amazon</span>, <span class="label-ios">iOS</span></div>

If you're seeing this error in your `adb logcat` (Android) or Xcode log then this means `window.plugins` was currently undefined when OneSignal was used. There are a few possible causes.

1. Make sure you have installed your app on a device. You will see this error if you try to run your app in a browser.

2. `window.plugins.OneSignal` was called to soon. Double check your code with [2. Add required code](/docs/phonegap-sdk-installation#2-add-required-code) to make sure your calling OneSignal from the correct spot.

----

## Unexpected call to didRegisterForRemoteNotificationsWithDeviceToken, ignoring
<div class="label-all label-type"><span class="label-android">Android</span>, <span class="label-amazon">Amazon</span>, <span class="label-ios">iOS</span></div>

The `Unexpected call to didRegisterForRemoteNotificationsWithDeviceToken, ignoring` comes from the `phonegap-plugin-push` and is known to interfere with other push notifications plugins. Please remove it by running `cordova plugin rm phonegap-plugin-push` and OneSignal should start working in your project.


## Android - Build error - "play-services-gcm"
<div class="label-all label-type"><span class="label-android">Android</span>, <span class="label-amazon">Amazon</span></div>

```
com.google.android.gms:play-services-gcm:+ as no versions of com.google.android.gms:play-services-gcm are available.
```
Double check that **Google Repository** is installed show in [3. Android](cordova-sdk-setup#section-3-android) of our setup instructions.
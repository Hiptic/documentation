---
title: "Mismatched Push Certificate"
excerpt: "Configuration Notice - <span class=\"label-all label-ios\">iOS</span>\n<div class=\"tag-all tag-troubleshooting\">Troubleshooting</div> <div class=\"tag-all tag-developers\">For Developers</div>"
---
**Mismatched Push Certificate** is thrown when Apple returns a `BadCertificateEnvironment` error. This means your push certificate's environment does not match your environment.

## Steps to Resolve
Please <a href="" class="contact-support">contact support</a> if you receive this error.
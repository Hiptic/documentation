---
title: "Troubleshooting Android"
excerpt: "Common setup issues with <span class=\"label-all label-android\">Android</span> and <span class=\"label-all label-amazon\">Amazon</span>\n<div class=\"tag-all tag-troubleshooting\">Troubleshooting</div> <div class=\"tag-all tag-developers\">For Developers</div>"
---
## Failed to resolve: com.onesignal:OneSignal:3.+
This means that Android Studio or Gradle could not download our plugin. Please check the following.
**1.** Open your browser to http://search.maven.org/ to make sure it loads on your system.
**2.** Make sure you're using Android Studio version 1.4.0 or newer.
**3.** Go to `File` > `Settings`.
**4.** Search for Offline work and uncheck this option.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/Aqg62wLSu2cFmkFOEeVg_AndroidStuidoOfflineWork.png",
        "AndroidStuidoOfflineWork.png",
        "696",
        "432",
        "#4d6ead",
        ""
      ]
    }
  ]
}
[/block]
**4.** Add the following to your `.gradle` file.
[block:code]
{
  "codes": [
    {
      "code": "repositories {\n    mavenCentral()\n}",
      "language": "c",
      "name": "gradle"
    }
  ]
}
[/block]
**5.** Try restarting Android Studio and then going to `Tools` > `Android` > `Sync Project With Gradle Files`.

----

## Error:Execution failed for task ':app:processDebugGoogleServices'.

If you are receiving the following Android Studio error when building your project
```
Error:Execution failed for task ':app:processDebugGoogleServices'. 
> Please fix the version conflict either by updating the version of the google-services plugin (information about the latest version is available at https://bintray.com/android/android-tools/com.google.gms.google-services/) or updating the version of com.google.android.gms to 9.0.0.
```

Remove the following line from your `.gradle` file.
```
apply plugin: 'com.google.gms.google-services'
```

----

## Error:Execution failed for task ':app:processDebugManifest'
If you see the following error make sure you have completed [step 1.2](android-sdk-setup#section-1-gradle-setup) correctly.
```
Execution failed for task ':app:processDebugManifest'
Manifest merger failed with multiple errors, see logs
```
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/d5c7ab7-AndroidStudioMissingManifestEntries.png",
        "AndroidStudioMissingManifestEntries.png",
        698,
        224,
        "#376ac2"
      ]
    }
  ]
}
[/block]

----

## No Users showing on the OneSignal dashboard
Please follow our [No users on dashboard](doc:no-users-on-dashboard-after-installing-sdk) guide first.

Make sure you have your Application in your `AndroidManifest.xml` and add logging around OneSignal to make sure it is being called.
Make sure you have `android:name=".ApplicationClass"`.
[block:code]
{
  "codes": [
    {
      "code": "<application \nandroid:allowBackup=\"true\" \nandroid:icon=\"@mipmap/ic_launcher\" \nandroid:label=\"@string/app_name\" \nandroid:theme=\"@style/AppTheme\"\nandroid:name=\".ApplicationClass\">",
      "language": "xml"
    }
  ]
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "public class ApplicationClass extends Application {\n\n   @Override\n   public void onCreate() {\n      super.onCreate();\n\t\t\t\n     \tLog.d(\"OneSignalTag\", \"Before OneSignal init\");\n     \n      OneSignal.setLogLevel(OneSignal.LOG_LEVEL.VERBOSE, OneSignal.LOG_LEVEL.NONE);\n      OneSignal.startInit(this).init();\n\n      Log.d(\"OneSignalTag\", \"After OneSignal init\");\n   }\n}",
      "language": "java"
    }
  ]
}
[/block]

----

## (Missing Google Play Services Library) status on the Dashboard
1. In Android Studio open `build.gradle` (Module: app) and make sure you are using the latest OneSignal SDK under dependencies.

[block:code]
{
  "codes": [
    {
      "code": "dependencies {\n    compile 'com.onesignal:OneSignal:[3.5.3,4.0.0)'\n}",
      "language": "csharp",
      "name": "Gradle"
    }
  ]
}
[/block]
----


## How to get a crash log from an Android device
### With Android Studio
**1.** Select `Android Monitor` from the bottom of the window.
------If you don't see this select it from `View` > `Tool Windows` > `Android Monitor`
**2.** Select your device from the drop down.
**3.** Ensure no filters are set and the type is set to Verbose.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/b328c01-Android_Studio_logcat.png",
        "Android_Studio_logcat.png",
        1459,
        279,
        "#e1e3e4"
      ]
    }
  ]
}
[/block]
**4.** Select all lines in the log by pressing Control + A and then copy them.
**5.** Paste them into a `.txt` file and send this to support. Include steps to reproduce the problem as well.


### With the terminal / command line.
**1.** `adb logcat -b all -d -v threadtime > onesignal_crash_logcat.txt`
**2.** Send the `onesignal_crash_logcat.txt` to support. Include steps to reproduce the problem as well.

If you don't have `adb` in your path you will need to fully path to `adb` in the Android SDK. It is under `<android-sdk>\platform-tools\adb`.
If you don't have the Android SDK installed you can just download the [SDK Platform Tools](https://developer.android.com/studio/releases/platform-tools.html#download) which contains the `adb` executable.


----

## Eclipse - ERROR - "conversion to dalvik format failed with error 1"
If you're getting a `conversion to dalvik format failed with error 1` error with `Dx bad class file magic (cafebabe) or version (0033.0000)` messages before this then you may have the wrong Java version set on your system. See the follow post to fix this as well as the other answers.
http://stackoverflow.com/a/9041471/1244574
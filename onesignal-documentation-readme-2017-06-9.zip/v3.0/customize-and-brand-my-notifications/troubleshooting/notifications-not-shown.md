---
title: "Notifications not shown"
excerpt: "<div class=\"tag-all tag-troubleshooting\">Troubleshooting</div> <div class=\"tag-all tag-developers\">For Developers</div>"
---
The following are reasons why notifications may show as delivered on the OneSignal dashboard or API, but are not visible on your device or website:

#### The app is currently In Focus
<div class="label-type label-all"><span class="label-ios">iOS</span>, <span class="label-all label-android">Android</span>, <span class="label-amazon">Amazon</span>, <span class="label-windows">Windows Phone</span></div>

By default, notifications will not be displayed on the device if your app is currently "in focus" (open and visible). However, you can call `inFocusDisplaying` with `InAppAlert` to show notifications as alert boxes in your app, or `Notification` to display the notification.

#### The app is Force Stopped
<div class="label-type"><span class="label-all label-android">Android</span></div>

When an app is in a "Force Stopped" state most events including GCM/FCM messages for push notifications will not be received. An app can be placed in this state in the following ways.
   * From Settings > Apps, "Force Stop" is pressed.
   * Long pressing the back button on some devices.
   * Using a 3rd party task killer like Greenify.
   * App is closed on some devices due to custom Android tweaks done by the manufacturer. See the below for specific instructions to disable this.
        * Huawei - Go to Settings > "Protected apps", check your app.
        * Sony - Tap on the battery icon. Go to Power Management > STAMINA mode > Apps active in standby > Add your app.
        * Asus - Check your app in the [Auto-start Manager](https://www.asus.com/support/faq/1011266).
        * Xiaomi  - Make sure "Auto-start" property enabled for your app in the settings.
        * New Xiaomi - Settings > Developer Options. Disable "memory optimization". To enabled Developer Options go to Settings > About. Tap on MIUI 8 times.

To confirm your app state is the issue send a few notifications and check for the following GCM logcat entry.
```
W/GCM-DMM: broadcast intent callback: result=CANCELLED forIntent { act=com.google.android.c2dm.intent.RECEIVE pkg=com.onesignal.example (has extras) }
```

Some device manufactures will white list apps from going into the force closed state. Example such as Gmail and Whatsapp.

#### Action buttons or iOS 10 media are set and requirements are not meet
<div class="label-type label-all"><span class="label-ios">iOS</span></div>

The app must be not force killed and the correct settings must be enabled when these options are set.
See our [Notifications with action buttons or iOS 10 media not displaying](troubleshooting-ios#section-notifications-with-action-buttons-or-ios-10-media-not-displaying) section for a full check list.
   
#### The app has push permissions Disabled
<div class="label-type label-all"><span class="label-ios">iOS</span>, <span class="label-all label-android">Android</span></div>

<span class="label-all label-ios">iOS</span> - Check your app under Settings > Notifications.

<span class="label-all label-android">Android</span> - Check the notification setting under Settings > Apps

#### You have network issues

The network / WiFi you're connected to may have closed your connection to Apple or Google servers'. Try disabling and re-enabling your internet connection. See our [Notifications delayed](doc:notifications-delayed) troubleshooting guide for more details details.

#### The browser is Full Screen
<div class="label-type"><span class="label-all">Web Push</span></div>

Make sure the browser is not in full screen mode, which prevents web push notifications from appearing.
---
title: "Notifications are blank"
excerpt: "Notifications appear but contain nothing. For <span class=\"label-all label-android\">Android</span>.\n<div class=\"tag-all tag-troubleshooting\">Troubleshooting</div> <div class=\"tag-all tag-developers\">For Developers</div>"
---
Sometimes <span class="label-all label-android">Android</span> notifications wind up appearing blank. This is usually due to another push SDK that is intercepting the OneSignal payload and not parsing it correctly. 

Most often, plugins for Cordova variants (Phonegap, Cordova, Ionic, Intel XDK) can misbehave this way. If you are running one of these variants, check your plugins using `cordova plugin list`, remove any other plugins that are push notification related, and try again.
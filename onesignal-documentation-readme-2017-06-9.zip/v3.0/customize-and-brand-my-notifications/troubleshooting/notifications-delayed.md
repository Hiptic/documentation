---
title: "Notifications delayed"
excerpt: ""
---
Normally push notifications do arrive quite quickly. But there are some rare cases where we've seen them get delayed:

Delays for notifications on Android Devices:

1. Some home and commercial wifi routers will cause the device's connection to Google's FCM/GCM servers to be closed. The device later re-opens the connection and receives the delayed notifications. (Discussed here: https://groups.google.com/forum/#!topic/android-gcm/Y33c9ib54jY) 

2. Some custom versions of the Android OS have a power-saving setting that can cause notifications to be delayed or ignored. For instance, Sony Xperia devices have a "Stamina Mode". (Discussed here: https://talk.sonymobile.com/t5/Xperia-Z3-Compact/Notifications-not-Working-When-Phone-in-Sleep-Mode/td-p/879641)

3. Some Android devices can enter a low power mode when their battery is low that may cause slight delays in receiving notifications.

Delays for notifications on iOS devices:

1. When sending notifications to a device build with a development provisioning profile, Apple's APNS servers may sometimes be less fast or reliable. You can compare a version of your app built with an AdHoc provisioning profile and a production push certificate to see if it works better. In the near future, Apple will be changing the way this system works so this problem will go away.

2. As with Android, some wifi routers will cause iOS notification delivery delays.

3. Notifications may be delayed if "Restrict background data" is checked for the app, if Wifi-Optimization is turned on in the advanced settings, or if priority mode is enabled.

WhatsApp has a good list of instructions on troubleshooting delayed Android and iOS notification at the bottom of their FAQ page here: https://www.whatsapp.com/faq/en/android/20887936
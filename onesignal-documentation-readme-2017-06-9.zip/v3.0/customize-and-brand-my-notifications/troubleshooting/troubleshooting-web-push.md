---
title: "Troubleshooting Web Push"
excerpt: "Common setup issues with <span class=\"label-all label-webpush\">Web Push</span> (<span class=\"label-all label-chrome\">Chrome</span>, <span class=\"label-all label-firefox\">Firefox</span>, <span class=\"label-all label-safari\">Safari</span>)\n<div class=\"tag-all tag-troubleshooting\">Troubleshooting</div> <div class=\"tag-all tag-developers\">For Developers</div>"
---
## My site isn't working in WordPress
<div class="label-all label-type"><span class="label-wordpress">WordPress</span></div>

1. In the Configuration tab of our WordPress plugin, did you set the Subdomain to be the value you chose on our dashboard platform setting? See WordPress Setup Guide > Chrome & Firefox Push > Step 8.

2. Did you manually add our JavaScript web SDK to your site? Our WordPress plugin provides all the necessary code; please make sure you're not including our SDK twice, or initializating OneSignal twice.

## My site isn't working in Firefox
<div class="label-all label-type"><span class="label-firefox">Firefox</span></div>

1. Make sure you are using Firefox v44+.

2. Make sure you are not using Firefox's Private Browsing mode. Notifications do not work in this mode.

3. Please [visit this webpage](https://jsfiddle.net/hpj0q3ax/11/) and let us know if you see any `Supported: false` or `Errors`.
[block:callout]
{
  "type": "warning",
  "title": "Still having trouble?",
  "body": "If you're still having trouble, please send us the debug logs from our SDK by [following steps 1 and 2 here](doc:troubleshooting-web-push#section-debugging-using-browser-developer-tools)."
}
[/block]
----

## My site isn't working in Chrome
<div class="label-all label-type"><span class="label-chrome">Chrome</span></div>

**Chrome on Android Users:** See the section right below this.

1. Make sure you are using a modern version of Chrome. We recommend Chrome v48+, though Chrome v42+ is supported.

2. Make sure you are not browsing in **Incognito mode** or **Guest browsing mode**. Notifications are disabled in Incognito mode, and Guest browsing mode is the same as Incognito mode.

3. Make sure you are not using Chrome in full screen mode. In full screen mode, [Chrome hides notifications](https://bugs.chromium.org/p/chromium/issues/detail?id=583746). 
[block:callout]
{
  "type": "warning",
  "body": "If you're still having trouble, please send us the debug logs from our SDK by [following steps 1 and 2 here](doc:troubleshooting-web-push#section-debugging-using-browser-developer-tools).",
  "title": "Still having trouble?"
}
[/block]
----

## My site isn't working on my mobile phone (Chrome on Android)
<div class="label-all label-type"><span class="label-android">Android</span></div>

<span class="label-all label-ios">iOS</span> - web push does **not** work on iOS devices (iPhone and iPads) because Safari for iOS does not support web push notifications. Apple only supports native app notifications at this time. [Read more here](https://onesignal.com/blog/when-will-web-push-be-supported-in-ios/) 

<span class="label-all label-android">Android</span> - To get push notifications, please make sure you are running Chrome on Android, and:
- The version is v42+
- You are **not** in Incognito / Private Browsing mode
- You have notifications enabled. 

To check whether notifications are enabled in Chrome on Android, tap the 3-dot menu --> Settings --> Site settings (under Advanced) --> Notifications, and make sure it's set to *"Ask before sending (recommended)"*. On the same menu, go to *"All sites"*, find your site and make sure notifications aren't blocked.
[block:callout]
{
  "type": "success",
  "body": "Done! Your site should be working again."
}
[/block]
----

## My HTTPS site isn't working
**Note**: *We print helpful error messages on the Developer Tools Console*. To open the Developer Tools Console, right click on the page, click *Inspect*, and click the *Console* tab. Usually we print the direct cause of the error on the console and a link to the solution.
<ol><li><p>Make sure you are using a supported browser. [iOS web push is not supported](https://onesignal.com/blog/when-will-web-push-be-supported-in-ios/). Microsoft Edge, Internet Explorer, Safari 5.1 on Windows is not supported.</p></li><li><p>Make sure you are not using Private Browsing mode / Incognito mode, and make sure your Chrome browser is not full screen (this hides notifications).</p></li><li><p>Make sure the following URLs are publicly accessible:</p>
<p>`https://site.com/manifest.json`
`https://site.com/OneSignalSDKWorker.js`
`https://site.com/OneSignalSDKUpdaterWorker.js`</p>
<p>If they are not accessible, please [follow Step 2 of our guide again](doc:web-push-sdk-setup-https#section-2-upload-required-files).</p></li>
<li><p>Copy the contents of your `https://site.com/manifest.json`. Visit [jsonlint.com](http://pro.jsonlint.com) and paste the contents in. Click the Checkbox to validate. Make sure it passes. If it does not pass, try to follow the instructions to fix the error. Usually the errors are:
- Missing comma at the end of the line (except last line)
- Missing quotes around text
- Using curly smart quotes instead of plain text quotes</p></li>
<li><p>Make sure the contents of your `https://site.com/manifest.json` has a gcm_sender_id value with *numbers only*.</p></li>
<li><p>Make sure `OneSignalSDKWorker.js` and `OneSignalSDKUpdaterWorker.js` are being served from the same domain of your site. It cannot be served by a CDN or a domain other than the domain the visitor is currently on.</p></li>
<li><p>Make sure `OneSignalSDKWorker.js` and `OneSignalSDKUpdaterWorker.js` are not being served by a redirect. This is not allowed due to browser restrictions. The file must be served directly.</p></li>
</ol>
[block:callout]
{
  "type": "success",
  "body": "Done! Notifications on your HTTPS site should now be working."
}
[/block]
----

## My HTTP site isn't working
**Note**: *We print helpful error messages on the Developer Tools Console*. To open the Developer Tools Console, right click on the page, click *Inspect*, and click the *Console* tab. Usually we print the direct cause of the error on the console and a link to the solution.

1. Make sure you are using a supported browser. [iOS web push is not supported](https://onesignal.com/blog/when-will-web-push-be-supported-in-ios/). Microsoft Edge, Internet Explorer, Safari 5.1 on Windows is not supported.

2. Make sure you are not using Private Browsing mode / Incognito mode, and make sure your Chrome browser is not full screen (this hides notifications).

3. Make sure you've set a **subdomainName** field in our init settings. Make sure the value for **subdomainName** [matches this value on your Chrome platform settings](https://i.imgur.com/0Dn3EDS.png).

4. Make sure [your Site URL is correct](https://i.imgur.com/qpfF8fQ.png). Do not combine `*` with your domain. You may use either `*` or use a valid URL.

[block:callout]
{
  "type": "success",
  "body": "Notifications on your HTTP site should now be working!"
}
[/block]
----

## My WordPress site isn't working

### HTTP Site Users
Make sure the *Choose Subdomain* value on our dashboard's platform settings matches the *Subdomain* textbox in our WordPress plugin Configuration tab.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/1ef3b00-Screen_Shot_2017-05-16_at_6.46.12_PM.png",
        "Screen Shot 2017-05-16 at 6.46.12 PM.png",
        990,
        671,
        "#8896a3"
      ]
    }
  ]
}
[/block]

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/6a127af-Screen_Shot_2017-05-16_at_6.50.50_PM.png",
        "Screen Shot 2017-05-16 at 6.50.50 PM.png",
        906,
        480,
        "#e6cbc9"
      ]
    }
  ]
}
[/block]
Make sure the beginning of the *Site URL* value on our dashboard's platform settings is the same as the URL you're using to access your site. If the *Site URL* is `http://example.com`, then you must access your site from `http://example.com`.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/4b9cd25-Screen_Shot_2017-05-16_at_6.52.49_PM.png",
        "Screen Shot 2017-05-16 at 6.52.49 PM.png",
        1036,
        657,
        "#8796a4"
      ]
    }
  ]
}
[/block]

[block:callout]
{
  "type": "success",
  "body": "Notifications on your Wordpress site should now be working!"
}
[/block]
----

## Clearing your cache and resetting push permissions
Even if your settings are configured correctly, if you had previously used incorrect settings, push notifications may not work due to invalid permission or background worker states. These steps will reset your site's notification permissions, clear your site's storage, and remove our background worker.

### Chrome (Desktop)
<div class="label-all label-type"><span class="label-chrome">Chrome</span></div>

1. Click the icon next your site. On the *Permissions* tab, if you see a *Permissions* section, make sure *Notifications* says *Use global default (Ask)*. If you don't see any *Permissions* section, you have no saved permissions -- move on to the next step.

<img src="https://files.readme.io/FxAvQEwrSuGU5my71lRL_chrome-unblock.jpg" style="max-width:438px"/>

2. *Clear site data* - On this same panel click "Show cookies and site data" (Windows) or "# from this site" (Mac). Select all the entries at once and click "Remove". No entries should be left.

<img src="https://files.readme.io/iOtkjFtiQcO3PloVRoei_chrome-reset-2.jpg"/>
<img src="https://files.readme.io/OhDjHTCGRNipIGc4ughb_chrome-reset-3.jpg"/>

3. **If your site is HTTP** visit `https://yoursubdomain.onesignal.com` and **repeat steps 1 - 2 for this subdomain URL**. Replace `yoursubdomain` with the value set in your init() call subdomainName or, if you use our WordPress plugin, with the value set in the Subdomain field.

4. Close tabs and windows pointing to your domain or https://yoursubdomain.onesignal.com. This is actually an important step -- don't skip it!
[block:callout]
{
  "type": "warning",
  "body": "Clearing cookies prevents web storage from working on your site until *all tabs/windows* to your site are closed, or until your browser is restarted.\n\n**This is important -- don't skip it!**",
  "title": "Restart your browser or close tabs to your site"
}
[/block]

5. Visit [chrome://serviceworker-internals/](chrome://serviceworker-internals/) in a new tab and press the 'Stop' and 'Unregister' buttons under any Scopes that contain yoursite.domain or https://yoursubdomain.onesignal.com. If they won't remove, make sure all tabs or windows pointing to either domain are closed.</p>
<img src="https://files.readme.io/66CdwknESjeKzX6E2Iim_chrome-reset-4.jpg"/>
[block:callout]
{
  "type": "success",
  "body": "Done! Open a *new* tab to your site and try it out!"
}
[/block]
### Chrome (Android)
<div class="label-all label-type"><span class="label-android">Android</span></div>

If you still have a notification *from your site* visible in your notification drawer: 

<ol><li><p>Click the gear icon and 'Site Settings'.</p>
<p><img src="https://files.readme.io/MDW3i3T4iktcqQ4APO2w_android-reset-1.jpg" style="max-width:500px;"></p></li><li><p>Click 'Clear & Reset'.</p>
<p><img src="https://files.readme.io/ze8bkPtQKuCY1Ge7fpoW_android-reset-2.jpg" style="max-width:500px"/></p></li></ol>

If you do not have a notification open, open Chrome on Android, tap the 3-dot menu, Settings, Site settings (under Advanced), Notifications, make sure it's set to *"Ask before sending (recommended)"*. Find your site on the list, click the entry, and click Clear and Reset.
[block:callout]
{
  "type": "success",
  "body": "Done! Open a *new* tab to your site and try it out!"
}
[/block]
### Firefox (Desktop)
<div class="label-all label-type"><span class="label-firefox">Firefox</span></div>

<ol><li><p>Click the icon next to your site.</p></li><li><p>Reset your notification permissions from *Allow* to *Always Ask*.</p>
<p><img src="https://files.readme.io/wdFBkbyDTU2WQNp5qE4M_firefox-reset-1.jpg" style="max-width:500px;"></p></li>
<li><p>On the same dialog, click the **>** button and then click **More Information**.</p>
<p><img src="https://files.readme.io/1qXIAtlRdqHXuuMklwSP_firefox-reset-2.jpg" style="max-width:500px"/></p>
<p><img src="https://files.readme.io/W0GyF4MESpLqolALoMIg_firefox-reset-3.jpg" style="max-width:500px"/></p></li>
<li><p>On the popup dialog that opens, click the *Permissions* tab, find the *Maintain Offline Storage* section, and click *Clear Storage*.</p>
<p><img src="https://files.readme.io/O8U7hwNsScuLBRi8vSV1_firefox-reset-4.jpg" style="max-width:500px"/></p></li></ol>

### Firefox (Android)

[Please follow this Firefox guide to clear all your browser data.](https://support.mozilla.org/en-US/kb/clear-your-browsing-history-and-other-personal-data#w_clear-specific-items-from-your-browser)

### Safari (Mac OS X Desktop)
<div class="label-all label-type"><span class="label-safari">Safari</span></div>

On the top menu bar, go to **Safari -> Preferences -> Notifications** and remove your site's entry. Then in the same preferences dialog, go to the **Privacy** tab and click **Clear Website Data**.
[block:callout]
{
  "type": "success",
  "body": "Done! Just refresh your site."
}
[/block]
----

## WordPress CDN Support
Using caching plugins with CDN support can cause files required to be served from your domain to be served from the CDN instead. Here's how to use the appropriate settings:

### WP Super Cache

1. Log in to your WordPress admin panel and visit **Settings > WP Super Cache**.

2. Click the **CDN** tab.

3. Make sure the **Exclude if substring** tab has *at least* the following contents: `.php, onesignal-free-web-push-notifications`. You can have more than this, but you must have at least these two entries.

4. Click the **Contents** tab.

5. Click the **Delete Cache** button.

6. The required files should now be served from your domain. Refresh your site page.

### WP Engine

You'll have to contact WP Engine. Here's a support ticket you can use:

> Hi!

> My site runs the OneSignal web push notifications plugin and we are having some issues with WPEngine serving certain files over its CDN. The OneSignal plugin team would like to request a CDN exception on URLs including the string "onesignal-free-web-push-notifications".

> Could you please add the above string to the exception list?

> Thanks!

### W3 Total Cache

1. Log in to your WordPress admin panel and click **Performance** on the left sidebar.

2. Click the **CDN** tab.

3. Find the textbox for "Rejected files".

4. Add an entry for `{plugins_dir}/onesignal-free-web-push-notifications/sdk_files/*`

4. Click Save all settings.

### CDN Enabler

1. Log in to your WordPress admin panel and click **Settings** -> **CDN Enabler** on the left sidebar.

2. Find the "Exclusions" textbox.

4. Add "onesignal-free-web-push-notifications". 

    Your textbox might look like ".php,onesignal-free-web-push-notifications".

5. Click *Save Changes*.
[block:callout]
{
  "type": "success",
  "body": "The required files should now be served from your domain! Just refresh your site page."
}
[/block]
----

## My Safari notification icons aren't showing up
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/TrAa5S1fR3mxCSy5meQw_jhPaLmF.png",
        "jhPaLmF.png",
        "801",
        "521",
        "#d44b4d",
        ""
      ]
    }
  ]
}
[/block]
If you uploaded your own Safari notification icons but they aren't showing up on your site, it's probably because *for each visitor, the Safari icons set at the time the permission prompt is shown for the visitor are the icons the visitor will see*. When the permission prompt is shown, the icons are downloaded locally to your system. Unless the permission is revoked, your visitor will not see your updated icon set.

To see your updated icon set, simply remove notification permissions for your Safari site. On Safari's top menu bar, go to **Safari -> Preferences -> Notifications** and remove your site's entry. Then visit your site again and subscribe to notifications. The moment you see the permission prompt, the new icons will be downloaded to your system and you should see them right away on the permission prompt.

----

## Debugging using Browser Developer Tools

The browser's developer tools can be used to interact with the web SDK on your webpage and enable logging or easily send test notifications to yourself.

### 1. Access the Browser Developer Tools Console
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/M6r7mvTPT7W1USDDy5Wz_console.png",
        "console.png",
        "1510",
        "598",
        "#dd6861",
        ""
      ],
      "border": true
    }
  ]
}
[/block]
<span class="label-all label-chrome">Chrome</span> - Right click on the page, click *Inspect*, and click the *Console* tab of the popup window that opens up.

<span class="label-all label-firefox">Firefox</span> - Right click on the page, click *Inspect element*, and click the *Console* tab of the popup window that opens up.

<span class="label-all label-safari">Safari</span> - Go to **Safari -> Preferences -> Advanced** and make sure *Show Develop menu in menu bar* is checked. Then, on your webpage, right click, click *Inspect element*, and click the *Console* tab of the popup window that opens up.

<span class="label-all label-android">Chrome on Android</span> - Debugging on Chrome on Android is more complicated, and requires a USB cable to connect your Android phone to your computer. Please [follow this guide](https://developer.chrome.com/devtools/docs/remote-debugging) to remotely access your mobile Chrome's Developer Tools console.

<span class="label-all label-android">Firefox on Android</span> - Debugging on Firefox on Android is more complicated, and requires a USB cable to connect your Android phone to your computer. Please [follow this guide](https://developer.mozilla.org/en-US/docs/Tools/Remote_Debugging/Debugging_Firefox_for_Android_with_WebIDE) to remotely access your mobile Firefox's Developer Tools console.

### 2. Enable web SDK logging

You should be able to run commands in the developer tools Console now.

Execute the following code:

`OneSignal.log.setLevel('trace');`

You should see `undefined` as the result.

If you see:

`Uncaught ReferenceError: OneSignal is not defined(…)` or `ReferenceError: OneSignal is not defined`, then OneSignal is not active on your webpage, or you need to switch to the `top` frame context (see above screenshot at the beginning of this section).

Now that our web SDK's debug logging is enabled, please close the tab and open a new tab to the same page (refreshing the page is not enough to trigger some of our SDK events). You should see a lot of output in the Console.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/PTU11ly5R0quyNQDYeb8_consoleLog1.png",
        "consoleLog1.png",
        "2880",
        "1214",
        "#3e4191",
        ""
      ]
    }
  ]
}
[/block]
### 3. Check if you are subscribed

Run in the Console:

```
function isPushNotificationsEnabledVerbose() {
    console.log('isPushNotificationsEnabledVerbose()');
    Promise.all([
            OneSignal.isPushNotificationsEnabled(),
            OneSignal.getUserId(),
            OneSignal.getRegistrationId(),
            OneSignal.getNotificationPermission(),
            OneSignal.isOptedOut(),
            OneSignal.isServiceWorkerActive()
        ])
        .then(([isSubscribed, userId, registrationId, notificationPermission, optedOut, serviceWorkerActive]) => {
            console.log('Is Completely Subscribed:', isSubscribed);
            console.log('');
            console.log('What is our OneSignal user ID?', userId);
            console.log('What is our push subscription token?', registrationId);
            console.log('What is the notification permission status?', notificationPermission);
            console.log('Are you manually opted out?', optedOut);
            console.log('Is a service worker registered and active? (should be false on Safari)', serviceWorkerActive);
            console.log('What is the current URL of this page?', location.href);
            console.log("What environment does OneSignal think it's in?", OneSignal.environment.getEnv());
        })
        .catch(e => {
            log.error("Issue determining whether push is enabled:", e);
            reject(e);
        });
}
isPushNotificationsEnabledVerbose();
```

Depending on whether you are subscribed, you should see:

```
Is Completely Subscribed: true

What is our OneSignal user ID? b7b14773-e053-44b6-8eee-1a8fe58c53ba
What is our push subscription token? fwJQA8TYCTk:APA91bFbQyYR9kVvgmxHGV7fKr7sktzh4v2fEXad2KRlqq_zupfUexqbPscpcQ4Iru3IAOQ9sIrrt1TtlUySK1Jy2Vg7lzwpGHCRLBqa-er2cuQ6T79AG9l4MWKrwTfehWcBTDj_BdGD
What is the notification permission status? granted
Are you manually opted out? false
Is a service worker registered and active? true
What is the current URL of this page? https://example.com
What environment does OneSignal think it's in? host
```

### 4. Send yourself a test notification

*Only if you are subscribed* (see above section), you can send yourself a test notification. This notification *will only go to you* and your other users will not receive this notification. In the console, run:

`OneSignal.sendSelfNotification()`

You should see something similar to `Promise {[[PromiseStatus]]: "pending", [[PromiseValue]]: undefined}`, and you should receive a web push notification shortly after. Make sure you aren't using Private Browsing Mode / Incognito mode on Chrome or Chrome's full screen mode as this can hide and disable notifications.

## Debugging not receiving Chrome notifications

**Note:** Please complete these steps in order.

1. Please see [My site isn't working in Chrome](#section-my-site-isn-t-working-in-chrome). You can't receive notifications in full screen mode, for example.

2. Please follow steps 1 - 4 in the section [Debugging using Browser Developer Tools](#section-debugging-using-browser-developer-tools) to try receiving a test notification.

    - For step #3, are you subscribed? If not, stop here, [completely clear your site data following these specific instructions](#section-clearing-your-cache-and-resetting-push-permissions), and then re-subscribe to your site in order to receive notifications. Run step #3 again after to verify you're actually subscribed. When following the clear site data instructions, please do remember to close all tabs to your site or restart your browser, since Chrome prevents the site's storage from being accessed until all existing tabs to your site are closed.
    
    - For step #4, do you receive a test notification? If you do, you're done!

3. If you're subscribed but you did not receive a test notification, please visit your OneSignal dashboard, visit the Sent Messages page, and click "Viewing: API Notifications" to view the test notifications you've sent yourself. Are they colored red (Invalid)? If they are colored red and Invalid, your web push keys are most likely mismatched. Please let us know on support about this.

4. If you're subscribed, did not receive a test notification, but you see the message has been delivered (colored green), please open Chrome to chrome://gcm-internals. Click the "Start Recording" button on the top left. Follow step #4 above to send yourself a test notification. Do you see a "Data msg received" like in the below screenshot (make sure to click "Start Recording" first)?

    - If you don't see a "Data msg received", then your Chrome browser is not receiving the notification at all. Please let us know on support about this.

    - If you see "Data msg received" but you still didn't receive a notification, proceed to step #5.

<p><img src="https://i.imgur.com/UYq90xD.png"></p>

5. Visit chrome://serviceworker-internals. If your site is an HTTPS site like https://example.com, search for *Scope: https://site.com*. If your site is an HTTP site using our popup subscription workaround, search for *Scope: https://subdomain.onesignal.com* where *subdomain* is the value you chose on your Chrome platform settings when you configured Chrome for the first time.

    Click *Inspect*, or *Start -> Inspect*, like below. A Chrome Developer Tools popup will appear.

<p><img src="https://i.imgur.com/krYNyip.png"></p>

6. On the Chrome Developer Tools popup to our service worker, click the *Console* tab, and run `OneSignalWorker.log.setLevel('trace');`. It should return `undefined`. Any messages from our service worker should now appear in this pop

7. Switch away from the worker's Dev Tools popup, and back to your main page's Developer Tools console (where you followed step 2). Please send yourself another test notification. You should a lot of output here with an error since you did not see the notification. Please on support about this error. You can right click on the Console -> Save as ... and copy the file contents to our chat support.
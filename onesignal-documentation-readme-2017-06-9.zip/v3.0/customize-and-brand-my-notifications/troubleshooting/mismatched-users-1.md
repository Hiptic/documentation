---
title: "Mismatched Users"
excerpt: "Configuration Notice - <span class=\"label-all label-android\">Android</span>, <span class=\"label-all label-webpush\">Web Push</span> (<span class=\"label-all label-chrome\">Chrome</span>, <span class=\"label-all label-firefox\">Firefox</span>)\n<div class=\"tag-all tag-troubleshooting\">Troubleshooting</div> <div class=\"tag-all tag-developers\">For Developers</div>"
---
**Mismatched Users** is thrown when Google returns a `MismatchSenderId` error. This is because some users' GCM/FCM registration tokens are tied to a Google Server API key that do not match their current project's Google Server API key.

## Steps to Resolve
### Android
When you configured your Google Project in the Google's Developer Console, you received a Project Number and a Server API Key. Our Android setup instructions ask you to put the Project Number in your Android project, and the Server API Key on our dashboard platform config.

Please make sure the Project Number in your Android project or app's code matches the Server API Key on our dashboard platform config *from the same Google project*.

Please make sure the Server API key on our dashboard's Android platform settings matches the Server API key in your Google project.

If you're using another SDK that uses push notifications, make sure the same Google Project Number is used both in our SDK and the other SDKs.

### HTTPS Sites
<div class="label-all label-type"><span class="label-all label-webpush">Web Push</span> (<span class="label-all label-chrome">Chrome</span>, <span class="label-all label-firefox">Firefox</span>)</div>

When you configured your Google Project in the Google's Developer Console, you received a Project Number and a Server API Key. Our website setup instructions ask you to put the Project Number in your `manifest.json` file, and the Server API Key on our dashboard platform config. 

When a visitor subscribes to push notifications on your website, the Project Number on your website and the Server API Key on our dashboard platform config is tied to a generated token. This token is linked to the Project Number and Server API Key at the time the user registers.

If, at the time the user registered, the Project Number and Server API Key do not match from the same Google Project, the user is marked as having a MismatchSenderId error.

This could be because you're using a Project Number from Google Project A while using the Server API Key from Google Project B.

Please review our setup instructions to make sure your Project Number and Server API Key are from the same Google Project and are correct in your configuration.

### HTTP Sites
<div class="label-all label-type"><span class="label-all label-webpush">Web Push</span> (<span class="label-all label-chrome">Chrome</span>, <span class="label-all label-firefox">Firefox</span>)</div>

When you configured your Google Project in the Google's Developer Console, you received a Project Number and a Server API Key. Our website setup instructions ask you to put the Project Number and Server API Key on our dashboard platform config. Modifying these dashboard platform config options are no longer possible; please <a href="" class="contact-support">contact support</a> to ask us for assistance.

The mismatched sender ID means that the Project Number does not match the Server API Key. This could be because you're using a Project Number from Google Project A while using the Server API Key from Google Project B. Once you set your Project Number and Server API Key, they should not be changed as your subscribed users are tied to both of these (changing any one of them causes this error). 

Please review our setup instructions to make sure your Project Number and Server API Key are from the same Google Project. Modifying these dashboard platform config options are no longer possible; please <a href="" class="contact-support">contact support</a> to ask us for assistance.
---
title: "\"Unreachable\" Devices"
excerpt: ""
---
When sending a notification, some number of devices will be "Unreachable".

In the case of mobile app notifications, Unreachable means that the device was once subscribed to notifications, but has now either uninstalled your application or opted-out of notifications.

In the case of web push, Unreachable means that the user has cleared their browser cookies or has opted-out of notifications from your website.

A device must receive at least two notifications to be detected as unreachable. The first notification will appear to have been successfully delivered. The device must be turned on and online to silently reject this first notification. After this, future notifications will then return an Unreachable error.

Once a device has been detected as unreachable, it will be marked as unsubscribed and future notifications will not be sent to it unless it re-subscribes to notifications again in the future.
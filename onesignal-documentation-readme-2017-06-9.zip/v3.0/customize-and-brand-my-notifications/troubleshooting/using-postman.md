---
title: "Using Postman"
excerpt: "How to use postman for Server REST API testing\n<div class=\"tag-all tag-developers\">For Developers</div>"
---
You can also use [Postman](https://www.getpostman.com) to work with our [Server REST API](ref:create-notification). Follow the screenshots below to see how to use Postman for our [Create notification API endpoint](ref:create-notification).

# Create notification

### 1. Select POST 
add: 
`https://onesignal.com/api/v1/notifications`

### 2. Create the Headers
Line 1 key: `Authorization`   value: `Basic ONESIGNAL_REST_API_KEY`
***Replace ONESIGNAL_REST_API_KEY with the value found in your OneSignal Dashboard > App Settings > Keys & IDs***

Line 2 key: `Content-Type`   value: `application/json`
***You MUST use this value with postman for our API.***
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/fKb06zZaQgW3AtnQqXUX_PostmanExample2.png",
        "PostmanExample2.png",
        "838",
        "220",
        "#1b96cc",
        ""
      ]
    }
  ]
}
[/block]
### 3. Add the Body
select `raw`
add your JSON
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/AWhI22Y7T8O4YUmgZba2_PostmanExample1.png",
        "PostmanExample1.png",
        "604",
        "208",
        "#485492",
        ""
      ]
    }
  ]
}
[/block]
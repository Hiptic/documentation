---
title: "How fast are notifications delivered?"
excerpt: ""
---
OneSignal delivers notifications at a rate of approximately 5,000 per second (300,000 per minute) per app per platform to FMC/GCM (Android and Chrome), APNS (iOS, MacOS and Safari Desktop), Mozilla and Opera at up to 200,000 per second (12 million per minute) across all of our clients. We send over 350M notifcations across all platforms daily. OneSignal also avoids delivering notifications to devices that are detected as having uninstalled your app or opted-out of notifications.

This delivery speed is based on per-application throughput limitations on each notification gateway (Google and Apple’s notification systems etc) along with a small amount of overhead on our side in order to provide accurate statistics and targeting capabilities.

You can learn about the technical details of our [fast delivery backend here](https://onesignal.com/blog/announcing-our-new-delivery-backend/) -- This system is now used for iOS, Android, and Web Push platforms.

Based on feedback from our clients, we are not aware of any vendors that send notifications at a faster rate than this while also being able to provide segmentation and analytics.
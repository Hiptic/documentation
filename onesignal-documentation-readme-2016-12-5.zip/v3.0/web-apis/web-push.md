---
title: "Web Push"
excerpt: "OneSignal Web Push API Reference. Works with <span class=\"label-all label-chrome\">Chrome</span>, <span class=\"label-all label-firefox\">Firefox</span> and <span class=\"label-all label-safari\">Safari</span>. \n<div class=\"tag-all tag-developers\">For Developers</div> <div class=\"tag-all tag-advanced\">Advanced Topic</div>"
---
[block:callout]
{
  "type": "warning",
  "title": "Advanced Topic",
  "body": "Most developers would be best served by going through our [Web Push SDK](docs:web-push-sdk) first, which is a more user-friendly starting point than the API."
}
[/block]

[block:parameters]
{
  "data": {
    "0-0": "### Initialization",
    "0-1": "",
    "h-2": "",
    "0-2": "",
    "h-0": "",
    "1-0": "[async](#section- -async-)",
    "1-1": "Javascript Flag",
    "1-2": "Loading asynchronously",
    "5-0": "### Registering Push",
    "6-0": "[registerForPushNotifications](#registerForPushNotifications)",
    "11-0": "### User IDs",
    "12-0": "[getUserId](#getUserId)",
    "12-1": "Function",
    "12-2": "Get the User ID of the device",
    "13-0": "[getRegistrationId](#getRegistrationId)",
    "13-1": "Function",
    "13-2": "",
    "14-0": "### Tags",
    "15-0": "[getTags](#section- -gettags-)",
    "15-1": "Function",
    "18-1": "Function",
    "19-1": "Function",
    "20-1": "Function",
    "15-2": "View Tags from a User",
    "18-2": "",
    "20-2": "",
    "19-2": "Delete a Tag from a User",
    "18-0": "[sendTags](#section- -sendtags-)",
    "19-0": "[deleteTag](#section- -deletetag-)",
    "20-0": "[deleteTags](#section- -deletetags-)",
    "21-0": "### Data",
    "23-0": "### Sending Notifications",
    "28-0": "### Receiving Notifications",
    "24-0": "[Create Notification](#section-createnotification)",
    "26-0": "[setSubscription](#section- -setsubscription-)",
    "26-1": "Function",
    "24-1": "REST API",
    "31-0": "[addListenerForNotificationOpened](#addListenerForNotificationOpened)",
    "31-1": "Function",
    "22-1": "Coming Soon",
    "22-0": "[syncHashedEmail](#section- -synchashedemail-)",
    "22-2": "Sync Anonymized User Email",
    "24-2": "Send or schedule a notification to a user",
    "26-2": "Opt users in or out of receiving notifications",
    "31-2": "When a user takes an action on a notification",
    "17-0": "[sendTag](#section- -sendtag-)",
    "17-1": "Function",
    "17-2": "Add a Tag to a User",
    "32-0": "[notificationOpenedCallBack](#notificationOpenedCallBack)",
    "32-1": "Callback",
    "32-2": "",
    "6-2": "Prompt Users to Enable Notifications",
    "16-0": "[tagsReceivedCallBack](#tagsReceivedCallBack)",
    "16-1": "Callback",
    "25-0": "[sendSelfNotification](#sendSelfNotification)",
    "25-1": "Function",
    "3-0": "[setDefaultNotificationUrl](#setDefaultNotificationUrl)",
    "4-0": "[setDefaultTitle](#setDefaultTitle)",
    "3-1": "Function",
    "4-1": "Function",
    "3-2": "",
    "2-0": "[init](#section- -init-)",
    "2-1": "Function",
    "2-2": "Initialize OneSignal",
    "7-0": "[showHttpPrompt](#showHttpPrompt)",
    "8-0": "[getNotificationPermission](#getNotificationPermission)",
    "9-0": "[isPushNotificationsSupported](#isPushNotificationsSupported)",
    "10-0": "[isPushNotificationsEnabled](#isPushNotificationsEnabled)",
    "10-2": "Determine whether user has notifications enabled",
    "10-1": "Function",
    "9-1": "Function",
    "8-1": "Function",
    "7-1": "Function",
    "6-1": "Function",
    "25-2": "Send notification to local browser",
    "27-0": "[Subscription Change](#subscriptionChangeEvent)",
    "27-1": "Event",
    "29-0": "[Notification Display](#notificationDisplayEvent)",
    "29-1": "Event",
    "30-0": "[Notification Dismiss](#notificationDismissEvent)",
    "30-1": "Event"
  },
  "cols": 3,
  "rows": 33
}
[/block]
## Initialization

### Loading SDK Asynchronously
<div class="label-all label-type">Javascript flag - <span class="label-recommended">recommended</span></div>

OneSignal supports loading `OneSignalSDK.js` with the `async` flag so your page load times don't increase. To use it, place the following code *before* calling any other OneSignal functions.
[block:code]
{
  "codes": [
    {
      "code": "<script src=\"https://cdn.onesignal.com/sdks/OneSignalSDK.js\" async></script>\n<script>var OneSignal = OneSignal || [];</script>",
      "language": "html"
    }
  ]
}
[/block]
Our API functions can be called asynchronously using either:

1. `OneSignal.push(["functionName", param1, param2]);`
2. `OneSignal.push(function() { OneSignal.functionName(param1, param2); });`

Option 2 must be used for functions that return a value like `isPushNotificationsSupported`. Option 2 also lets you call as many OneSignal functions as you need inside the passed-in function block.


### `init`
<div class="label-all label-type">Function</div>

Call this from each page of your site to initialize OneSignal.

Notes:
- Do not call this method twice. Doing so results in an error.
- This call is required before any other function can be used.

Init JSON `options` are as follows:
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`appId`",
    "1-0": "`subdomainName`",
    "2-0": "`autoRegister`",
    "3-0": "`path`",
    "4-0": "`promptOptions`",
    "0-1": "String",
    "1-1": "String",
    "2-1": "Boolean",
    "3-1": "String",
    "4-1": "JSON",
    "0-2": "<span class=\"label-all label-required\">Required</span> Your OneSignal app id found on the settings page at onesignal.com.",
    "1-2": "<span class=\"label-all label-required\">Required for HTTP</span> This must match the Subdomain you entered on the Web Push settings on the OneSignal dashboard.",
    "2-2": "(HTTPS only) Default `true`. Automatically show browser prompt to accept notifications. You can pass in false to delay this pop-up and then call `registerForPushNotifications` to prompt them later.",
    "3-2": "<span class=\"label-all label-notrec\">Special Case</span> (HTTPS only) Absolute path to OneSignal SDK web worker files. You only need to set this parameter if you do not want the files at the root of your site.",
    "4-2": "Localize the HTTP popup prompt. See below.",
    "5-0": "`welcomeNotification`",
    "5-1": "JSON",
    "5-2": "Customize or disable the welcome notification sent to new site visitors. See below.",
    "6-0": "`notifyButton`",
    "6-1": "JSON",
    "6-2": "Enable and customize the notifyButton. See below.",
    "7-0": "`persistNotification`",
    "7-1": "Boolean",
    "7-2": "<span class=\"label-all label-chrome\">Chrome</span> - Applies only on Chrome Desktop 47+. If false, the notification will disappear roughly after 20 seconds. If true, the notification will be displayed indefinitely until the user interacts with the notification (dismisses it or clicks it). If this optional value is not set, it defaults to true (i.e. notifications by default persist indefinitely). \n\n<span class=\"label-all label-firefox\">Firefox</span> and <span class=\"label-all label-safari\">Safari</span> - notifications automatically dismiss after some time and this parameter does not control that.",
    "8-2": "See our [Webhooks page](doc:webhooks) for the nested options.",
    "8-1": "JSON",
    "8-0": "`webhooks`"
  },
  "cols": 3,
  "rows": 9
}
[/block]
#### Init `promptOptions` parameters
Pass in these optional parameters within `promptOptions` when initializing to localize the HTTP popup prompt to your custom text and language. All entriesets are limited in length. Foreign characters accepted. Each parameter is optional, and its default is used when it is not included.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`actionMessage`",
    "0-2": "Text that says 'wants to show notifications' by default. Limited to 75 characters.",
    "0-1": "String",
    "1-1": "String",
    "2-1": "String",
    "3-1": "String",
    "4-1": "String",
    "5-1": "String",
    "6-1": "String",
    "7-1": "String",
    "8-1": "Boolean",
    "1-2": "Text that says 'This is an example notification'. Displays on non-mobile devices. Only one line is allowed.",
    "2-2": "Text that says 'Notifications will appear on your desktop'. Displays on non-mobile devices. Only one line is allowed.",
    "3-2": "Text that says 'This is an example notification'. Displays on mobile devices with limited screen width. Only one line is allowed.",
    "4-2": "Text that says 'Notifications will appear on your device'. Displays on mobile devices with limited screen width. Only one line is allowed.",
    "5-2": "Text that says '(you can unsubscribe anytime)'.",
    "6-2": "Text that says 'CONTINUE'.",
    "7-2": "Text that says 'NO THANKS'.",
    "8-2": "Set to false to hide the OneSignal logo.",
    "1-0": "`exampleNotificationTitleDesktop`",
    "2-0": "`exampleNotificationMessageDesktop`",
    "3-0": "`exampleNotificationTitleMobile`",
    "4-0": "`exampleNotificationMessageMobile`",
    "5-0": "`exampleNotificationCaption`",
    "6-0": "`acceptButtonText`",
    "7-0": "`cancelButtonText`",
    "8-0": "`showCredit`"
  },
  "cols": 3,
  "rows": 9
}
[/block]
#### Init `welcomeNotification` parameters
Pass in these optional parameters within `welcomeNotification` when initializing to customize or disable the welcome notification sent to new site visitors. Any person visiting your site for their first time, or an existing user who has completely cleared their cache is considered a new site visitor.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`disable`",
    "0-1": "Boolean",
    "1-0": "`title`",
    "1-1": "String",
    "2-0": "`message`",
    "2-1": "String",
    "0-2": "Disables sending a welcome notification to new site visitors. If you want to disable welcome notifications, this is the only option you need.",
    "1-2": "The welcome notification's title. You can localize this to your own language. If not set, or left blank, the site's title will be used. Set to one space ' ' to clear the title, although this is not recommended.",
    "2-2": "<span class=\"label-all label-required\">Required</span> The welcome notification's message. You can localize this to your own language. A message is required. If left blank or set to blank, the default of 'Thanks for subscribing!' will be used."
  },
  "cols": 3,
  "rows": 3
}
[/block]
#### Init `notifyButton` parameters
Pass in these optional parameters within `notifyButton` when initializing to enable and customize the notify button. All parameters below are optional. If not set, they will be replaced with their defaults.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`enable`",
    "0-1": "Boolean",
    "0-2": "Enable the notify button. The notify button is otherwise disabled by default.",
    "1-1": "String",
    "2-1": "String",
    "3-1": "JSON",
    "4-1": "Boolean",
    "5-1": "Boolean",
    "6-1": "Boolean",
    "1-2": "One of 'small', 'medium', or 'large'. The notify button will initially appear at one of these sizes, and then shrink down to size 'small' after the user subscribes.",
    "2-2": "Either 'bottom-left' or 'bottom-right'. The notify button will be fixed at this location on your page.",
    "3-2": "Specify CSS-valid pixel offsets using bottom, left, and right.",
    "4-2": "If you use the modal prompt for your HTTPS website, you should specify it here too so the bell shows the modal instead of the popup.",
    "5-2": "If true, the notify button will display an icon that there is 1 unread message. When hovering over the notify button, the user will see custom text set by `message.prenotify`.",
    "6-2": "Set `false` to hide the 'Powered by OneSignal' text in the notify button dialog popup.",
    "7-0": "`text`",
    "7-1": "JSON",
    "7-2": "Customize the notify button text. See the example code below to know what to change.",
    "6-0": "`showCredit`",
    "5-0": "`prenotify`",
    "4-0": "`modalPrompt`",
    "3-0": "`offset`",
    "2-0": "`position`",
    "1-0": "`size`"
  },
  "cols": 3,
  "rows": 8
}
[/block]
The following is a basic template of how you would call `init()`. [See our Customizing Features page to see additional examples.](doc:customizing-features) 

TODO: Code examples here
[block:code]
{
  "codes": [
    {
      "code": "// OneSignal is defined as an array here and uses push calls to support OneSignalSDK.js being loaded async.\nvar OneSignal = OneSignal || [];\n\nOneSignal.push([\"init\", {\n  appId: \"YOUR_APP_ID\",\n  // Your other init settings\n}]);",
      "language": "javascript"
    }
  ]
}
[/block]
### `setDefaultNotificationUrl`
<div class="label-all label-type">Function - <span class="label-chrome">Chrome</span> &middot; <span class="label-firefox">Firefox</span></div>

Pass in the full URL of the default page you want to open when a notification is clicked. When creating a notification, any URL you specify will take precedence and override the default URL. However if no URL is specified, this default URL specified by this call will open instead. If no default URL is specified at all, the notification opens to the root of your site by default.

<span class="label-all label-safari">Safari</span> - This function is not available. Instead, the default notification icon URL is the Site URL you set in your Safari settings.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`url`",
    "0-1": "String",
    "0-2": "page url to open from notifications"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.push(function() {\n  /* These examples are all valid */\n  OneSignal.setDefaultNotificationUrl(\"https://example.com\");\n  OneSignal.setDefaultNotificationUrl(\"https://example.com/subresource/resource\");\n  OneSignal.setDefaultNotificationUrl(\"http://subdomain.example.com:8080/a/b\");\n});",
      "language": "javascript"
    }
  ]
}
[/block]
### `setDefaultTitle`
<div class="label-all label-type">Function</div>

Sets the default title to display on notifications. If a notification is created with a title, the specified title always overrides this default title.

A notification's title defaults to the title of the page the user last visited. If your page titles vary between pages, this inconsistency can be undesirable. Call this to standardize page titles across notifications, as long as a notification title isn't specified.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`title`",
    "0-1": "String",
    "0-2": "String to set as a default title on notifications"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.push(function() \n  /* These examples are all valid */\n  OneSignal.setDefaultTitle(\"\");\n  OneSignal.setDefaultNotificationUrl(\"My Site\");\n});",
      "language": "javascript"
    }
  ]
}
[/block]
## Registering Push

### `registerForPushNotifications`
<div class="label-all label-type">Function</div>

*HTTP Sites:* Opens a popup window to subdomain.onesignal.com/subscribe to prompt the user to subscribe to push notifications. Call this in response to a user action like a button or link that was just clicked, otherwise the browser's popup blocker will prevent the popup from opening.

*HTTPS Sites:* You may call this at any time to show the prompt for push notifications. If notification permissions have already been granted, nothing will happen.

*HTTPS Sites (Optional):* Instead of directly prompting the browser's native permission prompt, you may instead use modalPrompt to show a full-screen modal with an image of a notification and show the user what to expect.

See the `subscriptionChange` event to know when the user has successfully subscribed.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-1": "Boolean",
    "0-0": "`modalPrompt`",
    "0-2": "Shows a modal popup window on your page explaining and showing an example notification with an option to continue or cancel before showing the native notification prompt to accept notifications. * (Option is only available for HTTPS when not using a subdomain. Otherwise a popup window will show with the same results.)*"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.push(function() {\n  OneSignal.registerForPushNotifications();\n});\n\nOneSignal.push(function() {\n  OneSignal.registerForPushNotifications({\n    modalPrompt: true\n  });\n});",
      "language": "javascript"
    }
  ]
}
[/block]

### `showHttpPrompt`
<div class="label-all label-type">Function</div>

Shows a prompt for HTTP site users to subscribe to notifications. Please see [HTTP Prompt](doc:web-push-http-prompt) for more details.
[block:code]
{
  "codes": [
    {
      "code": "OneSignal.showHttpPrompt();",
      "language": "javascript"
    }
  ]
}
[/block]

### `getNotificationPermission`
<div class="label-all label-type">Function</div>

Returns a Promise that resolves to the browser's current notification permission as 'default', 'granted', or 'denied'.

You can use this to detect whether the user has allowed notifications, blocked notifications, or has not chosen either setting.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`callback`",
    "0-1": "function",
    "0-2": "A callback function that will be called when the browser's current notification permission has been obtained, with one of 'default', 'granted', or 'denied'."
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.push([\"getNotificationPermission\", function(permission) {\n    console.log(\"Site Notification Permission:\", permission);\n    // (Output) Site Notification Permission: default\n}]);",
      "language": "javascript"
    }
  ]
}
[/block]
### `isPushNotificationsSupported`
<div class="label-all label-type">Function</div>

Returns true if the current browser viewing the page supports push notifications.

Almost all of the API calls on this page internally call this method first before continuing; this check is therefore optional but you may call it if you wish to display a custom message to the user.

This method is synchronous and returns immediately.
[block:code]
{
  "codes": [
    {
      "code": "OneSignal.push(function() {\n  /* These examples are all valid */\n  var isPushSupported = OneSignal.isPushNotificationsSupported();\n  if (isPushSupported) {\n    // Push notifications are supported\n  } else {\n    // Push notifications are not supported\n  }\n});",
      "language": "javascript"
    }
  ]
}
[/block]
### `isPushNotificationsEnabled`
<div class="label-all label-type">Function</div>

Returns a `Promise` that resolves to true if the user has already accepted push notifications and successfully registered with Google's GCM server and OneSignal's server (i.e. the user is able to receive notifications).

If you're deleting your user entry on our online dashboard for testing, the SDK will not sync with our dashboard and so this method will still return `true` (because you are still subscribed to the site's notifications). Follow [Clearing your cache and resetting push permissions](https://documentation.onesignal.com/v2.0/docs/website-push-common-problems#clearing-your-cache-and-resetting-push-permissions) to fix that.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`isPushNotificationsEnabledCallBack`",
    "0-1": "Function",
    "0-2": "Callback to be fired when the check completes. The first parameter of the callback is a boolean value indicating whether the user can receive notifications."
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.push(function() {\n  /* These examples are all valid */\n  OneSignal.isPushNotificationsEnabled(function(isEnabled) {\n    if (enabled)\n      console.log(\"Push notifications are enabled!\");\n    else\n      console.log(\"Push notifications are not enabled yet.\");    \n  });\n               \n  OneSignal.isPushNotificationsEnabled().then(function(isEnabled) {\n    if (enabled)\n      console.log(\"Push notifications are enabled!\");\n    else\n      console.log(\"Push notifications are not enabled yet.\");      \n  });\n});",
      "language": "javascript"
    }
  ]
}
[/block]
## User IDs

### `getUserId`
<div class="label-all label-type">Function</div>

Returns a `Promise` that resolves to the stored OneSignal user ID if one is set, otherwise the Promise resolves to null.

For custom implementations involving our REST API, associate this OneSignal user ID with your data.

Once created, the user ID will not change. If the user unsubscribes from web push, for example by clearing their browser data, and resubscribes, a new user ID will be created and a new entry will be stored on your app's users list. The old entry will not be automatically deleted.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`callback`",
    "0-1": "function",
    "0-2": "A callback function which sets the first parameter to the stored OneSignal user ID if one is set, otherwise the first parameter is set to null."
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.push(function() {\n  /* These examples are all valid */\n  OneSignal.getUserId(function(userId) {\n    console.log(\"OneSignal User ID:\", userId);\n    // (Output) OneSignal User ID: 270a35cd-4dda-4b3f-b04e-41d7463a2316    \n  });\n               \n  OneSignal.getUserId().then(function(userId) {\n    console.log(\"OneSignal User ID:\", userId);\n    // (Output) OneSignal User ID: 270a35cd-4dda-4b3f-b04e-41d7463a2316    \n  });\n});",
      "language": "javascript"
    }
  ]
}
[/block]

### `getRegistrationId`
<div class="label-all label-type">Function</div>

Returns a Promise that resolves to the stored OneSignal registration ID if one is set, otherwise the Promise resolves to null.

For custom implementations involving our REST API, use the above OneSignal user ID with your data instead of this registration ID. The registration ID is the device token associated with GCM or Apple's push notification server. It is an internal ID we use to generate the corresponding OneSignal user ID. We do not recommend using or storing the registration ID unless necessary.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`callback`",
    "0-1": "Function",
    "0-2": "A callback function which sets the first parameter to the stored OneSignal registration ID if one is set, otherwise the first parameter is set to null."
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.push([\"getRegistrationId\", function(registrationId) {\n    console.log(\"OneSignal Registration ID:\", registrationId);\n    // (Output) OneSignal Registration ID: cPMqRjFKn6U:APA91bGgr5-3ny36bQxBCA7uAoQIDsUtX6q7CL4FcsDiHlGgDh471C8cEktPYzTsO2OaOCeZmB0gLSSErzwM3fcZWI9LFkW8LEQzBVw7UbQ8NtlBF0dTADoYLF87xXSztUjAkFLP5_Vy\n}]);",
      "language": "javascript"
    }
  ]
}
[/block]
## Tags
### `getTags`
<div class="label-all label-type">Function</div>

Retrieve a list of tags that have been set on the user from the OneSignal server.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`callback`",
    "0-1": "Function",
    "0-2": "Callback to be fired when the list of tags has been retrieved. The first parameter of the callback is an object containing key-value pairs of the tags."
  },
  "cols": 3,
  "rows": 1
}
[/block]
Returns a `Promise` that is resolved with the object key-pairs of the tags you sent, or rejected with an error.
[block:code]
{
  "codes": [
    {
      "code": "OneSignal.push(function() {\n  /* These examples are all valid */\n  OneSignal.getTags(function(tags) {\n    // All the tags stored on the current webpage visitor\n  });\n               \n  OneSignal.getTags().then(function(tags) {\n    // All the tags stored on the current webpage visitor\n  });\n});",
      "language": "javascript"
    }
  ]
}
[/block]
### `tagsReceivedCallBack`
<div class="label-all label-type">Callback</div>

Gets all the tags set on a user from onesignal.com.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`tags`",
    "0-1": "JSON",
    "0-2": "JSON object of key value pairs retrieved from the OneSignal server."
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.push([\"getTags\", function(tags) {\n\t\tconsole.log(\"OneSignal getTags:\");\n\t\tconsole.log(tags);\n\t}]);",
      "language": "javascript"
    }
  ]
}
[/block]

### `sendTag`
<div class="label-all label-type">Function</div>

Tag a user based on an app event of your choosing so later you can create segments on [onesignal.com](https://onesignal.com) to target these users. We recommend using `sendTags` over `sendTag` if you need to add or update more than one tag on a user at a time. 

You can call `OneSignal.push(["sendTag", "key", "value"])` anytime after `var OneSignal = OneSignal || [];`; you do not have to wait until the user registers. Once the user registers, the tags will automatically be sent to our server as long as the page session is the same (i.e. the user has not navigated to another page).
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`key`",
    "1-0": "`value`",
    "2-0": "`callback`",
    "2-1": "Function",
    "2-2": "Call back to be fired when the tags have been sent to our server and a response has been returned. The first parameter of the callback is an object of the tags you sent (key-value pairs).",
    "1-2": "Value to set on the key.\n_NOTE:_ Passing in a blank String deletes the key, you can also call `deleteTag`.",
    "0-2": "Key of your choosing to create or update.",
    "0-1": "String",
    "1-1": "String"
  },
  "cols": 3,
  "rows": 3
}
[/block]
Returns a `Promise` that is resolved with the object key-pairs of the tags you sent, or rejected with an error.
[block:code]
{
  "codes": [
    {
      "code": "OneSignal.push(function() {\n  /* These examples are all valid */\n  OneSignal.sendTag(\"key\", \"value\");\n               \n  OneSignal.sendTag(\"key\", \"value\", function(tagsSent) {\n    // Callback called when tags have finished sending\n  });\n               \n  OneSignal.sendTag(\"key\", \"value\").then(function(tagsSent) {\n    // Callback called when tags have finished sending\n  });  \n});",
      "language": "javascript"
    }
  ]
}
[/block]
### `sendTags`
<div class="label-all label-type">Function</div>

Tag a user based on an app event of your choosing so later you can create segments on [onesignal.com](https://onesignal.com) to target these users.

You can call `OneSignal.push(["sendTags", {key2: "value2", key3: "value3"}])` anytime after `var OneSignal = OneSignal || [];`; you do not have to wait until the user registers. Once the user registers, the tags will automatically be sent to our server.


[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`keyValues`",
    "0-1": "JSON",
    "0-2": "Key value pairs of your choosing to create or update.\n_NOTE:_ Passing in a blank String as a value deletes the key, you can also call deleteTag or deleteTags.",
    "1-0": "`callback`",
    "1-1": "Function",
    "1-2": "Call back to be fired when the tags have been sent to our server and a response has been returned. The first parameter of the callback is an object of the tags you sent (key-value pairs)."
  },
  "cols": 3,
  "rows": 2
}
[/block]
Returns a `Promise` that is resolved with the object key-pairs of the tags you sent, or rejected with an error.
[block:code]
{
  "codes": [
    {
      "code": "OneSignal.push(function() {\n  /* These examples are all valid */\n  OneSignal.sendTags({key: 'value'});\n               \n  OneSignal.sendTags({\n    key: 'value',\n    key2: 'value2',\n  });\n\n  OneSignal.sendTags({\n    key: 'value',\n    key2: 'value2',\n  }, function(tagsSent) {\n    // Callback called when tags have finished sending    \n  });\n\n  OneSignal.sendTags({\n    key: 'value',\n    key2: 'value2',\n  }).then(function(tagsSent) {\n    // Callback called when tags have finished sending    \n  });\n});",
      "language": "javascript"
    }
  ]
}
[/block]
### `deleteTag`
<div class="label-all label-type">Function</div>

Deletes a tag that was previously set on a user with `sendTag` or `sendTags`. Use `deleteTags` if you need to delete more than one.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`key`",
    "0-1": "String",
    "0-2": "Key to remove."
  },
  "cols": 3,
  "rows": 1
}
[/block]
Returns a `Promise` that is resolved with the object key-pair of the tag you deleted, or rejected with an error.
[block:code]
{
  "codes": [
    {
      "code": "OneSignal.push(function() {\n  OneSignal.deleteTag(\"tagKey\");\n});",
      "language": "javascript"
    }
  ]
}
[/block]
### `deleteTags`
<div class="label-all label-type">Function</div>

Deletes tags that were previously set on a user with `sendTag` or `sendTags`.

[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`keys`",
    "0-1": "Array",
    "1-0": "`callback`",
    "1-1": "Function",
    "1-2": "Callback to be fired when the list of tags has been removed. The first parameter of the callback is an array of the tags that were deleted.",
    "0-2": "Keys to remove."
  },
  "cols": 3,
  "rows": 2
}
[/block]
Returns a `Promise` that is resolved with the object key-pairs of the tags you deleted, or rejected with an error.
[block:code]
{
  "codes": [
    {
      "code": "OneSignal.push(function() {\n  /* These examples are all valid */\n  OneSignal.deleteTags([\"key1\"]);\n               \n  OneSignal.deleteTags([\"key1\", \"key2\"]);\n\n  OneSignal.deleteTags([\"key1\", \"key2\"], function(tagsDeleted) {\n    // Callback called when tags have been deleted    \n  });\n\n  OneSignal.deleteTags([\"key1\", \"key2\"]).then(tagsDeleted) {\n  });\n});",
      "language": "javascript"
    }
  ]
}
[/block]
## Sending Notifications

### Create Notification
To send notifications to users, please see the [Create notification](ref:create-notification) REST API docs, or use the <a class="dash-link">OneSignal Dashboard</a>. Because the Web Push API is run client-side, it does not have the ability to programmatically send to multiple users at once, or users that are not currently on your website.

### `sendSelfNotification`
<div class="label-all label-type">Function - <span class="label-all label-advanced">Advanced</span></div>
[block:callout]
{
  "type": "warning",
  "body": "This does not send to all users. Please see our [Create notification](ref:create-notification) REST API for sending notifications. This function is primarily for your own internal testing.",
  "title": "Sends to individual users only"
}
[/block]
Sends a push notification to the current user on the webpage. This is a simplified utility function to send a test message to yourself or a quick message to the user. It does not support any targeting options.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`title`",
    "0-1": "String",
    "1-1": "String",
    "2-1": "String",
    "3-1": "String",
    "4-1": "Hash",
    "5-1": "Array of Hash",
    "5-0": "`buttons`",
    "4-0": "`data`",
    "3-0": "`icon`",
    "2-0": "`url`",
    "1-0": "`message`",
    "0-2": "The notification's title. Currently defaults to \"OneSignal Test Message\" if not set. Use a \" \" single space to get around this. Multiple languages are not supported; write the text in the language the current user should receive it in.",
    "1-2": "The notification's body content. Required. Multiple languages are not supported; write the text in the language the current user should receive it in.",
    "2-2": "The URL to launch when the notification is clicked.[ Use a special URL to prevent any URL from launching](https://documentation.onesignal.com/docs/web-push-action-buttons#how-can-i-prevent-the-action-button-from-opening-a). Defaults to this special URL if none is set.",
    "3-2": "The URL to use for the notification icon.",
    "4-2": "Additional data to pass for the notification.",
    "5-2": "See [Action Buttons](doc:web-push-action-buttons) docs."
  },
  "cols": 3,
  "rows": 6
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.sendSelfNotification(\n  /* Title (defaults if unset) */\n  \"OneSignal Web Push Notification\",\n  /* Message (defaults if unset) */\n  \"Action buttons increase the ways your users can interact with your notification.\", \n   /* URL (defaults if unset) */\n  'https://example.com/?_osp=do_not_open',\n  /* Icon */\n  'https://onesignal.com/images/notification_logo.png',\n  {\n    /* Additional data hash */\n    notificationType: 'news-feature'\n  }, \n  [{ /* Buttons */\n    /* Choose any unique identifier for your button. The ID of the clicked button is passed to you so you can identify which button is clicked */\n    id: 'like-button',\n    /* The text the button should display. Supports emojis. */\n    text: 'Like',\n    /* A valid publicly reachable URL to an icon. Keep this small because it's downloaded on each notification display. */\n    icon: 'http://i.imgur.com/N8SN8ZS.png',\n    /* The URL to open when this action button is clicked. See the sections below for special URLs that prevent opening any window. */\n    url: 'https://example.com/?_osp=do_not_open'\n  },\n  {\n    id: 'read-more-button',\n    text: 'Read more',\n    icon: 'http://i.imgur.com/MIxJp1L.png',\n    url: 'https://example.com/?_osp=do_not_open'\n  }]\n);",
      "language": "javascript"
    }
  ]
}
[/block]

### `setSubscription`
<div class="label-all label-type">Function - <span class="label-all label-advanced">Advanced</span></div>

[block:callout]
{
  "type": "warning",
  "title": "Do not use with Notify Button",
  "body": "This function is not for use with sites that implement the Notify Button, as this function may override user preferences."
}
[/block]
This function is for sites that wish to have more granular control of which users receive notifications, such as when implementing notification preference pages. 

This function lets a site mute or unmute notifications for the current user. This event is not related to actually prompting the user to subscribe. The user must already be subscribed for this function to have any effect.

Set to `false` to temporarily "mute" notifications from going to the user. If you previously set this to false, you can set it to `true` to "un-mute" notifications so that the user receives them again. 
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`unmute`",
    "0-1": "Boolean",
    "0-2": "`true` un-mutes any subscribed user \n`false` mutes any subscribed user"
  },
  "cols": 3,
  "rows": 1
}
[/block]
Returns a promise that resolves after temporarily opting the user out of receiving notifications by setting a flag on our system so that notifications are not delivered to the user. 
[block:code]
{
  "codes": [
    {
      "code": "OneSignal.push([\"setSubscription\", false]);",
      "language": "javascript"
    }
  ]
}
[/block]

### Subscription Change
<div class="label-all label-type">Event</div>

Occurs when the user's subscription state changes between unsubscribed and subscribed.

<span class="label-all label-chrome">Chrome</span> and <span class="label-all label-firefox">Firefox</span> - the user's subscription is `true` when:
- Your site is granted notification permissions
- Your site visitor's web storage database containing OneSignal-related data is intact
- You have not manually opted out the user from receiving notifications
    - The notify button's 'Subscribe' and 'Unsubscribe' button opts users in and out without affecting their other subscription parameters
    - `OneSignal.setSubscription()` is used to opt the user in and out
- Your site visitor has an installed background web worker used to display notifications

<span class="label-all label-safari">Safari</span> - only the first three are required for a valid subscription.

Use this event to find out when the user has successfully subscribed. The parameter will be set to true to represent a new subscribed state.

A user is no longer subscribed if:
- The user changes notification permissions
    - The icon next to the URL in the address bar can be clicked to modify site permissions
    - Chrome and Firefox notifications come with a button on the notification to block site notifications
- The user clears their browser data (clearing cookies will not effect subscription)
- Another background web worker overwrites our web worker

This event *is not related* to `OneSignal.setSubscription()`. `OneSignal.setSubscription()` is used to temporarily opt-out the user from receiving notifications by setting a flag on our system so that notifications are not delivered to the user. This event is more like an event for when `OneSignal.isPushNotificationsEnabled()` changes.

#### Callback Event Parameters
[block:parameters]
{
  "data": {
    "0-0": "`subscribed`",
    "0-1": "Boolean",
    "0-2": "Set to `true` if the user is currently subscribed; otherwise set to `false`.",
    "h-2": "Description",
    "h-1": "Type",
    "h-0": "Parameter"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.push(function() {\n  // Occurs when the user's subscription changes to a new value.\n  OneSignal.on('subscriptionChange', function (isSubscribed) {\n    console.log(\"The user's subscription state is now:\", isSubscribed);\n  });\n});",
      "language": "javascript"
    }
  ]
}
[/block]
This event can be listened to via the `on()` or `once()` listener:
[block:code]
{
  "codes": [
    {
      "code": "// Make sure OneSignal is initialized before listening to the event\nvar OneSignal = window.OneSignal || [];\nOneSignal.on('(event name here)', function(event) {\n  // This callback fires every time the event occurs\n});\nOneSignal.once('(event name here)', function(event) {\n  // This callback fires only once when the event occurs, and does not refire\n});",
      "language": "javascript"
    }
  ]
}
[/block]

## Receiving Notifications

### Notification Display
<div class="label-all label-type">Event - <span class="label-all label-chrome">Chrome</span></div>

Occurs after a notification is visibly displayed on the user's screen.

This event is fired on your page. If multiple browser tabs are open to your site, this event will be fired on *all* pages on which OneSignal is active.

#### Callback Event Parameters
`event` is a JavaScript object hash containing:
[block:parameters]
{
  "data": {
    "0-0": "`id`",
    "1-0": "`heading`",
    "2-0": "`content`",
    "3-0": "`url`",
    "4-0": "`icon`",
    "4-1": "String",
    "3-1": "String",
    "1-1": "String",
    "2-1": "String",
    "0-1": "UUID",
    "0-2": "The OneSignal notification ID of the notification that was just displayed.",
    "1-2": "The notification's title.",
    "2-2": "The notification's body message, not including the title.",
    "3-2": "The URL that will be opened if the user clicks on the notification.",
    "4-2": "The URL to the icon used for the notification. This is fetched every time the notification is displayed.",
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 5
}
[/block]
Note: Depending on the notification, more fields (e.g. action buttons) can be included in the callback parameter.
[block:code]
{
  "codes": [
    {
      "code": "OneSignal.on('notificationDisplay', function (event) {\n\tconsole.warn('OneSignal notification displayed:', event);\n  /*\n  {\n      \"id\": \"ce31de29-e1b0-4961-99ee-080644677cd7\",\n      \"heading\": \"OneSignal Test Message\",\n      \"content\": \"This is an example notification.\",\n      \"url\": \"https://onesignal.com?_osp=do_not_open\",\n      \"icon\": \"https://onesignal.com/images/notification_logo.png\"\n  }\n  */\n});",
      "language": "javascript"
    }
  ]
}
[/block]
This event can be listened to via the `on()` or `once()` listener:
[block:code]
{
  "codes": [
    {
      "code": "// Make sure OneSignal is initialized before listening to the event\nvar OneSignal = window.OneSignal || [];\nOneSignal.on('(event name here)', function(event) {\n  // This callback fires every time the event occurs\n});\nOneSignal.once('(event name here)', function(event) {\n  // This callback fires only once when the event occurs, and does not refire\n});",
      "language": "javascript"
    }
  ]
}
[/block]

### Notification Dismiss
<div class="label-all label-type">Event</div>

This event occurs when:
  - A user purposely dismisses the notification without clicking the notification body or action buttons
  - On Chrome on Android, a user dismisses all web push notifications (this event will be fired for each web push notification we show)
  - A notification expires on its own and disappears

**Note:** This event *does not occur* if a user clicks on the notification body or one of the action buttons. That is considered a notification click (please see the `addListenerForNotificationOpened` method).

Supported On: Chrome 50+ only.

This event is fired on your page. If multiple browser tabs are open to your site, this event will be fired on *all* pages on which OneSignal is active.

#### Callback Event Parameters
`event` is a JavaScript object hash containing:
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`id`",
    "1-0": "`heading`",
    "2-0": "`content`",
    "3-0": "`url`",
    "4-0": "`icon`",
    "4-2": "The URL to the icon used for the notification. This is fetched every time the notification is displayed.",
    "4-1": "String",
    "3-1": "String",
    "2-1": "String",
    "1-1": "String",
    "0-1": "UUID",
    "0-2": "The OneSignal notification ID of the notification that was just displayed.",
    "1-2": "The notification's title.",
    "2-2": "The notification's body message, not including the title.",
    "3-2": "The URL that will be opened if the user clicks on the notification."
  },
  "cols": 3,
  "rows": 5
}
[/block]
Note: Depending on the notification, more fields (e.g. action buttons) can be included in the callback parameter.
[block:code]
{
  "codes": [
    {
      "code": "OneSignal.on('notificationDismiss', function (event) {\n\tconsole.warn('OneSignal notification dismissed:', event);\n  /*\n  {\n      \"id\": \"ce31de29-e1b0-4961-99ee-080644677cd7\",\n      \"heading\": \"OneSignal Test Message\",\n      \"content\": \"This is an example notification.\",\n      \"url\": \"https://onesignal.com?_osp=do_not_open\",\n      \"icon\": \"https://onesignal.com/images/notification_logo.png\"\n  }\n  */\n});",
      "language": "javascript"
    }
  ]
}
[/block]
This event can be listened to via the `on()` or `once()` listener:
[block:code]
{
  "codes": [
    {
      "code": "// Make sure OneSignal is initialized before listening to the event\nvar OneSignal = window.OneSignal || [];\nOneSignal.on('(event name here)', function(event) {\n  // This callback fires every time the event occurs\n});\nOneSignal.once('(event name here)', function(event) {\n  // This callback fires only once when the event occurs, and does not refire\n});",
      "language": "javascript"
    }
  ]
}
[/block]
### `addListenerForNotificationOpened`
<div class="label-all label-type">Function</div>

Passed in callback that fires when the user clicks on a OneSignal notification. Please see the [callback documentation](https://documentation.onesignal.com/docs/website-sdk-api#section-notificationopenedcallback) as specific cases are required to trigger this event.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-2": "Passed in function which will receive one parameter containing JSON with data about the notification that was clicked.",
    "0-0": "`notificationOpenedCallBack`",
    "0-1": "function"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.push([\"addListenerForNotificationOpened\", function(data) {\n\tconsole.log(\"Received NotificationOpened:\");\n\tconsole.log(data);\n}]);",
      "language": "javascript"
    }
  ]
}
[/block]

### `notificationOpenedCallBack`
<div class="label-all label-type">Callback - <span class="label-chrome">Chrome</span> &middot; <span class="label-firefox">Firefox</span></div>

Occurs when a notification is clicked that opens a URL back to your page with the OneSignal SDK.

**By default:**
Suppose the notification opens the URL "https://yoursite.com/a/b/c/". If an existing tab is already open to the *same exact* URL, that tab will be focused and receive the callback. If no existing tab matching *the exact same URL* is open, a new browser tab will be opened and this newly opened tab will receive fire the notificationOpenedCallBack. If multiple existing tabs *all matching exactly the URL* of the notification are already open, one of the tabs will receive the callback.

**Alternatively:**

In the OneSignal web SDK init options, you can set `notificationClickHandlerMatch` to the literal string `"origin"`. This relaxes the matching restriction above so that existing browser tabs on your site don't need to exactly match the notification URL to be focused.

With this flag set, suppose the notification opens the URL "https://yoursite.com/a/b/c". If you have any browser tab open to "https://yoursite.com", for example "https://yoursite.com/zzz", then the tab with "https://yoursite.com/zzz" or "https://yoursite.com" will be focused and will receive the callback. Any tab that *matches your origin* will receive the callback.

*Note*: While the above is true for HTTPS sites (*any* tab that matches the origin will be focusable), for HTTP sites, the existing tab must be running the OneSignal SDK to catch the focus event from our background worker.  For HTTPS sites this restriction is not necessary.

This mode is useful for single-page apps that want to catch the event and handle their own redirection.

An *origin* is a combination of protocol, hostname, and port. https://domain.com is not the same origin as https://www.domain.com.

This callback accepts one parameter, which is a JavaScript object (JSON) containing the details of the notification, as listed below:
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-1": "String",
    "1-1": "String",
    "2-1": "String",
    "3-1": "String",
    "4-1": "String",
    "5-1": "JSON",
    "6-1": "String",
    "0-0": "`id`",
    "1-0": "`header`",
    "2-0": "`content`",
    "3-0": "`icon`",
    "4-0": "`url`",
    "5-0": "`data`",
    "6-0": "`action`",
    "6-2": "Describes whether the notification body was clicked or one of the action buttons (if present) was clicked. An empty string means the notification body was clicked, otherwise the string is set to the action button ID.",
    "5-2": "Key value pairs that were set on the notification.",
    "4-2": "The URL that this notification opened.",
    "3-2": "Icon set on the notification.",
    "2-2": "The message text the user seen in the notification.",
    "1-2": "Title set on the notification.",
    "0-2": "The OneSignal notification ID of the notification that was just clicked."
  },
  "cols": 3,
  "rows": 7
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "/* Do NOT call init twice */\nOneSignal.push([\"init\", {\n  /* Your other init settings ... */\n  notificationClickHandlerMatch: 'origin', /* See above documentation: 'origin' relaxes tab matching requirements *.\n  /* ... */\n}]);",
      "language": "javascript"
    }
  ]
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.push([\"addListenerForNotificationOpened\", function(data) {\n\tconsole.log(\"Received NotificationOpened:\", data);\n}]);",
      "language": "javascript"
    }
  ]
}
[/block]

## Deprecations

March 15, 2016: Deprecated `getIdsAvailable()` in favor of `getUserId()` and `getRegistrationId()`. Deprecated `idsAvailableCallback` in favor of `subscriptionChange` event.
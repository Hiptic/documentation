---
title: "React Native SDK"
excerpt: "OneSignal React Native SDK. Works with <span class=\"label-all label-ios\">iOS</span> and <span class=\"label-all label-android\">Android</span>.\n<div class=\"tag-all tag-developers\">For Developers</div>"
---
[block:callout]
{
  "type": "info",
  "title": "Just starting with React Native?",
  "body": "Check out our [React Native SDK Setup guide](doc:react-native-sdk-setup)."
}
[/block]

[block:callout]
{
  "type": "info",
  "title": "Third Party Library",
  "body": "OneSignal does not yet have an official first-party React Native SDK. However, there is a well-maintained [third party React Native library](https://github.com/geektimecoil/react-native-onesignal) that many of our customers use."
}
[/block]
---
title: "Corona SDK"
excerpt: "OneSignal Corona SDK Reference. Works with <span class=\"label-all label-ios\">iOS</span>, <span class=\"label-all label-android\">Android</span>, and <span class=\"label-all label-windows\">Windows Phone 8</span>.\n<div class=\"tag-all tag-developers\">For Developers</div>"
---
[block:callout]
{
  "type": "info",
  "title": "Just starting with Corona?",
  "body": "Check out our [Corona SDK Setup guide](doc:corona-sdk-setup)."
}
[/block]

[block:parameters]
{
  "data": {
    "0-0": "### Initialization",
    "0-1": "",
    "2-0": "[kOSSettingsKeyAutoPrompt](#section--kossettingskeyautoprompt-)",
    "2-1": "Function",
    "h-2": "",
    "0-2": "",
    "2-2": "<span class=\"label-all label-ios\">iOS</span> - Automatically Prompt Users to Enable Notifications",
    "h-0": "",
    "1-0": "[Init](#section--init-)",
    "1-1": "Function",
    "1-2": "Initialize OneSignal",
    "5-0": "### Registering Push",
    "6-0": "[RegisterForNotifications](#section--registerfornotifications-)",
    "7-0": "### User IDs",
    "8-0": "[IdsAvailableCallback](#section--idsavailablecallback-)",
    "8-1": "Function",
    "8-2": "Get the User ID of the device",
    "9-0": "### Tags",
    "10-0": "[GetTags](#section--gettags-)",
    "10-1": "Function",
    "12-1": "Function",
    "13-1": "Function",
    "14-1": "Function",
    "10-2": "View Tags from a User",
    "12-2": "",
    "14-2": "",
    "13-2": "Delete a Tag from a User",
    "12-0": "[SendTags](#section--sendtags-)",
    "13-0": "[DeleteTag](#section--deletetag-)",
    "14-0": "[DeleteTags](#section--deletetags-)",
    "15-0": "### Data",
    "18-0": "### Sending Notifications",
    "23-0": "### Receiving Notifications",
    "19-0": "[PostNotification](#section--postnotification-)",
    "20-0": "[CancelNotification](#section--cancelnotification-)",
    "21-0": "[ClearAllNotifications](#section--clearallnotifications-)",
    "22-0": "[SetSubscription](#section--setsubscription-)",
    "22-1": "Function",
    "21-1": "Function",
    "19-1": "Function",
    "20-1": "Function",
    "24-0": "[OSNotification](#section--osnotification-)",
    "24-1": "Function",
    "28-0": "[OSNotificationPayload](#section--osnotificationpayload-)",
    "28-1": "Function",
    "29-0": "### Appearance",
    "30-0": "[EnableVibrate](#section--enablevibrate-)",
    "31-0": "[EnableSound](#section--enablesound-)",
    "30-1": "Function",
    "31-1": "Function",
    "32-0": "### Debug",
    "33-0": "[SetLogLevel](#section--setloglevel-)",
    "33-1": "Function",
    "17-1": "Function",
    "17-0": "[SyncHashedEmail](#section--synchashedemail-)",
    "16-0": "[PromptLocation](#section--promptlocation-)",
    "16-1": "Function",
    "16-2": "Prompt Users for Location",
    "17-2": "Sync Anonymized User Email",
    "19-2": "Send or schedule a notification to a user",
    "20-2": "Delete a single app notification",
    "22-2": "Opt users in or out of receiving notifications",
    "21-2": "Delete all app notifications",
    "28-2": "Data that comes with a notification",
    "24-2": "When a notification is received by a device",
    "30-2": "<span class=\"label-all label-android\">Android</span> - When user receives notification, vibrate device less",
    "31-2": "<span class=\"label-all label-android\">Android</span> - When user receives notification, do not play a sound",
    "33-2": "Enable logging to help debug OneSignal implementation",
    "11-0": "[SendTag](#section--sendtag-)",
    "11-1": "Function",
    "11-2": "Add a Tag to a User",
    "25-0": "[OSNotificationAction](#section--osnotificationaction-)",
    "25-1": "Function",
    "25-2": "When a user takes an action on a notification",
    "3-0": "[kOSSettingsKeyInFocusDisplayOption](#section--kossettingskeyinfocusdisplayoption-)",
    "4-0": "[kOSSettingsKeyInAppLaunchURL](#section--kossettingskeyinapplaunchurl-)",
    "3-1": "Function",
    "4-1": "Function",
    "6-2": "Prompt Users to Enable Notifications",
    "4-2": "<span class=\"label-all label-ios\">iOS</span> - Open all URLs in In-App Safari Window",
    "3-2": "<span class=\"label-all label-android\">Android</span>, <span class=\"label-all label-ios\">iOS</span> - Automatically Display Notifications when app is in focus",
    "26-0": "[OSNotificationActionType](#section--osnotificationaction-)",
    "27-0": "[OSNotificationDisplayType](#section--osnotificationdisplaytype-)",
    "27-2": "Change how notifications are displayed to users",
    "26-1": "Function",
    "27-1": "Function",
    "6-1": "Function"
  },
  "cols": 3,
  "rows": 34
}
[/block]
## Initialize

### `Init`
Initializes OneSignal and lets you handle the opening of a push notification.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`appId`",
    "1-0": "`googleProjectNumber`",
    "2-0": "`DidReceiveRemoteNotificationCallBack`",
    "0-1": "String",
    "1-1": "String",
    "2-1": "Function",
    "0-2": "Your OneSignal app id, available in <a class=\"dash-link\" href=\"/docs/accounts-and-keys#section-keys-ids\">Keys & IDs</a>",
    "1-2": "<p><span class=\"label-all label-android\">Android</span> - `{googleProjectNumber: \"############\"}` is required. This is a 10 to 14 digit number. </p>\n\n<p><span class=\"label-all label-ios\">ios</span>, <span class=\"label-all label-windows\">windows phone 8</span> - Pass in `\"\"`</p>",
    "2-2": "Gets called when the user opens the notification or one is received while the app is in use."
  },
  "cols": 3,
  "rows": 3
}
[/block]
#### Callback
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "0-0": "`message`",
    "0-1": "String",
    "1-0": "`additionalData`",
    "h-1": "Type",
    "h-2": "Description",
    "0-2": "The message text the user seen in the notification.",
    "1-2": "Key value pairs that were set on the notification. \n\n`stacked_notifications` Table - Contains a Table for each notification that exists in the stack. `message` as well as keys listed above and ones you set with additional data will be available.",
    "1-1": "Table",
    "2-0": "`isActive`",
    "2-1": "Boolean",
    "2-2": "`true` if your app was currently being used when a notification came in."
  },
  "cols": 3,
  "rows": 3
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "-- This function gets called when the user opens a notification or one is received when the app is open and active.\n-- Change the code below to your app needs.\nfunction DidReceiveRemoteNotification(message, additionalData, isActive)\n    if (additionalData) then\n        if (additionalData.discount) then\n            native.showAlert( \"Discount!\", message, { \"OK\" } )\n            -- Take user to your in-app store\n        elseif (additionalData.actionSelected) then -- Interactive notification button pressed\n            native.showAlert(\"Button Pressed!\", \"ButtonID:\" .. additionalData.actionSelected, { \"OK\"} )\n        end\n    else\n        native.showAlert(\"OneSignal Message\", message, { \"OK\" } )\n    end\nend\n\nlocal OneSignal = require(\"plugin.OneSignal\")\nOneSignal.Init(\"5eb5a37e-b458-11e3-ac11-000c2940e62c\", \"703122844262\", DidReceiveRemoteNotification)",
      "language": "lua"
    }
  ]
}
[/block]
### `kOSSettingsKeyAutoPrompt`
<div class="label-all label-type">Function - <span class="label-all label-ios">iOS</span> - *formerly DisableAutoRegister*</div>

Automatically Prompt Users to Enable Notifications. Call `DisableAutoRegister` before `Init` to delay when the iOS system prompt asks for permissions to show push notifications. You can then call `RegisterForNotifications` after the player is done with your tutorial for example. This improves the opt-in rate for your app. This only affects iOS as Android devices always automatically register silently.

**Testing**
If you already answered the iOS Notification Permissions prompt you can reset it by following instructions here.

**Gotchas**
If your using this function, `IdsAvailableCallback`, and applicationIconBadgeNumber or any local notifications before calling `RegisterForNotifications` then the iOS system prompt asking for push permissions will show sooner and `IdsAvailableCallback` may not fire.
[block:code]
{
  "codes": [
    {
      "code": "OneSignal.DisableAutoRegister()",
      "language": "lua"
    }
  ]
}
[/block]

### `kOSSettingsKeyInFocusDisplayOption`
<div class="label-all label-type">Interface Element - <span class="label-all label-ios">iOS 10+</span></div>

Setting to control how OneSignal notifications will be shown when one is received while your app is in focus, for apps targeting <span class="label-all label-ios">iOS 10+</span>. 

`Notification` - native notification display while user has app in focus (can be distracting).
`InAppAlert` (<span class="label-all label-default">Default</span>) - native alert dialog display, which can be helpful during development.
`None` - notification is silent.
[block:callout]
{
  "type": "warning",
  "body": "We recommend you set this to `None` prior to launching your app, so users do not get interrupted while using your app.",
  "title": "Disable Before Launch"
}
[/block]

[block:callout]
{
  "type": "warning",
  "body": "<span class=\"label-all label-ios\">iOS 9 AND BELOW</span> - the `Notification` setting will fall back to `InAppAlert` ."
}
[/block]
### `kOSSettingsKeyInAppLaunchURL`
<div class="label-all label-type">Function - <span class="label-all label-ios">iOS</span> - *Coming Soon*</div>

`true` (<span class="label-all label-default">Default</span>) - Open all URLs in in-app Safari window
`false` - disables the display of launch URLs in-app but instead open the URL in Safari or other app (if deep linked or custom URL scheme passed).



## Registering Push
### `RegisterForNotifications`
<div class="label-all label-type">Function - <span class="label-ios">ios</span></div>

Use this only if you called `DisableAutoRegister` before `Init`. This will show the iOS system prompt to ask for push permissions. If the user presses yes they will be subscribed for push notifications on OneSignal.com.
[block:code]
{
  "codes": [
    {
      "code": "OneSignal.RegisterForNotifications()",
      "language": "lua"
    }
  ]
}
[/block]
## User IDs

### `IdsAvailableCallback`
<div class="label-all label-type">Function</div>

Lets you retrieve the OneSignal player id and device token. Your callback function is called after the device is successfully registered with OneSignal. If the device could not be successfully registered with Apple/Google or `DisableAutoRegister` was called then the pushToken parameter with be nil. If later the device registers with Apple/Google then the callback will be fired a 2nd time with both ids filled. Once the callback fires with both ids it will not be called again unless you call `IdsAvailableCallback` again.
[block:parameters]
{
  "data": {
    "0-0": "`idsAvailableCallback`",
    "0-1": "Function",
    "0-2": "Function that will get called when the user id is retrieved from OneSignal.",
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "function IdsAvailable(userID, pushToken)\n    print(\"PLAYER_ID:\" .. userID)\n    if (pushToken) then -- nil if user did not accept push notifications on iOS\n        print(\"PUSH_TOKEN:\" .. pushToken)\n    end\nend\n\nOneSignal.IdsAvailableCallback(IdsAvailable)",
      "language": "lua"
    }
  ]
}
[/block]
## Tags
### `GetTags`
<div class="label-all label-type">Function</div>

Retrieve a table of tags that have been set on the player from the OneSignal server.
[block:parameters]
{
  "data": {
    "0-0": "`tagsAvailableCallback`",
    "0-1": "Function",
    "0-2": "Function that gets called when the tags are retrieved from the OneSignal server.",
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:parameters]
{
  "data": {
    "0-0": "`keyValuePairs`",
    "0-1": "Table",
    "0-2": "Table of key value pairs retrieved from the OneSignal server.",
    "h-0": "Returns",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "function printAllTags(tags)\n   for key,value in pairs(tags) do\n      print( key, value )\n   end\nend\n\nOneSignal.GetTags(printAllTags)",
      "language": "lua"
    }
  ]
}
[/block]
### `SendTag`
<div class="label-all label-type">Function</div>

Tag a user with custom data so you can create segments on onesignal.com to target these users. Recommend using SendTags over SendTag if you need to set more than one tag on a user at a time.
[block:parameters]
{
  "data": {
    "h-0": "Parameters",
    "0-0": "`key`",
    "1-0": "`value`",
    "1-1": "String",
    "0-1": "String",
    "0-2": "Key of your choosing to create or update.",
    "1-2": "Value to set on the key. _NOTE:_ Passing in a blank String deletes the key, you can also call `DeleteTag` or `DeleteTags`. (TODO CONFIRM THIS ELABORATION)",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 2
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.SendTag(\"CoronaTag1\", \"value1\")",
      "language": "lua"
    }
  ]
}
[/block]

### `SendTags`
<div class="label-all label-type">Function</div>

Set multiple tags on a player with one call.
[block:parameters]
{
  "data": {
    "0-0": "`keyValuePairs`",
    "0-1": "Table",
    "0-2": "Key value pairs of your choosing to create or update.",
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.SendTags({[\"CoronaTag2\"] = \"value2\",[\"CoronaTag3\"] = \"value3\"})",
      "language": "lua"
    }
  ]
}
[/block]
### `DeleteTag`
<div class="label-all label-type">Function</div>

Delete a tag by its key from the user that was set with `SendTag` or `SendTags` calls. Recommend using `DeleteTags` over `DeleteTag` if you need to delete more than one tag on a user at a time.
[block:parameters]
{
  "data": {
    "0-0": "`key`",
    "0-1": "String",
    "0-2": "Key to remove from the tags set on a user.",
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.DeleteTag(\"CoronaTag1\")",
      "language": "lua"
    }
  ]
}
[/block]

### `DeleteTags`
<div class="label-all label-type">Function</div>

Delete tags by their keys from the user that were set with `SendTag` or `SendTags` calls.
[block:parameters]
{
  "data": {
    "0-0": "`key`",
    "0-1": "Table",
    "0-2": "List of keys to delete off the user.",
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.DeleteTags({\"key1\", \"key2\"})",
      "language": "lua"
    }
  ]
}
[/block]
## Data

### `PromptLocation`
<div class="label-all label-type">Function - <span class="label-ios">ios</span></div>

Prompts the user for location permission to allow geotagging based on the "Location radius" filter in <a class="dash-link" href="segmentation">Segments</a>.
[block:code]
{
  "codes": [
    {
      "code": "OneSignal.PromptLocation();",
      "language": "lua"
    }
  ]
}
[/block]
Required `build.settings`:
[block:code]
{
  "codes": [
    {
      "code": "settings =\n{\n    iphone =\n    {\n        plist =\n        {\n            NSLocationUsageDescription = \"Location permission prompt text\",\n            NSLocationWhenInUseUsageDescription = \"Location permission prompt text\",\n        },\n    },\n}",
      "language": "lua"
    }
  ]
}
[/block]
### `SyncHashedEmail`
<div class="label-all label-type">Function - *Coming Soon*</div>

Sends the user's email as an anonymized hash to prevent duplicated users.


## Sending Notifications
### `PostNotification`
<div class="label-all label-type">Function</div>

Allows you to send notifications from user to user or schedule ones in the future to be delivered to the current device.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "0-0": "`parameters`",
    "0-1": "Table",
    "0-2": "Contains notification options, see [Create Notification](ref:create-notification) POST call for all options.",
    "h-1": "Type",
    "h-2": "Description",
    "1-0": "`onSuccess`",
    "1-1": "function",
    "1-2": "(Optional) callback fires when the notification was created on OneSignal's server.\n\n`returnedJson` table (JSON) - response from OneSignal's server.",
    "2-0": "`onFailure`",
    "2-1": "function",
    "2-2": "callback fires when the notification failed to create\n\n`returnedJson` table (JSON) - response from OneSignal's server."
  },
  "cols": 3,
  "rows": 3
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "-- Creates a notification to be deliver to this device as a test.\nfunction IdsAvailable(userID, pushToken)\n    if (pushToken) then\n        local notification = {\n            [\"contents\"] = {[\"en\"] = \"test\"}\n        }\n        notification[\"include_player_ids\"] = {userID}\n        \n        OneSignal.PostNotification(notification,\n            function(jsonData)\n                native.showAlert( \"DEBUG\", \"POST OK!!!\", { \"OK\" } )\n                local json = require \"json\"\n                print(json.encode(jsonData))\n            end,\n            function(jsonData)\n                native.showAlert( \"DEBUG\", \"POST NOT OK!!!\", { \"OK\" } )\n                local json = require \"json\"\n                print(json.encode(jsonData))\n            end\n        )\n    end\nend\n\nOneSignal.IdsAvailableCallback(IdsAvailable)",
      "language": "lua"
    }
  ]
}
[/block]
### `cancelNotification`
<div class="label-all label-type">Function - <span class="label-all label-android">Android</span> - *Coming Soon*</div>

Delete a single app notification


### `ClearAllNotifications`
<div class="label-all label-type">Function</div>

Use this to clear all push notifications from your app from the device. Use this function instead of `system.cancelNotification()` as it does not clear Android remote notifications from OneSignal.
[block:code]
{
  "codes": [
    {
      "code": "OneSignal.ClearAllNotifications()",
      "language": "lua"
    }
  ]
}
[/block]



### `SetSubscription`
<div class="label-all label-type">Function</div>

You can call this function with `false` to opt users out of receiving all notifications through OneSignal. You can pass true later to opt users back into notifications.
[block:parameters]
{
  "data": {
    "0-0": "`enable`",
    "0-1": "boolean",
    "0-2": "",
    "h-0": "Parameter",
    "h-1": "Type"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.SetSubscription(false)",
      "language": "lua"
    }
  ]
}
[/block]
### Receiving Notifications

### `OSHandleNotificationReceivedBlock`
<div class="label-all label-type">Function - *Coming Soon*</div>

### `OSNotificationOpenedResult`
<div class="label-all label-type">Function - *Coming Soon*</div>

### `OSNotification`
<div class="label-all label-type">Function - *Coming Soon*</div>

### `OSNotificationAction`
<div class="label-all label-type">Function - *Coming Soon*</div>

### `OSNotificationDisplayType`
<div class="label-all label-type">Function - *Coming Soon*</div>

### `OSNotificationPayload`
<div class="label-all label-type">Function - *Coming Soon*</div>


## Appearance
### `enableVibrate`
<div class="label-all label-type">Function - <span class="label-android">Android</span></div>

By default OneSignal always vibrates the device when a notification is displayed unless the device is in a total silent mode. Passing `false` means that the device will only vibrate lightly when the device is in it's vibrate only mode. If both `EnableVibrate` and `EnableSound` are set to `false` then the device will never vibrate or make a sound.

*You can link this action to a UI button to give your user a vibration option for your notifications.*
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`enable`",
    "0-1": "boolean",
    "0-2": "`false` to disable vibrate, `true` to re-enable it."
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.EnableVibrate(false)",
      "language": "lua"
    }
  ]
}
[/block]
### `enableSound`
<div class="label-all label-type">Function - <span class="label-android">Android</span></div>

By default OneSignal plays the system's default notification sound when the device's notification system volume is turned on. Passing `false` means that the device will only vibrate unless the device is set to a total silent mode. If both `EnableVibrate` and `EnableSound` are set to `false` then the device will never vibrate or make a sound.

*You can link this action to a UI button to give your user a different sound option for your notifications.*
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`enable`",
    "0-1": "boolean",
    "0-2": "`false` to disable sound, `true` to re-enable it."
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.EnableSound(false)",
      "language": "lua"
    }
  ]
}
[/block]
## Debug
### `SetLogLevel`
<div class="label-all label-type">Function</div>

Enable logging to help debug if you run into an issue setting up OneSignal. The logging levels are available with increasingly more information, as follows:
`0` = None
`1` = Fatal
`2` = Errors
`3` = Warnings
`4` = Info
`5` = Debug
`6` = Verbose
[block:parameters]
{
  "data": {
    "h-0": "Parameters",
    "0-0": "`logLevel`",
    "1-0": "`visualLevel`",
    "1-1": "Integer",
    "0-1": "Integer",
    "0-2": "Sets the logging level to print the iOS Xcode log or the Android LogCat log.",
    "1-2": "Sets the logging level to show as alert dialogs.",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 2
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "-- Will show popup dialogs when the devices registers with Apple/Google and with OneSignal.\n-- Errors will be shown as popups too if there are any issues.\nOneSignal.SetLogLevel(4, 4)",
      "language": "lua"
    }
  ]
}
[/block]
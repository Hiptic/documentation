---
title: "Dashboard"
excerpt: "OneSignal Features - OneSignal Dashboard\n<div class=\"tag-all tag-developers\">For Developers</div> <div class=\"tag-all tag-marketers\">For Marketers</div>"
---
The OneSignal Dashboard is the primary user interface for working with OneSignal. The dashboard exposes all the functionality of OneSignal in an easy-to-use interface for developers and marketers alike. 

The main pages of the dashboard are:
- [Accounts & Keys](doc:accounts-and-keys) - managing your account and your app keys
- [All Apps](doc:all-apps) - access multiple apps you've created
- [Users & Devices](doc:users-and-devices) - your app's users
- [Segmentation](doc:segmentation) - creating and using segments
- [Notifications](doc:notifications) - sending notifications

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/1eeaa83-dashboard.png",
        "dashboard.png",
        2432,
        1598,
        "#eef5f7"
      ]
    }
  ]
}
[/block]
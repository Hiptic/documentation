---
title: "Mixpanel"
excerpt: "OneSignal Features - Integrating OneSignal with Mixpanel\n<div class=\"tag-all tag-developers\">For Developers</div> <div class=\"tag-all tag-marketers\">For Marketers</div>"
---
## Notification Behavior Tracking in Mixpanel

OneSignal supports tracking data when notifications are received and clicked on each platform, including sending this data to Mixpanel so that it can analyized in the context of your other user data.

<span class="label-all label-ios">iOS</span> -
1. Send an event to your analytics system from the `OSHandleNotificationReceivedBlock` event handler when a notification is received.

2. Send another event to your analytics system from the `OSHandleNotificationActionBlock` event handler when a notification is clicked.

<span class="label-all label-android">Android</span> - Same to above, but use `NotificationReceivedHandler` and `NotificationOpenedHandler`.

<span class="label-all">Web Push</span> - Same as above, but use our [Webhooks](doc:webhooks) events
---
title: "Google Analytics"
excerpt: "OneSignal Features - Integrating OneSignal with Google Analytics\n<div class=\"tag-all tag-developers\">For Developers</div> <div class=\"tag-all tag-marketers\">For Marketers</div>"
---
## Notification Behavior Tracking in Google Analytics

OneSignal supports tracking data when notifications are received and clicked on each platform, including sending this data to Google Analytics so that it can analyized in the context of your other user data.


<span class="label-all label-ios">iOS</span> -
1. Send an event to your analytics system from the `OSHandleNotificationReceivedBlock` event handler when a notification is received.

2. Send another event to your analytics system from the `OSHandleNotificationActionBlock` event handler when a notification is clicked.

<span class="label-all label-android">Android</span> - Same to above, but use `NotificationReceivedHandler` and `NotificationOpenedHandler`.

<span class="label-all">Web Push</span> -

**Tracking Notification Clicks, and post-click behavior**
The easiest way to track notification clicks is to add Google Analytics UTM parameters to the end of the URL for the notification. Here's an overview on UTM parameters: http://blog.rafflecopter.com/2014/04/utm-parameters-best-practices/

**Tracking notification permission opt-in**
You can use the subscriptionChange event of the OneSignal Javascript SDK to detect when a user subscribes to notifications or unsubscribes from notifications on your site.
---
title: "Platforms"
excerpt: ""
---
## App Settings
The App Settings page is where you configure the platforms associated with your app. 

<img src="https://files.readme.io/b2735ac-Screen_Shot_2016-10-05_at_4.58.41_PM.png"/>
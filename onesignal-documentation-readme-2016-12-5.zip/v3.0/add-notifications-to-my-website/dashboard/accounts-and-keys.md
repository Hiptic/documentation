---
title: "Accounts & Keys"
excerpt: "OneSignal Features - Accounts and Keys\n<div class=\"tag-all tag-developers\">For Developers</div> <div class=\"tag-all tag-marketers\">For Marketers</div>"
---
## Administrators
<div class="label-type">[All Apps](doc:all-apps) > **App Settings** > **Administrators** (tab)</div>

Each separate OneSignal app can have multiple administrators added to the app. Each administrator you add has full access and control over your app, including the ability to delete the app or even remove you as an administrator. 
[block:callout]
{
  "type": "warning",
  "body": "We do not currently support a permission system or log what actions other administrators take. Please be sure to only add administrators you trust."
}
[/block]
Administrators are added *per-app* and not *per-user*. The app administrator can only access the app(s) they have been added to, and not the other apps you have access to. This means if you have multiple apps that you want another person to access, you will have to invite them within each app.

### Adding Administrators
You can view, add, and remove administrators from the OneSignal Dashboard by going to **App Settings** and selecting the **Administrators** tab. Administrators are invited to join your app via their email address.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/4d913f2-Screen_Shot_2016-09-21_at_9.36.54_PM.png",
        "Screen Shot 2016-09-21 at 9.36.54 PM.png",
        2090,
        880,
        "#e9ebee"
      ]
    }
  ]
}
[/block]

[block:callout]
{
  "type": "warning",
  "title": "OneSignal Account Required",
  "body": "Any administrators invited to OneSignal must already have a OneSignal account."
}
[/block]
----

## Keys & IDs
<div class="label-type">[All Apps](doc:all-apps) > **App Settings** > **Keys & IDs** (tab)</div>

To use your key, add an HTTP header with the key `Authorization` and the value `Basic REST_API_KEY`, where you should replace `REST_API_KEY` with your actual APP REST API key.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/5F5kXsWQWCasHw6bh6ZD_MUg1sW3.png",
        "MUg1sW3.png",
        "1433",
        "673",
        "#35363e",
        ""
      ]
    }
  ]
}
[/block]
The keys for all your apps are also available all together within the Account section.

----

## Account
<div class="label-type">**Account** > **Account & API Keys**</div>

Your account details are available from the account menu, available by clicking your profile image in the lower left corner of the dashboard. This is where you can update your Organization name, email, and password. 

<img src="https://files.readme.io/aed588a-Account_Button.png"\>

### User Auth Key
The Account section is also where you can find your **User Auth Key**, available at the bottom of the page below the REST API keys for each of your OneSignal apps. 

The User Auth Key can be used by by adding an HTTP header with the key `Authorization` and the value `Basic USER_AUTH_API_KEY`, where you should replace `USER_AUTH_API_KEY` with your key.

<img src="https://files.readme.io/36ae25a-Account.png"\>
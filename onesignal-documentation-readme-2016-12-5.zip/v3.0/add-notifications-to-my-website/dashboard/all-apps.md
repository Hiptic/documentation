---
title: "All Apps"
excerpt: "OneSignal Features - All Apps Page \n<div class=\"tag-all tag-developers\">For Developers</div> <div class=\"tag-all tag-marketers\">For Marketers</div>"
---
Your OneSignal account supports one or more applications. The All Apps page provides an overview of each application in your account, including the stage of setup it is in, and an overview of users in each app. Clicking on an app brings you to the app's [Dashboard](doc:dashboard).
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/d021f50-Screen_Shot_2016-09-21_at_9.30.14_PM.png",
        "Screen Shot 2016-09-21 at 9.30.14 PM.png",
        2370,
        1476,
        "#1f2730"
      ]
    }
  ]
}
[/block]
## Renaming and Deleting
Clicking on the options menu (the three dots in the top right corner) brings up a menu allowing you to rename or delete your application. 
[block:callout]
{
  "type": "danger",
  "title": "Deletion is Permanent",
  "body": "If you delete your app, there is no way to restore it!"
}
[/block]

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/0febfce-Screen_Shot_2016-09-21_at_9.31.49_PM.png",
        "Screen Shot 2016-09-21 at 9.31.49 PM.png",
        1230,
        582,
        "#eef4fa"
      ]
    }
  ]
}
[/block]
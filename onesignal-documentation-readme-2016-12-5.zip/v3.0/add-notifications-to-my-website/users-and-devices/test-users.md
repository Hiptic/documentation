---
title: "Test Users"
excerpt: "OneSignal Features - Test Users\n<div class=\"tag-all tag-developers\">For Developers</div> <div class=\"tag-all tag-marketers\">For Marketers</div>"
---
Test Users are a special group of user devices that you can manually manage in order to test delivery of notifications. Each user's device may be added to the list of Test Users. These are accessible from <a class="dash-link" href="/docs/users-and-devices">All Users</a>.

## Adding Test Users
To add a user to your list of test users, do the following

<ol><li><p>Load the app on the user's device</p></li><li><p>Go to <a class="dash-link" href="/docs/users-and-devices">All Users</a></p></li><li><p>Find the user in question. You may have to click the **First Session** column to sort by the date of the first session. They should be the first user in the list if they just opened the app.</p></li><li><p>Click 'Options' on this user, and then click 'Add to Test Users' (see below)</p></li></ol>
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/f770390-Screen_Shot_2016-09-28_at_3.25.47_PM.png",
        "Screen Shot 2016-09-28 at 3.25.47 PM.png",
        1946,
        1236,
        "#ededed"
      ]
    }
  ]
}
[/block]

[block:callout]
{
  "type": "success",
  "body": "You're all set! You can confirm the user has been added to test users by switching the view to Test Users by clicking 'Viewing: All Users' and selecting Test Users."
}
[/block]
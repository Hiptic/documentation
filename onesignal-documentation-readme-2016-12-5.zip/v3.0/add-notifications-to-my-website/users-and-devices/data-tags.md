---
title: "Data & Tags"
excerpt: "OneSignal Features - Data and Tags\n<div class=\"tag-all tag-developers\">For Developers</div> <div class=\"tag-all tag-marketers\">For Marketers</div>"
---
## Tags
Tags are data attributes that can be added to users via OneSignal SDKs or the [Server REST API](ref:create-notification). Tags are powerful way to target users using <a class="dash-link" href="/docs/segmentation">Segments</a>, or even a way to match users across different services (such as your CRM).

Tags can be either a string or a number and you can assign them to a user. Common tags would be things like email, gender, or level in your game. Once a user has a tag, you can target notifications to that user by creating a Segment with a Filter that matches the tag, or by using the Tags targeting options in our API.

Tags are visible from <a class="dash-link" href="/docs/users-and-devices">All Users</a>. However, tags may only be added to users via the SDK or API at this time. They cannot be added via the dashboard.

----
### FAQ
<div class="label-type"><span class="label-all label-developers">For Developers</span></div>

#### How many custom tags can I create?
There is no limit on the number of custom tags you can create. However we recommend not assigning more than 20 tags per user if you have more than 3 million subscribers, otherwise notifications targeted by tag may be delivered slightly slower.

#### Are tags case sensitive?
Yes, both the key and the value are case sensitive. If you want them to be case insensitive make sure to force them as lowercase or uppercase when calling `sendTags` or any of our API REST functions.

#### How do I delete all tags from a user?
You must delete the tags by calling them individually.

#### Is it possible to get a user's location by the REST API?
You can use the [CSV export](ref:csv-export) API endpoint to get this data.
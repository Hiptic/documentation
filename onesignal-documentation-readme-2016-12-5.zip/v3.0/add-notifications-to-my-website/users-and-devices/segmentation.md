---
title: "Segments"
excerpt: "OneSignal Features - Segments & Filters\n<div class=\"tag-all tag-developers\">For Developers</div> <div class=\"tag-all tag-marketers\">For Marketers</div>"
---
Segments allow you to target a subset of your users with notifications. You may create any number of segments. Segments are created by adding **filters** based on certain data attributes.

When creating segments with multiple filters, the users in that segment are those that pass **all** the filters. In other words, results are the intersection of all filters combined together. This allows for precise user targeting.

## Accessing Segments
The Segments page is where you can view an overview of your segments and add / edit / delete segments:
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/fc8aa83-Screen_Shot_2016-09-21_at_10.14.27_PM.png",
        "Screen Shot 2016-09-21 at 10.14.27 PM.png",
        2462,
        1552,
        "#393a3f"
      ]
    }
  ]
}
[/block]
To view the individual users within a segment, use the segments drop-down filter in <a class="dash-link" href="/docs/users-and-devices#section-all-users-page">All Users</a>. Below is an example of viewing users within the 'Reached Level 50' segment:
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/50483f4-Screen_Shot_2016-10-07_at_1.59.26_PM.png",
        "Screen Shot 2016-10-07 at 1.59.26 PM.png",
        2110,
        1350,
        "#eceded"
      ]
    }
  ]
}
[/block]

----
## Default Segments
By default, OneSignal creates four different segments that you may target. 
[block:parameters]
{
  "data": {
    "h-0": "Segment",
    "h-1": "Description",
    "0-0": "`All`",
    "1-0": "`Active`",
    "2-0": "`Not Active`",
    "0-1": "<span class=\"label-all label-default\">Default</span> - all subscribed user devices",
    "1-1": "<span class=\"label-all label-default\">Default</span> - all subscribed user devices that have communicated with OneSignal servers in the last 7 days",
    "2-1": "<span class=\"label-all label-default\">Default</span> - all subscribed user devices that have **not** communicated with OneSignal servers in the last 7 days",
    "3-0": "`Engaged`",
    "3-1": "<span class=\"label-all label-default\">Default</span> - all subscribed user devices that have communicated with OneSignal servers in the last 7 days, and who have more than 4 sessions in your app."
  },
  "cols": 2,
  "rows": 4
}
[/block]
These default segments may be deleted, except the `All` segment.

----
## Creating Segments Using Filters
The users in a segment are determined based on one or more filters that determine the rules for which users are included in the segment (you cannot directly add users to segments). These filters are added together (technically `AND`, not `OR`), so the resulting segment is a list of users that match ALL filters you've added.

Within the Segments page, click the **New Segment** button. From here, name your segment and click 'Create':
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/3a49654-Screen_Shot_2016-09-21_at_10.17.40_PM.png",
        "Screen Shot 2016-09-21 at 10.17.40 PM.png",
        1478,
        644,
        "#30343e"
      ]
    }
  ]
}
[/block]
Your new segment will start without any filters. Click 'Add Filter' to begin filtering by different data attributes:
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/1a9cb2a-Screen_Shot_2016-09-21_at_10.18.15_PM.png",
        "Screen Shot 2016-09-21 at 10.18.15 PM.png",
        1776,
        414,
        "#eeeef2"
      ]
    }
  ]
}
[/block]
Several different **Filter Types** are available to select among ([see Filter Types, below](#section-filter-types)). Each Filter Type has different options, based on the type of data it is. For instance, in the following example the Country filter can be equal to a selectable country code. Clicking 'Save' adds the filter to the segment.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/bdccd1d-Screen_Shot_2016-09-21_at_10.34.38_PM.png",
        "Screen Shot 2016-09-21 at 10.34.38 PM.png",
        1782,
        460,
        "#ecedf0"
      ]
    }
  ]
}
[/block]
After a segment is saved, the user count is recalculated (this may show 'Loading...' for a short while). You can continue to add multiple filters in the same way:
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/2a86523-Screen_Shot_2016-09-21_at_10.50.43_PM.png",
        "Screen Shot 2016-09-21 at 10.50.43 PM.png",
        1782,
        542,
        "#ececef"
      ]
    }
  ]
}
[/block]
Each filter added will show how many users that filter applies to (for segments that contain more than 100,000 users, this number is approximate). The total user count is the intersection of all the filters:
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/a5ae5cc-Screen_Shot_2016-09-21_at_10.53.40_PM.png",
        "Screen Shot 2016-09-21 at 10.53.40 PM.png",
        1788,
        544,
        "#ececef"
      ]
    }
  ]
}
[/block]
----
## Deleting Segments
You can delete a segment by clicking the 'X' in the top right corner of the segment. A confirmation dialog will appear. If you click 'Ok', the segment will be deleted. 

----
## Filter Types
[block:parameters]
{
  "data": {
    "h-0": "Filter Type",
    "h-1": "Description",
    "0-0": "First Session Time",
    "1-0": "Last Session Time",
    "2-0": "Session Count",
    "3-0": "Total Usage Duration",
    "4-0": "Amount Spent",
    "5-0": "Purchased Item",
    "6-0": "Language Code",
    "7-0": "App Version",
    "8-0": "Device Type",
    "9-0": "User Tag",
    "10-0": "Location Radius",
    "11-0": "Is Device Rooted",
    "12-0": "Not subscribed to notifications from (other app)",
    "13-0": "Email",
    "14-0": "Country",
    "0-1": "The first date/time the user's device communicated with OneSignal servers.",
    "1-1": "The most recent date/time the user's device communicated with OneSignal servers.",
    "2-1": "The number of times the user's device has opened your app",
    "3-1": "The total number of seconds the user's device has had your app open",
    "4-1": "The amount the user has spent on In-App Purchases\n<span class=\"label-all label-ios\">iOS</span>, <span class=\"label-all label-android\">Android</span>, <span class=\"label-all label-amazon\">Amazon</span> - this data is available without additional work\n<span class=\"label-all label-windows\">Windows Phone</span>, <span class=\"label-all\">Web Push</span> - you must integrate in-app purchase data as a tag and filter based on that tag.",
    "5-1": "Filter by code of In-App Purchase item\n\n<span class=\"label-all label-ios\">iOS</span>, <span class=\"label-all label-android\">Android</span>, <span class=\"label-all label-amazon\">Amazon</span> - this data is available without additional work\n<span class=\"label-all label-windows\">Windows Phone</span>, <span class=\"label-all\">Web Push</span> - you must integrate in-app purchase data as a tag and filter based on that tag.",
    "6-1": "Language of user's device. See [Language & Localization](doc:language-localization) for possible codes.",
    "7-1": "Version of your app",
    "8-1": "Device operating system. Options:\n`Android`\n`iOS`\n`Windows Phone`\n`Chrome`\n`Firefox`\n`Safari`",
    "9-1": "<span class=\"label-all label-advanced\">Requires Data</span> - Tags you have added to the user's device. See [Data & Tags](doc:data-tags) for more details.",
    "10-1": "<span class=\"label-all label-advanced\">Requires Data</span> - Radius in meters from a particular geocoordinate (lat, long).",
    "11-1": "<span class=\"label-all label-android\">Android</span> - whether devices is rooted",
    "13-1": "<span class=\"label-all label-advanced\">Requires Data</span> - Hashed email of user (used for device matching)",
    "14-1": "Country the user's device was in the last time it communicated with OneSignal servers.",
    "12-1": "<span class=\"label-all label-advanced\">Advanced</span> - Whether user is not subscribed to notifications from another app you have access to."
  },
  "cols": 2,
  "rows": 15
}
[/block]



----
## FAQ
#### How do I add specific users to a Segment?
Because segments are created by filters, you will need to add a [tag](doc:data-tags) for each user you wish to be in a segment. Then, when creating the segment, add a "User tag" filter to your segment matching the same tag. 

#### Why do I have zero users in the All Segment?
See [All users are shown as not subscribed](doc:all-users-are-shown-as-not-subscribed) in our Troubleshooting guide.

#### How can I view all the users in a segment? 
Presently there is no way to view users by segment. We've gotten feedback on this and will be offering this capability in the future. In the meantime, you can follow our instructions on [Exporting Data](doc:exporting-data) to do your own analysis on your users.
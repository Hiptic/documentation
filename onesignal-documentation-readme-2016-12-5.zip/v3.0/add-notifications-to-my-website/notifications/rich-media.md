---
title: "Rich Media"
excerpt: "OneSignal Features - Rich Media\n<div class=\"tag-all tag-developers\">For Developers</div> <div class=\"tag-all tag-marketers\">For Marketers</div>"
---
OneSignal supports adding rich media to <span class="label-all label-android">Android</span> and <span class="label-all label-ios">iOS</span> notifications.

- [Android Customizations](doc:android-customizations).

## Rich Notifications
<div class="label-all label-type"><span class="label-ios">iOS 10+</span></div>

Apple introduced the concept of Rich Notifications in iOS 10, which allow deeper interaction with your app from the notification itself. These are great for short interactions that do not require the full app experience, and represent the growing importance of notifications to an app's user experience. 

Rich notifications side-step the process of tapping a notification, unlocking the phone, waiting for the app to load, and then interacting with the app, by creating opportunities for short interactions within the notification itself. 

OneSignal fully supports iOS 10 rich notifications. You can read more about Rich Notifications in our blog post on [iOS Customizations](https://onesignal.com/blog/sending-rich-notifications-in-ios10-with-onesignal/). 

At a technical level, there are two types of rich notifications: **content extensions** and **media attachments**. 

### Content Extensions
Content extensions allow developers to add custom views of their app within a notification. For instance, this notification lets the user view the relevant details of their calendar when responding to a meeting invite.
[block:html]
{
  "html": "<iframe src='https://gfycat.com/ifr/VibrantJollyAnnashummingbird' frameborder='0' scrolling='no' width='320' height='576' allowfullscreen></iframe>"
}
[/block]
### Media Attachments
Media attachments allow developers to attach URLs to relevant content. This is great for live events, photo tagging, and game updates, as well as all sorts of other visual content. Pictures speak a thousand words, and video more so, and with media attachments its never been easier to transport users into another place at the touch of a button. In the following example, a travel app could prompt users with visuals of a wonderful destination:
[block:html]
{
  "html": "<iframe src='https://gfycat.com/ifr/InsidiousSerpentineLacewing' frameborder='0' scrolling='no' width='320' height='576' allowfullscreen></iframe>"
}
[/block]
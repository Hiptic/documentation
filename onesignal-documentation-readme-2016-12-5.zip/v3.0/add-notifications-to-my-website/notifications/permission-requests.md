---
title: "Permission Messages & Requests"
excerpt: "OneSignal Features - Permission Messages & Requests\n<div class=\"tag-all tag-developers\">For Developers</div> <div class=\"tag-all tag-marketers\">For Marketers</div>"
---
Asking permission to send push notifications is one of the most important things your app or website can do. Getting permission means you have a channel with which to reach and re-engage your users, improving their experience and the value of your product. This is why *how* you ask for permissions is a crucial design decision for your app or website. 

## What are Permission Messages & Permission Requests?
<div class="label-type label-all"><span class="label-ios">iOS</span>, <span class="label-android">Android</span>, Web Push (<span class="label-chrome">Chrome</span>, <span class="label-firefox">Firefox</span>, <span class="label-safari">Safari</span>)</div>

**Permission Messages** are custom messages that a developer can present to users *prior to* triggering the **Permission Request** of the device / browser. In the following example the Permission Message is on the left, and a Permission Request is on the right:

<img src="https://files.readme.io/1049f40-Example-PermissionMessage-Request.png"/>

Using Permission Messages prior to Permission Requests is a best practice in both mobile and web push, because they increase the likelihood users will stay subscribed to your push notifications and find value in them. Permission Messages do three things:

1. Inform a user of the value of subscribing to push notifications. 

2. Capture user intent with buttons like 'Sure' and 'Not Now'.

3. Trigger a Permission Request, if users indicate intent.

Permission Messages are a 'soft request', meaning that they are not invoking the 'hard request' of the system Permission Request dialog. This is important because if a user denies a system Permission Request, the developer **is unable to prompt the user again**, unless the user goes through an multi-step process to re-enable these permissions. On the other hand, if a user dismisses a Permission Message, the app or website can still present them the option later on.

[block:parameters]
{
  "data": {
    "h-0": "Prompt",
    "0-0": "Permission Message",
    "1-0": "Permission Request",
    "h-1": "User Allows",
    "h-2": "User Doesn't Allow",
    "0-1": "Trigger Permission Request",
    "0-2": "Let user continue on",
    "1-1": "<span class=\"label-all label-yes\">Push Permission Granted</span>",
    "1-2": "<span class=\"label-all label-no\">Push Permission Denied</span>, app no longer able to trigger Permission Request"
  },
  "cols": 3,
  "rows": 2
}
[/block]
## OneSignal Permission Messages

<span class="label-all label-ios">iOS</span>, <span class="label-all label-android">Android</span> - OneSignal does not currently offer pre-made Permission Message templates for mobile apps. However you may design your own, and use the OneSignal API to trigger Permission Requests if the user taps to agree to your message.

<span class="label-all">Web Push (<span class="label-chrome">Chrome</span>, <span class="label-firefox">Firefox</span>, <span class="label-safari">Safari</span>)</span> - OneSignal offers three pre-made Permission Message templates, which may be triggered automatically upon arrival to your site, or programmatically at a time of your choosing. You may also design your own using the OneSignal API.

### Fullscreen Permission Message
<div class="label-type label-all">Web Push (<span class="label-chrome">Chrome</span>, <span class="label-firefox">Firefox</span>, <span class="label-safari">Safari</span>)</div>

The Fullscreen Permission Message is presented on top of your site (or in a pop-up window on HTTP sites), and is the most attention-grabbing message design. Users must dismiss it to continue using your site. 
<img src="https://i.imgur.com/KuQcvEV.png"/>
<img src="https://files.readme.io/19a6714-Fullscreen_PrePermission_Message_HTTPS.png"/>

Tutorials: [Trigger Fullscreen Permission Message](doc:customize-permission-messages#section-trigger-fullscreen-permission-message), [Customize Fullscreen Permission Message](doc:customize-permission-messages#section-customize-fullscreen-permission-message)

### Slidedown Permission Message
<div class="label-type label-all">Web Push (<span class="label-chrome">Chrome</span>, <span class="label-firefox">Firefox</span>, <span class="label-safari">Safari</span>)</div>

The Slidedown Permission Message displays on top of your site, in the top center of the browser. While not as attention-grabbing as the Full Screen Permission Message, users must still dismiss it to fully view your site.

<img src="https://files.readme.io/94b280b-Slidedown_PrePermission_Message.png"/>

Tutorials: [Trigger Slidedown Permission Message](doc:customize-permission-messages#section-trigger-slidedown-permission-message), [Customize Slidedown Permission Message](doc:customize-permission-messages#section-customize-slidedown-permission-message)

### Subscription Bell
<div class="label-type label-all">Web Push (<span class="label-chrome">Chrome</span>, <span class="label-firefox">Firefox</span>, <span class="label-safari">Safari</span>)</div>

The subscription bell is a small widget that resides in the lower left corner of your site, which users can click to bring up the Permission Request for your site. It is designed to be small enough that you may keep it on your site at all times, and does not require users to dismiss it (like the above designs).

<img src="https://files.readme.io/70a7cb8-Subscription_Button.png"/>

Tutorials: [Trigger Subscription Bell](doc:customize-permission-messages#section-trigger-subscription-bell), [Customize Subscription Bell](doc:customize-permission-messages#section-customize-subscription-bell)

## Recommended Reading
[Mobile UX Design: The Right Ways to Ask Users for Permissions](https://icons8.com/articles/mobile-ux-design-the-right-ways-to-ask-users-for-permissions/)

[Permission to Push: Using Custom In-App Messages to Get Push Opt-Ins From Users](http://info.localytics.com/blog/using-in-app-messages-for-push-message-opt-ins)

## FAQ

### How do I ask an iOS user to activate notifications later if they've already chosen NO the first time they were asked?

*The user will have to turn on notifications for your app in their device settings.*

It's not possible to show the prompt again, but some apps show a guide on how to enable notifications in the device settings. One common practice is to have your app show its own dialog first asking if a user wants notifications, and have them select "yes", before showing the native one. That way you don't lose your chance to show them the native prompt if they decide to change their mind later.
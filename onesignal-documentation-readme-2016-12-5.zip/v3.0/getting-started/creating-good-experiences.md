---
title: "Creating Good Experiences"
excerpt: ""
---
[block:html]
{
  "html": "<section class=\"cards\">\n  <div class=\"platform-card\">\n    <div class=\"card-image\">\n      <img src=\"https://files.readme.io/8154TKtTSteH02tdizUv_3ad1a8a2-37de-11e6-9e63-4a04d19c6de4.png\"/>\n    </div>\n    <footer>\n      <div class=\"left-footer\">\n        <span class=\"title\">Dashboard Walkthrough</span>\n      </div>\n      <div class=\"right-footer\">\n        <button class=\"getting-started\">GO</button>\n      </div>\n    </footer>\n  </div>\n  <div class=\"platform-card\">\n    <div class=\"card-image\">\n      <img src=\"https://files.readme.io/8154TKtTSteH02tdizUv_3ad1a8a2-37de-11e6-9e63-4a04d19c6de4.png\"/>\n    </div>\n    <footer>\n      <div class=\"left-footer\">\n        <span class=\"title\">Mobile SDK Setup</span>\n      </div>\n      <div class=\"right-footer\">\n        <button class=\"getting-started\">GO</button>\n      </div>\n    </footer>\n  </div>\n</section>"
}
[/block]
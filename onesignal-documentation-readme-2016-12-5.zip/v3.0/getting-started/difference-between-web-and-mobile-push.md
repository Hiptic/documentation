---
title: "Web and Mobile Push Differences"
excerpt: ""
---
## What are Mobile Push Notifications?

Mobile Notifications are notifications for applications that you have downloaded on your mobile device or tablet.

Mobile notifications require users to opt-in to notifications, and then will show up on the device's lock screen and notification center.

[Get started with Mobile Push Notifications](doc:mobile-sdk-setup) 
[block:callout]
{
  "type": "info",
  "body": "OneSignal also supports Push Notifications for [macOS apps](doc:macos-app-sdk-setup) and [Chrome Extensions](doc:chrome-extension-sdk-setup)."
}
[/block]
----
## What are Web Push Notifications?

Web push notifications are messages that come from a website. You get them on your desktop or device even when the website is not open in your browser. It is a new marketing channel to re engage your site visitors without knowing their email or other contact details.

Web Push Notifications generally work only on SSL sites (HTTPS), however OneSignal provides this feature for HTTP sites by assigning you a free HTTPS subdomain, which allows them to work as if your site were HTTPS.

[Get started with Web Push](doc:web-push-setup)
---
title: "Product Overview"
excerpt: "About OneSignal and how to get started"
---
## What is OneSignal?
OneSignal is a high volume and reliable push notification service for websites and mobile applications. We support all major native and mobile platforms by providing dedicated SDKs for each platform, a [RESTful server API](ref:create-notification), and an [online dashboard](https://onesignal.com) for marketers to design and send push notifications.

## What are Push Notifications?

Push notifications are a feature built into mobile devices, web browsers, and operating systems. They are an easy way for developers and marketers to send short, real-time, messages to users with announcements, news, or events.

----
## Why should I use OneSignal?

<span class="label-all label-benefit">Easy to use</span> - Implementing reliable interfaces to the GCM/FCM (Google) and APNS (Apple) protocols is difficult. There are open source projects to do it, but even the best ones break when message quantity begins to exceed 500,000 at a time. These protocols also change frequently, for instance, Apple recently released a new notification protocol and deprecated their old one.

<span class="label-all label-benefit">Advanced Functionality</span> - OneSignal provides marketing tools including A/B testing, segment targeting, localization, drip marketing, and conversion tracking.

<span class="label-all label-benefit">Platform Support</span> - OneSignal provides a single UI and API to deliver messages across iOS, Android, Amazon Fire, Windows Phone,  Chrome Apps, Safari, Chrome Web, and Firefox. 

<span class="label-all label-benefit">SDK Support</span> - OneSignal provides SDKs for nearly every major cross-platform mobile development environment, including Unity, PhoneGap, Cordova, Ionic, Intel XDK, React Native, Corona, Xamarin, Marmalade, and Adobe Air.

<span class="label-all label-benefit">Free</span> - Best of all, OneSignal is a **free** service that supports **unlimited** devices and notifications. 

----
## How do I get started?
<span class="label-all label-developers">Developers</span> - Go to our [Mobile](doc:mobile-sdk-setup) or [Web Push](doc:web-push-setup) setup guides to get started implementing OneSignal in your product today!

<span class="label-all label-marketers">Marketers</span> - Talk to your developers, and meanwhile get acquainted with [OneSignal Features](doc:dashboard) in our user manual.
[block:callout]
{
  "type": "info",
  "body": "If you have any questions feel free to drop us a line! Email us at [support@onesignal.com](mailto:support@onesignal.com) or chat with us using the bright red button!",
  "title": "Questions?"
}
[/block]
----
## OneSignal Screenshots
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/8154TKtTSteH02tdizUv_3ad1a8a2-37de-11e6-9e63-4a04d19c6de4.png",
        "3ad1a8a2-37de-11e6-9e63-4a04d19c6de4.png",
        "1863",
        "1270",
        "#7ab2b9",
        ""
      ]
    }
  ]
}
[/block]

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/3m1sWXiqS6eVDcvGzRlb_3a034174-37de-11e6-988e-be8065842f06.png",
        "3a034174-37de-11e6-988e-be8065842f06.png",
        "1863",
        "1048",
        "#52b6a2",
        ""
      ]
    }
  ]
}
[/block]

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/S0VP6ecTRj2D4JFs7lwO_3bc59ec6-37de-11e6-8739-d0ffc786d964.png",
        "3bc59ec6-37de-11e6-8739-d0ffc786d964.png",
        "1863",
        "1270",
        "#936e5e",
        ""
      ]
    }
  ]
}
[/block]

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/AvwLhbi0SB6AwBOGy9Qy_3d847c1e-37de-11e6-9068-d92b735da91e-1.png",
        "3d847c1e-37de-11e6-9068-d92b735da91e-1.png",
        "1432",
        "1182",
        "#e29b3d",
        ""
      ]
    }
  ]
}
[/block]
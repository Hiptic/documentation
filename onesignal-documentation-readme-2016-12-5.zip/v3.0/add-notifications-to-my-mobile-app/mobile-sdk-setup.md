---
title: "Mobile SDK Setup"
excerpt: "OneSignal supports 12 different ways to implement your mobile app\n<div class=\"tag-all tag-developers\">For Developers</div>"
---
[block:html]
{
  "html": "<style>\n  #content-container .content-body.grid-75 { width:100%; }\n  #content-container #content-toc.grid-25 { width:0%; display:none; }\n</style>"
}
[/block]
Select your platform below for setup instructions to add OneSignal to your app.

## Mobile Platform Support
[block:parameters]
{
  "data": {
    "h-0": "SDK",
    "h-1": "iOS",
    "h-2": "Android",
    "h-3": "Amazon Fire",
    "h-4": "Windows Phone 8.0",
    "h-5": "Windows Phone 8.1",
    "h-6": "Other",
    "0-0": "Native",
    "1-0": "[Unity](doc:unity-sdk-setup)",
    "2-0": "[PhoneGap](doc:phonegap-sdk-setup)",
    "3-0": "[Cordova](doc:cordova-sdk-setup)",
    "4-0": "[Ionic](doc:ionic-sdk-setup)",
    "5-0": "[Intel XDK](doc:intel-xdk-setup)",
    "6-0": "[React Native](doc:react-native-sdk-setup)",
    "8-0": "[Cocos2d-x](doc:cocos2d-x-sdk-setup)",
    "7-0": "[Corona](doc:corona-sdk-setup)",
    "9-0": "[Marmalade](doc:marmalade-sdk-setup)",
    "10-0": "[Adobe Air](doc:adobe-air-sdk-setup)",
    "11-0": "[Xamarin](doc:xamarin-sdk-setup)",
    "0-1": "<span class=\"label-all label-yes\">[Yes](doc:ios-sdk-setup) </span>",
    "0-2": "<span class=\"label-all label-yes\">[Yes](doc:android-sdk-setup)</span>",
    "0-3": "<span class=\"label-all label-yes\">[Yes](doc:amazon-sdk-setup) </span>",
    "0-4": "<span class=\"label-all label-yes\">[Yes](doc:windows-phone-sdk-setup)</span>",
    "0-5": "<span class=\"label-all label-yes\">[Yes](doc:windows-phone-sdk-setup)</span>",
    "1-1": "<span class=\"label-all label-yes\">Yes</span>",
    "1-2": "<span class=\"label-all label-yes\">Yes</span>",
    "1-3": "<span class=\"label-all label-yes\">Yes</span>",
    "2-1": "<span class=\"label-all label-yes\">Yes</span>",
    "2-2": "<span class=\"label-all label-yes\">Yes</span>",
    "2-3": "<span class=\"label-all label-yes\">Yes</span>",
    "3-1": "<span class=\"label-all label-yes\">Yes</span>",
    "3-2": "<span class=\"label-all label-yes\">Yes</span>",
    "3-3": "<span class=\"label-all label-yes\">Yes</span>",
    "4-3": "<span class=\"label-all label-yes\">Yes</span>",
    "4-2": "<span class=\"label-all label-yes\">Yes</span>",
    "4-1": "<span class=\"label-all label-yes\">Yes</span>",
    "5-1": "<span class=\"label-all label-yes\">Yes</span>",
    "5-2": "<span class=\"label-all label-yes\">Yes</span>",
    "5-3": "<span class=\"label-all label-yes\">Yes</span>",
    "6-1": "<span class=\"label-all label-yes\">Yes</span>",
    "6-2": "<span class=\"label-all label-yes\">Yes</span>",
    "6-3": "<span class=\"label-all label-yes\">Yes</span>",
    "7-1": "<span class=\"label-all label-yes\">Yes</span>",
    "7-2": "<span class=\"label-all label-yes\">Yes</span>",
    "2-5": "<span class=\"label-all label-yes\">Yes</span>",
    "3-5": "<span class=\"label-all label-yes\">Yes</span>",
    "4-5": "<span class=\"label-all label-yes\">Yes</span>",
    "5-5": "<span class=\"label-all label-yes\">Yes</span>",
    "7-3": "<span class=\"label-all label-yes\">Yes</span>",
    "8-1": "<span class=\"label-all label-yes\">Yes</span>",
    "8-2": "<span class=\"label-all label-yes\">Yes</span>",
    "9-1": "<span class=\"label-all label-yes\">Yes</span>",
    "9-2": "<span class=\"label-all label-yes\">Yes</span>",
    "8-3": "<span class=\"label-all label-yes\">Yes</span>",
    "9-3": "<span class=\"label-all label-yes\">Yes</span>",
    "10-1": "<span class=\"label-all label-yes\">Yes</span>",
    "10-2": "<span class=\"label-all label-yes\">Yes</span>",
    "11-2": "<span class=\"label-all label-yes\">Yes</span>",
    "11-3": "<span class=\"label-all label-yes\">Yes</span>",
    "11-1": "<span class=\"label-all label-yes\">Yes</span>",
    "1-5": "<span class=\"label-all label-yes\">Yes</span>",
    "1-4": "<span class=\"label-all label-no\">No</span>",
    "2-4": "<span class=\"label-all label-no\">No</span>",
    "3-4": "<span class=\"label-all label-no\">No</span>",
    "4-4": "<span class=\"label-all label-no\">No</span>",
    "5-4": "<span class=\"label-all label-no\">No</span>",
    "6-4": "<span class=\"label-all label-no\">No</span>",
    "7-4": "<span class=\"label-all label-no\">No</span>",
    "8-4": "<span class=\"label-all label-no\">No</span>",
    "9-4": "<span class=\"label-all label-yes\">Yes</span>",
    "10-4": "<span class=\"label-all label-no\">No</span>",
    "11-4": "<span class=\"label-all label-no\">No</span>",
    "6-5": "<span class=\"label-all label-no\">No</span>",
    "7-5": "<span class=\"label-all label-no\">No</span>",
    "8-5": "<span class=\"label-all label-no\">No</span>",
    "9-5": "<span class=\"label-all label-yes\">Yes</span>",
    "10-5": "<span class=\"label-all label-no\">No</span>",
    "11-5": "<span class=\"label-all label-no\">No</span>",
    "10-3": "<span class=\"label-all label-no\">No</span>",
    "12-0": "[Titanium](doc:titanium-sdk-setup)",
    "12-1": "<span class=\"label-all label-yes\">Yes</span>",
    "12-2": "<span class=\"label-all label-yes\">Yes</span>",
    "12-3": "<span class=\"label-all label-no\">No</span>",
    "12-4": "<span class=\"label-all label-no\">No</span>",
    "12-5": "<span class=\"label-all label-no\">No</span>"
  },
  "cols": 6,
  "rows": 13
}
[/block]
## Desktop Platform Support
[block:parameters]
{
  "data": {
    "0-0": "[MacOS Apps](doc:macos-app-sdk-setup)",
    "1-0": "[Chrome Apps / Extensions](doc:chrome-extension-sdk-setup)"
  },
  "cols": 1,
  "rows": 2
}
[/block]

[block:callout]
{
  "type": "info",
  "title": "Looking for Web Push?",
  "body": "OneSignal also supports sending push notifications via the web browser. For more information, read [Web Push Setup](doc:web-push-setup)."
}
[/block]
---
title: "Customize Notification Sounds"
excerpt: "Adding custom sounds to some or all of your notifications. Works with <span class=\"label-all label-ios\">iOS</span>, <span class=\"label-all label-android\">Android</span> (and derivatives like <span class=\"label-all label-amazon\">Amazon</span>), and <span class=\"label-all label-windows\">Windows Phone</span>.\n<div class=\"tag-all tag-developers\">For Developers</div>"
---
Custom sounds are a way to provide a more unique, branded experience for your app. 

You may add a custom sound with every notification you send, or you may add sounds to just certain types of notifications. For instance, a game with a title like "Jewel Breaker" may wish to have a jewel-like sound always play when sending notifications. Meanwhile, a social network may wish to only play sounds when the user receives a message from another user, to differentiate those notifications from more generic system notifications. 

## How to Add Custom Sounds

### 1. Create Sound Files
Be sure to create sound files according to the following rules. If the device cannot find the file in question, or if the file is not in a supported format, it will fall back to the default system notification sound.
[block:parameters]
{
  "data": {
    "h-0": "Platform",
    "h-1": "Extensions",
    "h-2": "Notes",
    "0-0": "<span class=\"label-all label-ios\">iOS</span>",
    "1-0": "<span class=\"label-all label-android\">Android</span>",
    "2-0": "<span class=\"label-all label-amazon\">Amazon</span>",
    "0-1": "`.wav` `.aiff` `.caf`",
    "1-1": "`.wav` `.mp3` `.ogg`",
    "2-1": "`.wav` `.mp3` `.ogg`",
    "3-0": "<span class=\"label-all label-windows\">Windows</span>",
    "0-2": "Apple is picky about file formats. Sounds must be encoded as Linear PCM, MA4 (IMA/ADPCM), µLaw, or aLaw. Must be less than 30 seconds.",
    "3-1": "`.wav` `.mp3` `.wma`",
    "3-2": "Must be less than 10 seconds"
  },
  "cols": 3,
  "rows": 4
}
[/block]
### 2. Add Sound Files to App
To adds sounds to notifications, you must include the sound files as resources within your app, as external URLs are not supported.

#### iOS
Add sound files to the appropriate location in your Xcode project depending on your SDK.
[block:parameters]
{
  "data": {
    "1-0": "PhoneGap, Cordova, Ionic",
    "2-0": "PhoneGap Build (PGB)",
    "h-1": "Folder",
    "h-0": "SDK",
    "2-1": "Add file to `www`. File **must** be called `beep.wav`",
    "1-1": "Add files to `Resources` directory within the Xcode project in `<project-root>/platforms/ios/project-name.xcodeproj`, and  (<a href=\"https://files.readme.io/Zn35Nuk8SAeADiXyRaTA_Cordova%20iOS%20custom%20notifiction%20sound.png\" target=\"_new\">see here</a>)",
    "0-0": "iOS Native",
    "0-1": "Add files to the Xcode project root. Make sure **Add to targets** is selected when adding files so that they are automatically add to the bundle resources (<a href=\"https://files.readme.io/9997e49-iOS_Resources.png\" target=\"_new\">see here</a>)",
    "3-0": "Unity",
    "3-1": "Add sounds anywhere in your Unity project, build your project, and then move those sounds to the Xcode project root.",
    "4-0": "Corona, Corona Enterprise",
    "4-1": "Add to root of Corona project folder",
    "5-0": "Marmalade",
    "5-1": "Add to project folder"
  },
  "cols": 2,
  "rows": 6
}
[/block]
#### Android (and derivatives like Amazon)
Add sound files to the appropriate folder in your project depending on your SDK. If the folder does not exist, create it.
[block:parameters]
{
  "data": {
    "h-1": "Folder",
    "h-0": "SDK",
    "h-2": "Notes",
    "0-0": "Android & Amazon Native",
    "0-1": "`res/raw`",
    "1-0": "PhoneGap, Cordova, Ionic",
    "2-0": "PhoneGap Build (PGB)",
    "1-1": "`<project-root>/platforms/android/res/raw/`",
    "2-1": "`<project-root>/locales/android/raw/`\n\nSee [this github link](https://github.com/phonegap/build/issues/472#issuecomment-172662620) for more details on the directory structure if you're having issues.",
    "2-2": "",
    "4-0": "Unity",
    "4-1": "`Assets/Plugins/Android/OneSignalConfig/res/raw`\n\n*NOTE: Your sound and icon file names must be lowercase and can't contain anything else except underscores and numbers.*",
    "5-0": "Corona",
    "5-1": "Not supported",
    "6-0": "Corona Enterprise",
    "6-1": "Add to root of Corona project folder",
    "7-0": "Marmalade",
    "7-1": "`android/res/raw`",
    "3-0": "Intel XDK",
    "3-1": "Not supported, however [there is a workaround here](https://software.intel.com/en-us/forums/intel-xdk/topic/680309#comment-1883224)."
  },
  "cols": 2,
  "rows": 8
}
[/block]
#### Windows Phone
If custom sound files are not found, the notification will not display at all. Custom sounds only work on Windows Phone 8.0 Update 3 or later.
[block:parameters]
{
  "data": {
    "h-0": "SDK",
    "h-1": "Folder",
    "0-0": "Native",
    "1-0": "Marmalade",
    "0-1": "Add a sound file to the root of your project. Then, right click on your sound file and select **Properties**. Under Advanced>Copy to Output Directory select \"Copy always\" (<a href=\"https://files.readme.io/d5LiCMiwSBiHb0tPrpTB_WindowPhone8.1_SDK_Custom_Sound.png\" target=\"_new\">see here</a>)",
    "1-1": "Add to project folder"
  },
  "cols": 2,
  "rows": 2
}
[/block]

### 3. Update SDK Files as Necessary
#### Marmalade
In your project's .mkb file, add the following inside the deployments section:
[block:parameters]
{
  "data": {
    "0-0": "<span class=\"label-all label-android\">Android</span>",
    "0-1": "`android-external-res=\"android/res\"\n`",
    "1-1": "`[Data]`\n`(data)`\n`notification.wav`",
    "2-1": "`[Data]`\n`(data)`\n`NAME OF EACH FILE HERE`\n\nList each notification sound file individually (e.g. `bell1.wav`). Alternatively, you can use a wildcard (`*.wav`) to include them all.",
    "1-0": "<span class=\"label-all label-ios\">iOS</span>",
    "2-0": "<span class=\"label-all label-windows\">Windows</span>"
  },
  "cols": 2,
  "rows": 3
}
[/block]
### 4. Send Notifications With Sounds

To send a notification with a sound, within <a class="dash-link" href="/docs/sending-notifications">New Message</a> open **Options**, and specify the sound file to play for each platform. 

<span class="label-all label-ios">iOS</span>, <span class="label-all label-windows">Windows</span> - Add the file extension when referencing the sound resource. For instance, `explode_sound.wav`. If you're using **PhoneGap Build (PGB)**, set the sound filename to `www/beep.wav`.


<img src="https://files.readme.io/497b99c-Screen_Shot_2016-09-28_at_8.06.18_PM.png" width="350"/>


<span class="label-all label-android">Android</span>, <span class="label-all label-amazon">Amazon</span> - Do **not** add the file extension when referencing the sound resource. For instance, `explode_sound`.

<img src="https://files.readme.io/99d9053-Screen_Shot_2016-09-28_at_8.08.34_PM.png" width="400"/>

<span class="label-all">REST API </span> - Instead of sending via the dashboard, you can send notifications with sounds in the REST API by using the appropriate parameter and file extension depending on your platform (see more in [Create notification REST API docs](ref:create-notification#section-appearance)).
[block:callout]
{
  "type": "warning",
  "body": "If you've very recently added a sound resource to your app, you may want to wait a few days before sending notifications using the sound. This is because it can take many days or even weeks for the majority of your users to update their apps to the latest version which contain your new sound resource. \n\nIf a user has an older version of your app without the sound resource and receives a notification that references it, they will hear only the default system notification sound.",
  "title": "New sounds take a while to propagate to all users"
}
[/block]
----
## FAQ
#### Can I set a default sound?
<span class="label-all label-android">Android</span> - If you add a sound file called `onesignal_default_sound` (e.g. `onesignal_default_sound.mp3`) to your app resources, OneSignal will use this sound for all notifications your app sends. You may still override this sound by referencing a different sound file within <a class="dash-link" href="/docs/sending-notifications">New Message</a> or the API.

<span class="label-all label-ios">iOS</span> - OneSignal does not support default sounds directly. However, a workaround is to create a <a class="dash-link" href="/docs/templates">Template</a> that references a sound file, and use that that template for every message you send.

#### Why is my notification not playing the custom sound file?
There are a few reasons why a sound may not play. 

- Sound file has an incorrect file extension
- Sound file is not encoded in a supported format
- Sound file is in the incorrect location
- Sound file is too long

Currently OneSignal does not log the resource incorrect issues, we're working on adding this to your logs.

<span class="label-all label-ios">iOS</span> - Read more in [Apple's documentation](https://developer.apple.com/library/content/documentation/NetworkingInternet/Conceptual/RemoteNotificationsPG/Chapters/IPhoneOSClientImp.html#//apple_ref/doc/uid/TP40008194-CH103-SW6) for tips on how to encode files and test them.

<span class="label-all label-android">Android</span> - Make sure that it is getting built into your APK by extracting it and making sure it is located in `res/raw/`.
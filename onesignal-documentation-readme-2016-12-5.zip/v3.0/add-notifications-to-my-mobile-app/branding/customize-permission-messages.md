---
title: "Customize Permission Messages"
excerpt: "Prompting users to opt-in to your notifications for <span class=\"label-all\">Web Push</span> (<span class=\"label-all label-chrome\">Chrome</span>, <span class=\"label-all label-firefox\">Firefox</span>, and <span class=\"label-all label-safari\">Safari</span>) notifications.\n<div class=\"tag-all tag-developers\">For Developers</div>"
---
To learn about Permission Messages and Permission Requests, including an overview and best practices, first read our [feature overview of Permission Messages & Requests](doc:permission-requests). 

## How to add custom Permission Messages
<div class="label-type label-all">Web Push (<span class="label-all label-chrome">Chrome</span>, <span class="label-all label-firefox">Firefox</span>, and <span class="label-all label-safari">Safari</span>)</div>

OneSignal offers three Permission Message designs: Fullscreen, Slidedown, and Subscription Bell. In addition, you may implement your own custom link, an example is below.

### Triggering Permission Messages
The following are ways to trigger Permission Messages within OneSignal.
[block:parameters]
{
  "data": {
    "h-0": "Permission Message",
    "1-0": "[Slidedown](#section-trigger-slidedown-permission-message)",
    "2-0": "[Fullscreen](#section-trigger-fullscreen-permission-message)",
    "h-1": "Triggering Notes",
    "1-1": "<span class=\"label-all label-optional\">Wordpress</span> - enabled by default.",
    "2-1": "Disabled by default. May be triggered manually on page load.",
    "h-2": "",
    "1-2": "",
    "2-2": "",
    "0-2": "",
    "0-0": "[Subscription Bell](#section-trigger-subscription-bell)",
    "0-1": "<span class=\"label-all label-yes\">HTTPS</span>, <span class=\"label-all label-no\">HTTP</span> - enabled by default.",
    "3-0": "[Custom Link](#section-trigger-custom-link-permission-message)",
    "3-1": "Create custom Permission Message."
  },
  "cols": 2,
  "rows": 4
}
[/block]
#### Trigger Subscription Bell
The subscription bell is enabled through the example code we provide in our web push setup guides ([HTTPS](doc:web-push-sdk-setup-https), [HTTP](doc:web-push-sdk-setup-http)). The parameter that automatically shows the subscription bell is the parameter `notifyButton: { enable: true }` when initializing the web SDK. 

We do not currently support a way to manually show or hide the subscription bell manually.


#### Trigger Slidedown Permission Message
The message can be triggered any time via [showHttpPrompt()](doc:web-push-sdk#section--showhttpprompt-).

<span class="label-all label-yes">HTTPS</span> - the Slidedown Permission Message can be triggered "automatically" if you call OneSignal.showHttpPrompt(). However, please note that this slidedown message cannot replace the browser's native prompt. The browser's native permission prompt must always be finally shown before the user can be subscribed.

<span class="label-all label-no">HTTP</span> - If you wish to automatically trigger the Slidedown Permission Message when a user arrives to your website, set `autoRegister: true` during initialization ([see example code](doc:web-push-sdk-setup-http#section-2-include-and-initialize-the-sdk)). When users click 'Allow', this message trigger a pop-up version of the Fullscreen Permission Message, which will trigger a Permission Request. 

<span class="label-all label-optional">Wordpress</span> - This feature is enabled by default, and can be turned off in the Configuration tab of the [Wordpress plugin](doc:wordpress). 

Note: there are several reasons [why a user may *not* see the Permission Message](#section-why-isn-t-my-permission-message-showing-up-), and [why a user may see the Permission Message frequently](#section-why-does-my-permission-message-keep-showing-up-).


#### Trigger Fullscreen Permission Message
You may create your own button or link that calls [registerForPushNotifications()](https://documentation.onesignal.com/v3.0/docs/web-push-sdk#section--registerforpushnotifications-) to trigger the Fullscreen Permission Message.

<span class="label-all label-yes">HTTPS</span> - You may also programmatically trigger the Fullscreen Permission Message by passing the flag `modalPrompt: true` to the API call [registerForPushNotifications()](https://documentation.onesignal.com/v3.0/docs/web-push-sdk#section--registerforpushnotifications-). 

<span class="label-all label-no">HTTP</span> - Due to browsers blocking popups, your site may not programmatically trigger the Fullscreen Permission Message. The Fullscreen Permission Message will appear as a pop-up window when users click either our [Subscription Bell](#section-subscription-bell), or a button or link you create that triggers it. 


#### Trigger Custom Link Permission Message
Instead of using our pre-built templates, you may also choose to create your own Permission Message with a link. 

<span class="label-all label-yes">HTTPS</span> - this link prompts a Permission Request when clicked. 

<span class="label-all label-no">HTTP</span> - this link prompts a pop-up window version of the [Fullscreen Permission Message](#section-trigger-fullscreen-permission-message) when clicked.

We highly recommend only showing this custom Permission Message and link if a) the user is unsubscribed, and b) the user's browser supports notifications. Below is an example of code that does this:
[block:code]
{
  "codes": [
    {
      "code": "<body>\n    <a href=\"#\" id=\"subscribe-link\" style=\"display: none;\">Subscribe to Notifications</a>\n    <script>\n        function subscribe() {\n            OneSignal.push([\"registerForPushNotifications\"]);\n            event.preventDefault();\n        }\n\n        var OneSignal = OneSignal || [];\n        /* This example assumes you've already initialized OneSignal */\n        OneSignal.push(function() {\n            // If we're on an unsupported browser, do nothing\n            if (!OneSignal.isPushNotificationsSupported()) {\n                return;\n            }\n            OneSignal.isPushNotificationsEnabled(function(isEnabled) {\n                if (isEnabled) {\n                    // The user is subscribed to notifications\n                    // Don't show anything\n                } else {\n                    document.getElementById(\"subscribe-link\").addEventListener('click', subscribe);\n                    document.getElementById(\"subscribe-link\").style.display = '';\n                }\n            });\n        });\n    </script>\n</body>",
      "language": "html",
      "name": "HTML"
    }
  ]
}
[/block]
----

### Customizing Permission Message content
To create the most compelling messages for why users should subscribe to your push notifications, you need to customize your Permission Message content. You may enter text in your own language, but please note all fields are limited in length (usually to one line of text). If you have chosen to implement a [Custom Link](#section-trigger-custom-link-permission-message) (above), you may customize it any way you like.
[block:parameters]
{
  "data": {
    "h-0": "Permission Message",
    "h-1": "Customizability Notes",
    "h-2": "",
    "1-0": "Slidedown",
    "2-0": "Fullscreen",
    "1-1": "Icon, text, and buttons",
    "2-1": "Icon, text, and buttons",
    "0-0": "Subscription Bell",
    "0-1": "Color and text"
  },
  "cols": 2,
  "rows": 3
}
[/block]
#### Customize Subscription Bell
The colors and text of the Subscription Bell can be customized, however the icon itself cannot.

<span class="label-all label-optional">Wordpress</span> - customizing all of the features below can be found on the Configuration tab of our plugin.

<span class="label-all label-yes">HTTPS</span>, <span class="label-all label-no">HTTP</span> - Use the `notifyButton` parameter in your web SDK initialization options.
[block:code]
{
  "codes": [
    {
      "code": "// Do NOT call init() twice\nOneSignal.push([\"init\", {\n    /* Your other init options here */\n    notifyButton: {\n        enable: true, /* Required to use the notify button */\n        size: 'medium', /* One of 'small', 'medium', or 'large' */\n        theme: 'default', /* One of 'default' (red-white) or 'inverse\" (white-red) */\n        position: 'bottom-right', /* Either 'bottom-left' or 'bottom-right' */\n        offset: {\n            bottom: '0px',\n            left: '0px', /* Only applied if bottom-left */\n            right: '0px' /* Only applied if bottom-right */\n        },\n        prenotify: true, /* Show an icon with 1 unread message for first-time site visitors */\n        showCredit: false, /* Hide the OneSignal logo */\n        text: {\n            'tip.state.unsubscribed': 'Subscribe to notifications',\n            'tip.state.subscribed': \"You're subscribed to notifications\",\n            'tip.state.blocked': \"You've blocked notifications\",\n            'message.prenotify': 'Click to subscribe to notifications',\n            'message.action.subscribed': \"Thanks for subscribing!\",\n            'message.action.resubscribed': \"You're subscribed to notifications\",\n            'message.action.unsubscribed': \"You won't receive notifications again\",\n            'dialog.main.title': 'Manage Site Notifications',\n            'dialog.main.button.subscribe': 'SUBSCRIBE',\n            'dialog.main.button.unsubscribe': 'UNSUBSCRIBE',\n            'dialog.blocked.title': 'Unblock Notifications',\n            'dialog.blocked.message': \"Follow these instructions to allow notifications:\"\n        }\n    }\n}]);",
      "language": "javascript"
    }
  ]
}
[/block]
##### Customizing Subscription Bell Colors

You can override the theme's colors by entering your own. Values are strings which are then interpreted by CSS, so any CSS-valid color works as each value. For example, `white`, `#FFFFFF`, `#FFF`, `rgb(255, 255, 255)`, `rgba(255, 255, 255, 1.0)`, and `transparent` are all valid values.
[block:code]
{
  "codes": [
    {
      "code": "// Do NOT call init() twice\nOneSignal.push([\"init\", {\n  // Your other init options here\n  notifyButton: {\n    enable: true, // Required to use the notify button\n    // Your other notify button settings here\n    colors: { // Customize the colors of the main button and dialog popup button\n      'circle.background': 'rgb(84,110,123)',\n      'circle.foreground': 'white',\n      'badge.background': 'rgb(84,110,123)',\n      'badge.foreground': 'white',\n      'badge.bordercolor': 'white',\n      'pulse.color': 'white',\n      'dialog.button.background.hovering': 'rgb(77, 101, 113)',\n      'dialog.button.background.active': 'rgb(70, 92, 103)',\n      'dialog.button.background': 'rgb(84,110,123)',\n      'dialog.button.foreground': 'white'\n    },\n  }\n}]);",
      "language": "javascript"
    }
  ]
}
[/block]
##### Hiding the Subscription Bell
To hide the subscription bell after subscribing, or only show it on certain pages, be sure to return the value `false` *or* a `Promise` that resolves to the value `false` in the `displayPredicate` function during initialization. This function is evaluated before the subscription bell is shown. You may return any other value to show the subscription bell.

Here is an example *hiding* the subscription bell if the user is subscribed:
[block:code]
{
  "codes": [
    {
      "code": "// Do NOT call init() twice\n// This is just an example\nOneSignal.push([\"init\", {\n    /* Your other init options here */\n    notifyButton: {\n        /* Your other notify button settings here ... */\n        enable: true,\n        displayPredicate: function() {\n            return OneSignal.isPushNotificationsEnabled()\n                .then(function(isPushEnabled) {\n                    /* The user is subscribed, so we want to return \"false\" to hide the notify button */\n                    return !isPushEnabled;\n                });\n        },\n    }\n}]);",
      "language": "javascript"
    }
  ]
}
[/block]

#### Customize Slidedown Permission Message

<span class="label-all label-yes">HTTPS</span>, <span class="label-all label-no">HTTP</span> - You may customize the text in the Slidedown Permission Message by including the contents in your initialization function:
[block:code]
{
  "codes": [
    {
      "code": "// Do NOT call init() twice\nOneSignal.push([\"init\", {\n    // Your other init options here\n    promptOptions: {\n        /* These prompt options values configure both the HTTP prompt and the HTTP popup. */\n        /* actionMessage limited to 90 characters */\n        actionMessage: \"We'd like to show you notifications for the latest news and updates.\",\n        /* acceptButtonText limited to 15 characters */\n        acceptButtonText: \"ALLOW\",\n        /* cancelButtonText limited to 15 characters */\n        cancelButtonText: \"NO THANKS\"\n    }\n}]);",
      "language": "javascript"
    }
  ]
}
[/block]
<span class="label-all label-optional">Wordpress</span> - You may customize the text in the Slidedown Permission Message by following these steps:

1. Visit the *OneSignal Push* page of our WordPress plugin, and click the *Configuration* tab. 

2. Visit the section titled *Popup Settings*.

3. The fields *Action Message*, *Accept Button Text*, and *Cancel Button Text* are used for the drop-down prompt.

4. The notification icon can be set from <a class="dash-link" href="/docs/platforms#section-app-settings">App Settings</a> by clicking *Configure* next to the Google Chrome & Mozilla Firefox platform settings.

<span class="label-all label-yes">HTTPS</span>, <span class="label-all label-no">HTTP</span>, <span class="label-all label-optional">Wordpress</span> - You may customize the image shown in the Slidedown Permission Message by editing the **Default Notification Icon URL** in your dashboard:
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/d9ec957-kJVTvSP.png",
        "kJVTvSP.png",
        2268,
        1308,
        "#7a7b7a"
      ]
    }
  ]
}
[/block]
If you do not have a Default Notification Icon URL set, OneSignal will show a generic icon.

#### Customize Fullscreen Permission Message
To customize the text, buttons, and images in the Fullscreen Permission Message, use the `promptOptions` parameter in your [init()](web-push-sdk#section--init-) options. You may change all text except the URL on the notification image (subdomain.onesignal.com). You may enter text in your own language, but please note all fields are limited in length (usually to one line of text). Any fields you do not define will use their defaults.
[block:code]
{
  "codes": [
    {
      "code": "// Do NOT call init() twice\nOneSignal.push([\"init\", {\n    // Your other init options here\n    promptOptions: {\n        /* Change bold title, limited to 30 characters */\n        siteName: 'OneSignal Documentation',\n        /* Subtitle, limited to 90 characters */\n        actionMessage: \"We'd like to show you notifications for the latest news and updates.\",\n        /* Example notification title */\n        exampleNotificationTitle: 'Example notification',\n        /* Example notification message */\n        exampleNotificationMessage: 'This is an example notification',\n        /* Text below example notification, limited to 50 characters */\n        exampleNotificationCaption: 'You can unsubscribe anytime',\n        /* Accept button text, limited to 15 characters */\n        acceptButtonText: \"ALLOW\",\n        /* Cancel button text, limited to 15 characters */\n        cancelButtonText: \"NO THANKS\"\n    }\n}]);",
      "language": "javascript"
    }
  ]
}
[/block]
**Customizing "Click Allow":** Set the `autoAcceptTitle` of `promptOptions`:
[block:code]
{
  "codes": [
    {
      "code": "// Do NOT call init() twice\nOneSignal.push([\"init\", {\n    // Your other init options here\n    promptOptions: {\n        /* Change click allow text, limited to 30 characters */\n        autoAcceptTitle: 'Click Allow',\n        /* ... */\n    }\n}]);",
      "language": "javascript"
    }
  ]
}
[/block]
----

## How to trigger Permission Requests
<div class="label-type label-all"><span class="label-yes">HTTPS Only</span></div>

Permission Requests appear directly from the browser asking users to allow notification permissions. Users are directly subscribed after clicking Allow, without any further interaction required.

<img src="https://files.readme.io/494fb59-Browser_Push_Permission_Request.png"/>

The browser permission request can be automatically shown to site visitors, or be triggered programmatically to be shown at a later time. 

#### Automatically triggering Permission Requests
The browser permission request is automatically shown when:
- Your site is an <span class="label-all label-yes">HTTPS</span> site
- Your OneSignal JavaScript initialization settings contains the `autoRegister: true` property
  - See step 2 of our [Web Push SDK Setup (HTTPS)](doc:web-push-sdk-setup-https) for a code example of where to place the `autoRegister: true` property
- The user *has not clicked* the **X** button to dismiss the request
  - Users who dismiss the prompt will not see it again until they restart their browser

<span class="label-all label-optional">Wordpress</span> - In the Configuration tab of our WordPress plugin, you must additionally enable *Automatically prompt new site visitors to subscribe to push notification*.

#### Manually triggering Permission Requests
The browser permission request can be triggered manually via [registerForPushNotifications()](doc:web-push-sdk). You may wish to do this after presenting users a Permission Message, such as the Slidedown Permission Message. Note that Permissions Requests [may not always appear](#section-why-isn-t-my-permission-request-showing-up-).

## How to customize Permission Requests
Permission Requests are shown by the device or browser and are not customizable. All devices and browsers present the request in the appropriate language.



## FAQ

### Why does my Permission Message keep showing up?
The Slidedown Permission Message is automatically shown when:
- Your OneSignal JavaScript initialization settings contains the `autoRegister: true` property. On HTTPS sites, this automatically triggers the browser's native permission prompt. See step 2 of our [Web Push SDK Setup (HTTP)](doc:web-push-sdk-setup-http) guide for a code example of where to place the `autoRegister` property. On HTTP sites, this automatically shows the slidedown pre-permission message prompt for a similar effect.
- The user visited your page in a new browser tab or window. Users navigating between links on the same browser tab or refreshing the same page will not trigger the drop-down prompt
- All of the reasons listed below in "Why isn't my Permission Message showing up?" (next section) must not occur. If any of those reasons are true as well, we do not show the Slidedown Permission Message.

When the first two conditions are true (and none of the conditions listed in the next section are true), the slidedown pre-permission message will slide down from the top as soon as the page loads, covering other page elements. On a mobile browser, the message will slide up from the bottom.


### Why isn't my Permission Message showing up?
#### Slidedown Permission Message
Even if you trigger `showHttpPrompt()`, it may not always show the message. The message *will not be shown* if any of the following are true:

- The user previously dismissed the message by clicking the "No Thanks" button
- The user has blocked notifications for `your-subdomain.onesignal.com`
- The user is already successfully subscribed to notifications
  A user who is already subscribed does not need to re-subscribe.
- You have manually opted out the user via our `setSubscription(false)` API

If you've intentionally disabled a user's permissions by calling `setSubscription(false)`, you must manually opt the user back in by calling `setSubscription(true)`; our drop-down prompt will not show.

If the prompt is not shown, the `showHttpPrompt()` method returns a Promise that resolves to a string value briefly describing the reason the prompt was not shown. You may also enable debug logging for the SDK via `OneSignal.log.setLevel('trace');` to see explanations of why the prompt is not shown.

### Why isn't my Permission Request showing up?
A Permission Request may not show when triggered if one of the three conditions is true:

- The user has already allowed notifications
- The user is already subscribed
- The user blocked notifications
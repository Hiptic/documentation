---
title: "Android Customizations"
excerpt: "Customizing <span class=\"label-all label-android\">Android</span> notifications with your app icons, colors, and style\n<div class=\"tag-all tag-developers\">For Developers</div>"
---
## Custom Notification Icons
Read more in [Customize Notification Icons](doc:customize-notification-icons) 

----
## Action Buttons
Android 4.1 and newer devices support actions buttons. You can specify up to 3 buttons that will display below your notification content. Read [Customize Action Buttons](doc:customize-action-buttons) for more.

----
## Big Picture
Android 4.1 and newer devices support a big picture that will show below your notification text when it is expanded. It can be located in your drawable folders, your assets folder in your app, or it can be loaded remotely from a server with a URL.

The image should be a 2:1 aspect ratio otherwise Android will crop your image. Android not have a size limit however see our recommended minimum, balanced, and maximum sizes below.
* Minimum - 512x256
* Balanced - 1024x512
* Maximum - 2048x1024
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/bL7zcy7gScW42PDyFdhf_AndroidActionButtonsImageLinks-1.png",
        "AndroidActionButtonsImageLinks-1.png",
        "800",
        "292",
        "#438ed9",
        ""
      ]
    }
  ]
}
[/block]
----
## Background Images
Using our latest SDK you can add a background image to all your notifications by adding a image file named `onesignal_bgimage_default_image` to your `res/drawable-xxxhdpi` folder. The size should be 2176x256 (17:2) to fit all devices including landscape mode. In portrait mode the user may only see 1280x256 (5:1) on some devices so do design your image accordingly.

Use `onesignal_bgimage_notif_title_color` and `onesignal_bgimage_notif_body_color` in your `values/colors.xml` to set text colors to match your image.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/ge1mfexQ0y8yCHSn5sag_CustomAndroid_Images_Blog.gif",
        "CustomAndroid_Images_Blog.gif",
        600,
        1067,
        "#323232",
        ""
      ]
    }
  ]
}
[/block]
Example `color.xml` file. Title is set to red and the body is set to green below.
[block:code]
{
  "codes": [
    {
      "code": "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<resources>\n    <color name=\"onesignal_bgimage_notif_title_color\">#FFFF0000</color>\n    <color name=\"onesignal_bgimage_notif_body_color\">#FF00FF00</color>\n</resources>",
      "language": "xml"
    }
  ]
}
[/block]
The image by default will be top left aligned, you may change it to be right aligned by setting the key `onesignal_bgimage_notif_image_align` to `right` in your `strings.xml`.
Example:

[block:code]
{
  "codes": [
    {
      "code": "<resources>\n    <string name=\"onesignal_bgimage_notif_image_align\">right</string>\n</resources>",
      "language": "xml"
    }
  ]
}
[/block]
In additional to locally setting the image in your app, it can be with the `android_background_layout` field through the [Create notification](ref:create-notification) REST API call.
[block:callout]
{
  "type": "warning",
  "body": "The small and large icons will be overridden by the background image. Include it as part of your image if you need it to show still."
}
[/block]
----
## Notification Stacking
Simply enter any value in the “Group Key” field under Options>Android on the New Message page on the dashboard. This is the `android_group` on the REST API. Notifications with the same group key will automatically stack on the device.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/GnEw4PmmSVWWfgX5Uc3W_stacked_notification.png",
        "stacked_notification.png",
        "900",
        "460",
        "#886865",
        ""
      ]
    }
  ]
}
[/block]
- Stacking works on all our latest SDKs and on Android devices all the way back to Android 2.3.
- If a group is set on a notification the changes made with `NotificationCompat.Builder` in the `NotificationExtenderService` will be ignored. This restriction will be fixed in a future SDK version.
- Also works on Amazon devices, set the group key listed under the amazon settings as well.

----
## App Icon Badge Counts
The OneSignal SDK automatically sets the badge count on your app to the number of notifications that are currently in the notification shade. If you want to disable this you can add the following to your `AndroidManifest.xml`.
[block:code]
{
  "codes": [
    {
      "code": "<application ...>\n   <meta-data android:name=\"com.onesignal.BadgeCount\" android:value=\"DISABLE\" />\n</application>",
      "language": "xml"
    }
  ]
}
[/block]
You can remove the badge permissions with the following entries.
[block:code]
{
  "codes": [
    {
      "code": "<uses-permission android:name=\"com.sec.android.provider.badge.permission.READ\" tools:node=\"remove\" />\n<uses-permission android:name=\"com.sec.android.provider.badge.permission.WRITE\" tools:node=\"remove\" />\n<uses-permission android:name=\"com.htc.launcher.permission.READ_SETTINGS\" tools:node=\"remove\" />\n<uses-permission android:name=\"com.htc.launcher.permission.UPDATE_SHORTCUT\" tools:node=\"remove\" />\n<uses-permission android:name=\"com.sonyericsson.home.permission.BROADCAST_BADGE\" tools:node=\"remove\" />\n<uses-permission android:name=\"com.sonymobile.home.permission.PROVIDER_INSERT_BADGE\" tools:node=\"remove\" />\n<uses-permission android:name=\"com.anddoes.launcher.permission.UPDATE_COUNT\" tools:node=\"remove\" />\n<uses-permission android:name=\"com.majeur.launcher.permission.UPDATE_BADGE\" tools:node=\"remove\" />\n<uses-permission android:name=\"com.huawei.android.launcher.permission.CHANGE_BADGE\" tools:node=\"remove\"/>\n<uses-permission android:name=\"com.huawei.android.launcher.permission.READ_SETTINGS\" tools:node=\"remove\" />\n<uses-permission android:name=\"com.huawei.android.launcher.permission.WRITE_SETTINGS\" tools:node=\"remove\" />",
      "language": "xml"
    }
  ]
}
[/block]
You will also need to add the the following to your manifest tag at the top of the file.
`xmlns:tools="http://schemas.android.com/tools"`
[block:code]
{
  "codes": [
    {
      "code": "<manifest xmlns:android=\"http://schemas.android.com/apk/res/android\"\n          xmlns:tools=\"http://schemas.android.com/tools\"\n          package=\"com.onesignal.example\">\n          ...\n</manifest>",
      "language": "xml"
    }
  ]
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "",
      "language": "text"
    }
  ]
}
[/block]
----
## Notification Sounds
Read more in [Customize Notification Sounds](doc:customize-notification-sounds) 

----
## Background Data and Notification Overriding
OneSignal supports sending additional data along with a notification as key value pairs. You can read this additional data when a notification is opened by adding a [setNotificationOpenedHandler](doc:android-native-sdk#section--setnotificationopenedhandler-) instead.

However if you want to one of the following continue with the instructions below.

* Receive data in the background with or without displaying a notification.
* Override specific notification settings depending on client side app logic such as custom accent color, vibration pattern, or other any other `NotificationCompat` options available.


1. Create a class that extends `NotificationExtenderService` and implement the `onNotificationProcessing` method.

[block:code]
{
  "codes": [
    {
      "code": "import com.onesignal.OSNotificationPayload;\nimport com.onesignal.NotificationExtenderService;\n\npublic class NotificationExtenderBareBonesExample extends NotificationExtenderService {\n   @Override\n   protected boolean onNotificationProcessing(OSNotificationReceivedResult receivedResult) {\n     \t// Read properties from result.\n     \n      // Return true to stop the notification from displaying.\n      return false;\n   }\n}",
      "language": "java"
    }
  ]
}
[/block]
2.  Add the following to your `AndroidManifest.xml`.

*Replace 'YOUR_CLASS_NAME' with the class name you used above.*
[block:code]
{
  "codes": [
    {
      "code": "<service\n   android:name=\".YOUR_CLASS_NAME\"\n   android:exported=\"false\">\n   <intent-filter>\n      <action android:name=\"com.onesignal.NotificationExtender\" />\n   </intent-filter>\n</service>",
      "language": "xml"
    }
  ]
}
[/block]
3. To override or extend specific notification properties call `displayNotification` with `OverrideSettings`.
[block:code]
{
  "codes": [
    {
      "code": "import android.support.v4.app.NotificationCompat;\n\nimport com.onesignal.OSNotificationPayload;\nimport com.onesignal.NotificationExtenderService;\n\nimport java.math.BigInteger;\n\npublic class NotificationExtenderExample extends NotificationExtenderService {\n   @Override\n   protected boolean onNotificationProcessing(OSNotificationReceivedResult receivedResult) {\n      OverrideSettings overrideSettings = new OverrideSettings();\n      overrideSettings.extender = new NotificationCompat.Extender() {\n         @Override\n         public NotificationCompat.Builder extend(NotificationCompat.Builder builder) {\n            // Sets the background notification color to Green on Android 5.0+ devices.\n            return builder.setColor(new BigInteger(\"FF00FF00\", 16).intValue());\n         }\n      };\n\n      OSNotificationDisplayedResult displayedResult = displayNotification(overrideSettings);\n\t\t\tLog.d(\"OneSignalExample\", \"Notification displayed with id: \" + displayedResult.androidNotificationId);\n\n      return true;\n   }\n}",
      "language": "java"
    }
  ]
}
[/block]
**Additional Notes**
* `NotificationExtenderService` is an Android `IntentService` so please do all your work synchronously. A wake lock is obtained so the device will not sleep while you're processing the payload.
*  By default `BigTextStyle` is set as style so to change the body text you must override the style with the following:
```
.setStyle(new NotificationCompat.BigTextStyle().bigText(message))
```
* If you plan on setting a big picture make sure to check for this before setting the `BigTextStyle` style above.

----
## Resume last Activity when opening a Notification
Add the following code to the top of `onCreate` in your launcher `Activity`.
[block:code]
{
  "codes": [
    {
      "code": "private static boolean activityStarted;\n\n@Override\nprotected void onCreate(Bundle savedInstanceState) {\n  super.onCreate(savedInstanceState);\n\n  if (   activityStarted\n      && getIntent() != null\n      && (getIntent().getFlags() & Intent.FLAG_ACTIVITY_REORDER_TO_FRONT) != 0) {\n  \tfinish();\n  \treturn;\n  }\n  \n  activityStarted = true;\n}",
      "language": "java"
    }
  ]
}
[/block]
**Additional information:**
By default OneSignal calls `startActivity` with the following intent flags.
```
Intent.FLAG_ACTIVITY_REORDER_TO_FRONT | Intent.FLAG_ACTIVITY_NEW_TASK
```
----
## Changing the open action of a notification
By default OneSignal will open or resume your launcher Activity when a notification is tapped on. You can disable this behavior by adding the meta-data tag `com.onesignal.NotificationOpened.DEFAULT` set to `DISABLE` inside your application tag in your `AndroidManifest.xml`.
[block:code]
{
  "codes": [
    {
      "code": "<application ...>\n   <meta-data android:name=\"com.onesignal.NotificationOpened.DEFAULT\" android:value=\"DISABLE\" />\n</application>",
      "language": "xml"
    }
  ]
}
[/block]
Make sure you are initializing `OneSignal` with [setNotificationOpenedHandler](doc:android-native-sdk#section--setnotificationopenedhandler-) in the `onCreate` method in your `Application` class. You will need to call `startActivity` from this callback.

----
## Example Project

We have an example project with a custom sound, small icon, and large icon [you can try for reference.](https://github.com/one-signal/OneSignal-Android-SDK/tree/master/Examples)

----
## Android SDK API Reference
See our [Android Native](android-native-sdk) SDK reference for more information.
---
title: "Customize Notification Icons"
excerpt: "Adding custom icons to some or all of your notifications. Works with <span class=\"label-all label-android\">Android</span> (and derivatives like <span class=\"label-all label-amazon\">Amazon</span>).\n<div class=\"tag-all tag-developers\">For Developers</div>"
---
Icons are a way to provide a more unique, branded experience for your <span class="label-all label-android">Android</span> and <span class="label-all label-amazon">Amazon</span> app. Note that <span class="label-all label-ios">iOS</span> doesn't support custom icons, as it uses the app icon for all notifications.

You may add a default icon that appears with every notification you send, or you may add icons to just certain types of notifications. The below tutorial shows you how to do both.

## About Notification Icons
Android supports both Small and Large Notification Icons. 

**Small Notification Icons** - by default our SDK automatically uses either a white bell icon or your App's launcher icon. Starting with Android 5, the OS forces Small Notification Icons to be all white when your app targets Android API 21+. If you don't make a correct icon, it will most likely be displayed as a bell or solid white icon in the status bar.

**Large Notification Icons** - The large notification icon will show up to the left of the notification text on Android 3.0+ devices. If you do not set a large icon, the small icon will be used instead. OneSignal will auto scale large notification icons for you to prevent the icon from being cropped. 
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/9c153e7-Android_Notification_Layouts.png",
        "Android Notification Layouts.png",
        744,
        700,
        "#232627"
      ]
    }
  ]
}
[/block]
## How to Add Default Icons
We strongly recommend adding default icons to every <span class="label-all label-android">Android</span> and <span class="label-all label-amazon">Amazon</span> app.

### 1. Generate Icons
#### Option A: Using Android Asset Studio
<div class="label-type label-all"><span class="label-recommended">Recommended</span></div>

To quickly and easily generate small icons with the correct settings, we recommend using the [Android Asset Studio](http://romannurik.github.io/AndroidAssetStudio/icons-notification.html#source.space.trim=1&source.space.pad=0&name=ic_stat_onesignal_default). Use `ic_stat_onesignal_default` as the name. 

#### Option B: Manually Create Icons
<div class="label-type label-all"><span class="label-notrec">Not Recommended</span></div>

If you prefer to create your own icons, you must make your icons the following size and colors:
[block:parameters]
{
  "data": {
    "h-1": "Size (px)",
    "h-0": "Type",
    "h-2": "",
    "0-0": "Small Notification Icon",
    "1-0": "Small Notification Icon",
    "2-0": "Small Notification Icon",
    "3-0": "Small Notification Icon",
    "4-0": "Large Notification Icon",
    "0-1": "24x24",
    "1-1": "36x36",
    "2-1": "48x48",
    "3-1": "72x72",
    "0-2": "",
    "1-2": "",
    "2-2": "",
    "3-2": "",
    "4-1": "256x256",
    "4-2": ""
  },
  "cols": 2,
  "rows": 5
}
[/block]
### 2.Create project paths
Make sure the following paths exist, create any folders you are missing.
[block:parameters]
{
  "data": {
    "h-0": "SDK",
    "h-1": "File path",
    "0-0": "Android Native",
    "1-0": "PhoneGap, Cordova, Ionic",
    "1-1": "`<project-root>/platforms/android/res/drawable-hdpi/` (36x36)\n`<project-root>/platforms/android/res/drawable-xhdpi/` (48x48)\n`<project-root>/platforms/android/res/drawable-xxhdpi/` (72x72)\n`<project-root>/platforms/android/res/drawable-xxxhdpi/` (256x256) (Large Icon)",
    "2-0": "PhoneGap Build (PGB)",
    "2-1": "`<project-root>/locales/android/drawable-hdpi/` (36x36)\n`<project-root>/locales/android/drawable-xhdpi/` (48x48)\n`<project-root>/locales/android/drawable-xxhdpi/` (72x72)\n`<project-root>/locales/android/drawable-xxxhdpi/` (256x256) (Large Icon)\n\n\nSee [this github link](https://github.com/phonegap/build/issues/472#issuecomment-172662620) for more details on the directory structure if you're having issues.",
    "4-0": "Corona",
    "4-1": "Add files to root (all sizes)",
    "0-1": "`res/drawable-mdpi/` (24x24)\n`res/drawable-hdpi/` (36x36)\n`res/drawable-xhdpi/` (48x48)\n`res/drawable-xxhdpi/` (72x72)\n`res/drawable-xxxhdpi/` (256x256) (Large Icon)",
    "3-0": "Intel XDK",
    "3-1": "Limited, see [this work around](https://software.intel.com/en-us/forums/intel-xdk/topic/680309#comment-1883224)"
  },
  "cols": 2,
  "rows": 5
}
[/block]
### 3. Name Icons Appropriately
Next, you must be sure the icon filenames are correct. If you used Android Asset Studio for your small icon then this step may have already been done for you.

#### Android 3.0+
[block:parameters]
{
  "data": {
    "0-0": "Native, \nPhoneGap, Cordova, Ionic, \nPhoneGap Build (PGB)",
    "1-0": "Corona",
    "h-0": "SDK",
    "h-1": "Filename",
    "0-1": "`/drawable-[SIZE_NAMES]/ic_stat_onesignal_default.png`\n`/drawable-xxxhdpi/ic_onesignal_large_icon_default.png` (Large Icon)",
    "1-1": "`IconNotificationDefault-mdpi-v11.png` (24x24)\n`IconNotificationDefault-hdpi-v11.png` (36x36)\n`IconNotificationDefault-xhdpi-v11.png` (48x48)\n`IconNotificationDefault-xxhdpi-v11.png` (72x72)\n`ic_onesignal_large_icon_default.png` (256x256)(Large Icon)"
  },
  "cols": 2,
  "rows": 2
}
[/block]
#### Android 2.3
[block:parameters]
{
  "data": {
    "0-0": "Native, \nPhoneGap, Cordova, Ionic, \nPhoneGap Build (PGB)",
    "h-0": "SDK",
    "h-1": "Filename",
    "1-0": "Corona",
    "1-1": "`IconNotificationDefault-mdpi.png` (24x24)\n`IconNotificationDefault-hdpi.png` (36x36)\n`IconNotificationDefault-xhdpi.png` (48x48)\n`IconNotificationDefault-xxhdpi.png` (72x72)",
    "0-1": "`/drawable-[SIZE_NAMES]/ic_stat_onesignal_default.png` (all small icon sizes)"
  },
  "cols": 2,
  "rows": 2
}
[/block]

[block:callout]
{
  "type": "success",
  "body": "Done! You should be all set with your new default icons"
}
[/block]
----

## How to Add Non-Default Icons
<div class="label-type label-all"><span class="label-optional">Optional</span></div>

After you've added your default icons, you may choose to add more non-default icons. These will let you show different icons depending on the types of notifications your app sends. For instance, a game with a title like "Jewel Breaker" may wish to have a different colored jewel icon for every notification sent that represents the player's level. Meanwhile, a social network may wish to show a chat bubble icon when the user receives a message from another user to differentiate those notifications from more generic system notifications.

OneSignal supports overriding default icons on a per-message basis. 

### 1. Generate Icons
Follow the steps above to generate icons and place them in the appropriate folder for your SDK.

### 2. Name Non-Default Icons
To add non-default icons, you must name them something other than the default names specified above. For instance, you may name one `message_icon`.

### 3. Send Notifications with Non-Default Icons
If you've followed the above steps for creating default icons, and have updated your app, you'll be able to reference those icons when you send a notification. To send a notification with an icon, within <a class="dash-link" href="/docs/sending-notifications">New Message</a> open Android Options, and specify the icon to use.

Do not add the file extension when referencing the icon file. For instance, in the below example the file is referenced as `message_icon`.

<img src="https://files.readme.io/d078e09-Screen_Shot_2016-10-13_at_4.35.42_PM.png" width="400"/>

With Large Notification Icons, you can also supply a URL where the icon will be displayed from.

<span class="label-all">REST API</span> - Instead of sending via the dashboard, you can send notifications with icons in the REST API by using the appropriate parameter and file extension depending on your platform (see more in Create notification REST API docs).
[block:callout]
{
  "type": "warning",
  "title": "New icons take a while to propagate to all users",
  "body": "If you've very recently added an icon resource to your app, you may want to wait a few days before sending notifications using the icon. This is because it can take many days or even weeks for the majority of your users to update their apps to the latest version which contain your new icons."
}
[/block]
---
title: "User-User Messages"
excerpt: "Tutorial - Sending notifications directly from one user to another\n<div class=\"tag-all tag-developers\">For Developers</div> <div class=\"tag-all tag-marketers\">For Marketers</div>"
---
*To send user-to-user messages, you will need to set up your own server to track OneSignal Player IDs for each of your users.*

1. When OneSignal is initialized in your application, we provide a callback to retrieve the user's OneSignal ID. Use this callback to save the users' OneSignal ID to your server. In Unity, for example, this is done through the [IdsAvailableCallback](https://documentation.onesignal.com/docs/unity-sdk#section--idsavailablecallback-) method.

2. To send a message to a user, call our API method [Create notification](ref:create-notification). Alternatively, your server can send the target users' OneSignal IDs to your app, which can then use our Client SDK to send the notification. In Unity, for example, this is done through the [PostNotification](https://documentation.onesignal.com/docs/unity-sdk#section--postnotification-) method.
---
title: "Intel XDK Setup"
excerpt: "OneSignal Intel XDK Setup Guide. Works with <span class=\"label-all label-ios\">iOS</span>, <span class=\"label-all label-android\">Android</span> (and derivatives like <span class=\"label-all label-amazon\">Amazon</span>) and <span class=\"label-all label-windows\">Windows Phone 8.1</span>.\n<div class=\"tag-all tag-developers\">For Developers</div>"
---
## Update SDK
If you already have an app with the Intel XDK, your app should remain up to date with the latest OneSignal SDK since your project is built remotely. If you have not set up an app yet, follow the instructions below.

----

## Setup SDK

### Generate Credentials
Before setting up Intel XDK, you must generate the appropriate credentials for the platform(s) you are releasing on:

<span class="label-all label-ios">iOS</span> - [Generate an iOS Push Certificate](doc:generate-an-ios-push-certificate) 

<span class="label-all label-android">Android</span> - [Generate a Google Server API Key](doc:generate-a-google-server-api-key) 

<span class="label-all label-amazon">Amazon</span> - [Generate an Amazon API Key](doc:generate-an-amazon-api-key) 

### 1. Import OneSignal Plugin
**1.1.** Click the Projects menus in the top left and scroll down to "Cordova Hybrid Mobile App Settings". Expand "Plugin Management" and click "Add Plugins to this Project".
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/UT91p9DERi9apsGzWThS_Intel%20XDK-addplugin1.png",
        "Intel XDK-addplugin1.png",
        "1064",
        "547",
        "#6aa4b9",
        ""
      ]
    }
  ]
}
[/block]
**1.2.** Select "Third-Party Plugins" then pit "Git repo" as the Plugin source. Enter the following as the "Repo URL":

```
https://github.com/one-signal/OneSignal-Cordova-SDK.git#PGB-Compat
```
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/CbydSs06QWWrIW1hMHBS_Intel%20XDK-addplugin2.png",
        "Intel XDK-addplugin2.png",
        "901",
        "541",
        "#1062a3",
        ""
      ]
    }
  ]
}
[/block]
**1.3.** <span class="label-all label-android">Android</span> - Add the follow 2 dependent plugins following the instructions above.
* `https://github.com/floatinghotpot/google-play-services`
* `https://github.com/floatinghotpot/cordova-plugin-android-support-v4`

*Note: Omit android-support-v4 if you're using Crosswalk 16 or newer.*

**1.4.** <span class="label-all label-windows">Windows Phone 8.1</span> - Open `intelxdk.config.additions.xml` and add the following lines.
```
<preference name="windows-target-version" value="8.1" />
<preference name="WindowsToastCapable" value="true" />
```

### 2. Add required code
**2.1.** Add the following to the first javascript file that loads with your app.
- This is `<project-dir>/www/js/index.js` for most Cordova projects.
- Add this to your `app.js`.
[block:code]
{
  "codes": [
    {
      "code": "// Add to index.js or the first page that loads with your app.\n// For Intel XDK and please add this to your app.js.\n\ndocument.addEventListener('deviceready', function () {\n  // Enable to debug issues.\n  // window.plugins.OneSignal.setLogLevel({logLevel: 4, visualLevel: 4});\n  \n  var notificationOpenedCallback = function(jsonData) {\n    console.log('notificationOpenedCallback: ' + JSON.stringify(jsonData));\n  };\n\n  window.plugins.OneSignal\n    .startInit(\"YOUR_APPID\", \"YOUR_GOOGLE_PROJECT_NUMBER_IF_ANDROID\")\n    .handleNotificationOpened(notificationOpenedCallback)\n    .endInit();\n  \n  // Sync hashed email if you have a login system or collect it.\n  //   Will be used to reach the user at the most optimal time of day.\n  // window.plugins.OneSignal.syncHashedEmail(userEmail);\n}, false);",
      "language": "javascript",
      "name": "Intel XDK"
    }
  ]
}
[/block]
**2.2 ** Update initialization parameters 

Replace `YOUR_APPID` with your OneSignal AppId, available in <a class="dash-link" href="/docs/accounts-and-keys#section-keys-ids">Keys & IDs</a>

<span class="label-all label-android">Android</span> - Replace `YOUR_GOOGLE_PROJECT_NUMBER_IF_ANDROID` with your Google Project Number. 

<span class="label-all label-ios">iOS</span>, <span class="label-all label-windows">Windows Phone</span> - Leave `YOUR_GOOGLE_PROJECT_NUMBER_IF_ANDROID` blank if your app isn't for Android.

<span class="label-all label-recommended">Recommended</span> - Change `inFocusDisplaying` to `None` when app is ready for launch. See [Intel XDK Reference](doc:intel-xdk#section--infocusdisplaying-) for instructions.

<span class="label-all label-optional">Optional</span> - follow the [Intel XDK reference](doc:intel-xdk) to add code for when users tap on and open notifications to your liking by using the chaining methods `handleNotificationReceived` and `handleNotificationOpened`.

----
## SDK API
Check out our [Intel XDK Reference](doc:intel-xdk) for more OneSignal functions.
[block:callout]
{
  "type": "warning",
  "title": "Push Notification Testing Requirements",
  "body": "* *iOS* - Must test on a real device, Simulator does not support Apple push notifications.\n* *Android*\n   * You **MUST** build and install your app's APK. \n   * You may use an emulator but it must have an updated version of Google Play services installed.\n* Does **NOT** work with the Intel XDA Debug mode."
}
[/block]

[block:callout]
{
  "type": "info",
  "title": "Troubleshooting",
  "body": "If you run into any errors see [Troubleshooting Cordova Variants](doc:troubleshooting-cordova-variants), our our general [Troubleshooting](doc:known-issues) section."
}
[/block]
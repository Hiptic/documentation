---
title: "MacOS App SDK Setup"
excerpt: "OneSignal MacOS App SDK Setup Guide. Works with <span class=\"label-all label-ios\">MacOS</span> \n<div class=\"tag-all tag-developers\">For Developers</div>"
---
OneSignal does not currently have a macOS SDK available, however OneSignal can be used to send notifications to MacOS apps. Please refer to [Apple's documentation](https://developer.apple.com/notifications/) to learn how to obtain a push token.

To register a macOS device, call POST /players with a device_type of 9 to represent the Mac OS X platform and pass in the push token for the identifier parameter.
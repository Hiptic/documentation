---
title: "Unity SDK Setup"
excerpt: "OneSignal Unity SDK Setup Guide. Works with <span class=\"label-all label-ios\">iOS</span>, <span class=\"label-all label-android\">Android</span> (and derivatives like <span class=\"label-all label-amazon\">Amazon</span>) and <span class=\"label-all label-windows\">Windows Phone 8.1</span>.\n<div class=\"tag-all tag-developers\">For Developers</div>"
---
## Setup SDK

### Generate Credentials
Before setting up the Unity SDK, you must generate the appropriate credentials for the platform(s) you are releasing on:

<span class="label-all label-ios">iOS</span> - [Generate an iOS Push Certificate](doc:generate-an-ios-push-certificate) 

<span class="label-all label-android">Android</span> - [Generate a Google Server API Key](doc:generate-a-google-server-api-key) 

<span class="label-all label-amazon">Amazon Fire</span> - [Generate an Amazon API Key](doc:generate-an-amazon-api-key) 

<span class="label-all label-windows">Windows Phone 8.1</span> - [Generate a Windows Phone Package SID and Secret](doc:generate-a-windows-phone-package-sid-and-secret) 

### 1. Import the plugin

**1.1** Download the [latest unitypackage file](https://github.com/one-signal/OneSignal-Unity-SDK/releases)

**1.2** Open your Unity project, then open the downloaded unitypackage file for the version of Unity you're using.

**1.3** The following import package screen will come up. Press import.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/a86be7b-UnityOneSignalImportDialog.png",
        "UnityOneSignalImportDialog.png",
        353,
        521,
        "#c6c6c6"
      ]
    }
  ]
}
[/block]
### 2. Adding the required code

**2.1** In the first scene that is loaded when your game is opened, add the following code to an object that is enabled in the scene. (You can create a new Script file or add it to an existing Script like your own GameController or TitlescreenController that you may have already created.)
[block:code]
{
  "codes": [
    {
      "code": "using System.Collections.Generic;  \nvoid Start () {\n    // Enable line below to enable logging if you are having issues setting up OneSignal. (logLevel, visualLogLevel)\n    // OneSignal.SetLogLevel(OneSignal.LOG_LEVEL.INFO, OneSignal.LOG_LEVEL.INFO);\n  \n  OneSignal.StartInit(\"b2f7f966-d8cc-11e4-bed1-df8f05be55ba\")\n    .HandleNotificationOpened(HandleNotificationOpened)\n    .EndInit();\n  \n  // Sync hashed email if you have a login system or collect it.\n  //   Will be used to reach the user at the most optimal time of day.\n  // OneSignal.syncHashedEmail(userEmail);\n}\n\n// Gets called when the player opens the notification.\nprivate static void HandleNotificationOpened(OSNotificationOpenedResult result) {\n}",
      "language": "csharp"
    },
    {
      "code": "import System.Collections.Generic;\nfunction Start () {\n   OneSignal.StartInit(\"b2f7f966-d8cc-11e4-bed1-df8f05be55ba\", \"703322744261\")\n      .HandleNotificationOpened(HandleNotificationOpened)\n      .EndInit();\n}\n// Gets called when the player opens the notification.\nprivate static function HandleNotificationOpened(result : OSNotificationOpenedResult) : void {\n}",
      "language": "javascript",
      "name": "UnityScript (AKA Unity JavaScript)"
    }
  ]
}
[/block]
**2.2** Update `"b2f7f966-d8cc-11e4-bed1-df8f05be55ba"` with your OneSignal app id.

### 3. Android Setup
<div class="label-type label-all"><span class="label-android">Android</span></div>

**3.1** - Run `Assets` > `Play Services Resolver` > `Android Resolver` > `Resolve Client Jars` from the menu bar.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/478ff06-UnityOneSignalUnity1.2.2Reslover.png",
        "UnityOneSignalUnity1.2.2Reslover.png",
        684,
        481,
        "#d1d3d4"
      ]
    }
  ]
}
[/block]
**3.2** Replace the example icons located in `Assets/Plugins/Android/OneSignalConfig/res` with your own.
*File names **must** be lowercase and cannot contain anything else except underscores and numbers.*
See our [Customize Notification Icons](doc:customize-notification-icons) page for more details.

### 4. Amazon ADM Setup
<div class="label-type label-all"><span class="label-amazon">Amazon</span></div>

**4.1.** Open `Plugins/Android/AndroidManifest.xml`. If you don't have one create this file with the following contents and skip to step 4.5.
[block:code]
{
  "codes": [
    {
      "code": "<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"no\"?>\n<manifest xmlns:amazon=\"http://schemas.amazon.com/apk/res/android\" xmlns:android=\"http://schemas.android.com/apk/res/android\" android:installLocation=\"auto\" package=\"COM.YOUR.PACKAGE_NAME\" platformBuildVersionCode=\"23\" >\n    <supports-screens android:anyDensity=\"true\" android:largeScreens=\"true\" android:normalScreens=\"true\" android:smallScreens=\"true\" android:xlargeScreens=\"true\"/>\n    <application android:debuggable=\"false\" android:icon=\"@drawable/app_icon\" android:isGame=\"true\" android:label=\"@string/app_name\" android:theme=\"@style/UnityThemeSelector\">\n        <activity android:configChanges=\"locale|fontScale|keyboard|keyboardHidden|mcc|mnc|navigation|orientation|screenLayout|screenSize|smallestScreenSize|touchscreen|uiMode\" android:label=\"@string/app_name\" android:launchMode=\"singleTask\" android:name=\"com.unity3d.player.UnityPlayerActivity\" android:screenOrientation=\"fullSensor\">\n            <intent-filter>\n                <action android:name=\"android.intent.action.MAIN\"/>\n                <category android:name=\"android.intent.category.LAUNCHER\"/>\n                <category android:name=\"android.intent.category.LEANBACK_LAUNCHER\"/>\n            </intent-filter>\n            <meta-data android:name=\"unityplayer.UnityActivity\" android:value=\"true\"/>\n        </activity>\n        \n        <amazon:enable-feature android:name=\"com.amazon.device.messaging\" android:required=\"false\"/>\n        <service android:name=\"com.onesignal.ADMMessageHandler\" android:exported=\"false\" />\n        <receiver android:name=\"com.onesignal.ADMMessageHandler$Receiver\"\n                  android:permission=\"com.amazon.device.messaging.permission.SEND\" >\n          <intent-filter>\n            <action android:name=\"com.amazon.device.messaging.intent.REGISTRATION\" />\n            <action android:name=\"com.amazon.device.messaging.intent.RECEIVE\" />\n            <category android:name=\"COM.YOUR.PACKAGE_NAME\" />\n          </intent-filter>\n        </receiver>\n    </application>\n    <uses-feature android:glEsVersion=\"0x20000\"/>\n    <uses-feature android:name=\"android.hardware.touchscreen\" android:required=\"false\"/>\n    <uses-feature android:name=\"android.hardware.touchscreen.multitouch\" android:required=\"false\"/>\n    <uses-feature android:name=\"android.hardware.touchscreen.multitouch.distinct\" android:required=\"false\"/>\n    \n    <uses-permission android:name=\"com.amazon.device.messaging.permission.RECEIVE\" />\n    <permission android:name=\"COM.YOUR.PACKAGE_NAME.permission.RECEIVE_ADM_MESSAGE\" android:protectionLevel=\"signature\" />\n    <uses-permission android:name=\"COM.YOUR.PACKAGE_NAME.permission.RECEIVE_ADM_MESSAGE\" />\n</manifest>",
      "language": "xml"
    }
  ]
}
[/block]
**4.2.** Open `Plugins/Android/AndroidManifest.xml` file and add `xmlns:amazon="http://schemas.amazon.com/apk/res/android"` in the manifest tag right after the `xmlns:android` property. See example below.
[block:code]
{
  "codes": [
    {
      "code": "<manifest xmlns:android=\"http://schemas.android.com/apk/res/android\"\n    xmlns:amazon=\"http://schemas.amazon.com/apk/res/android\"\n    package=\"COM.YOUR.PACKAGE_NAME\"\n    android:versionCode=\"1\"\n    android:versionName=\"1.0\" >",
      "language": "xml"
    }
  ]
}
[/block]
**4.3.** Add the following permissions.
[block:code]
{
  "codes": [
    {
      "code": "<uses-permission android:name=\"com.amazon.device.messaging.permission.RECEIVE\" />\n<permission android:name=\"COM.YOUR.PACKAGE_NAME.permission.RECEIVE_ADM_MESSAGE\" android:protectionLevel=\"signature\" />\n<uses-permission android:name=\"COM.YOUR.PACKAGE_NAME.permission.RECEIVE_ADM_MESSAGE\" />",
      "language": "xml"
    }
  ]
}
[/block]
**4.4.** In the application tag add the following.
[block:code]
{
  "codes": [
    {
      "code": "<application>\n  <amazon:enable-feature android:name=\"com.amazon.device.messaging\" android:required=\"false\"/>\n\n  <service android:name=\"com.onesignal.ADMMessageHandler\" android:exported=\"false\" />\n  <receiver android:name=\"com.onesignal.ADMMessageHandler$Receiver\"\n            android:permission=\"com.amazon.device.messaging.permission.SEND\" >\n    <intent-filter>\n      <action android:name=\"com.amazon.device.messaging.intent.REGISTRATION\" />\n      <action android:name=\"com.amazon.device.messaging.intent.RECEIVE\" />\n      <category android:name=\"COM.YOUR.PACKAGE_NAME\" />\n    </intent-filter>\n  </receiver>\n</application>",
      "language": "xml"
    }
  ]
}
[/block]
**4.5.** Replace all 3 of instances of `COM.YOUR.PACKAGE_NAME` with your package name in AndroidManifest.xml.

** 4.6 ** Place your `api_key.txt` in a new folder named `assets` under Assets/Plugins/Android/.

*To create an `api_key.txt` for your app follow our [Generate an Amazon API Key](doc:generate-an-amazon-api-key)*


### 5. iOS Setup
<div class="label-type label-all"><span class="label-ios">iOS</span></div>
[block:callout]
{
  "type": "danger",
  "title": "Important - XCode 8",
  "body": "You **MUST** follow the Capabilities steps below if you are using Xcode 8!\n*If you miss this step users will not get a push token or have mismatch environment issues.*\n*OneSignal is tested with Xcode 7.3.1 and newer. May work on older versions of Xcode but we do not provide support for it.*"
}
[/block]
**5.1** Build from Unity and open the Xcode project.
**5.2** Select the root project and Under Capabilities Enable "Push Notifications".
**5.3** Next Enable "Background Modes" and check "Remote notifications".
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/681ae2d-Xcode_capabilities.png",
        "Xcode capabilities.png",
        961,
        774,
        "#f0f0f0"
      ]
    }
  ]
}
[/block]
**5.4** In future builds from Unity always pick the "Append" option on the folder warning so you do not have to repeat the steps above again.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/mBpYPsxeRSixlq1uRopW_Unity%20iOS%20build.png",
        "Unity iOS build.png",
        "416",
        "146",
        "#293863",
        ""
      ]
    }
  ]
}
[/block]

[block:callout]
{
  "type": "warning",
  "title": "Google Play Games for Unity",
  "body": "There was a bug in Google Play Games for Unity version 0.9.20 on iOS which prevents the device from subscribing the device for push notifications. Please make sure you're using version 0.9.21 or newer of their plugin."
}
[/block]

### 6. Windows Phone 8.1 (WP8.1)
<div class="label-type label-all"><span class="label-windows">Windows Phone 8.1</span></div>

*Your app does not have to be published however, you must have it created on the Windows Dev Center. Follow our [Windows Phone Project SID & Secret](http://documentation.onesignal.com/v2.0/docs/windows-phone-client-sid-secret) setup if you have not done this yet.*

**6.1** Build from Unity and open the solution file `.sln` from the created build folder.
**6.2** Double click on `Package.appxmanifest` then select the "Application" tab and scroll down to the "Notifications:" section. Change "Toast capable:" to Yes.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/09PDTEPyT9SeH2t94nhQ_WindowPhone8.1_SDK_2.1.png",
        "WindowPhone8.1_SDK_2.1.png",
        "851",
        "282",
        "#384868",
        ""
      ]
    }
  ]
}
[/block]
**6.3** Under the Capabilities tab make sure "Internet (Client & Server)" is checked. Lastly make sure to save.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/IZAwsDacQEmg7e0gCyWL_WindowPhone8.1_SDK_2.2.png",
        "WindowPhone8.1_SDK_2.2.png",
        "856",
        "294",
        "#38547c",
        ""
      ]
    }
  ]
}
[/block]
**6.4** Right click on your VS project and select Store>Associate App with the Store...
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/hvgs1BRPTAaBddQstYKt_WindowPhone8.1__SDK_1.1.png",
        "WindowPhone8.1__SDK_1.1.png",
        "714",
        "510",
        "#2f4363",
        ""
      ]
    }
  ]
}
[/block]
**6.5** Click Next and sign into your Microsoft account.

**6.6** Select your app and press Next.

**6.7.** Lastly press Associate.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/xjGGyJ7QTuaGNyRjQagW_WindowPhone8.1_SDK_4.3.png",
        "WindowPhone8.1_SDK_4.3.png",
        "786",
        "643",
        "#3489da",
        ""
      ]
    }
  ]
}
[/block]

[block:callout]
{
  "type": "success",
  "body": "Done! You should be all set to go with your Unity app."
}
[/block]

----
## SDK API
To see all available methods, see our [Unity SDK](doc:unity-sdk).
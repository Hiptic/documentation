---
title: "Corona SDK Setup"
excerpt: "OneSignal Corona SDK Setup Guide. Works with <span class=\"label-all label-ios\">iOS</span> and <span class=\"label-all label-android\">Android</span> (and derivatives like <span class=\"label-all label-amazon\">Amazon</span>).\n<div class=\"tag-all tag-developers\">For Developers</div>"
---
## CoronaCards Setup
OneSignal works with <span class="label-all label-windows">Windows Phone 8.0</span> CoronaCards. Follow our native [Windows Phone SDK Setup](doc:windows-phone-sdk-setup) instead of the ones below.

----
## Setup SDK

If you are running an Enterprise Corona app, [see instructions below](#section-setup-sdk-corona-enterprise-)

### Generate Credentials
Before setting up the Corona SDK, you must generate the appropriate credentials for the platform(s) you are releasing on:

<span class="label-all label-ios">iOS</span> - [Generate an iOS Push Certificate](doc:generate-an-ios-push-certificate) 

<span class="label-all label-android">Android</span> - [Generate a Google Server API Key](doc:generate-a-google-server-api-key) 

<span class="label-all label-amazon">Amazon</span> - [Generate an Amazon API Key](doc:generate-an-amazon-api-key) 

### 1. Add OneSignal to your Account

**1.1** Login into your account on Corona's site and bring up the [OneSignal plugin](https://store.coronalabs.com/plugin/onesignal) on the Corona plugin directory.

**1.2** Click the "FREE" button.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/yWjPepQRYuZp7tBdXHAw_Corona%20enable%20plugin.png",
        "Corona enable plugin.png",
        "723",
        "548",
        "#f18026",
        ""
      ]
    }
  ]
}
[/block]
**1.3** Click "Finish Checkout".
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/cHE0NfWORS6iDctafnvf_Corona%20enable%20plugin2.png",
        "Corona enable plugin2.png",
        "720",
        "543",
        "#404f6d",
        ""
      ]
    }
  ]
}
[/block]
----
### 2. Add OneSignal to Your Project

**2.1** Update the build.settings file in the Corona project folder to contain the following inside of `settings = {`.
[block:code]
{
  "codes": [
    {
      "code": "plugins =\n{\n    [\"plugin.OneSignal\"] =\n    {\n        publisherId = \"com.onesignal\",\n    },\n    -- Omit if you're using 'plugin.googleAnalytics'\n    [\"plugin.google.play.services\"] =\n    {\n        publisherId = \"com.coronalabs\",\n        supportedPlatforms = { android=true, [\"android-kindle\"]=true },\n    },\n}",
      "language": "lua"
    }
  ]
}
[/block]
**2.2** <span class="label-all label-ios">iOS</span> - Add the following line inside of 'plist = {' in build.settings.
[block:code]
{
  "codes": [
    {
      "code": "UIBackgroundModes = {\"remote-notification\"},",
      "language": "lua"
    }
  ]
}
[/block]
----
### 3. Add Required Code

**3.1**  At the top of main.lua, place the following code.
[block:code]
{
  "codes": [
    {
      "code": "-- This function gets called when the user opens a notification or one is received when the app is open and active.\n-- Change the code below to fit your app's needs.\nfunction DidReceiveRemoteNotification(message, additionalData, isActive)\n    if (additionalData) then\n        if (additionalData.discount) then\n            native.showAlert( \"Discount!\", message, { \"OK\" } )\n            -- Take user to your app store\n        elseif (additionalData.actionSelected) then -- Interactive notification button pressed\n            native.showAlert(\"Button Pressed!\", \"ButtonID:\" .. additionalData.actionSelected, { \"OK\"} )\n        end\n    else\n        native.showAlert(\"OneSignal Message\", message, { \"OK\" } )\n    end\nend\n\nlocal OneSignal = require(\"plugin.OneSignal\")\n-- Uncomment SetLogLevel to debug issues.\n-- OneSignal.SetLogLevel(4, 4)\nOneSignal.Init(\"XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX\", \"############\", DidReceiveRemoteNotification)",
      "language": "lua"
    }
  ]
}
[/block]
**3.2** Replace `XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX` with your Application Key, available in <a class="dash-link" href="/docs/accounts-and-keys#section-keys-ids">Keys & IDs</a>.

**3.3** <span class="label-all label-android">Android</span> - Replace `############` with your Google Project number.

**3.4** <span class="label-all label-amazon">Amazon</span> - Put your `app_key.txt` (from [Generate an Amazon API Key](doc:generate-an-amazon-api-key) instructions above) into the root of your Corona project folder. When you build your app change the `Target App Store` setting to `Amazon`.

----
### Troubleshooting

If get an error saying `"Plugin_OneSignal not found"` make sure the plugin shows active on your account on the Corona's plugin directory page. Also make sure the same account you used on their site is the same account you signed into in the Corona Simulator. If that is correct you may need to wait 30 minutes up to 1 hour for OneSignal to become active on your account. Feel free to contact us or Corona if this error persists.


----
## Setup SDK (Corona Enterprise)

### Generate Credentials
Before setting up the Corona SDK, you must generate the appropriate credentials for the platform(s) you are releasing on:

<span class="label-all label-ios">iOS</span> - [Generate an iOS Push Certificate](doc:generate-an-ios-push-certificate) 

<span class="label-all label-android">Android</span> - [Generate a Google Server API Key](doc:generate-a-google-server-api-key) 

<span class="label-all label-amazon">Amazon</span> - [Generate an Amazon API Key](doc:generate-an-amazon-api-key) 

### 1. Add Required Code

**1.1**  At the top of main.lua, place the following code.
[block:code]
{
  "codes": [
    {
      "code": "-- This function gets called when the user opens a notification or one is received when the app is open and active.\n-- Change the code below to fit your app's needs.\nfunction DidReceiveRemoteNotification(message, additionalData, isActive)\n    if (additionalData) then\n        if (additionalData.discount) then\n            native.showAlert( \"Discount!\", message, { \"OK\" } )\n            -- Take user to your app store\n        elseif (additionalData.actionSelected) then -- Interactive notification button pressed\n            native.showAlert(\"Button Pressed!\", \"ButtonID:\" .. additionalData.actionSelected, { \"OK\"} )\n        end\n    else\n        native.showAlert(\"OneSignal Message\", message, { \"OK\" } )\n    end\nend\n\nlocal OneSignal = require(\"plugin.OneSignal\")\nOneSignal.Init(\"XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX\", \"############\", DidReceiveRemoteNotification)",
      "language": "lua"
    }
  ]
}
[/block]
**1.2** Replace `XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX` with your Application Key in <a class="dash-link" href="/docs/accounts-and-keys#section-keys-ids">Keys & IDs</a>.

** 1.3** Replace `############` with your Google Project number if your app is for Android.

### 2. Add Plugin to iOS
<div class="label-type label-all"><span class="label-ios">iOS</span></div>

**2.1** Extract `onesignal/XXXX.XXXX/iphone/` from the CoronaEnterprisePlugins.XXXX.XXXX.tgz. (found on the Corona Daily Builds page under Corona Enterprise)

**2.2** Add libplugin_OneSignal.a to your Xcode project.

**2.3** Enable "Background Modes" and check "Remote notifications" under Capabilities on the "Unity-iphone" target.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/dxkwPBPKR9eekLLm3zfA_SC-EnableBGModes.png",
        "SC-EnableBGModes.png",
        "1000",
        "493",
        "#e85b53",
        ""
      ]
    }
  ]
}
[/block]

**2.4** Open your `-Info.p` file add the key `CoronaDelegates` as an Array type. Add an entry as `OneSignalCoronaDelegate`.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/zp1NUJ9LSDCsKWDJsihd_CoronaEnterpriseAddPlist.png",
        "CoronaEnterpriseAddPlist.png",
        "679",
        "96",
        "#264077",
        ""
      ]
    }
  ]
}
[/block]
### 3. Add Plugin to Android
<div class="label-type label-all"><span class="label-android">Android</span> & <span class="label-amazon">Amazon</span></div>

**3.1** Extract `onesignal/XXXX.XXXX/android/` from the CoronaEnterprisePlugins.XXXX.XXXX.tgz. (found on the Corona Daily Builds page under Corona Enterprise)

**3.2** Create a folder named `armeabi-v7a` under `android/libs` in your project and place the `libplugin.OneSignal.so` there.

**3.3** Copy OneSignal.jar, OneSignalSDK.jar, and android-support-v4.jar to your android/libs folder.

**3.4** Add the following permissions to your AndroidManifest.xml file.
[block:code]
{
  "codes": [
    {
      "code": "<permission android:name=\"COM.YOUR.PACKAGE_NAME.permission.C2D_MESSAGE\"\n            android:protectionLevel=\"signature\"/>\n<uses-permission android:name=\"COM.YOUR.PACKAGE_NAME.permission.C2D_MESSAGE\"/>\n\n<uses-permission android:name=\"android.permission.INTERNET\"/>\n<uses-permission android:name=\"android.permission.VIBRATE\"/>\n\n<!-- Keeps the processor from sleeping when a message is received. -->\n<uses-permission android:name=\"android.permission.WAKE_LOCK\"/>\n\n<!-- This app has permission to register and receive data message. -->\n<uses-permission android:name=\"com.google.android.c2dm.permission.RECEIVE\"/>",
      "language": "xml"
    }
  ]
}
[/block]

**3.5**  In the application tag add the following.
[block:code]
{
  "codes": [
    {
      "code": "<application ...>\n    <meta-data android:name=\"com.google.android.gms.version\"\n       android:value=\"@integer/google_play_services_version\" />\n\n  \t<receiver android:name=\"com.onesignal.NotificationOpenedReceiver\" />\n\t\t\n    <receiver\n        android:name=\"com.onesignal.GcmBroadcastReceiver\"\n        android:permission=\"com.google.android.c2dm.permission.SEND\" >\n        <intent-filter>\n            <action android:name=\"com.google.android.c2dm.intent.RECEIVE\" />\n            <category android:name=\"COM.YOUR.PACKAGE_NAME\" />\n        </intent-filter>\n    </receiver>\n    <service android:name=\"com.onesignal.GcmIntentService\" />\n    <service android:name=\"com.onesignal.SyncService\" android:stopWithTask=\"false\" />\n    <activity android:name=\"com.onesignal.PermissionsActivity\" android:theme=\"@android:style/Theme.Translucent.NoTitleBar\" />\n</application>",
      "language": "xml"
    }
  ]
}
[/block]

**3.6** *(Optional)* If you need receive other GCM message through Corona (like Helpshift) then add the following to your AndroidManifest.xml.
[block:code]
{
  "codes": [
    {
      "code": "<receiver\n  android:name=\"com.onesignal.CoronaGCMFilterProxyReceiver\"\n  android:permission=\"com.google.android.c2dm.permission.SEND\" >\n    <intent-filter>\n        <action android:name=\"com.google.android.c2dm.intent.RECEIVE\" />\n        <category android:name=\"COM.YOUR.PACKAGE_NAME\" />\n    </intent-filter>\n</receiver>",
      "language": "xml"
    }
  ]
}
[/block]
**3.7** Replace 'COM.YOUR.PACKAGE_NAME' with your full package name from the last 2 steps.

**3.8** Open your `android/project.properties` and the following.
[block:code]
{
  "codes": [
    {
      "code": "android.library.reference.2=relative_path/google-play-services_lib",
      "language": "text"
    }
  ]
}
[/block]
The path you add MUST be relative and not absolute and should look something like this ../../../android-sdks/extras/google/google_play_services/libproject/google-play-services_lib.

**3.9** Build you app. If you get an error about build.xml is missing then cd to the google-play-services_lib folder in the andorid sdk and run
[block:code]
{
  "codes": [
    {
      "code": "android update lib-project --path . --target android-10",
      "language": "shell"
    }
  ]
}
[/block]

[block:callout]
{
  "type": "warning",
  "body": "If you have proguard enabled on your project you must add the following lines to your proguard config file. (Default name is proguard-project.txt).\n```\n-dontwarn com.onesignal.**\n-dontwarn com.gamethrive.**\n```",
  "title": "Proguard"
}
[/block]
### 4. Add Plugin to Amazon
<div class="label-type label-all"><span class="label-amazon">Amazon</span></div>

**4.1** Follow all the steps from [Add Plugin to Android](#section-3-add-plugin-to-android)

**4.2** Add the following permission to your `AndroidManifest.xml`
[block:code]
{
  "codes": [
    {
      "code": "<uses-permission android:name=\"com.amazon.device.messaging.permission.RECEIVE\" />\n<permission android:name=\"COM.YOUR.PACKAGE_NAME.permission.RECEIVE_ADM_MESSAGE\" android:protectionLevel=\"signature\" />\n<uses-permission android:name=\"COM.YOUR.PACKAGE_NAME.permission.RECEIVE_ADM_MESSAGE\" />",
      "language": "xml"
    }
  ]
}
[/block]

**4.3**  In the application tag add the following.
[block:code]
{
  "codes": [
    {
      "code": "<application ...>\n  <amazon:enable-feature android:name=\"com.amazon.device.messaging\" android:required=\"false\" xmlns:amazon=\"http://schemas.amazon.com/apk/res/android\" />\n\n  <service android:name=\"com.onesignal.ADMMessageHandler\" android:exported=\"false\" />\n  <receiver\n            android:name=\"com.onesignal.ADMMessageHandler$Receiver\"\n            android:permission=\"com.amazon.device.messaging.permission.SEND\" >\n\n    <intent-filter>\n      <action android:name=\"com.amazon.device.messaging.intent.REGISTRATION\" />\n      <action android:name=\"com.amazon.device.messaging.intent.RECEIVE\" />\n      <category android:name=\"COM.YOUR.PACKAGE_NAME\" />\n    </intent-filter>\n\n  </receiver>\n</application>",
      "language": "xml"
    }
  ]
}
[/block]

**4.4** Replace `COM.YOUR.PACKAGE_NAME` with your full package name from the last 2 steps.

**4.5.** Put your `app_key.txt` into the root of your Corona project folder. To get this file follow our [Generate an Amazon API Key](doc:generate-an-amazon-api-key) instructions.


[block:callout]
{
  "type": "success",
  "body": "Done! You should be all set to go with your Corona app."
}
[/block]
---
title: "Android SDK Setup"
excerpt: "OneSignal <span class=\"label-all label-android\">Android</span> SDK Setup Guide. Also for <span class=\"label-all label-amazon\">Amazon</span> apps using Android Studio.\n<div class=\"tag-all tag-developers\">For Developers</div>"
---
[block:callout]
{
  "type": "info",
  "body": "If you're using an app framework to build your <span class=\"label-all label-android\">Android</span> app, we have higher level SDKs for the following: [Unity](doc:unity-sdk-setup), [PhoneGap](doc:phonegap-sdk-setup), [Cordova](doc:cordova-sdk-setup), [Ionic](doc:ionic-sdk-setup), [Intel XDK](doc:intel-xdk-setup), [React Native](doc:react-native-sdk-setup), [Corona](doc:corona-sdk-setup), [Cocos2d](doc:cocos2d-x-sdk-setup), [Marmalade](doc:marmalade-sdk-setup), [Adobe Air](doc:adobe-air-sdk-setup), and [Xamarin](doc:xamarin-sdk-setup).",
  "title": "Using an app framework?"
}
[/block]
## Update SDK
If you have an app with a previous version of the Android SDK, read our [Upgrading to Android SDK 3.0 guide](doc:upgrading-to-android-sdk-30).

## Setup SDK (Android Studio)
Android Studio is the most common way to build <span class="label-all label-android">Android</span> projects. The following instructions are also applicable if you're using Android Studio to build your <span class="label-all label-amazon">Amazon</span> app ([see more](doc:amazon-sdk-setup)).

### Generate Credentials
Follow the steps to [Generating a Google Server API Key](doc:generate-a-google-server-api-key).

### 1. Gradle Setup

**1.1** Open your `build.gradle` (Module: app) file and add the following to your dependencies.
[block:code]
{
  "codes": [
    {
      "code": "dependencies {\n    compile 'com.onesignal:OneSignal:3.+@aar'\n    \n    // Required for OneSignal, even if you have added FCM.\n    compile 'com.google.android.gms:play-services-gcm:+'\n    \n    // Required for geotagging\n    compile \"com.google.android.gms:play-services-location:+\"\n    \n    // play-services-analytics is only needed when using 8.1.0 or older. \n    // compile 'com.google.android.gms:play-services-analytics:+'\n}",
      "language": "c",
      "name": "Gradle"
    }
  ]
}
[/block]
**1.2** In the same `build.gradle` file, add the following in your `android` > `defaultConfig` section.
* Update `PUT YOUR ONESIGNAL APP ID HERE` with your OneSignal app id
[block:code]
{
  "codes": [
    {
      "code": "android {\n   defaultConfig {\n      manifestPlaceholders = [onesignal_app_id: \"PUT YOUR ONESIGNAL APP ID HERE\",\n                              // Project number pulled from dashboard, local value is ignored.\n                              onesignal_google_project_number: \"REMOTE\"]\n    }\n }",
      "language": "c",
      "name": "Gradle"
    }
  ]
}
[/block]

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/d5c1d26-AndroidStudioOneSignalGradleSetup.png",
        "AndroidStudioOneSignalGradleSetup.png",
        1057,
        641,
        "#e7e7de"
      ],
      "sizing": "smart"
    }
  ]
}
[/block]
<br>
### 2. Add Required Code

**2.1** Add the following to the `onCreate` method in your `Application` class.
[block:code]
{
  "codes": [
    {
      "code": "import com.onesignal.OneSignal;\n\npublic class YourAppClass extends Application {\n   @Override\n   public void onCreate() {\n      super.onCreate();\n      OneSignal.startInit(this).init();\n     \n      // Sync hashed email if you have a login system or collect it.\n      //   Will be used to reach the user at the most optimal time of day.\n      // OneSignal.syncHashedEmail(userEmail);\n   }\n}",
      "language": "java"
    }
  ]
}
[/block]
*Don't have a class that extends Application in your project?
Follow [this tutorial](https://www.mobomo.com/2011/05/how-to-use-application-object-of-android/) to create one.*

### 3. Create a default notification icon
**3.1** Starting with Android Lollipop 5.0 a small notification icon is required for the icon to be visible in the status bar. Follow the [Customize Notification Icons](doc:customize-notification-icons) instructions to create a small notification icon.

### 4. Add Optional Notification Handlers
[NotificationOpenedHandler](doc:android-native-sdk#section--notificationopenedhandler-) - This will be called when a notification is tapped on.
See our [setNotificationOpenedHandler](doc:android-native-sdk#section--setnotificationopenedhandler-) documentation to add one.

[NotificationReceivedHandler](doc:android-native-sdk#section--notificationreceivedhandler-) - This will be called when a notification is received while your app is running.
See our [setNotificationReceivedHandler](doc:android-native-sdk#section--setnotificationreceivedhandler-) documentation to add one.

**NotificationExtenderService** - This can be setup to receive silent notifications when your app is not running or to override how notifications are shown in the notification shade. See the [Background Data and Notification Overriding](doc:android-customizations#background-data-and-notification-overriding) section to set this up.

### Next Steps
<span class="label-all label-android">Android</span> - Setup is done! All `AndroidManifest.xml` entries are added by our SDK for you. Make sure you are testing push notifications on a device or emulator that has Google Play services installed and updated on it.

<span class="label-all label-amazon">Amazon</span> - Return to the [Amazon SDK Setup](doc:amazon-sdk-setup) for more instructions.
[block:callout]
{
  "type": "success",
  "body": "Done! You should be all set to go with your Android app."
}
[/block]

[block:callout]
{
  "type": "info",
  "body": "To see all available methods for <span class=\"label-all label-android\">Android</span> and <span class=\"label-all label-amazon\">Amazon</span>, see our [Android Native SDK Reference](doc:android-native-sdk).",
  "title": "Additional Documentation"
}
[/block]
----
<br><br><br><br>

## Setup SDK (Eclipse)
Eclipse is an uncommon way to build <span class="label-all label-android">Android</span> projects. These instructions are **not** for <span class="label-all label-amazon">Amazon</span> projects built in Eclipse.
[block:callout]
{
  "type": "warning",
  "body": "Google no longer support building apps with Eclipse. Their last update to Eclipse was [August 2015](https://developer.android.com/studio/tools/sdk/eclipse-adt.html).\nPlease follow [Google's Android Studio migration guide](http://android-developers.blogspot.com/2015/06/an-update-on-eclipse-android-developer.html).",
  "title": "Deprecated!"
}
[/block]
### Generate Credentials
Follow the steps to [Generating a Google Server API Key](doc:generate-a-google-server-api-key).

### 1. Project setup
[block:callout]
{
  "type": "info",
  "body": "OneSignal requires Google Play services (`google-play-services_lib`) and Android Support Library v4 (`android-support-v4.jar`). `android-support-v13.jar` can be used instead if your project already requires it.",
  "title": "'Google Play services' & 'Android Support Library'"
}
[/block]
**1.1.** Download the latest [OneSignal Android SDK](https://github.com/one-signal/OneSignal-Android-SDK/releases).

**1.2.** Run the Android SDK Manager and install or update "Android Support Library" and "Google Play services" from the Extras section. 
[block:callout]
{
  "type": "info",
  "body": "\"SDK Path:\" is shown on this window, replace `<android-sdk>` with your path in the steps below."
}
[/block]

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/SZZIIcSJmYc9xWDSzLNg_SC-AndroidSDKManage.png",
        "SC-AndroidSDKManage.png",
        "609",
        "684",
        "#64af71",
        ""
      ]
    }
  ]
}
[/block]
**1.3.** Import `<android-sdk>\extras\google\google_play_services\libproject\google-play-services_lib` project into your workspace. Go to File>Import and then go to Android>Existing Android Code into Workspace.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/qoxyA5W0SnefRJx6ofTN_SC-ImportCode.png",
        "SC-ImportCode.png",
        "549",
        "494",
        "#67b56c",
        ""
      ]
    }
  ]
}
[/block]

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/lAqcg1cQQOWblXcaS9mh_SC-ImportProj.png",
        "SC-ImportProj.png",
        "514",
        "476",
        "#66b46e",
        ""
      ]
    }
  ]
}
[/block]
**1.4.** Right click on your project and go to Properties. On the left Select Android and then press the "Add..." button in Library section. Pick the `google-play-services_lib`.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/fq2Dvz1dTUizAbP9MdHp_SC-PickGooglePlayServices.png",
        "SC-PickGooglePlayServices.png",
        "667",
        "638",
        "#64b271",
        ""
      ]
    }
  ]
}
[/block]
**1.5.** Next place `onesignalsdk.jar` and `<android-sdk>\extras\android\support\v4\android-support-v4.jar` into your project's libs
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/W00zFu0QOWzkL5H0qL3X_Untitled-2.jpg",
        "Untitled-2.jpg",
        "217",
        "244",
        "#8a423c",
        ""
      ]
    }
  ]
}
[/block]
**1.6.** Right click on your project to go Properties and select "Java Build Path" on the left. Next click on the "Order and Export" tab and make sure "Android Dependencies" is checked.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/XDZ2jJPTRxuP6LnaKCJ0_SC-AndroidDependencies.png",
        "SC-AndroidDependencies.png",
        "717",
        "491",
        "#65b36e",
        ""
      ]
    }
  ]
}
[/block]
### 2. AndroidManifest.xml

**2.1.** Add the following permissions to `AndroidManifest.xml`.
[block:code]
{
  "codes": [
    {
      "code": "<permission android:name=\"${manifestApplicationId}.permission.C2D_MESSAGE\"\n            android:protectionLevel=\"signature\" />\n<uses-permission android:name=\"${manifestApplicationId}.permission.C2D_MESSAGE\" />\n<uses-permission android:name=\"android.permission.INTERNET\" />\n<uses-permission android:name=\"com.google.android.c2dm.permission.RECEIVE\" />\n<uses-permission android:name=\"android.permission.WAKE_LOCK\" />\n<uses-permission android:name=\"android.permission.VIBRATE\" />\n<uses-permission android:name=\"android.permission.ACCESS_NETWORK_STATE\" />\n<uses-permission android:name=\"android.permission.RECEIVE_BOOT_COMPLETED\" />\n\n<!-- START: ShortcutBadger -->\n<!-- Samsung -->\n<uses-permission android:name=\"com.sec.android.provider.badge.permission.READ\"/>\n<uses-permission android:name=\"com.sec.android.provider.badge.permission.WRITE\"/>\n\n<!-- HTC -->\n<uses-permission android:name=\"com.htc.launcher.permission.READ_SETTINGS\"/>\n<uses-permission android:name=\"com.htc.launcher.permission.UPDATE_SHORTCUT\"/>\n\n<!-- Sony -->\n<uses-permission android:name=\"com.sonyericsson.home.permission.BROADCAST_BADGE\"/>\n<uses-permission android:name=\"com.sonymobile.home.permission.PROVIDER_INSERT_BADGE\"/>\n\n<!-- Apex -->\n<uses-permission android:name=\"com.anddoes.launcher.permission.UPDATE_COUNT\"/>\n\n<!-- Solid -->\n<uses-permission android:name=\"com.majeur.launcher.permission.UPDATE_BADGE\"/>\n\n<!-- Huawei -->\n<uses-permission android:name=\"com.huawei.android.launcher.permission.CHANGE_BADGE\" />\n<uses-permission android:name=\"com.huawei.android.launcher.permission.READ_SETTINGS\" />\n<uses-permission android:name=\"com.huawei.android.launcher.permission.WRITE_SETTINGS\" />\n<!-- End: ShortcutBadger -->",
      "language": "xml"
    }
  ]
}
[/block]
**2.2.** In your application tag add the following.
[block:code]
{
  "codes": [
    {
      "code": "<application ...>\n  <meta-data android:name=\"com.google.android.gms.version\"\n             android:value=\"@integer/google_play_services_version\" />\n  <meta-data android:name=\"onesignal_app_id\"\n             android:value=\"${onesignal_app_id}\" />\n\n  <receiver android:name=\"com.onesignal.GcmBroadcastReceiver\"\n            android:permission=\"com.google.android.c2dm.permission.SEND\" >\n    <intent-filter>\n      <action android:name=\"com.google.android.c2dm.intent.RECEIVE\" />\n      <category android:name=\"${manifestApplicationId}\" />\n    </intent-filter>\n  </receiver>\n  <receiver android:name=\"com.onesignal.NotificationOpenedReceiver\" />\n  <service android:name=\"com.onesignal.GcmIntentService\" />\n  <service android:name=\"com.onesignal.SyncService\" android:stopWithTask=\"false\" />\n  <activity android:name=\"com.onesignal.PermissionsActivity\" android:theme=\"@android:style/Theme.Translucent.NoTitleBar\" />\n  \n  <service android:name=\"com.onesignal.NotificationRestoreService\" />\n  <receiver android:name=\"com.onesignal.BootUpReceiver\">\n    <intent-filter>\n      <action android:name=\"android.intent.action.BOOT_COMPLETED\" />\n      <action android:name=\"android.intent.action.QUICKBOOT_POWERON\" />\n    </intent-filter>\n  </receiver>\n  <receiver android:name=\"com.onesignal.UpgradeReceiver\" >\n    <intent-filter>\n      <action android:name=\"android.intent.action.MY_PACKAGE_REPLACED\" />\n    </intent-filter>\n  </receiver>\n</application>",
      "language": "xml"
    }
  ]
}
[/block]
**2.3** Replace all 3 of instances `${manifestApplicationId}` with your package name in AndroidManifest.xml.
**2.4** Replace `${onesignal_app_id}` with your OneSignal app id.

### 3. Add Required Code
**3.1** Add the following to the onCreate method on your Application class.
[block:code]
{
  "codes": [
    {
      "code": "import com.onesignal.OneSignal;\n\npublic class YourAppClass extends Application {\n   @Override\n   public void onCreate() {\n      super.onCreate();\n      OneSignal.startInit(this).init();\n      \n      // Sync hashed email if you have a login system or collect it.\n      //   Will be used to reach the user at the most optimal time of day.\n      // OneSignal.syncHashedEmail(userEmail);\n   }\n}",
      "language": "java"
    }
  ]
}
[/block]
*Don't have a class that extends Application in your project?
Follow [this tutorial](https://www.mobomo.com/2011/05/how-to-use-application-object-of-android/) to create one.*

### 4. Add Optional Notification Handlers

[NotificationOpenedHandler](doc:android-native-sdk#section--notificationopenedhandler-) - This will be called when a notification is tapped on.
See our [setNotificationOpenedHandler](doc:android-native-sdk#section--setnotificationopenedhandler-) documentation to add one.

[NotificationReceivedHandler](doc:android-native-sdk#section--notificationreceivedhandler-) - This will be called when a notification is received while your app is running.
See our [setNotificationReceivedHandler](doc:android-native-sdk#section--setnotificationreceivedhandler-) documentation to add one.

**NotificationExtenderService** - This can be setup to receive silent notifications when your app is not running or to override how notifications are shown in the notification shade. See the [Background Data and Notification Overriding](doc:android-customizations#background-data-and-notification-overriding) section to set this up.
[block:callout]
{
  "type": "warning",
  "title": "Proguard",
  "body": "If you have proguard enabled on your project you must add the following lines to your proguard config file. (Default name is proguard-project.txt).\n```\n-dontwarn com.onesignal.**\n\n-keep class com.google.android.gms.common.api.GoogleApiClient {\n    void connect();\n    void disconnect();\n}\n\n-keep public interface android.app.OnActivityPausedListener {*;}\n\n-keep class com.onesignal.shortcutbadger.impl.AdwHomeBadger { <init>(...); }\n-keep class com.onesignal.shortcutbadger.impl.ApexHomeBadger { <init>(...); }\n-keep class com.onesignal.shortcutbadger.impl.AsusHomeLauncher { <init>(...); }\n-keep class com.onesignal.shortcutbadger.impl.DefaultBadger { <init>(...); }\n-keep class com.onesignal.shortcutbadger.impl.HuaweiHomeBadger { <init>(...); }\n-keep class com.onesignal.shortcutbadger.impl.NewHtcHomeBadger { <init>(...); }\n-keep class com.onesignal.shortcutbadger.impl.NovaHomeBadger { <init>(...); }\n-keep class com.onesignal.shortcutbadger.impl.SolidHomeBadger { <init>(...); }\n-keep class com.onesignal.shortcutbadger.impl.SonyHomeBadger { <init>(...); }\n-keep class com.onesignal.shortcutbadger.impl.XiaomiHomeBadger { <init>(...); }\n```"
}
[/block]

[block:callout]
{
  "type": "success",
  "body": "Done! You should be all set to go with your Android app."
}
[/block]

### Next Steps
[block:callout]
{
  "type": "info",
  "title": "Additional Documentation",
  "body": "We highly recommend following at least our [Small Notification Icon](doc:android-customizations#section-small-notification-icons) instructions to make sure your notification icon displays correctly.\n- To see all available methods, see our [Android SDK API Documentation](doc:android-native-sdk)."
}
[/block]
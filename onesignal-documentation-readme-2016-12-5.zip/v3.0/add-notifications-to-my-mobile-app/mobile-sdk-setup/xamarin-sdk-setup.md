---
title: "Xamarin SDK Setup"
excerpt: "OneSignal Xamarin SDK Reference. Works with <span class=\"label-all label-ios\">iOS</span> and <span class=\"label-all label-android\">Android</span> (and derivatives like <span class=\"label-all label-amazon\">Amazon</span>).\n<div class=\"tag-all tag-developers\">For Developers</div>"
---
## Setup SDK (Quickstart)

### Generate Credentials
Before setting up the Xamarin SDK, you must generate the appropriate credentials for the platform(s) you are releasing on:

<span class="label-all label-ios">iOS</span> - [Generate an iOS Push Certificate](doc:generate-an-ios-push-certificate) 

<span class="label-all label-android">Android</span> - [Generate a Google Server API Key](doc:generate-a-google-server-api-key) 

<span class="label-all label-amazon">Amazon</span> - [Generate an Amazon API Key](doc:generate-an-amazon-api-key) 


Follow the below steps to add OneSignal to Xamarin.Android and Xamarin.iOS.
### Quickstart
There is an example solution included in __OneSignal-Xamarin-SDK__ that could get started. All you would need to edit would be:

<span class="label-all label-ios">iOS</span> - The value for `Bundle identifier` in `Info.plist` source section.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/IhvWuTjERNCLGEi9EQYo_iOSQuickstart.png",
        "iOSQuickstart.png",
        "3166",
        "2104",
        "#1f388e",
        ""
      ]
    }
  ]
}
[/block]

[block:callout]
{
  "type": "success",
  "body": "Done! For a more detailed walk-through of Xamarin, follow the steps below."
}
[/block]
----
## Setup SDK

### Generate Credentials
Before setting up the Xamarin SDK, you must generate the appropriate credentials for the platform(s) you are releasing on:

<span class="label-all label-ios">iOS</span> - [Generate an iOS Push Certificate](doc:generate-an-ios-push-certificate) 

<span class="label-all label-android">Android</span> - [Generate a Google Server API Key](doc:generate-a-google-server-api-key) 

<span class="label-all label-amazon">Amazon</span> - [Generate an Amazon API Key](doc:generate-an-amazon-api-key) 

### 1. Getting Started

**1.1** Download and unzip the [latest OneSignal Xamarin SDK](https://github.com/one-signal/OneSignal-Xamarin-SDK/releases/latest).

**1.2** In Xamarin Studio, for your Xamarin application, create a __Cross-platform Single View__ application. Select __Use Shared Library__ for your Shared Code strategy.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/VNdNBs5ShiIx24FAuUjS_SharedProjectDialog.png",
        "SharedProjectDialog.png",
        "1808",
        "1312",
        "#294058",
        ""
      ]
    }
  ]
}
[/block]
**1.3** Right click on your solution and go to `Add` > `Add Existing Project`.  Select `OneSignal-Xamarin-SDK/SDK/Common/Com.OneSignal/Com.OneSignal/Com.OneSignal.shproj`.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/OD8cK52Q0iB7pkqr7hoU_ImportComOneSignal.png",
        "ImportComOneSignal.png",
        "2028",
        "1410",
        "#2950b8",
        ""
      ]
    }
  ]
}
[/block]
**1.4** Follow the steps according to what platform you are targeting:

<span class="label-all label-android">Android</span> - [Xamarin Android Setup](#section-2-xamarin-android-setup)

<span class="label-all label-ios">iOS</span> - [Xamarin iOS Setup](#section-3-xamarin-ios-setup)


### 2. Xamarin.Android Setup
<div class="label-all label-type"><span class="label-android">Android</span></div>

**2.1** In the Android project of your Cross-application Xamarin solution, add a link to file __OneSignalAndroid.cs__ located at _OneSignal-Xamarin-SDK/SDK/Android/OneSignalAndroid.cs_.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/QtKCD3QRDKFzo8Lrbe1t_AddOneSignalAndroid.png",
        "AddOneSignalAndroid.png",
        "1820",
        "1094",
        "#23409a",
        ""
      ]
    }
  ]
}
[/block]
**2.2** Under references, add the following:
* The __Com.OneSignal__ shared project
* The __OneSignal.Android.Binding__ located at _OneSignal-Xamarin-SDK-<latest>/OneSignal.Android.Binding/OneSignal.Android.Binding/bin/Release/OneSignal.Android.Binding.dll_
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/MwPSKt7KRiisMMJYKUSW_AddComOneSignalRef.png",
        "AddComOneSignalRef.png",
        "1770",
        "712",
        "#294dc9",
        ""
      ]
    }
  ]
}
[/block]

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/mfw1BgaeSJmUPkHnDiIj_AddAndroidBindingDll.png",
        "AddAndroidBindingDll.png",
        "3332",
        "1224",
        "#25448d",
        ""
      ]
    }
  ]
}
[/block]
**2.3** Add the following required components into your application:
* Android Support Library v4
* Google Play Services - Location
* Google Play Services - Cloud Messaging (GCM)
* Google Play Services - Analytics
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/j7lwGeFaQO6LTIXnr5TF_AndroidComponents.png",
        "AndroidComponents.png",
        "664",
        "850",
        "#94450d",
        ""
      ]
    }
  ]
}
[/block]
**2.4** Add the following permissions to `AndroidManifest.xml`.
[block:code]
{
  "codes": [
    {
      "code": "<permission android:name=\"${manifestApplicationId}.permission.C2D_MESSAGE\"\n            android:protectionLevel=\"signature\" />\n<uses-permission android:name=\"${manifestApplicationId}.permission.C2D_MESSAGE\" />",
      "language": "xml"
    }
  ]
}
[/block]
**2.5** In your application tag, add the following.
[block:code]
{
  "codes": [
    {
      "code": "<application ....>\n\n  <receiver android:name=\"com.onesignal.GcmBroadcastReceiver\"\n            android:permission=\"com.google.android.c2dm.permission.SEND\" >\n    <intent-filter>\n      <action android:name=\"com.google.android.c2dm.intent.RECEIVE\" />\n      <category android:name=\"${manifestApplicationId}\" />\n    </intent-filter>\n  </receiver>\n</application>",
      "language": "xml"
    }
  ]
}
[/block]
Make sure to replace all 3 of instances `${manifestApplicationId}` with your package name in AndroidManifest.xml.

**2.7** Add the following Initialization code to the onCreate method on your MainActivity class of your application.
[block:code]
{
  "codes": [
    {
      "code": "using Android.App;\nusing Android.Widget;\nusing Android.OS;\nusing Com.OneSignal;\n\nnamespace Example.Shared.Application.Droid\n{\n\t[Activity (Label = \"Example.Shared.Application\", MainLauncher = true, Icon = \"@mipmap/icon\")]\n\tpublic class MainActivity : Activity\n\t{\n\t\tint count = 1;\n\n\t\tprotected override void OnCreate (Bundle savedInstanceState)\n\t\t{\n\t\t\tbase.OnCreate (savedInstanceState);\n\n\t\t\t// Initialize OneSignal\n      OneSignal.StartInit(\"YOUR_APP_ID\", \"YOUR_GOOGLE_PROJECT_NUMBER\")\n        .EndInit();\n\n\t\t\t// Set our view from the \"main\" layout resource\n\t\t\tSetContentView (Resource.Layout.Main);\n\n\t\t\t// Get our button from the layout resource,\n\t\t\t// and attach an event to it\n\t\t\tButton button = FindViewById<Button> (Resource.Id.myButton);\n\t\t\t\n\t\t\tbutton.Click += delegate {\n\t\t\t\tbutton.Text = string.Format (\"{0} clicks!\", count++);\n\t\t\t};\n\t\t}\n\t}\n}",
      "language": "csharp"
    }
  ]
}
[/block]
**2.10** Add the example notification opened and received delegates ```exampleNotificationReceivedDelegate``` ```exampleNotificationOpenedDelegate``` to run additional code when the notification is either received or opened. __(Optional)__
[block:code]
{
  "codes": [
    {
      "code": "using Android.App;\nusing Android.Widget;\nusing Android.OS;\nusing Com.OneSignal;\n\nnamespace Example.Shared.Application.Droid\n{\n\t[Activity (Label = \"Example.Shared.Application\", MainLauncher = true, Icon = \"@mipmap/icon\")]\n\tpublic class MainActivity : Activity\n\t{\n\t\tint count = 1;\n\n\t\tprotected override void OnCreate (Bundle savedInstanceState)\n\t\t{\n\t\t\tbase.OnCreate (savedInstanceState);\n      \n      OneSignal.NotificationReceived exampleNotificationReceivedDelegate = delegate (OSNotification notification)\n         {\n            try\n            {\n               System.Console.WriteLine(\"OneSignal Notification Received:\\nMessage: {0}\", notification.payload.body);\n               Dictionary<string, object> additionalData = notification.payload.additionalData;\n               \n               if (additionalData.Count > 0)\n                  System.Console.WriteLine(\"additionalData: {0}\", additionalData);\n            }\n            catch (System.Exception e)\n            {\n               System.Console.WriteLine(e.StackTrace);\n            }\n         };\n\n         // Notification Opened Delegate\n         OneSignal.NotificationOpened exampleNotificationOpenedDelegate = delegate (OSNotificationOpenedResult result)\n         {\n            try\n            {\n               System.Console.WriteLine(\"OneSignal Notification opened:\\nMessage: {0}\", result.notification.payload.body);\n               Dictionary<string, object> additionalData = result.notification.payload.additionalData;\n               if (additionalData.Count > 0)\n                  System.Console.WriteLine(\"additionalData: {0}\", additionalData);\n               \n               \n               List<Dictionary<string, object>> actionButtons = result.notification.payload.actionButtons;\n               if (actionButtons.Count > 0)\n                  System.Console.WriteLine(\"actionButtons: {0}\", actionButtons);\n            }\n            catch (System.Exception e)\n            {\n               System.Console.WriteLine(e.StackTrace);\n            }\n         };\n      \n\t\t\t// Initialize OneSignal\n      OneSignal.StartInit(\"YOUR_APP_ID\", \"YOUR_GOOGLE_PROJECT_NUMBER\")\n        .HandleNotificationReceived(exampleNotificationReceivedDelegate)\n        .HandleNotificationOpened(exampleNotificationOpenedDelegate)\n        .EndInit();\n\n\t\t\t// Set our view from the \"main\" layout resource\n\t\t\tSetContentView (Resource.Layout.Main);\n\n\t\t\t// Get our button from the layout resource,\n\t\t\t// and attach an event to it\n\t\t\tButton button = FindViewById<Button> (Resource.Id.myButton);\n\t\t\t\n\t\t\tbutton.Click += delegate {\n\t\t\t\tbutton.Text = string.Format (\"{0} clicks!\", count++);\n\t\t\t};\n\t\t}\n\t}\n}",
      "language": "csharp"
    }
  ]
}
[/block]
### 3. Xamarin.iOS Setup
<div class="label-all label-type"><span class="label-ios">iOS</span></div>

**3.1** In the iOS project of your Cross-application Xamarin solution, add a link to file __OneSignalIOS.cs__ located at _OneSignal-Xamarin-SDK-<latest>/SDK/iOS/OneSignalIOS.cs_.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/f7bGrRATUIE5yMVuwUEw_AddOneSignalIOS.png",
        "AddOneSignalIOS.png",
        "1746",
        "1248",
        "#23419c",
        ""
      ]
    }
  ]
}
[/block]
**3.2** Under references, add the following:
* The __Com.OneSignal__ shared project
* The __OneSignal.iOS.Binding__ located at _OneSignal-Xamarin-SDK-<latest>/OneSignal.iOS.Binding/OneSignal.iOS.Binding/bin/Release/OneSignal.iOS.Binding.dll_
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/k8ZpdfMeSlarJ4PEDI6k_AddComOneSignalRef.png",
        "AddComOneSignalRef.png",
        "2332",
        "1614",
        "#2849bb",
        ""
      ]
    }
  ]
}
[/block]

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/GLzWGeNIRvylh7CzHmpB_AddiOSBindingDll.png",
        "AddiOSBindingDll.png",
        "3358",
        "1842",
        "#2445a1",
        ""
      ]
    }
  ]
}
[/block]
**3.3** In your application's __Info.plist__, verify your _Bundle Identifier_ matches you App Settings' Bundle ID, _Enable Background Modes_, allow _Remote notifications_ under the __Application__ tab and set your OneSignal Application ID in the __Source__ tab.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/KVAFqY9zSB2MUErANFrV_InfoPlist1.png",
        "InfoPlist1.png",
        "2574",
        "1448",
        "#1c3179",
        ""
      ]
    }
  ]
}
[/block]

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/S6cGWRoyT2KqshtrwWng_InfoPlist2.png",
        "InfoPlist2.png",
        "2854",
        "1078",
        "#1d368d",
        ""
      ]
    }
  ]
}
[/block]
**3.4** In `AppDelegate.cs`, add OneSignal's initialization code in your `FinishedLaunching` method.
[block:code]
{
  "codes": [
    {
      "code": "using Foundation;\nusing UIKit;\nusing Com.OneSignal;\n\nnamespace Example.Shared.Application.iOS\n{\n\t// The UIApplicationDelegate for the application. This class is responsible for launching the\n\t// User Interface of the application, as well as listening (and optionally responding) to application events from iOS.\n\t[Register (\"AppDelegate\")]\n\tpublic class AppDelegate : UIApplicationDelegate\n\t{\n\t\t// class-level declarations\n\n\t\tpublic override UIWindow Window {\n\t\t\tget;\n\t\t\tset;\n\t\t}\n\n\t\tpublic override bool FinishedLaunching (UIApplication application, NSDictionary launchOptions)\n\t\t{\n\t\t\t// Initialize OneSignal\n         OneSignal.StartInit(\"YOUR_APP_ID\")\n           .EndInit();\n\n\t\t\treturn true;\n\t\t}\n\t}\n}",
      "language": "csharp"
    }
  ]
}
[/block]
**3.5** Add the example notification received or opened delegate ```exampleNotificationReceivedDelegate``` ```exampleNotificationOpenedDelegate``` to run additional code when the notification is opened. __(Optional)__
[block:code]
{
  "codes": [
    {
      "code": "using Foundation;\nusing UIKit;\nusing Com.OneSignal;\n\nnamespace Example.Shared.Application.iOS\n{\n\t// The UIApplicationDelegate for the application. This class is responsible for launching the\n\t// User Interface of the application, as well as listening (and optionally responding) to application events from iOS.\n\t[Register (\"AppDelegate\")]\n\tpublic class AppDelegate : UIApplicationDelegate\n\t{\n\t\t// class-level declarations\n\n\t\tpublic override UIWindow Window {\n\t\t\tget;\n\t\t\tset;\n\t\t}\n\n\t\tpublic override bool FinishedLaunching (UIApplication application, NSDictionary launchOptions)\n\t\t{\n               OneSignal.NotificationReceived exampleNotificationReceivedDelegate = delegate (OSNotification notification)\n         {\n            try\n            {\n               System.Console.WriteLine(\"OneSignal Notification Received: {0}\", notification.payload.body);\n               Dictionary<string, object> additionalData = notification.payload.additionalData;\n\n               if (additionalData.Count > 0)\n                  System.Console.WriteLine(\"additionalData: {0}\", additionalData);\n            }\n            catch (System.Exception e)\n            {\n               System.Console.WriteLine(e.StackTrace);\n            }\n         };\n         \n\t\t\t// Notification Opened Delegate\n\t\t\tOneSignal.NotificationOpened exampleNotificationOpenedDelegate = delegate(OSNotificationOpenedResult result)\n         {\n\t\t\t\ttry\n\t\t\t\t{\n               System.Console.WriteLine (\"OneSignal Notification opened: {0}\", result.notification.payload.body);\n               \n               Dictionary<string, object> additionalData = result.notification.payload.additionalData;\n               List<Dictionary<string, object>> actionButtons = result.notification.payload.actionButtons;\n               \n               if (additionalData.Count > 0)\n                  System.Console.WriteLine(\"additionalData: {0}\", additionalData);\n\n               if (actionButtons.Count > 0)\n                  System.Console.WriteLine (\"actionButtons: {0}\", actionButtons);\n\t\t\t\t}\n\t\t\t\tcatch (System.Exception e)\n\t\t\t\t{\n\t\t\t\t\tSystem.Console.WriteLine (e.StackTrace);\n\t\t\t\t}\n\t\t\t};\n\n\t\t\t// Initialize OneSignal\n      OneSignal.StartInit(\"YOUR_APP_ID\")\n        .HandleNotificationReceived(exampleNotificationReceivedDelegate)\n        .HandleNotificationOpened(exampleNotificationOpenedDelegate)\n        .EndInit();\n\n\t\t\treturn true;\n\t\t}\n\t}\n}",
      "language": "csharp"
    }
  ]
}
[/block]

[block:callout]
{
  "type": "success",
  "body": "Done! You should be all set to go with your Xamarin app."
}
[/block]
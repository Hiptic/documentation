---
title: "Marmalade SDK Setup"
excerpt: "OneSignal Marmalade SDK Setup Guide. Works with <span class=\"label-all label-ios\">iOS</span>, <span class=\"label-all label-android\">Android</span> (and derivatives like <span class=\"label-all label-amazon\">Amazon</span>), and <span class=\"label-all label-windows\">Windows Phone 8.0 & 8.1</span>.\n<div class=\"tag-all tag-developers\">For Developers</div>"
---
[block:callout]
{
  "type": "warning",
  "body": "To use the latest OneSignal SDK for Marmalade please update to Marmalade 7.8 or later. OneSignal may work on older versions of Marmalade but is not guaranteed.",
  "title": "Marmalade 7.8+"
}
[/block]
## Setup SDK

### Generate Credentials
Before setting up the Marmalade SDK, you must generate the appropriate credentials for the platform(s) you are releasing on:

<span class="label-all label-ios">iOS</span> - [Generate an iOS Push Certificate](doc:generate-an-ios-push-certificate) 

<span class="label-all label-android">Android</span> - [Generate a Google Server API Key](doc:generate-a-google-server-api-key) 

<span class="label-all label-amazon">Amazon</span> - [Generate an Amazon API Key](doc:generate-an-amazon-api-key) 

### 1. Download latest OneSignal SDK

**1.1.** Download the [latest extension](https://github.com/one-signal/OneSignal-Marmalade-SDK/releases).

**1.2.** Place the `s3eOneSignal` folder one level up from your project folder.

### 2. Add the extension to your project

**2.1.** Open your project's .mkb file and add the following. 
[block:code]
{
  "codes": [
    {
      "code": "options\n{\n\tmodule_path=../s3eOneSignal\n}\nsubproject ../s3eOneSignal/s3eOneSignal.mkf\n\ndeployments\n{\n  android-extra-strings='(gps_app_id, 999)'  ## required by google-play-services.\n\n  iphone-link-opts=\"-weak_framework UIKit\"\n\n\twp8-custom-manifest=OneSignalCustomWP8Manifest.xml\n\twp8-custom-manifest-fill=0\n}",
      "language": "sass",
      "name": "MKB"
    }
  ]
}
[/block]
### 3. Add required code

**3.1.** Open the .cpp file that contains your `int main()` function.

**3.2.** Include s3eOneSignal.h
[block:code]
{
  "codes": [
    {
      "code": "#include \"s3eOneSignal.h\"",
      "language": "cplusplus"
    }
  ]
}
[/block]
**3.3.** Add the following 3 lines to the top of the main function and update them as appropriate (below)
[block:code]
{
  "codes": [
    {
      "code": "OneSignalInitialize(\"5eb5a37e-b458-11e3-ac11-000c2940e62c\", \"703322744261\", (OneSignalNotificationReceivedCallbackFn)HandleReceivedNotification, true);\ns3eDeviceRegister(S3E_DEVICE_PAUSE, &OneSignalSystemPaused, NULL);\ns3eDeviceRegister(S3E_DEVICE_UNPAUSE, &OneSignalSystemResume, NULL);",
      "language": "cplusplus"
    }
  ]
}
[/block]
Update `OneSignalInitialize`'s 1st parameter with your OneSignal App Id, which can be found in <a class="dash-link">Keys & IDs</a>.

<span class="label-all label-android">Android</span>, <span class="label-all label-amazon">Amazon</span> - update the 2nd parameter with your Google Project Number.

<span class="label-all label-ios">iOS</span>, <span class="label-all label-windows">Windows Phone</span> - update the 2nd parameter with `NULL`.


**3.4.** Add the following `HandleReceivedNotification` function above your `int main()` function and customize to your liking.
[block:code]
{
  "codes": [
    {
      "code": "static void HandleReceivedNotification(OneSignalNotificationReceivedResult* result, void* userData) {\n    char buffer[1024];\n    sprintf(buffer, \"NOTIFICATION RECIEVED CALLBACK MESSAGE: %s\", result->m_Message);\n    s3eDebugOutputString(buffer);\n    if (result->m_AdditionalData != NULL) {\n        char buffer2[1024];\n        sprintf(buffer2, \"NOTIFICATION RECIEVED CALLBACK ADDITIONALDATA: %s\", result->m_AdditionalData);\n        s3eDebugOutputString(buffer2);\n    }\n}",
      "language": "cplusplus"
    }
  ]
}
[/block]
### 4. Android Setup
<div class="label-all label-type"><span class="label-android">Android</span></div>

**4.1.** Build like normal, no extra setup steps!

**4.2.** If you are also using the s3eFacebook plugin you will need to follow these [additional steps](http://documentation.onesignal.com/v2.0/docs/marmalade-additional-setup).

### 5. Amazon Setup
<div class="label-all label-type"><span class="label-amazon">Amazon</span></div>

**5.1.** Open your project's .mkb file and add the following:
[block:code]
{
  "codes": [
    {
      "code": "assets\n{\n\tandroid/assets/api_key.txt\n}",
      "language": "sass",
      "name": "MKB"
    }
  ]
}
[/block]
**5.2.** Place your `api_key.txt` file into `<project-folder>/android/assets/`. Create the folders if you do not have them yet.

*To create an `api_key.txt` for your app follow our [Generate an Amazon API Key](doc:generate-an-amazon-api-key)*

### 6. iOS Setup
<div class="label-all label-type"><span class="label-ios">iOS</span></div>

**6.1.** Build like normal, no extra setup steps!

### 7. Windows Phone Setup
<div class="label-all label-type"><span class="label-windows">Windows Phone</span></div>

**7.1.** From the Marmalade hub press BUILD then package to create an up to date `WMAppManifest.xml` release file with some OneSignal settings defaulted in.

**7.2.** Copy `WMAppManifest.xml` from `build_PROJECTNAME_vc12_wp8toolset\deployments\default\wp8\release\wp8-arm\intermediate_files` to the root of your project folder and rename it to `ProjectWP8Manifest.xml`.

**7.3.** Open `ProjectWP8Manifest.xml` and add `<Capability Name="ID_CAP_PUSH_NOTIFICATION"/>` under `<Capabilities>`.

**7.4.** Replace the current `<DefaultTask>` tag with `<DefaultTask Name="_default" NavigationPage="Marmalade.App;component/MainPage.xaml"/>`
[block:callout]
{
  "type": "success",
  "body": "Done! You should be all set to go with your Marmalade app."
}
[/block]
----
## Additional Documentation
[block:callout]
{
  "type": "info",
  "title": "",
  "body": "To see all available methods, see our [Marmalade SDK](doc:marmalade-sdk)."
}
[/block]
---
title: "Cordova SDK Setup"
excerpt: "OneSignal Cordova SDK Setup Guide. Works with <span class=\"label-all label-ios\">iOS</span>, <span class=\"label-all label-android\">Android</span> (and derivatives like <span class=\"label-all label-amazon\">Amazon</span>) and <span class=\"label-all label-windows\">Windows Phone 8.1</span>.\n<div class=\"tag-all tag-developers\">For Developers</div>"
---
## Update SDK
If you already have an app with the Cordova SDK, you can run this to ensure your SDK is on the latest version:
[block:code]
{
  "codes": [
    {
      "code": "cordova plugin update onesignal-cordova-plugin",
      "language": "shell"
    }
  ]
}
[/block]
If you have not set up an app yet, follow the instructions below.

----

## Setup SDK
### Generate Credentials
Before setting up the Cordova SDK, you must generate the appropriate credentials for the platform(s) you are releasing on:

<span class="label-all label-ios">iOS</span> - [Generate an iOS Push Certificate](doc:generate-an-ios-push-certificate) 

<span class="label-all label-android">Android</span> - [Generate a Google Server API Key](doc:generate-a-google-server-api-key) 

<span class="label-all label-amazon">Amazon</span> - [Generate an Amazon API Key](doc:generate-an-amazon-api-key) 

<span class="label-all label-windows">Windows Phone 8.1</span> - [Generate a Windows Phone Package SID and Secret](doc:generate-a-windows-phone-package-sid-and-secret) 

### 1. Import OneSignal Plugin
*Please follow step 1A or 1B based how you build your app.*

#### 1A. Import from the Terminal
Run the following from your project directory.
[block:code]
{
  "codes": [
    {
      "code": "cordova plugin add onesignal-cordova-plugin",
      "language": "shell",
      "name": "Cordova"
    },
    {
      "code": "# Cordova 4 has a number of security holes, recommend updating to the latest version.\n\ncordova plugin add https://github.com/one-signal/OneSignal-Cordova-SDK.git#PGB-Compat\n\n# Android - require \"Google Play services\" and \"Android Support Library v4\" to be included with your app.\n# Add the following plugins if you do not have them in your app already from another plugin.\nhttps://github.com/floatinghotpot/google-play-services\nhttps://github.com/floatinghotpot/cordova-plugin-android-support-v4",
      "language": "c",
      "name": "Pre-4.0 Cordova"
    }
  ]
}
[/block]
*-- OR --*

#### 1B. Visual Studio

**1.** Open your project's `config.xml` and select Platforms. Make sure you have Cordova CLI 5 or higher.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/NJSVHqOoSdWLKoI7C1Vn_VSCordovaVersion.png",
        "VSCordovaVersion.png",
        "894",
        "224",
        "#2e537f",
        ""
      ]
    }
  ]
}
[/block]
**2.** Right click on `config.xml` and select "View Code".
**3.** Add the following to the file:
[block:code]
{
  "codes": [
    {
      "code": "  <vs:features>\n    <vs:feature>onesignal-cordova-plugin</vs:feature>\n  </vs:features>",
      "language": "xml"
    }
  ]
}
[/block]

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/PbYr1oAeTuS98pXIXgqW_VSCordovaAddOneSignal.png",
        "VSCordovaAddOneSignal.png",
        "838",
        "312",
        "#2f4d92",
        ""
      ]
    }
  ]
}
[/block]

### 2. Add required code
**2.1.** Add the following to the first javascript file that loads with your app.
- This is `<project-dir>/www/js/index.js` for most Cordova projects.
[block:code]
{
  "codes": [
    {
      "code": "// Add to index.js or the first page that loads with your app.\n// For Intel XDK and please add this to your app.js.\n\ndocument.addEventListener('deviceready', function () {\n  // Enable to debug issues.\n  // window.plugins.OneSignal.setLogLevel({logLevel: 4, visualLevel: 4});\n  \n  var notificationOpenedCallback = function(jsonData) {\n    console.log('notificationOpenedCallback: ' + JSON.stringify(jsonData));\n  };\n\n  window.plugins.OneSignal\n    .startInit(\"YOUR_APPID\", \"YOUR_GOOGLE_PROJECT_NUMBER_IF_ANDROID\")\n    .handleNotificationOpened(notificationOpenedCallback)\n    .endInit();\n  \n  // Sync hashed email if you have a login system or collect it.\n  //   Will be used to reach the user at the most optimal time of day.\n  // window.plugins.OneSignal.syncHashedEmail(userEmail);\n}, false);",
      "language": "javascript",
      "name": "Cordova"
    }
  ]
}
[/block]
**2.2 ** Update initialization parameters 

Replace `YOUR_APPID` with your OneSignal AppId, available in <a class="dash-link" href="/docs/accounts-and-keys#section-keys-ids">Keys & IDs</a>

<span class="label-all label-android">Android</span>, <span class="label-all label-amazon">Amazon</span> - Replace `YOUR_GOOGLE_PROJECT_NUMBER_IF_ANDROID` with your Google Project Number. 

<span class="label-all label-ios">iOS</span>, <span class="label-all label-windows">Windows Phone</span> - Leave `YOUR_GOOGLE_PROJECT_NUMBER_IF_ANDROID` blank if your app isn't for Android.

<span class="label-all label-recommended">Recommended</span> - Change `inFocusDisplaying` to `None` when app is ready for launch. See [Cordova SDK Reference](doc:cordova-sdk#section--infocusdisplaying-) for instructions.

<span class="label-all label-optional">Optional</span> - follow the [Cordova SDK reference](doc:cordova-sdk) to add code for when users tap on and open notifications to your liking by using the chaining methods `handleNotificationReceived` and `handleNotificationOpened`.


### 3. Android

**3.1 ** Open the Android SDK Manager.

**3.2 ** Make sure to install and update the following under Extras:

- Android Support **Repository**
- Google **Repository**
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/cfbZBwxSmeToNEbZJoz0_AndroidSDKGoogleRepository.png",
        "AndroidSDKGoogleRepository.png",
        "600",
        "341",
        "#c7413e",
        ""
      ]
    }
  ]
}
[/block]

**3.3 ** Follow the [Customize Notification Icons](doc:customize-notification-icons) instructions to create a small notification icon required for Android 5.0+ devices.

### 4. Amazon ADM

Place your `api_key.txt` file into your `<project-dir>/platforms/android/assets/` folder.

*To create an `api_key.txt` for your app follow our [Generate an Amazon API Key](doc:generate-an-amazon-api-key)*

### 5. iOS
[block:callout]
{
  "type": "danger",
  "title": "Important - XCode 8",
  "body": "You **MUST** follow the Capabilities steps below if you are using Xcode 8!\n*If you miss this step users will not get a push token or have mismatch environment issues.*"
}
[/block]
**5.1** Select the root project and Under Capabilities Enable "Push Notifications".
**5.2** Next Enable "Background Modes" and check "Remote notifications".
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/b80f76b-Xcode_capabilities.png",
        "Xcode capabilities.png",
        961,
        774,
        "#f0f0f0"
      ]
    }
  ]
}
[/block]
### 6. Windows Phone 8.1 (WP8.1)

*Your app does not have to be published however, you must have it created on the Windows Dev Center. Follow our [Windows Phone Project SID & Secret](http://documentation.onesignal.com/v2.0/docs/windows-phone-client-sid-secret) setup if you have not done this yet.*

**6.1** Run `cordova build windows` and open the .sln in <project-root>/platforms/windows/

**6.2** Under the Windows Phone 8.1 project double click on `Package.appxmanifest` then select the "Application" tab and scroll down to the "Notifications:" section. Change "Toast capable:" to Yes.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/0eX5aHISfWQhNWmLJGoJ_WindowPhone8.1_SDK_2.1.png",
        "WindowPhone8.1_SDK_2.1.png",
        "851",
        "282",
        "#384868",
        ""
      ]
    }
  ]
}
[/block]
**6.3** Right click on your VS project and select Store>Associate App with the Store...
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/tKhdtb2jQdSMnHskkysn_WindowPhone8.1__SDK_1.1.png",
        "WindowPhone8.1__SDK_1.1.png",
        "714",
        "510",
        "#2f4363",
        ""
      ]
    }
  ]
}
[/block]
**6.4** Click Next and sign into your Microsoft account.

**6.5** Select your app and press Next.

**6.6.** Lastly press Associate.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/mUHzdp7SlyXIpWn71Y6Q_WindowPhone8.1_SDK_4.3.png",
        "WindowPhone8.1_SDK_4.3.png",
        "786",
        "643",
        "#3489da",
        ""
      ]
    }
  ]
}
[/block]

[block:callout]
{
  "type": "success",
  "body": "Done! You should be all set to go with your Cordova app."
}
[/block]
----
## SDK API
Check out our [Cordova SDK](doc:cordova-sdk) for more OneSignal functions.
[block:callout]
{
  "type": "warning",
  "title": "Push Notification Testing Requirements",
  "body": "* *iOS* - Must test on a real device, Simulator does not support Apple push notifications.\n* *Android*\n   * You **MUST** build and install your app's APK. \n   * You may use an emulator but it must have an updated version of Google Play services installed."
}
[/block]

[block:callout]
{
  "type": "info",
  "title": "Troubleshooting",
  "body": "If you run into any errors see [Troubleshooting Cordova Variants](doc:troubleshooting-cordova-variants), our our general [Troubleshooting](doc:known-issues) section."
}
[/block]
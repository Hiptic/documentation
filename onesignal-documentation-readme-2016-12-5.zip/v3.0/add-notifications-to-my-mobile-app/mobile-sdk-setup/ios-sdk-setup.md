---
title: "iOS SDK Setup"
excerpt: "OneSignal <span class=\"label-all label-ios\">iOS</span> SDK Reference. \n<div class=\"tag-all tag-developers\">For Developers</div>"
---
[block:callout]
{
  "type": "info",
  "body": "If you're using an app framework to build your <span class=\"label-all label-ios\">iOS</span> app, we have higher level SDKs for the following:\n[Unity](doc:unity-sdk-setup), [PhoneGap](doc:phonegap-sdk-setup), [Cordova](doc:cordova-sdk-setup), [Ionic](doc:ionic-sdk-setup), [Intel XDK](doc:intel-xdk-setup), [React Native](doc:react-native-sdk-setup), [Corona](doc:corona-sdk-setup), [Cocos2d](doc:cocos2d-x-sdk-setup), [Marmalade](doc:marmalade-sdk-setup), [Adobe Air](doc:adobe-air-sdk-setup), and [Xamarin](doc:xamarin-sdk-setup).",
  "title": "Using an app framework?"
}
[/block]
## Update SDK
If you have an app with a previous version of the iOS SDK, read our [Upgrading to iOS SDK 2.0 guide](doc:upgrading-to-ios-sdk-20).

## Setup SDK

### Generate Credentials
Follow the instructions to [generate an iOS Push Certificate](doc:generate-an-ios-push-certificate).

### 1. Import OneSignal into your Xcode project

#### Option A: Use CocoaPods (Recommended)
[Setting up CocoaPods](http://guides.cocoapods.org/using/getting-started.html) on your system if you don't have it already.
   - Make sure you have the latest `1.1.0` version by running `pod --version` from the terminal.
   - Run the following to upgrade `sudo gem install cocoapods`
 
**1.1** Make sure your current Xcode project is closed.
**1.2**  Run `pod init`
**1.3** Run `echo "pod 'OneSignal'" >> Podfile`
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**NOTE** (React Native only) : Run `echo "pod 'OneSignal', '~> 1.13.3'" >> Podfile` instead.
**1.3** Run `pod install`
**1.4** Open the newly created `.xcworkspace` file.<br>*Make sure to always open the workspace from now on.*
<br>
 **-- OR --**
<br>
#### Option B: Use Carthage
You can also use [Carthage](https://github.com/Carthage/Carthage#installing-carthage) for setting up and upgrading the OneSignal SDK.

**1.1** Make sure your current Xcode project is closed.
**1.2** Run `echo 'github "OneSignal/OneSignal-iOS-SDK"' >> Cartfile`
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**NOTE** (React Native only) : Run `echo 'github "OneSignal/OneSignal-iOS-SDK" "1.13.3"' >> Cartfile` instead.
**1.3** Run `carthage update`.
**1.4** Open your Xcode project.
**1.5** On your application targets’ “General” settings tab, in the “Linked Frameworks and Libraries” section, drag and drop `OneSignal.framework` from the `$(PROJECT_DIR)/Carthage/Build/iOS` folder on disk.
**1.6** On your application targets’ “Build Phases” settings tab, click the “+” icon and choose “New Run Script Phase”. Create a Run Script in which you specify your shell (ex: `bin/sh`), add the following contents to the script area below the shell:
`/usr/local/bin/carthage copy-frameworks`
**1.7** add the path to the `OneSignal` framework under “Input Files”:
`$(SRCROOT)/Carthage/Build/iOS/OneSignal.framework`
[block:callout]
{
  "type": "info",
  "body": "This script works around an App Store submission bug triggered by universal binaries and ensures that necessary bitcode-related files and dSYMs are copied when archiving."
}
[/block]
----
### 2. Add Required Capabilities
[block:callout]
{
  "type": "danger",
  "title": "Important - XCode 8",
  "body": "You **MUST** follow the Capabilities steps below if you are using Xcode 8!\n*If you miss this step users will not get a push token or have mismatch environment issues.*\n*OneSignal is tested with Xcode 7.3.1 and newer. May work on older versions of Xcode but we do not provide support for it.*"
}
[/block]
**2.1** Select the root project and Under Capabilities Enable "Push Notifications".
**2.2** Next Enable "Background Modes" and check "Remote notifications".
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/VflTGOPzRDu2YmhiRgiV_Xcode%20capabilities.png",
        "Xcode capabilities.png",
        "961",
        "774",
        "#385e92",
        ""
      ],
      "sizing": "80"
    }
  ]
}
[/block]
### 3. Add Required Code
Add following code to your AppDelegate.

[block:code]
{
  "codes": [
    {
      "code": "#import \"AppDelegate.h\"\n\n//Add this line\n#import <OneSignal/OneSignal.h>\n\n@implementation AppDelegate\n\n- (BOOL)application:(UIApplication*)application didFinishLaunchingWithOptions:(NSDictionary*)launchOptions {\n    \n  //Add this line. Replace '5eb5a37e-b458-11e3-ac11-000c2940e62c' with your OneSignal App ID.\n   [OneSignal initWithLaunchOptions:launchOptions appId:@\"5eb5a37e-b458-11e3-ac11-000c2940e62c\"];\n  \n  // Sync hashed email if you have a login system or collect it.\n  //   Will be used to reach the user at the most optimal time of day.\n  // [OneSignal syncHashedEmail:userEmail];\n    \n   return YES;\n}",
      "language": "objectivec",
      "name": "Objective-C (AppDelegate.m)"
    },
    {
      "code": "import OneSignal\n\nfunc application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {\n        \n   //Add this line. Replace '5eb5a37e-b458-11e3-ac11-000c2940e62c' with your OneSignal App ID.\n   OneSignal.initWithLaunchOptions(launchOptions, appId: \"5eb5a37e-b458-11e3-ac11-000c2940e62c\")\n   \n  // Sync hashed email if you have a login system or collect it.\n  //   Will be used to reach the user at the most optimal time of day.\n  // OneSignal.syncHashedEmail(userEmail)\n   \n   return true\n}",
      "language": "swift",
      "name": "Swift (AppDelegate.swift)"
    }
  ]
}
[/block]

[block:callout]
{
  "type": "warning",
  "body": "Make sure `OneSignal initWithLaunchOptions` is called from your `didFinishLaunchingWithOptions` method otherwise it may not get subscribed."
}
[/block]

[block:callout]
{
  "type": "success",
  "title": "",
  "body": "Done! The Xcode simulator doesn't support push notifications so you must test on a device."
}
[/block]

----
## Optional: Notification Opened Callback
If you need to process any information on the notification *(such as deep linking to to a specific screen in your app)* you can add a notification action callback that will fire when the user reacts to a notification received.

Replace the code you added in step 3 in your `didFinishLaunchingWithOptions` method with the code below.*
[block:code]
{
  "codes": [
    {
      "code": "[OneSignal initWithLaunchOptions:launchOptions appId:@\"b2f7f966-d8cc-11e4-bed1-df8f05be55ba\" handleNotificationAction:^(OSNotificationOpenedResult *result) {\n        \n        // This block gets called when the user reacts to a notification received\n        OSNotificationPayload* payload = result.notification.payload;\n        \n        \n        NSString* messageTitle = @\"OneSignal Example\";\n        NSString* fullMessage = [payload.body copy];\n        \n        if (payload.additionalData) {\n            \n            if(payload.title)\n                messageTitle = payload.title;\n            \n            NSDictionary* additionalData = payload.additionalData;\n            \n            if (additionalData[@\"actionSelected\"])\n                fullMessage = [fullMessage stringByAppendingString:[NSString stringWithFormat:@\"\\nPressed ButtonId:%@\", additionalData[@\"actionSelected\"]]];\n        }\n        \n        UIAlertView* alertView = [[UIAlertView alloc] initWithTitle:messageTitle\n                                                            message:fullMessage\n                                                           delegate:self\n                                                  cancelButtonTitle:@\"Close\"\n                                                  otherButtonTitles:nil, nil];\n        [alertView show];\n\n    }];",
      "language": "objectivec"
    },
    {
      "code": "OneSignal.initWithLaunchOptions(launchOptions, appId: \"b2f7f966-d8cc-11e4-bed1-df8f05be55ba\") { (result) in\n            \n\t\t// This block gets called when the user reacts to a notification received\n            \n\t\tlet payload = result.notification.payload\n\t\tlet messageTitle = \"OneSignal Example\"\n\t\tvar fullMessage = payload.title\n            \n\t\t//Try to fetch the action selected\n\t\tif let additionalData = payload.additionalData, actionSelected = additionalData[\"actionSelected\"] as? String {\n\t\t\tfullMessage =  fullMessage + \"\\nPressed ButtonId:\\(actionSelected)\"\n\t\t}\n            \n\t\tlet alertView = UIAlertView(title: messageTitle, message: fullMessage, delegate: nil, cancelButtonTitle: \"Close\")\n\t\talertView.show()\n\t}",
      "language": "swift"
    }
  ]
}
[/block]
----
## Optional: Custom notification sounds
Drag and drop the custom notification sounds you want available into the root of the XCode project.

Read more in [Customize Notification Sounds](doc:customize-notification-sounds) for information on file formats, differences between platforms, and how to send notifications with custom sounds.

----
[block:callout]
{
  "type": "info",
  "body": "To see all available methods, see our [iOS Native SDK](doc:ios-native-sdk) documentation.",
  "title": "Additional Documentation"
}
[/block]
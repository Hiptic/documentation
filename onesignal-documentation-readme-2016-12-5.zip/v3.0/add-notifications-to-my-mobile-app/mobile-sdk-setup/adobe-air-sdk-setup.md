---
title: "Adobe Air SDK Setup"
excerpt: "OneSignal Adobe Air SDK Reference. Works with <span class=\"label-all label-ios\">iOS</span> and <span class=\"label-all label-android\">Android</span>."
---
## Setup SDK

### Generate Credentials
Before setting up the Adobe Air SDK, you must generate the appropriate credentials for the platform(s) you are releasing on:

<span class="label-all label-ios">iOS</span> - [Generate an iOS Push Certificate](doc:generate-an-ios-push-certificate) 

<span class="label-all label-android">Android</span> - [Generate a Google Server API Key](doc:generate-a-google-server-api-key) 

### Select Third Party SDK
There is currently no first-party Adobe Air SDK. You may use one of the following options to build your Adobe Air app:

#### Milkman Games OneSignal Adobe Air Plugin
Adobe Air support is available via an excellent 3rd party extension courtesy of Milkman Games for a one time fee of $39.99.

**1.** Purchase the Milkman Games EasyPush extension on [this page](https://www.milkmanplugins.com/easy-push-notifications-air-ane).

**2.** Follow their instructions to add it to your app.

#### Open Source OneSignal Adobe Air Plugin
There is also a free and open source Adobe Air plugin for OneSignal available [here](https://github.com/marpies/onesignal-ane).

#### Write Your Own
<span class="label-all label-advanced">Advanced Topic</span> - If you prefer, you can write your own extension that integrates with our [server REST API](ref:create-notification).
---
title: "NativeScript SDK Setup"
excerpt: "OneSignal NativeScript SDK Setup Guide. Works with <span class=\"label-all label-ios\">iOS</span> and <span class=\"label-all label-android\">Android</span> (and derivatives like <span class=\"label-all label-amazon\">Amazon</span>).\n<div class=\"tag-all tag-developers\">For Developers</div>"
---
## Setup SDK

### Generate Credentials
Before setting up the NativeScript SDK, you must generate the appropriate credentials for the platform(s) you are releasing on:

<span class="label-all label-ios">iOS</span> - [Generate an iOS Push Certificate](doc:generate-an-ios-push-certificate) 

<span class="label-all label-android">Android</span> - [Generate a Google Server API Key](doc:generate-a-google-server-api-key) 

<span class="label-all label-amazon">Amazon</span> - [Generate an Amazon API Key](doc:generate-an-amazon-api-key) 

### Follow Guide
Then, [follow this guide](https://www.npmjs.com/package/nativescript-onesignal) to setup OneSignal with your NativeScript App.
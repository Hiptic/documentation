---
title: "Blogger"
excerpt: "<div class=\"tag-all tag-developers\">For Developers</div>"
---
To use OneSignal with Blogger, please follow our [Web Push SDK Setup (HTTP)](doc:web-push-sdk-setup-http)  guide. Due to limitations of Blogger, our HTTPS setup process is not possible.
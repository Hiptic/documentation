---
title: "Wordpress"
excerpt: "<div class=\"tag-all tag-developers\">For Developers</div> <div class=\"tag-all tag-marketers\">For Marketers</div>"
---
If you host your own WordPress site, you can install our [WordPress Plugin](https://wordpress.org/plugins/onesignal-free-web-push-notifications/) to use web push notifications. Please follow the instructions on our WordPress plugin's Setup guide, and ignore our documentation here for SDK installation. The same steps are in our plugin's Setup guide.





----

## Customizing WordPress Plugin Behavior
<div class="label-type"><span class="label-all label-advanced">Advanced Topic</span> &middot; <span class="label-all label-developers">For Developers</span></div>

Our WordPress plugin comes with some [action and filter hooks](https://www.tipsandtricks-hq.com/wordpress-action-hooks-and-filter-hooks-an-introduction-4163) that allow you to write PHP code to extend our plugin's functionality.

For example, our hooks can be used to:
- Automatically check or uncheck the [meta box checkbox](http://i.imgur.com/xJ4BuSb.png) "Send notification on post publish"
  - You can use this to make it easier for content publishes to automatically send notifications for certain kind of posts
- Always send a notification for certain post
  - (e.g. custom post types)
- Never send a notification for certain posts
  - You can combine the include/exclude filter
- Override any notification parameter, add extra parameters, remove extra parameters, and even send multiple notifications using the same call
[block:callout]
{
  "type": "warning",
  "body": "For all the following example usage calls, you'll have to copy and paste the PHP code into a file that will always be called. The goal is to add the below code to this file so that it will get called when our plugin takes the specified action. We recommend using [WordPress' must-use plugins feature](https://www.sitepoint.com/wordpress-mu-plugins/) to add your code to a file in the special specified directory to ensure your code is not overwritten when our plugin updates or when you update WordPress.",
  "title": "Important Note"
}
[/block]

### Activating OneSignal on certain pages only

Customizing which pages OneSignal is active on when using our WordPress plugin is possible.

We offer two options that can be combined:

- **Initializing OneSignal conditionally from server-sided PHP**

  Please see the [onesignal_initialize_sdk Filter](#section-onesignal_initialize_sdk-filter) section of this page. Using this WordPress filter hook will allow you to use server-sided PHP code to determine when to initialize OneSignal.

  This is useful if you want to target pages based on properties that are only available on the server side.

- **Never initialize OneSignal automatically, manually initialize OneSignal on target pages using client-sided JavaScript**

  Please visit our WordPress plugin's Configuration page in your WordPress admin area. Scroll down to the bottom and enable "Use my own SDK initialization script".

  When this option is enabled, OneSignal *will not* be automatically initialized on *any* page, and you must add JavaScript code to each page to initialize OneSignal.

  This creates a global JavaScript variable on the page `window._oneSignalInitOptions` that you can use to initialize OneSignal with (see below) any time you choose.

  You can add conditional JavaScript rules to modify when you'd like to initialize OneSignal.

  Initialize OneSignal with:

  ```js
  window.OneSignal = window.OneSignal || [];
  window.OneSignal.push(function() {
    window.OneSignal.init(window._oneSignalInitOptions);
  });
  ```

---
### onesignal_initialize_sdk Filter

Return true to allow our WordPress plugin to initialize our web SDK, which creates all the UI elements on the page and prompts users to subscribe.

Return false to customize when you would like the SDK to be initialized (e.g. only on certain pages).

When true, the target pages will not be automatically in initialized. You must manually initialize OneSignal by calling  `OneSignal.init(window._oneSignalInitOptions);` in the client-sided JavaScript code of the page.

When false, the target pages will be automatically initialized (like normal) -- unless you have "Use my own SDK initialization script" enabled in the WordPress Configuration page (near the bottom).
[block:code]
{
  "codes": [
    {
      "code": "<?php\nadd_filter('onesignal_initialize_sdk', 'onesignal_initialize_sdk_filter', 10, 1);\nfunction onesignal_initialize_sdk_filter($onesignal_settings) {\n    // Return true to allow the SDK to initialize normally\n    // Return false to prevent the SDK from initializing\n    return true;\n}",
      "language": "php"
    }
  ]
}
[/block]
----
### onesignal_meta_box_send_notification_checkbox_state Filter

Overrides the state of the [meta box checkbox "Send notification on post publish"](http://i.imgur.com/xJ4BuSb.png).
[block:code]
{
  "codes": [
    {
      "code": "<?php\nadd_filter('onesignal_meta_box_send_notification_checkbox_state', 'filter', 10, 2);\n// Available keys for $onesignal_wp_settings: https://github.com/OneSignal/OneSignal-WordPress-Plugin/blob/master/onesignal-settings.php#L5\nfunction filter($post, $onesignal_wp_settings) {\n  // Always leave the checkbox \"Send notification on <post type> <action> (e.g. post publish)\" unchecked\n  return false;\n}   ",
      "language": "php"
    }
  ]
}
[/block]
----
### onesignal_include_post Filter

Called every time a post's status changes as part of WordPress's [transition_post_status](https://codex.wordpress.org/Post_Status_Transitions#transition_post_status_Hook).

Returning `true` will always send a notification for the specified post. Returning `false` does nothing; it simply passes control back to our main plugin logic. It's important to note returning `false` does not exclude the post -- that is done in the `onesignal_exclude_post` filter.

You can use the `onesignal_include_post` and `onesignal_exclude_post` filter together. The order of operations is *INCLUDE -> EXCLUDE*. The `onesignal_include_post` filter is run first to determine whether a post is included. If a post is not included, the `onesignal_exclude_post` filter is run next to determine whether this post is excluded. If the post is not excluded, our normal plugin logic runs.

[block:code]
{
  "codes": [
    {
      "code": "<?php\nadd_filter('onesignal_include_post', 'onesignal_include_post_filter', 10, 3);\nfunction onesignal_include_post_filter($new_status, $old_status, $post) {\n  return false;\n}",
      "language": "php"
    }
  ]
}
[/block]
----
### onesignal_exclude_post Filter

Called every time a post's status changes as part of WordPress's [transition_post_status](https://codex.wordpress.org/Post_Status_Transitions#transition_post_status_Hook).

Returning `true` will never send a notification for the specified post. Returning `false` does nothing; it simply passes control back to our main plugin logic. It's important to note returning `false` does not include the post -- that is done in the `onesignal_include_post` filter.

You can use the `onesignal_include_post` and `onesignal_exclude_post` filter together. The order of operations is *INCLUDE -> EXCLUDE*. The `onesignal_include_post` filter is run first to determine whether a post is included. If a post is not included, the `onesignal_exclude_post` filter is run next to determine whether this post is excluded. If the post is not excluded, our normal plugin logic runs.

[block:code]
{
  "codes": [
    {
      "code": "<?php\nadd_filter('onesignal_exclude_post', 'onesignal_exclude_post_filter', 10, 3);\nfunction onesignal_exclude_post_filter($new_status, $old_status, $post) {\n  return false;\n}",
      "language": "php"
    }
  ]
}
[/block]
----
### onesignal_send_notification Filter

Called after all the notification creation parameters have been determined, and right before the notification is actually sent.

You may modify any of the parameters to, for example:
- Change the notification's title, message, and URL
- Send the notification to additional platforms (e.g. Android and iOS)
- Prevent the notification from being sent to certain platforms
- Schedule the notification to be sent in the future
- Add [action buttons](doc:web-push-action-buttons) 
- Cancel the notification from being sent

Please see our [Create notification](ref:create-notification) docs page for the full parameter list and description of what's accepted in the `$fields` hash.

[block:code]
{
  "codes": [
    {
      "code": "<?php\nadd_filter('onesignal_send_notification', 'onesignal_send_notification_filter', 10, 4);\n\nfunction onesignal_send_notification_filter($fields, $new_status, $old_status, $post)\n{\n   // Change the notification's title, message, and URL\n  $fields['headings'] = array(\"en\" => \"English notification title\");\n  $fields['contents'] = array(\"en\" => \"English notification message body\");\n  $fields['url'] = 'https://example.com';\n  \n  // Send to additional platforms (e.g. Android and iOS)\n  $fields['isAndroid'] = true;\n  $fields['isIos'] = true;\n  \n  // Prevent the notification from being sent to certain platforms\n  $fields['isFirefox'] = false;\n  \n  // Schedule the notification to be sent in the future\n  $fields['send_after'] = \"Sept 24 2018 14:00:00 GMT-0700\";\n  \n  // Schedule the notification to be delivered at the specific hour of the destination timezone\n  $fields['delayed_option'] = 'timezone';\n  $fields['delivery_time_of_day'] = '9:00AM';\n  \n  // Add web push action buttons (different action buttons are used for Android and iOS)\n  $fields['web_buttons'] = array(\n    \"id\" => \"like-button\",\n    \"text\" => \"Like\",\n    \"icon\" => \"http://i.imgur.com/N8SN8ZS.png\",\n    \"url\" => \"https://example.com\"\n  );\n  \n  // Cancel the notification from being sent\n  $fields['do_send_notification'] = false;\n  \n  return $fields;\n}",
      "language": "php"
    }
  ]
}
[/block]
----
## Opening web and mobile notifications in the browser and app
<div class="label-type"><span class="label-all label-advanced">Advanced Topic</span> &middot; <span class="label-all label-developers">For Developers</span></div>

If you have web and mobile platforms users, you can send two notifications: the first notification to web browsers and the second notification to mobile phones. The web push notification will open in a web browser and the mobile push notification will open in your app.

For the first notification sent to web push users, send the notification normally without specifically excluding any parameters.

For the second notification sent to mobile users, *make sure to exclude* the `url` parameter. If the `url` parameter is included, a new browser tab will be opened to that URL. Instead, pass data in to the `additionalData` field (in a custom format your app will be able to parse), and then use the mobile notification opened / notification clicked handler to navigate the user to a section in your app.

Here is [an example using native Android](http://stackoverflow.com/a/37935082/555547). Here is the documentation for the [native notificationOpened handler](doc:android-native-sdk#section--setnotificationopenedhandler-) used by the example.

If you're using Cordova, Phonegap, or Ionic, be sure to [use the notificationOpened handler from the Cordova, Phonegap, or Ionic section of our docs](doc:cordova-sdk#section--notificationopenedcallback-) . On the code example, be sure to click the variant describing how to open a page in your app.

----
### WordPress Users Only

To take advantage of our WordPress plugin doing this for you, you will have to follow some additional instructions below to add a WordPress filter hook.

1. On our plugin's Configuration page, please *disable* the option "Send notifications additionally to iOS & Android platforms". This option does not allow customizing the mobile notifications so we have to disable this option first.

2. You'll have to copy and paste the PHP code into a file that will always be called. The goal is to add the below code to this file so that it will get called when our plugin takes the specified action. We recommend using [WordPress' must-use plugins feature](https://www.sitepoint.com/wordpress-mu-plugins/) to add your code to a file in the special specified directory to ensure your code is not overwritten when our plugin updates or when you update WordPress.
[block:code]
{
  "codes": [
    {
      "code": "<?php\nadd_filter('onesignal_send_notification', 'onesignal_send_notification_filter', 10, 4);\n\nfunction onesignal_send_notification_filter($fields, $new_status, $old_status, $post)\n{\n    /* Goal: We don't want to modify the original $fields array, because we want the original web push notification to go out unmodified. However, we want to send an additional notification to Android and iOS devices with an additionalData property.\n    */\n    $fields_dup = $fields;\n    $fields_dup['isAndroid'] = true;\n    $fields_dup['isIos'] = true;\n    $fields_dup['isAnyWeb'] = false;\n    $fields_dup['isWP'] = false;\n    $fields_dup['isAdm'] = false;\n    $fields_dup['isChrome'] = false;\n    $fields_dup['data'] = array(\n        \"myappurl\" => $fields['url']\n    );\n    /* Important to unset the URL to prevent opening the browser when the notification is clicked */\n    unset($fields_dup['url']);\n    /* Send another notification via cURL */\n    $ch = curl_init();\n    $onesignal_post_url = \"https://onesignal.com/api/v1/notifications\";\n    /* Hopefully OneSignal::get_onesignal_settings(); can be called outside of the plugin */\n    $onesignal_wp_settings = OneSignal::get_onesignal_settings();\n    $onesignal_auth_key = $onesignal_wp_settings['app_rest_api_key'];\n    curl_setopt($ch, CURLOPT_URL, $onesignal_post_url);\n    curl_setopt($ch, CURLOPT_HTTPHEADER, array(\n        'Content-Type: application/json',\n        'Authorization: Basic ' . $onesignal_auth_key\n    ));\n    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);\n    curl_setopt($ch, CURLOPT_HEADER, true);\n    curl_setopt($ch, CURLOPT_POST, true);\n    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields_dup));\n    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);\n\n    // Optional: Turn off host verification if SSL errors for local testing\n    // curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);\n\n    /* Optional: cURL settings to help log cURL output response\n    curl_setopt($ch, CURLOPT_FAILONERROR, false);\n    curl_setopt($ch, CURLOPT_HTTP200ALIASES, array(400));\n    curl_setopt($ch, CURLOPT_VERBOSE, true);\n    curl_setopt($ch, CURLOPT_STDERR, $out);\n    */\n    $response = curl_exec($ch);\n    /* Optional: Log cURL output response\n    fclose($out);\n    $debug_output = ob_get_clean();\n    $curl_effective_url = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);\n    $curl_http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);\n    $curl_total_time = curl_getinfo($ch, CURLINFO_TOTAL_TIME);\n    onesignal_debug('OneSignal API POST Data:', $fields);\n    onesignal_debug('OneSignal API URL:', $curl_effective_url);\n    onesignal_debug('OneSignal API Response Status Code:', $curl_http_code);\n    if ($curl_http_code != 200) {\n    onesignal_debug('cURL Request Time:', $curl_total_time, 'seconds');\n    onesignal_debug('cURL Error Number:', curl_errno($ch));\n    onesignal_debug('cURL Error Description:', curl_error($ch));\n    onesignal_debug('cURL Response:', print_r($response, true));\n    onesignal_debug('cURL Verbose Log:', $debug_output);\n    }\n\n    */\n    curl_close($ch);\n    return $fields;\n}",
      "language": "php"
    }
  ]
}
[/block]
---
title: "Shopify"
excerpt: "<div class=\"tag-all tag-developers\">For Developers</div>"
---
To use OneSignal with Shopify, please follow our [Web Push SDK Setup (HTTP)](doc:web-push-sdk-setup-http) installation guide. Although Shopify supports SSL sites, Shopify does not allow uploaded files to be served from your domain without a redirect, which breaks support for our HTTPS web push integration.
---
title: "Web Push SDK Setup (HTTPS)"
excerpt: "OneSignal SDK Setup Guide for HTTPS websites. Works with all <span class=\"label-all label-webpush\">Web Push</span> platforms (<span class=\"label-all label-chrome\">Chrome</span>, <span class=\"label-all label-firefox\">Firefox</span>, <span class=\"label-all label-safari\">Safari</span>)\n<div class=\"tag-all tag-developers\">For Developers</div>"
---
After completing this section, your site will be able to send notifications to visitors, and your visitors will be able to subscribe to your site's notifications. 

----
## Determining if your site fully supports HTTPS
To use this setup guide, your site must fully support <span class="label-all label-yes">HTTPS</span>, which you can determine by looking for the following:

- My site begins with `https://`, and display a green lock icon on the browser's address bar
- My site forcefully redirects all `http://` requests to `https://` requests. In other words, users accessing the site via HTTP will be redirected to the HTTPS version. 
[block:callout]
{
  "type": "info",
  "body": "If you've determined that your site **does not** fully support <span class=\"label-all label-yes\">HTTPS</span>, follow the [Web Push SDK Setup (HTTP)](doc:web-push-sdk-setup-http) guide instead of this guide.",
  "title": "HTTPS not fully supported?"
}
[/block]

----
## 1. Configure OneSignal settings
<div class="label-all label-type"><span class="label-chrome">Chrome</span>, <span class="label-firefox">Firefox</span></div>

Go to <a class="dash-link" href="/docs/platforms">App Settings</a> and click **Configure** for the **Google Chrome** platform (instructions for Safari are [below](#section-4-safari-support-optional-)).
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/NKNoweVSDCUPUr208hjb_chrome-platform.jpg",
        "chrome-platform.jpg",
        "2408",
        "1200",
        "#6ab4b3",
        ""
      ]
    }
  ]
}
[/block]
### 1.1 Enter Site URL
Most users may just enter their base site URL for this field (e.g. `example.com`). However, if your site meets one of the below cases, please follow these recommendations:

#### My site uses a subfolder
If your site uses a subfolder, like `example.com/blog` (where `blog` is the subfolder), please only enter `example.com`.

#### My site uses both www and non-www links
For sites that are accessible from both www & non-www links, such as `example.com` AND `www.example.com`, please **only enter one** that you wish to send push notifications from. 

<span class="label-all label-recommended">Recommended</span> - **redirect** traffic from one to the other (e.g. users that browse to `example.com` are redirected to `www.example.com`), so that all your traffic only goes to one. 

#### My company has many domains or subdomains that I want to control together
<span class="label-all label-no">HTTP ONLY</span> - If your company has many web properties on different domains or subdomains, please refer to the [HTTP Web Push SDK Setup guide](doc:web-push-sdk-setup-http), as this feature only works using our HTTP method of registering.

### 1.2 Enter Icon URL
Enter a link to an icon file that is at least 80x80 pixels (<span class="label-all label-recommended">Recommended</span> size is 192x192). The file must be `.png`, `.jpg`, or `.gif`.

----
## 2. Upload required files
**2.1** [Download and unzip the SDK files](https://github.com/one-signal/OneSignal-Website-SDK/releases/download/1.6.0/OneSignalSDKFiles.zip).

You should have:
- `manifest.json`
- `OneSignalSDKWorker.js`
- `OneSignalSDKUpdaterWorker.js`

**2.2** Edit `manifest.json`:
- Change `name` and `short_name` to your site's name
- Do **not** change the gcm_sender_id key (`482941778795`). This is a shared key used for push notifications (previously it required your own key, but this is no longer needed!)
[block:code]
{
  "codes": [
    {
      "code": "{\n  \"name\": \"YOUR_SITE_NAME\",\n  \"short_name\": \"YOUR_SITE_NAME\",\n  \"start_url\": \"/\",\n  \"display\": \"standalone\",\n  \"gcm_sender_id\": \"482941778795\"\n}",
      "language": "json"
    }
  ]
}
[/block]
**2.3** Upload the files to the **top-level root** of your site directory. The following URLs should be publicly accessible:
- `https://site.com/manifest.json`
- `https://site.com/OneSignalSDKWorker.js`
- `https://site.com/OneSignalSDKUpdaterWorker.js`

----
## 3. Include and initialize the SDK
**3.1** Include `manifest.json` in your `<head>`. 
- *An error occurs if `manifest.json` is included in `<body>`*.
- Your `<link rel="manifest" href="/manifest.json">` *must appear before* any other `<link rel="manifest" ...>` in `<head>`, otherwise it will not be found

**3.2** Include the SDK from our CDN asynchronously.

**3.3** Initialize the SDK, and queue its initialization for when the SDK is fully loaded. Your `appId` is available in <a class="dash-link" href="/docs/accounts-and-keys#section-keys-ids">Keys & IDs</a>. 
[block:code]
{
  "codes": [
    {
      "code": "<head>\n  <link rel=\"manifest\" href=\"/manifest.json\">\n  <script src=\"https://cdn.onesignal.com/sdks/OneSignalSDK.js\" async></script>\n  <script>\n    var OneSignal = window.OneSignal || [];\n    OneSignal.push([\"init\", {\n      appId: \"YOUR_APP_ID\",\n      autoRegister: false,\n      notifyButton: {\n        enable: true /* Set to false to hide */\n      }\n    }]);\n  </script>\n</head>",
      "language": "html"
    }
  ]
}
[/block]

----
## 4. Safari Support (Optional)
<div class="label-all label-type"><span class="label-safari">Safari</span></div>
[block:callout]
{
  "type": "info",
  "title": "",
  "body": "iOS Safari does not support web push. [See our list of supported browsers](doc:web-push-setup)"
}
[/block]
**4.1** Go to <a class="dash-link" href="/docs/platforms">App Settings</a> and click **Configure** for the **Apple Safari** platform.
**4.2** Type in your *Site Name*. This is shown when prompting users to subscribe ([show me](http://notify.tech/wp-content/plugins/onesignal-free-web-push-notifications/views/images/settings/safari-prompt.jpg)).
**4.3** Type in the same *Site URL* you [typed in above](#section-configure-onesignal-settings). 
**4.4** If you don't have a `.p12` certificate file, don't upload one.
**4.5** Upload your site icons. Please upload a `256 x 256` icon for each of the sizes (the icon will be automatically resized for each textbox). Please be sure to upload an icon for each slot!
**4.6** Add your `safari_web_id` to the *existing* init() call.
[block:code]
{
  "codes": [
    {
      "code": "// Do NOT call init twice, use existing init\nOneSignal.push([\"init\", {\n  /* Your other settings, for example:\n       (e.g.) appId: '...' \n     Place the following call on the outermost brace\n  */\n  safari_web_id: 'YOUR_SAFARI_WEB_ID'\n}]);",
      "language": "javascript"
    }
  ]
}
[/block]
----
[block:callout]
{
  "type": "success",
  "title": "Finished Web Push Setup!",
  "body": "You're all set with push notifications for your website. \n\nNext step: [Customize Permission Messages](doc:customize-permission-messages)"
}
[/block]

----
## Miscellaneous

----
### How can I automatically dismiss a notification after some time?

On Firefox and Safari, notifications are automatically dismissed after a short amount of time. On Chrome, by default, notifications last indefinitely (they are displayed until the user interacts with it by dismissing it or clicking it). On Chrome Desktop v47+, you can add [the `persistNotification` parameter](doc:web-push-sdk#section--init-)  to your OneSignal init call to control whether a notification is displayed indefinitely or dismissed after 20 seconds.

`persistNotification` defaults to true if unset. Set it to false to automatically dismiss the notification after 20 seconds (Chrome Desktop v47+ only).

**Dismissing Notifications After ~20 Sec. (Chrome Desktop v47+)**
[block:code]
{
  "codes": [
    {
      "code": "// Do NOT call init() twice\nOneSignal.push([\"init\", {\n  // Your other init options here\n  persistNotification: false // Automatically dismiss the notification after ~20 seconds in Chrome Deskop v47+\n}]);",
      "language": "javascript"
    }
  ]
}
[/block]
----
### Can manifest.json, OneSignalSDKWorker.js, and OneSignalSDKUpdaterWorker.js be served from a subfolder of my site?

**manifest.json**

- This file can be served from anywhere (from any origin, not just your site's) and any subfolder and the file can be named however you would like. Just be sure to include the file with the correct path and filename. This file only affects Chrome; Safari and Firefox do not use a manifest.json for push notifications.

**OneSignalSDKWorker.js & OneSignalSDKUpdaterWorker.js**

- These files should not be renamed and the files should be served from the top-level root
- Alternatively, these two files can be served from a sub-directory only if these two files are served with an additional HTTP header "Service-Worker-Allowed: /". These two files make up our service worker, a background web worker to display notifications. Parts of our web SDK depend on the service worker being registered properly: it should be served with the HTTP header "Service-Worker-Allowed: /" if served from a subfolder, otherwise it should be served at the top-level root of your site.

If the files are served with the HTTP header "Service-Worker-Allowed: /", please add this code **before** initializing the SDK:
[block:code]
{
  "codes": [
    {
      "code": "var OneSignal = OneSignal || [];\nOneSignal.push(function() {\n  // Be sure to call this code *before* you initialize the web SDK\n  \n  // This registers the workers at the root scope, which is allowed by the HTTP header \"Service-Worker-Allowed: /\"\n  OneSignal.SERVICE_WORKER_PARAM = { scope: '/' };\n});",
      "language": "javascript"
    }
  ]
}
[/block]
If the files are served from a subfolder, please add this code **during** the initialization options so our SDK knows where to find the workers:
[block:code]
{
  "codes": [
    {
      "code": "// Do NOT call init() twice\nOneSignal.push([\"init\", {\n  // Your other init options here\n  path: '/subfolder/', /* A trailing slash is required */\n}]);",
      "language": "javascript"
    }
  ]
}
[/block]
### Can OneSignal integrate with another service worker on my site or a Progressive Web App?

**Note:** This only applies if your site has another service worker. If you are developing a Polymer site or a Progressive Web App, you most likely have another service worker.

Our service workers OneSignalSDKWorker.js and OneSignalSDKUpdaterWorker.js overwrite other service workers that are registered with the topmost (site root) service worker scope. The solution is to merge all other service worker scripts into our service worker scripts using `importScripts()` and to register the merged service worker instead of the original worker.

Both OneSignalSDKWorker.js and OneSignalSDKUpdaterWorker.js contain the following code:

```
importScripts('https://cdn.onesignal.com/sdks/OneSignalSDK.js');
```

Please modify both OneSignalSDKWorker.js and OneSignalSDKUpdaterWorker.js to import your other service worker scripts, like:

```
importScripts('https://site.com/my-other-service-worker.js');
importScripts('https://cdn.onesignal.com/sdks/OneSignalSDK.js');
```

We recommend the above approach instead of importing our service worker into another file because our web SDK replaces other workers that are registered on the root scope.

Additionally, please be sure to modify your site's code to register OneSignalSDKWorker.js and OneSignalSDKUpdaterWorker.js (the merged workers) instead of your own worker.

More about service workers [can be read here](https://developer.mozilla.org/en-US/docs/Web/API/Service_Worker_API/Using_Service_Workers).
[block:callout]
{
  "type": "warning",
  "title": "Keep SDK Files Together",
  "body": "Remember to keep all 3 SDK files together and they must be placed at the root of your site's directory.\n\n `https://cdn.onesignal.com/sdks/OneSignalSDK.js` and `manifest.json` must be located in the `<head>` of all pages. This ensures all pages can subscribe for notifications, and that session count can be accurately counted."
}
[/block]

[block:callout]
{
  "type": "info",
  "title": "Testing On Local Environment",
  "body": "If you're testing your site on https://localhost, you may have to run your browser with extra flags to bypass certificate warnings from improperly validated certificates.\n\nOn Chrome, you can quit Chrome and run it with:` --ignore-certificate-errors`. Firefox and Safari provide built-in mechanisms to create exceptions for security certificates."
}
[/block]
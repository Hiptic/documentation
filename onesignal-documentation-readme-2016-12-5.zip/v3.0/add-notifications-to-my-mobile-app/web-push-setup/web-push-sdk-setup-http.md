---
title: "Web Push SDK Setup (HTTP)"
excerpt: "OneSignal SDK Setup Guide for HTTP websites. Works with all <span class=\"label-all label-webpush\">Web Push</span> platforms (<span class=\"label-all label-chrome\">Chrome</span>, <span class=\"label-all label-firefox\">Firefox</span>, <span class=\"label-all label-safari\">Safari</span>)\n<div class=\"tag-all tag-developers\">For Developers</div>"
---
After completing this section, your site will be able to send notifications to visitors, and your visitors will be able to subscribe to your site's notifications.

----
## Determining if your site fully supports HTTPS
Use this setup guide only if your site **does not** fully support HTTPS, which you can determine by looking for the following:

- My site begins with `http://`, and does **not** display a green lock icon on the browser's address bar
- My site does **not** forcefully redirect all `http://` requests to `https://` requests. In other words, users accessing the site via HTTP will **not** be redirected to an HTTPS version. 
[block:callout]
{
  "type": "info",
  "body": "If you've determined that your site fully supports HTTPS, follow the [Web Push SDK Setup (HTTPS)](doc:web-push-sdk-setup-https) guide instead of this guide.",
  "title": "HTTPS fully supported?"
}
[/block]

----
## 1. Configure OneSignal settings
<div class="label-all label-type"><span class="label-chrome">Chrome</span>, <span class="label-firefox">Firefox</span></div>

Go to <a class="dash-link" href="/docs/platforms">App Settings</a> and click **Configure** for the **Google Chrome** platform (instructions for Safari are [below](#section-3-safari-support-optional-)).
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/TDcX2IqRt6eXXslvPqbH_chrome-platform.jpg",
        "chrome-platform.jpg",
        "2408",
        "1200",
        "#6ab4b3",
        ""
      ]
    }
  ]
}
[/block]
### 1.1 Enter Site URL
Most users may just enter their base site URL for this field (e.g. `example.com`). However, if your site meets one of the below cases, please follow these recommendations:

#### My site uses a subfolder
If your site uses a subfolder, like `example.com/blog` (where `blog` is the subfolder), please only enter `example.com`.

#### My site uses both www and non-www links
For sites that are accessible from both www & non-www links, such as `example.com` AND `www.example.com`, please **only enter one** that you wish to send push notifications from. 

<span class="label-all label-recommended">Recommended</span> - **redirect** traffic from one to the other (e.g. users that browse to `example.com` are redirected to `www.example.com`), so that all your traffic only goes to one. 

#### My company has many domains or subdomains that I want to control together
If your company has many web properties on different domains or subdomains, you may enter the `*` wildcard in the URL field. 


### 1.2 Enter Icon URL
Enter a link to an icon file that is at least 80x80 pixels (<span class="label-all label-recommended">Recommended</span> size is 192x192). The file must be `.png`, `.jpg`, or `.gif`.

### 1.3 Indicate Non-HTTPS Site
Check the box *My site is not fully HTTPS*, and scroll down to see the *Subdomain* field.

### 1.4 Choose subdomain
We recommend using the name of your site as your subdomian (e.g. `example.onesignal.com`). 

- Use only one word -- do not add the domain
- Dashes, letters, and numbers are allowed (e.g. `my-blog` is a valid subdomain)
- Push notifications will officially come from *subdomain*.onesignal.com

----
## 2. Include and initialize the SDK
Include the SDK from our CDN asynchronously, and initialize it. Your `subdomainName` is defined above, and your `appId` is available in <a class="dash-link" href="/docs/accounts-and-keys#section-keys-ids">Keys & IDs</a>. 
[block:code]
{
  "codes": [
    {
      "code": "<head>\n  <script src=\"https://cdn.onesignal.com/sdks/OneSignalSDK.js\" async='async'></script>\n  <script>\n    var OneSignal = window.OneSignal || [];\n    OneSignal.push([\"init\", {\n      appId: \"YOUR_APP_ID\",\n      autoRegister: false, /* Set to true to automatically prompt visitors */\n      subdomainName: 'SUBDOMAIN_NAME',   \n      notifyButton: {\n          enable: true /* Set to false to hide */\n      }\n    }]);\n  </script>\n</head>",
      "language": "html"
    }
  ]
}
[/block]

----
## 3. Safari Support (Optional)
<div class="label-all label-type"><span class="label-safari">Safari</span></div>
[block:callout]
{
  "type": "info",
  "title": "",
  "body": "iOS Safari does not support web push. [See our list of supported browsers](doc:web-push-setup)"
}
[/block]
**3.1** Go to <a class="dash-link" href="/docs/platforms">App Settings</a> and click **Configure** for the **Apple Safari** platform.

**3.2** Type in your *Site Name*. This is shown when prompting users to subscribe ([show me](http://notify.tech/wp-content/plugins/onesignal-free-web-push-notifications/views/images/settings/safari-prompt.jpg)).

**3.3** Type in the same *Site URL* you [typed in above](#section-1-configure-onesignal-settings). 
  
**3.4** If you don't have a `.p12` certificate file, don't upload one.

**3.5** Upload your site icons. Please upload a `256 x 256` icon for each of the sizes (the icon will be automatically resized for each textbox). Please be sure to upload an icon for each slot!

**3.6** Add your `safari_web_id` to the *existing* init() call.
[block:code]
{
  "codes": [
    {
      "code": "// Do NOT call init twice, use existing init\nOneSignal.push([\"init\", {\n  /* Your other settings, for example:\n       (e.g.) appId: '...' \n     Place the following call on the outermost brace\n  */\n  safari_web_id: 'YOUR_SAFARI_WEB_ID'\n}]);",
      "language": "javascript"
    }
  ]
}
[/block]
----
[block:callout]
{
  "type": "success",
  "title": "Done with Web Push setup!",
  "body": "You're all set with push notifications for your website. \n\nNext step: [Customize Permission Messages](doc:customize-permission-messages)"
}
[/block]
----
## Miscellaneous

### How can I automatically dismiss a notification after some time?

On Firefox and Safari, notifications are automatically dismissed after a short amount of time. On Chrome, by default, notifications last indefinitely (they are displayed until the user interacts with it by dismissing it or clicking it). On Chrome Desktop v47+, you can add [the `persistNotification` parameter](doc:web-push-sdk#section--init-) to your OneSignal init call to control whether a notification is displayed indefinitely or dismissed after 20 seconds.

`persistNotification` defaults to true if unset. Set it to false to automatically dismiss the notification after 20 seconds (Chrome Desktop v47+ only).

**Dismissing Notifications After ~20 Sec. (Chrome Desktop v47+)**
[block:code]
{
  "codes": [
    {
      "code": "// Do NOT call init() twice\nOneSignal.push([\"init\", {\n  // Your other init options here\n  persistNotification: false // Automatically dismiss the notification after ~20 seconds in Chrome Deskop v47+\n}]);",
      "language": "javascript"
    }
  ]
}
[/block]

[block:callout]
{
  "type": "success",
  "body": "You're all set up! See our [Web Push Prompts](doc:web-push-prompts) page as well.",
  "title": "Setup Complete"
}
[/block]

[block:callout]
{
  "type": "danger",
  "title": "Changing Settings",
  "body": "- To upgrade your site from HTTP --> HTTPS, [please follow this guide](doc:web-push-http-vs-https#section-http-https). *You must create a new app or users will receive duplicate notifications*."
}
[/block]
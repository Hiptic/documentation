---
title: "Intel XDK"
excerpt: "OneSignal Intel XDK API Reference. Works with <span class=\"label-all label-ios\">iOS</span>, <span class=\"label-all label-android\">Android</span> (and derivatives like <span class=\"label-all\">Amazon</span>), <span class=\"label-all label-windows\">Windows Phone 8.1</span>, and <span class=\"label-all label-fireos\">Firefox OS</span>.\n<div class=\"tag-all tag-developers\">For Developers</div>"
---
[block:callout]
{
  "type": "warning",
  "title": "3.0 SDK Update",
  "body": "A number the methods and classes below are only available on our new 3.0 SDK.\nPlease follow our [Upgrading to SDK 3.0](upgrading-to-sdk-30) guide if you are still on our 2.0 version."
}
[/block]

[block:parameters]
{
  "data": {
    "0-0": "### Initialization",
    "0-1": "",
    "h-2": "",
    "0-2": "",
    "h-0": "",
    "1-0": "[init](#section--init-)",
    "1-1": "Builder Method",
    "1-2": "Initialize OneSignal",
    "7-0": "### Registering Push",
    "8-0": "[registerForPushNotifications](#section--registerforpushnotifications-)",
    "9-0": "### User IDs",
    "10-0": "[getIds](#section--getids-)",
    "10-1": "Method",
    "10-2": "Get the User ID of the device",
    "11-0": "### Tags",
    "12-0": "[getTags](#section--gettags-)",
    "12-1": "Method",
    "15-1": "Method",
    "16-1": "Method",
    "17-1": "Method",
    "12-2": "View Tags from a User",
    "15-2": "",
    "17-2": "",
    "16-2": "Delete a Tag from a User",
    "15-0": "[sendTags](#section--sendtags-)",
    "16-0": "[deleteTag](#section--deletetag-)",
    "17-0": "[deleteTags](#section--deletetags-)",
    "18-0": "### Data",
    "21-0": "### Sending Notifications",
    "25-0": "### Receiving Notifications",
    "22-0": "[postNotification](#section--postnotification-)",
    "23-0": "[cancelNotification](#section--cancelnotification-)",
    "24-0": "[setSubscription](#section--setsubscription-)",
    "24-1": "Method",
    "22-1": "Method",
    "23-1": "Method",
    "26-0": "[NotificationReceivedHandler](#section--notificationreceivedhandler-)",
    "26-1": "Handler",
    "28-0": "[OSNotification](#section--osnotification-)",
    "28-1": "Class",
    "30-0": "[OSNotificationPayload](#section--osnotificationpayload-)",
    "30-1": "Class",
    "31-0": "### Appearance",
    "32-0": "[enableVibrate](#section--enablevibrate-)",
    "33-0": "[enableSound](#section--enablesound-)",
    "32-1": "Method",
    "33-1": "Method",
    "34-0": "### Debug",
    "35-0": "[setLogLevel](#section--setloglevel-)",
    "35-1": "Method",
    "20-1": "Method",
    "20-0": "[syncHashedEmail](#section--synchashedemail-)",
    "19-0": "[promptLocation](#section--promptlocation-)",
    "19-1": "Method",
    "4-0": "[autoPromptLocation](#section--autopromptlocation-)",
    "4-1": "Builder Method",
    "5-0": "[inFocusDisplaying](#section--infocusdisplaying-)",
    "5-1": "Builder Method",
    "6-1": "Builder Method",
    "6-0": "[disableGmsMissingPrompt](#section--disablegmsmissingprompt-)",
    "4-2": "Automatically Prompt Users for Location",
    "5-2": "Automatically Display Notifications when app is in focus",
    "6-2": "Automatically Prompt User to update Google Play if out of date",
    "19-2": "Prompt Users for Location",
    "20-2": "Sync Anonymized User Email",
    "22-2": "Send or schedule a notification to a user",
    "23-2": "Delete a single app notification *(coming soon)*",
    "24-2": "Opt users in or out of receiving notifications",
    "30-2": "Data that comes with a notification *(coming soon)*",
    "28-2": "",
    "26-2": "When a notification is received by a device *(coming soon)*",
    "32-2": "When user receives notification, vibrate device less",
    "33-2": "When user receives notification, do not play a sound",
    "35-2": "Enable logging to help debug OneSignal implementation",
    "14-0": "[sendTag](#section--sendtag-)",
    "14-1": "Method",
    "14-2": "Add a Tag to a User",
    "29-0": "[OSNotificationAction](#section--osnotificationaction-)",
    "29-1": "Class",
    "29-2": "How user opened notification *(coming soon)*",
    "27-0": "[notificationOpenedCallback](#section--notificationopenedcallback-)",
    "27-1": "Handler",
    "27-2": "When a user takes an action on a notification *(coming soon)*",
    "2-0": "[setNotificationReceivedHandler](#section--setnotificationreceivedhandler-)",
    "3-0": "[setNotificationOpenedHandler](#section--setnotificationopenedhandler-)",
    "2-1": "Builder Method",
    "3-1": "Builder Method",
    "8-2": "Prompt Users to Enable Notifications",
    "8-1": "Method",
    "13-0": "[tagsReceivedCallBack](#section--tagsreceivedcallback-)",
    "13-1": "Callback"
  },
  "cols": 3,
  "rows": 36
}
[/block]
## Initialization

### `init`
<div class="label-all label-type">Builder Method</div>

Only required method you need to call to setup OneSignal to receive push notifications. Call this from the `deviceready` event.
[block:parameters]
{
  "data": {
    "0-0": "`appId`",
    "0-1": "String",
    "0-2": "Your OneSignal app id, available in <a class=\"dash-link\">Keys & IDs</a>",
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "1-0": "`options`",
    "1-1": "JSON",
    "1-2": "<p>`{googleProjectNumber: \"############\"}` is required for Android.</p>\n<p>`{autoRegister: false}` is optional for iOS. (If this is used then you must call `registerForPushNotifications` at anther point in your app)</p>",
    "2-0": "`didReceiveRemoteNotificationCallBack(Optional)`",
    "2-1": "function",
    "2-2": "Function that gets called when a notification is opened or one is received when your app is in use. Function will receive one parameter with JSON about the incoming notification."
  },
  "cols": 3,
  "rows": 3
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "window.plugins.OneSignal.init(\"5eb5a37e-b458-11e3-ac11-000c2940e62c\",\n                               {googleProjectNumber: \"703322744261\",\n                                autoRegister: true},\n                                app.didReceiveRemoteNotificationCallBack);",
      "language": "javascript"
    }
  ]
}
[/block]
### `setNotificationReceivedHandler`
<div class="label-all label-type">Builder Method - *Coming Soon*</div>

Sets a notification received handler. The instance will be called when a notification is received whether it was displayed or not. 

See the [NotificationReceivedHandler](#section--notificationreceivedhandler-) documentation for an example of the `ExampleNotificationReceivedHandler` class.
[block:parameters]
{
  "data": {
    "0-0": "`handler`",
    "0-1": "[NotificationReceivedHandler](#section--notificationreceivedhandler-)",
    "0-2": "Instance to a class implementing this interference.",
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.startInit(this)   \n   .setNotificationReceivedHandler(new ExampleNotificationReceivedHandler())\n   .init();",
      "language": "java"
    }
  ]
}
[/block]

### `inFocusDisplaying` 
<div class="label-all label-type">Builder Method - *Coming Soon*</div>

Setting to control how OneSignal notifications will be shown when one is received while your app is in focus. By default this is set to `inAppAlert`, which can be helpful during development. 

<span class="label-all label-android">Android</span> - `Notification` option is only available on Android.
[block:callout]
{
  "type": "warning",
  "title": "Disable Before Launch",
  "body": "We recommend you set this to `none` prior to launching your app, so users do not get interrupted while using your app."
}
[/block]

[block:parameters]
{
  "data": {
    "0-0": "`displayOption`",
    "0-1": "OSInFocusDisplayOption",
    "0-2": "Options are `None`, `InAppAlert`, and `Notification` (<span class=\"label-all label-android\">Android</span>).",
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.startInit(this)\n  .inFocusDisplaying(OneSignal.OSInFocusDisplayOption.Notification)\n  .init();",
      "language": "java"
    }
  ]
}
[/block]

## Registering Push
### `registerForPushNotifications`
<div class="label-all label-type">Method - <span class="label-ios">iOS</span></div>

Call this when you would like to prompt an iOS user to accept push notifications with the default system prompt. Only use if you passed false to autoRegister when calling init.

[block:code]
{
  "codes": [
    {
      "code": "window.plugins.OneSignal.registerForPushNotifications();",
      "language": "javascript"
    }
  ]
}
[/block]
## User IDs
### `getIds`
<div class="label-all label-type">Method</div>

Lets you retrieve the OneSignal user id and the device token. Your handler is called after the device is successfully registered with OneSignal.
[block:parameters]
{
  "data": {
    "0-0": "`idsReceivedCallBack`",
    "0-1": "function",
    "0-2": "Passed in function which will receive one parameter containing JSON with userId and pushToken.",
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "window.plugins.OneSignal.getIds(function(ids) {\n  console.log('getIds: ' + JSON.stringify(ids));\n  alert(\"userId = \" + ids.userId + \", pushToken = \" + ids.pushToken);\n});",
      "language": "javascript"
    }
  ]
}
[/block]
### `idsReceivedCallBack`
<div class="label-all label-type">Callback</div>

Get the OneSignal userId and the device's push token.
[block:parameters]
{
  "data": {
    "h-0": "Parameter (JSON)",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`userId`",
    "0-1": "String",
    "1-0": "`pushToken`",
    "1-1": "String",
    "1-2": "a push token is a Google/Apple assigned identifier(_unique per device per app_).",
    "0-2": "OneSignal userId is a UUID formatted string. (_unique per device per app_)"
  },
  "cols": 3,
  "rows": 2
}
[/block]

[block:callout]
{
  "type": "warning",
  "body": "The JSON might be blank if push notifications are not accepted on iOS, Google Play services are not installed, or from a connection issue.",
  "title": "May be blank"
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "window.plugins.OneSignal.getIds(function(ids) {\n  document.getElementById(\"OneSignalUserID\").innerHTML = \"UserID: \" + ids.userId;\n  document.getElementById(\"OneSignalPushToken\").innerHTML = \"PushToken: \" + ids.pushToken;\n  console.log('getIds: ' + JSON.stringify(ids));\n});",
      "language": "javascript"
    }
  ]
}
[/block]
## Tags
### `getTags`
<div class="label-all label-type">Method</div>

Retrieve a list of tags that have been set on the user from the OneSignal server.
[block:parameters]
{
  "data": {
    "0-0": "`tagsReceivedCallback`",
    "0-1": "function",
    "0-2": "Passed in function which will receive one parameter containing JSON.",
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 1
}
[/block]
Contents of `tagsReceivedCallBack`
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`tags`",
    "0-1": "JSON",
    "0-2": "JSON object of key value pairs retrieved from the OneSignal server."
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "window.plugins.OneSignal.getTags(function(tags) {\n  console.log('Tags Received: ' + JSON.stringify(tags));\n});",
      "language": "javascript",
      "name": null
    }
  ]
}
[/block]
### `sendTag`
<div class="label-all label-type">Method</div>

Tag a user based on an app event of your choosing so later you can create segments in <a class="dash-link">Segments</a> to target these users. Use `sendTags` if you need to set more than one tag on a user at a time.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "0-0": "`key`",
    "1-0": "`value`",
    "0-1": "String",
    "1-1": "String",
    "0-2": "Key of your choosing to create or update.",
    "1-2": "Value to set on the key. _NOTE:_ Passing in a blank String deletes the key, you can also call `deleteTag` or `deleteTags`.",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 2
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "window.plugins.OneSignal.sendTag(\"key\", \"value\");",
      "language": "javascript"
    }
  ]
}
[/block]
### `sendTags`
<div class="label-all label-type">Method</div>

Tag a user based on an app event of your choosing so later you can create segments in <a class="dash-link">Segments</a> to target these users.
[block:parameters]
{
  "data": {
    "0-0": "`keyValues`",
    "0-1": "JSONObject",
    "0-2": "Key value pairs of your choosing to create or update. _NOTE:_ Passing in a blank String as a value deletes the key, you can also call `deleteTag` or `deleteTags`.",
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "window.plugins.OneSignal.sendTags({key: \"value\", key2: \"value2\"});",
      "language": "javascript"
    }
  ]
}
[/block]
### `deleteTag`
<div class="label-all label-type">Method</div>

Deletes a single tag that was previously set on a user with `sendTag` or `sendTags`. Use `deleteTags` if you need to delete more than one.
[block:parameters]
{
  "data": {
    "0-0": "`key`",
    "0-1": "String",
    "0-2": "Key to remove.",
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "window.plugins.OneSignal.deleteTag(\"key\");",
      "language": "javascript"
    }
  ]
}
[/block]
### `deleteTags`
<div class="label-all label-type">Method</div>

Deletes one or more tags that were previously set on a user with `sendTag` or `sendTags`.
[block:parameters]
{
  "data": {
    "0-0": "`keys`",
    "0-1": "Array",
    "0-2": "Keys to remove.",
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "window.plugins.OneSignal.deleteTags([\"key1\", \"key2\"]);",
      "language": "javascript"
    }
  ]
}
[/block]
## Data
### `promptLocation`
<div class="label-all label-type">Method - <span class="label-ios">iOS</span>, <span class="label-android">Android</span></div>

Prompts the user for location permissions. This allows for geotagging so you can send notifications to users based on location.
[block:code]
{
  "codes": [
    {
      "code": "window.plugins.OneSignal.promptLocation();",
      "language": "javascript"
    }
  ]
}
[/block]

[block:html]
{
  "html": "<div class=\"platform-instruction\">\n  <h5 class=\"label-ios\"\">iOS Instructions</h5>\n  <p>You must add <strong>all</strong> of the following to your iOS plist settings:</p>\n  <p><code>NSLocationUsageDescription</code></p>\n  <p><code>NSLocationWhenInUseUsageDescription</code></p>\n</div>"
}
[/block]

[block:html]
{
  "html": "<div class=\"platform-instruction\">\n  <h5 class=\"label-android\"\">Android Instructions</h5>\n  <p>You must add <strong>one</strong> of the following Android Permissions:</p>\n  <p><code>&lt;uses-permission android:name=&quot;android.permission.ACCESS_FINE_LOCATION&quot;/&gt;</code></p>\n  <p><code>&lt;uses-permission android:name=&quot;android.permission.ACCESS_COARSE_LOCATION&quot;/&gt;</code></p>\n</div>"
}
[/block]

### `syncHashedEmail`
<div class="label-all label-type">Method - *Coming Soon*</div>

Sends the user's email as an anonymized hash to prevent duplicated users.





## Sending Notifications

### `postNotification`
<div class="label-all label-type">Method</div>

Allows you to send notifications from user to user or schedule ones in the future to be delivered to the current device.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "0-0": "`parameters`",
    "0-1": "Object",
    "0-2": "Contains notification options, see [Create Notification](ref:create-notification) POST call for all options.",
    "h-1": "Type",
    "h-2": "Description",
    "1-0": "`onSuccess`",
    "1-1": "function",
    "1-2": "(Optional) callback fires when the notification was created on OneSignal's server.\n\n`returnedJson` (JSON) - response from OneSignal's server.",
    "2-0": "`onFailure`",
    "2-1": "function",
    "2-2": "callback fires when the notification failed to create\n\n`returnedJson` (JSON) - response from OneSignal's server."
  },
  "cols": 3,
  "rows": 3
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "window.plugins.OneSignal.getIds(function(ids) {\n  var notificationObj = { contents: {en: \"message body\"},\n                          include_player_ids: [ids.userId]};\n  window.plugins.OneSignal.postNotification(notificationObj,\n    function(successResponse) {\n      console.log(\"Notification Post Success:\", successResponse);\n    },\n    function (failedResponse) {\n      console.log(\"Notification Post Failed: \", failedResponse);\n      alert(\"Notification Post Failed:\\n\" + JSON.stringify(failedResponse));\n    }\n  );\n});",
      "language": "javascript",
      "name": "Simple"
    }
  ]
}
[/block]
### `cancelNotification`
<div class="label-all label-type">Method - *Coming Soon*</div>

Cancels a single OneSignal notification based on its Android notification integer id. Use instead of `NotificationManager.cancel(id);` otherwise the notification will be restored when your app is restarted.
[block:code]
{
  "codes": [
    {
      "code": "int id = 1234;\nOneSignal.cancelNotification(id);",
      "language": "java"
    }
  ]
}
[/block]
### `setSubscription`
<div class="label-all label-type">Method</div>

You can call this method with false to opt users out of receiving all notifications through OneSignal. You can pass true later to opt users back into notifications.
[block:parameters]
{
  "data": {
    "0-0": "`enable`",
    "0-1": "boolean",
    "0-2": "",
    "h-0": "Parameter",
    "h-1": "Type"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "window.plugins.OneSignal.setSubscription(false);",
      "language": "javascript"
    }
  ]
}
[/block]
## Receiving Notifications

### `NotificationReceivedHandler`
<div class="label-all label-type">Handler - *Coming Soon*</div>

Fires when a OneSignal notification is displayed to the user, or when it is received if it is a background / silent notification.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "0-0": "`notification`",
    "0-1": "[OSNotification](#section--osnotification-)",
    "0-2": "Contains both the user's response and properties of the notification.",
    "h-1": "Type",
    "h-2": "Description",
    "0-3": "",
    "h-3": ""
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:callout]
{
  "type": "warning",
  "body": "- If you will be displaying your own in app message when a notification is received make sure to call [inFocusDisplaying](#section--infocusdisplaying-) with `None` to disable OneSignal's in app AlertBox.\n- If want to change how a notification is displayed in the notification shade or process a silent notification when your app isn't running see our [Background Data and Notification Overriding](android-notification-customizations#background-data-and-notification-overriding) guide.",
  "title": "Important behavior notes"
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "// TODO",
      "language": "javascript"
    }
  ]
}
[/block]
### `NotificationOpenedHandler`
<div class="label-all label-type">Handler - *Coming Soon*</div>

Use to process a OneSignal notification the user just tapped on.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "0-0": "`result`",
    "0-1": "[OSNotificationOpenResult](#section--osnotificationopenresult-)",
    "0-2": "Contains both the user's response and properties of the notification.",
    "h-2": "Description",
    "h-1": "Type",
    "0-3": "",
    "h-3": "Description"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "// TODO",
      "language": "javascript"
    }
  ]
}
[/block]

#### notificationOpenedCallback
Function that gets called when a notification is opened or one is received when your app is in use. Function will receive one parameter with JSON about the incoming notification.
[block:parameters]
{
  "data": {
    "h-0": "Parameter (JSON)",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`message`",
    "0-1": "String",
    "0-2": "The message text the user seen in the notification.",
    "1-0": "`additionalData`",
    "1-1": "JSONObject",
    "1-2": "Key value pairs that were set on the notification. (See below)",
    "2-0": "`isActive`",
    "2-1": "boolean",
    "2-2": "`true` if your app was currently being used when a notification came in."
  },
  "cols": 3,
  "rows": 3
}
[/block]
Contents of `additionalData`:
[block:parameters]
{
  "data": {
    "h-0": "Parameter (JSON)",
    "h-1": "Typ",
    "h-2": "Description",
    "0-0": "`title`",
    "0-1": "String",
    "0-2": "Title displayed in the notification.",
    "1-0": "`actionButtons`",
    "1-1": "ArrrayOfObjects",
    "1-2": "Any buttons that were present on the notification.\n`text` - String - Text displayed on the button.\n`id` - String - Id set on the button.",
    "2-0": "`actionSelected`",
    "2-1": "String",
    "2-2": "Id of the button on the notification that was clicked. `__DEFAULT__` will be set if buttons were set on the notification but the user tap on the notification itself.",
    "3-0": "`sound`",
    "3-1": "String",
    "4-1": "String",
    "5-1": "ArrrayOfObjects",
    "3-2": "Sound set on the notification.",
    "4-2": "launchURL set on the notification.",
    "4-0": "`launchURL`",
    "5-2": "Contains an object for each notification that exists in the stack. `message` as well as keys listed above and ones you set with additional data.",
    "5-0": "`stacked_notifications`"
  },
  "cols": 3,
  "rows": 6
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": " var notificationOpenedCallback = function(jsonData) {\n\talert(\"Notification received:\\n\" + JSON.stringify(jsonData));\n  console.log('didReceiveRemoteNotificationCallBack: ' + JSON.stringify(jsonData));\n}",
      "language": "javascript",
      "name": "Basic"
    },
    {
      "code": "// This example will show an alert box if the user presses the button with the id \"id1\" on the notification.\n var notificationOpenedCallback = function(jsonData) {\n\tif (jsonData.additionalData) {\n  \tif (jsonData.additionalData.actionSelected == \"id1\")\n      alert(\"Button id1 pressed!\");\n  }\n}",
      "language": "javascript",
      "name": "Handle Action Buttons"
    },
    {
      "code": "// Set 'Additional Data' ('data' field on the REST API) when you send your notification with targetUrl equal to the url you want to navigate to.\nvar notificationOpenedCallback = function(jsonData) {\n\tif (jsonData.additionalData && jsonData.additionalData.targetUrl)\n      location.href = jsonData.additionalData.targetUrl;\n}",
      "language": "javascript",
      "name": "Open page in app"
    },
    {
      "code": "// Any additional data you set on the notification will be stored in stacked_notifications with your key\n var notificationOpenedCallback = function(jsonData) {\n  if (   jsonData.additionalData\n      && jsonData.additionalData.stacked_notifications) {\n    var notifications = jsonData.additionalData.stacked_notifications;\n    for (var i = 0; i < notifications.length; i++) {\n      alert(notifications[i].message);\n      console.log(notifications[i]);\n    }\n  }\n}",
      "language": "javascript",
      "name": "Stacked Notifications"
    }
  ]
}
[/block]
### `OSNotification`
<div class="label-all label-type">Class - *Coming Soon*</div>
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`isAppInFocus`",
    "1-0": "`shown`",
    "0-1": "boolean",
    "1-1": "boolean",
    "2-1": "int",
    "3-1": "[OSNotificationPayload](#section--osnotificationpayload-)",
    "4-1": "DisplayType",
    "5-1": "List<[OSNotificationPayload](#section--osnotificationpayload-)>",
    "0-2": "Was app in focus.",
    "1-2": "Was notification shown to the user. Will be false for silent notifications.",
    "2-0": "`androidNotificationId`",
    "2-2": "<span class=\"label-all label-android\">Android</span> - Android Notification assigned to the notification. Can be used to cancel or replace the notification.",
    "3-0": "`payload`",
    "3-2": "Payload received from OneSignal.",
    "4-0": "`displayType`",
    "4-2": "How the notification was displayed to the user. Can be set to `Notification`, `InAppAlert`, or `None` if it was not displayed.",
    "5-0": "`groupedNotifications`",
    "5-2": "<span class=\"label-all label-android\">Android</span> - Notification is a summary notification for a group this will contain all notification payloads it was created from."
  },
  "cols": 3,
  "rows": 6
}
[/block]

### `OSNotificationAction`
<div class="label-all label-type">Class - *Coming Soon*</div>
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-1": "ActionType",
    "1-1": "String",
    "1-0": "`actionID`",
    "0-0": "`type`",
    "0-2": "Was the notification opened normally (`Opened`) or was a button pressed on the notification (`ActionTaken`).",
    "1-2": "If `type` == `ActionTaken` then this will contain the id of the button pressed."
  },
  "cols": 3,
  "rows": 2
}
[/block]

### `OSNotificationPayload`
<div class="label-all label-type">Class - *Coming Soon*</div>

TODO - add tags for platform-specific parameters
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-1": "String",
    "1-1": "String",
    "2-1": "String",
    "3-1": "JSONObject",
    "4-1": "String",
    "5-1": "String",
    "6-1": "String",
    "7-1": "String",
    "8-1": "String",
    "9-1": "String",
    "0-0": "`notificationId`",
    "1-0": "`title`",
    "2-0": "`body`",
    "3-0": "`additionalData`",
    "4-0": "`smallIcon`",
    "5-0": "`largeIcon`",
    "6-0": "`bigPicture`",
    "7-0": "`smallIconAccentColor`",
    "8-0": "`launchUrl`",
    "9-0": "`sound`",
    "10-0": "`ledColor`",
    "10-1": "String",
    "11-0": "`lockScreenVisibility`",
    "11-1": "int",
    "12-0": "`groupKey`",
    "12-1": "String",
    "13-0": "`groupMessage`",
    "13-1": "string",
    "14-0": "`actionButtons`",
    "14-1": "List<[ActionButton](#section--osnotificationpayload-actionbutton-)>",
    "16-1": "BackgroundImageLayout",
    "16-0": "`backgroundImageLayout`",
    "17-0": "`rawPayload`",
    "17-1": "String",
    "17-2": "Raw JSON payload string received from OneSignal.",
    "16-2": "<span class=\"label-all label-android\">Android</span> - If a background image was set this object will be available.",
    "14-2": "List of action buttons on the notification.",
    "13-2": "<span class=\"label-all label-android\">Android</span> - Summary text displayed in the summary notification.",
    "15-0": "`fromProjectNumber`",
    "15-1": "String",
    "15-2": "<span class=\"label-all label-android\">Android</span> - The Google project number the notification was sent under.",
    "12-2": "<span class=\"label-all label-android\">Android</span> - Notifications with this same key will be grouped together as a single summary notification.",
    "11-2": "<span class=\"label-all label-android\">Android</span> - Privacy setting for how the notification should be shown on the lockscreen of Android 5+ devices. `1` = Public (fully visible)(default), `0` = Private (Contents are hidden), `-1` = Secret (not shown).",
    "10-2": "<span class=\"label-all label-android\">Android</span> - Devices that have a notification LED will blink in this color. ARGB format.",
    "9-2": "Sound resource to play when the notification is shown.",
    "8-2": "URL to open when opening the notification.",
    "7-2": "<span class=\"label-all label-android\">Android</span> - Accent color shown around small notification icon on Android 5+ devices. ARGB format.",
    "6-2": "<span class=\"label-all label-android\">Android</span> - Big picture image set on the notification.",
    "5-2": "<span class=\"label-all label-android\">Android</span> - Large icon set on the notification.",
    "4-2": "<span class=\"label-all label-android\">Android</span> - Small icon resource name set on the notification.",
    "3-2": "Custom additional data that was sent with the notification. Set on the dashboard under Options > Additional Data or with the 'data' field on the REST API.",
    "2-2": "Body of the notification.",
    "1-2": "Title of the notification.",
    "0-2": "OneSignal notification UUID."
  },
  "cols": 3,
  "rows": 18
}
[/block]
### `OSNotificationPayload.ActionButton`
<div class="label-all label-type">Class - *Coming Soon*</div>
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-1": "String",
    "1-1": "String",
    "2-1": "String",
    "0-0": "`id`",
    "1-0": "`text`",
    "1-2": "Text show on the button to the user.",
    "2-0": "`icon`",
    "0-2": "Id assigned to the button.",
    "2-2": "<span class=\"label-all label-android\">Android</span> - Icon shown on the button."
  },
  "cols": 3,
  "rows": 3
}
[/block]
### `OSNotificationPayload.BackgroundImageLayout`
<div class="label-all label-type">Class - <span class="label-all label-android">Android</span> - *Coming Soon*</div>
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-1": "String",
    "1-1": "String",
    "2-1": "String",
    "0-0": "`image`",
    "0-2": "Image URL or name used as the background image.",
    "1-2": "Text color of the title on the notification. ARGB Format.",
    "2-2": "Text color of the body on the notification. ARGB Format.",
    "1-0": "`titleTextColor`",
    "2-0": "`bodyTextColor`"
  },
  "cols": 3,
  "rows": 3
}
[/block]

### `OSNotificationOpenResult`
<div class="label-all label-type">Class - *Coming Soon*</div>
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`notification`",
    "1-0": "`action`",
    "1-1": "[OSNotificationAction](#section--osnotificationaction-)",
    "0-1": "[OSNotification](#section--osnotification-)",
    "0-2": "Notification the user opened.",
    "1-2": "The action the user took on the notification."
  },
  "cols": 3,
  "rows": 2
}
[/block]
## Appearance

### `enableVibrate`
<div class="label-all label-type">Method - <span class="label-android">Android</span></div>


*You can call this from your UI from a button press for example to give your user's options for your notifications.*

By default OneSignal always vibrates the device when a notification is displayed unless the device is in a total silent mode. Passing `false` means that the device will only vibrate lightly when the device is in it's vibrate only mode.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "'enable'",
    "0-1": "boolean",
    "0-2": "`false` to disable vibrate, `true` to re-enable it."
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "window.plugins.OneSignal.enableVibrate(false);",
      "language": "javascript"
    }
  ]
}
[/block]
### `enableSound`
<div class="label-all label-type">Method - <span class="label-android">Android</span></div>

*You can call this from your UI from a button press for example to give your user's options for your notifications.*

By default OneSignal plays the system's default notification sound when the device's notification system volume is turned on. Passing `false` means that the device will only vibrate unless the device is set to a total silent mode.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`enable`",
    "0-1": "boolean",
    "0-2": "`false` to disable sound, `true` to re-enable it."
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "window.plugins.OneSignal.enableSound(false);",
      "language": "java"
    }
  ]
}
[/block]
## Debug

### `setLogLevel`
<div class="label-all label-type">Method</div>

Enable logging to help debug if you run into an issue setting up OneSignal. The logging levels are available with increasingly more information, as follows: 
`0` = None
`1` = Fatal
`2` = Errors
`3` = Warnings
`4` = Info
`5` = Debug
`6` = Verbose
[block:parameters]
{
  "data": {
    "h-0": "Parameters",
    "0-0": "`logLevel`",
    "1-0": "`visualLevel`",
    "1-1": "integer",
    "0-1": "integer",
    "0-2": "Sets the logging level to print to the iOS Xcode log or the Android LogCat log.",
    "1-2": "Sets the logging level to show as alert dialogs.",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 2
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "// Will show popup dialogs when the devices registers with Apple/Google and with OneSignal.\n// Errors will be shown as popups too if there are any issues.\nwindow.plugins.OneSignal.setLogLevel({logLevel: 4, visualLevel: 4});",
      "language": "javascript"
    }
  ]
}
[/block]
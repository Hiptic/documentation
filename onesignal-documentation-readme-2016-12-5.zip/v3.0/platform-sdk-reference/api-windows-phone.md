---
title: "Windows Phone"
excerpt: "OneSignal Windows Phone API Reference. Works with <span class=\"label-all label-windows\">Windows Phone 8.0 & 8.1</span>.\n<div class=\"tag-all tag-developers\">For Developers</div>"
---
[block:callout]
{
  "type": "warning",
  "title": "Windows Phone 10",
  "body": "The OneSignal SDK does not currently support Windows Phone 10. We're working on it! Thanks"
}
[/block]

[block:parameters]
{
  "data": {
    "0-0": "### Initialization",
    "0-1": "",
    "h-2": "",
    "0-2": "",
    "h-0": "",
    "1-0": "[init](#section--init-)",
    "1-1": "Method",
    "1-2": "Initialize OneSignal",
    "2-0": "### User IDs",
    "3-0": "[IdsAvailable](#section--idsavailable-)",
    "3-1": "Method",
    "3-2": "Get the User ID of the device",
    "5-0": "### Tags",
    "6-0": "[GetTags](#section--gettags-)",
    "6-1": "Method",
    "9-1": "Method",
    "10-1": "Method",
    "11-1": "Method",
    "6-2": "View Tags from a User",
    "9-2": "",
    "11-2": "",
    "10-2": "Delete a Tag from a User",
    "9-0": "[SendTags](#section--sendtags-)",
    "10-0": "[DeleteTag](#section--deletetag-)",
    "11-0": "[DeleteTags](#section--deletetags-)",
    "12-0": "### Data",
    "14-0": "### Receiving Notifications",
    "15-0": "[NotificationReceived](#section--notificationreceived-)",
    "15-1": "Method",
    "13-0": "[SendPurchase](#section--sendpurchase-)",
    "13-1": "Method",
    "13-2": "Get In-App Purchase Information",
    "15-2": "When a notification is received by a device",
    "8-0": "[SendTag](#section--sendtag-)",
    "8-1": "Method",
    "8-2": "Add a Tag to a User",
    "4-0": "[GetIdsAvailable](#section--getidsavailable-)",
    "4-1": "Delegate",
    "7-0": "[TagsReceived](#section--tagsreceived-)"
  },
  "cols": 3,
  "rows": 16
}
[/block]
## Initialization
### Init
<div class="label-all label-type">Method</div>

Only required method you call to setup OneSignal to recieve push notifications. Must be called from OnNavigatedTo and on any page your app can start from. For most basic apps you will just add it to MainPage.xaml.cs.

[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`appId`",
    "0-1": "String",
    "0-2": "Your OneSignal app id, available in <a class=\\\"dash-link\\\">Keys & IDs</a>",
    "1-0": "`inNotificationDelegate`",
    "1-1": "NotificationReceived",
    "1-2": "Calls this delegate when a notification is opened or one is received when the user is in your app."
  },
  "cols": 3,
  "rows": 2
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "protected override void OnNavigatedTo(NavigationEventArgs navEventArgs) {\n            base.OnNavigatedTo(navEventArgs);\n            OneSignal.Init(\"5eb5a37e-b458-11e3-ac11-000c2940e62c\", ReceivedNotification);\n        }",
      "language": "csharp"
    }
  ]
}
[/block]

## Registering Push

## User IDs

### IdsAvailable
<div class="label-all label-type">Delegate</div>

Delegate you can define to get the OneSignal userId and Google registration Id or an iOS push token.

[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`userId`",
    "0-1": "String",
    "1-0": "`pushToken`",
    "1-1": "String",
    "1-2": "Microsoft Channel Uri(_unique per device per app_).\n\n_NOTE:_ Might be blank if there was a connection issue with Microsoft.",
    "0-2": "OneSignal userId is a UUID formatted string.(_unique per device per app_)"
  },
  "cols": 3,
  "rows": 2
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "private void IdsAvailable(string userID, string pushToken) {\n\t\tSystem.Diagnostics.Debug.WriteLine(\"UserID:\"  + userID);\n\t\tSystem.Diagnostics.Debug.WriteLine(\"pushToken:\" + pushToken);\n\t}",
      "language": "csharp"
    }
  ]
}
[/block]

### GetIdsAvailable
<div class="label-all label-type">Method</div>

Lets you retrieve the OneSignal user id and push token. Your delegate is called after the device is successfully registered with OneSignal. If the device has already successfully registered, the delegate will be called immediately.

[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`inIdsAvailableDelegate`",
    "0-1": "IdsAvailable",
    "0-2": "Calls the delegate when the user id is available. If you need more than one method subscribed to the event add to `GameThrive.idsAvailableDelegate` and leave the parameter to this method blank. The passed in delegate removes all other delegates."
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "void SomeMethod() {\n\t\tOneSignal.GetIdsAvailable(IdsAvailable);\n\t}\n\n\tprivate void IdsAvailable(string userID, string pushToken) {\n\t\tSystem.Diagnostics.Debug.WriteLine(\"UserID:\"  + userID);\n\t\tSystem.Diagnostics.Debug.WriteLine(\"pushToken:\" + pushToken);\n\t}",
      "language": "csharp"
    }
  ]
}
[/block]
## Tags
### `GetTags`
<div class="label-all label-type">Method</div>

Retrieve a list of tags that have been set on the user from the OneSignal server.
[block:parameters]
{
  "data": {
    "0-0": "`inTagsReceivedDelegate`",
    "0-1": "TagsReceived",
    "0-2": "Delegate gets called once the tags are available. If you need more than one method subscribed to the event add to `GameThrive.tagsReceivedDelegate` and leave the parameter to this method blank. The passed in delegate removes all other delegates.",
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "void SomeMethod() {\n\t\tOneSignal.GetTags(TagsReceived);\n}\n\nprivate void TagsReceived(IDictionary<string, string> tags) {\n\tforeach (var tag in tags)\n\t\tSystem.Diagnostics.Debug.WriteLine(tag.Key + \":\" + tag.Value);\n}",
      "language": "csharp"
    }
  ]
}
[/block]
### `TagsReceived`
<div class="label-all label-type">Delegate</div>

Delegate you can define to get the all the tags set on a user from onesignal.com.
[block:parameters]
{
  "data": {
    "0-0": "`tags`",
    "0-1": "IDictionary<string, string>",
    "0-2": "Dictionary of key value pairs retrieved from the OneSignal server.",
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "private static void TagsReceived(Dictionary<string, object> tags) {\n\t\tforeach (var tag in tags)\n\t\t\tSystem.Diagnostics.Debug.WriteLine(tag.Key + \":\" + tag.Value);\n\t}",
      "language": "csharp"
    }
  ]
}
[/block]
### `SendTag`
<div class="label-all label-type">Method</div>

Tag a user based on an app event of your choosing so later you can create segments on [onesignal.com](https://onesignal.com) to target these users. Using SendTags instead if you need to set more than one tag on a user at a time.

[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "1-0": "`value`",
    "1-1": "String",
    "1-2": "Value to set on the key.",
    "0-0": "`key`",
    "0-1": "String",
    "0-2": "Key of your choosing to create or update.\n\n_NOTE:_ Passing in a blank string deletes the key, you can also call `DeleteTag`."
  },
  "cols": 3,
  "rows": 2
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.SendTag(\"key\", \"value\");",
      "language": "csharp"
    }
  ]
}
[/block]
### `SendTags`
<div class="label-all label-type">Method</div>

Tag a user based on an app event of your choosing so later you can create segments on [onesignal.com](https://onesignal.com) to target these users.
[block:parameters]
{
  "data": {
    "0-0": "`keyValuePairs`",
    "0-1": "IDictionary<string, string> OR IDictionary<string, int> OR IDictionary<string, object>",
    "0-2": "Keys and values of your choosing to create or update. _NOTE:_ Passing in a blank string deletes the key, you can also call DeleteTag or DeleteTags.",
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.SendTags(new Dictionary<string, string>() {\n                {\"Key1\", \"Value1\"},\n                {\"Key2\", \"Value2\"}\n            });",
      "language": "csharp"
    }
  ]
}
[/block]
### `DeleteTag`
<div class="label-all label-type">Method</div>

Deletes a tag that was previously set on a user with `sendTag`. Use DeleteTags if you need to delete more than one.
[block:parameters]
{
  "data": {
    "0-0": "`key`",
    "0-1": "String",
    "0-2": "Key to remove.",
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.DeleteTag(\"key\");",
      "language": "csharp"
    }
  ]
}
[/block]

### DeleteTags
<div class="label-all label-type">Method</div>

Deletes a tag that was previously set on a user with `SendTag` or `SendTags`.
[block:parameters]
{
  "data": {
    "0-0": "`keys`",
    "0-1": "IList<string> tags",
    "0-2": "Key to remove.",
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.DeleteTags(new List<string>(){\"Key1\", \"Key2\"});",
      "language": "csharp"
    }
  ]
}
[/block]
## Data
### `SendPurchase`
<div class="label-all label-type">Method</div>

Call this method when a user completes an in-app purchase, and provide the amount spent in USD. This can later be used to target free vs paid users when sending a push notification.
[block:parameters]
{
  "data": {
    "0-0": "`amount`",
    "0-1": "Double OR decimal",
    "0-2": "Key to remove.",
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "OneSignal.SendPurchase(1.23d);",
      "language": "csharp"
    }
  ]
}
[/block]
## Sending Notifications
Use REST API

## Receiving Notifications

### `NotificationReceived`
<div class="label-all label-type">Delegate</div>

Delegate you can define to process information on the notification the user just opened.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`additionalData`",
    "0-1": "IDictionary<string, string>",
    "0-2": "Key value pairs that were set on the notification.",
    "1-0": "`isActive`",
    "1-1": "Boolean",
    "1-2": "`true` if your app was currently being used when a notification came in."
  },
  "cols": 3,
  "rows": 2
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "private static void ReceivedNotification((IDictionary<string, string> additionalData, bool isActive) {\n\t\t// When isActive is true this means the user is currently in your app.\n\t\t// Use isActive and your own app logic so you don't interupt the user with a popup or menu when they are in the middle of using your app.\n\t\tif (additionalData != null) {\n\t\t\tif (additionalData.ContainsKey(\"discount\")) {\n\t\t\t\textraMessage = \"DISCOUNT!\";\n\t\t\t\t// Take user to your store.\n\t\t\t}\n\t\t\telse if (additionalData.ContainsKey(\"bonusCredits\")) {\n\t\t\t\textraMessage = \"BONUS CREDITS!\";\n\t\t\t\t// Take user to your store.\n\t\t\t}\n\t\t}\n\t}",
      "language": "csharp"
    }
  ]
}
[/block]
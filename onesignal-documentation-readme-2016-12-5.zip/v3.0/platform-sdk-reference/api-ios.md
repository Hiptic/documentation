---
title: "iOS Native"
excerpt: "OneSignal <span class=\"label-all label-ios\">ios</span> Native API Reference\n<div class=\"tag-all tag-developers\">For Developers</div>"
---
[block:parameters]
{
  "data": {
    "0-0": "### Initialization",
    "0-1": "",
    "2-0": "[kOSSettingsKeyAutoPrompt](#section--kossettingskeyautoprompt-)",
    "2-1": "Interface Element",
    "h-2": "",
    "0-2": "",
    "2-2": "Automatically Prompt Users to Enable Notifications",
    "h-0": "",
    "1-0": "[initWithLaunchOptions](#section--initwithlaunchoptions-)",
    "1-1": "Method",
    "1-2": "Initialize OneSignal",
    "5-0": "### Registering Push",
    "6-0": "[registerForPushNotifications](#section--registerforpushnotifications-)",
    "7-0": "### User IDs",
    "8-0": "[IdsAvailable](#section--idsavailable-)",
    "8-1": "Method",
    "8-2": "Get the User ID of the device",
    "9-0": "[OSIdsAvailableBlock](#section--osidsavailableblock-)",
    "9-1": "Callback",
    "9-2": "",
    "12-0": "### Tags",
    "13-0": "[getTags](#section--gettags-)",
    "13-1": "Method",
    "15-1": "Method",
    "16-1": "Method",
    "17-1": "Method",
    "13-2": "View Tags from a User",
    "15-2": "",
    "17-2": "",
    "16-2": "Delete a Tag from a User",
    "15-0": "[sendTags](#section--sendtags-)",
    "16-0": "[deleteTag](#section--deletetag-)",
    "17-0": "[deleteTags](#section--deletetags-)",
    "18-0": "### Data",
    "22-0": "### Sending Notifications",
    "27-0": "### Receiving Notifications",
    "23-0": "[postNotification](#section--postnotification-)",
    "25-0": "[clearOneSignalNotifications](#section--clearonesignalnotifications-)",
    "26-0": "[setSubscription](#section--setsubscription-)",
    "26-1": "Method",
    "25-1": "Method",
    "23-1": "Method",
    "31-0": "[OSNotification](#section--osnotification-)",
    "31-1": "Interface Element",
    "36-0": "[OSNotificationPayload](#section--osnotificationpayload-)",
    "36-1": "Interface Element",
    "37-0": "### Debug",
    "38-0": "[setLogLevel](#section--setloglevel-)",
    "38-1": "Method",
    "20-1": "Method",
    "20-0": "[syncHashedEmail](#section--synchashedemail-)",
    "19-0": "[promptLocation](#section--promptlocation-)",
    "19-1": "Method",
    "3-0": "[kOSSettingsKeyInAppAlerts](#section--kossettingskeyinappalerts-)",
    "3-1": "Interface Element",
    "4-0": "[kOSSettingsKeyInAppLaunchURL](#section--kossettingskeyinapplaunchurl-)",
    "4-1": "Interface Element",
    "3-2": "Automatically Display Notifications when app is in focus",
    "4-2": "Open all URLs in In-App Safari Window",
    "19-2": "Prompt Users for Location",
    "20-2": "Sync Anonymized User Email",
    "23-2": "Send or schedule a notification to a user",
    "26-2": "Opt users in or out of receiving notifications",
    "25-2": "Delete all app notifications",
    "36-2": "Data that comes with a notification",
    "31-2": "",
    "38-2": "Enable logging to help debug OneSignal implementation",
    "14-0": "[sendTag](#section--sendtag-)",
    "14-1": "Method",
    "14-2": "Add a Tag to a User",
    "32-0": "[OSNotificationAction](#section--osnotificationaction-)",
    "32-1": "Interface Element",
    "32-2": "How user opened notification",
    "28-0": "[OSHandleNotificationReceivedBlock](#section--oshandleNotificationreceivedblock-)",
    "28-1": "Callback",
    "28-2": "When a notification is received by a device",
    "6-1": "Method",
    "6-2": "Prompt Users to Enable Notifications",
    "10-0": "[OSResultSuccessBlock](#section--osresultsuccessblock-)",
    "11-0": "[OSFailureBlock](#section--osfailureblock-)",
    "10-1": "Callback",
    "11-1": "Callback",
    "10-2": "",
    "11-2": "",
    "30-0": "[OSHandleNotificationActionBlock](#section-oshandlenotificationactionblock-)",
    "30-1": "Callback",
    "30-2": "When a user takes an action on a notification",
    "33-0": "[OSNotificationActionType](#section--osnotificationactiontype-)",
    "33-1": "Interface Element",
    "33-2": "",
    "35-0": "[OSNotificationDisplayType](#section--osnotificationdisplaytype-)",
    "35-1": "Interface Element",
    "35-2": "Change how notifications are displayed to users",
    "21-2": "Get In-App Purchase Information",
    "21-0": "Automatic",
    "34-0": "[OSNotificationOpenedResult](#section--osnotificationopenedresult-)",
    "34-1": "Interface Element",
    "24-0": "[handleNotificationReceived](#section--handlenotificationreceived-)",
    "24-1": "Parameter",
    "29-0": "[handleNotificationAction](#section--handlenotificationaction-)"
  },
  "cols": 3,
  "rows": 39
}
[/block]

## Initialization

### initWithLaunchOptions
<div class="label-all label-type">Method</div>

Must be called from `didFinishLaunchingWithOptions` in `AppDelegate.m`.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-2": "launchOptions that you received from `didFinishLaunchingWithOptions`",
    "0-1": "NSDictionary*",
    "0-0": "`launchOptions`",
    "1-1": "NSString*",
    "1-0": "`appId`",
    "1-2": "Your OneSignal app id found on the settings page at onesignal.com",
    "2-1": "[OSHandleNotificationReceivedBlock](#OSHandleNotificationReceivedBlock)",
    "2-0": "`callback(Optional)`",
    "2-2": "Function to be called when a notification is received",
    "3-1": "[OSHandleNotificationActionBlock](#OSHandleNotificationActionBlock)",
    "3-0": "`callback(Optional)`",
    "3-2": "Function to be called when a user reacts to a notification received",
    "4-2": "<p>Customization settings to change OneSignal's default behavior</p>\n<p>[kOSSettingsKeyAutoPrompt](#kOSSettingsKeyAutoPrompt) - Default is `true` which automatically prompts for notifications permissions</p>\n<p>[kOSSettingsKeyInAppAlerts](#kOSSettingsKeyInAppAlerts) - Default is `true` which automatically shows an in app alert when a notification is received.</p>",
    "4-0": "`settings(Optional)`",
    "4-1": "NSDictionary*"
  },
  "cols": 3,
  "rows": 5
}
[/block]

[block:callout]
{
  "type": "info",
  "body": "`application:didRegisterForRemoteNotificationsWithDeviceToken:` will still fire even if `kOSSettingsKeyAutoPrompt` is set to `false`. This behavior will happen on iOS 8+ devices.",
  "title": "iOS 8.0+ Note"
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "- (BOOL)application:(UIApplication*)application didFinishLaunchingWithOptions:(NSDictionary*)launchOptions {\n \n  [OneSignal initWithLaunchOptions:launchOptions appId:@\"YOUR_ONESIGNAL_APP_ID\" handleNotificationReceived:^(OSNotification *notification) {\n        NSLog(@\"Received Notification - %@\", notification.payload.notificationID);\n    } handleNotificationAction:^(OSNotificationOpenedResult *result) {\n        \n        // This block gets called when the user reacts to a notification received\n        OSNotificationPayload* payload = result.notification.payload;\n        \n        NSString* messageTitle = @\"OneSignal Example\";\n        NSString* fullMessage = [payload.body copy];\n        \n        if (payload.additionalData) {\n            \n            if(payload.title)\n                messageTitle = payload.title;\n            \n            NSDictionary* additionalData = payload.additionalData;\n            \n            if (additionalData[@\"actionSelected\"])\n                fullMessage = [fullMessage stringByAppendingString:[NSString stringWithFormat:@\"\\nPressed ButtonId:%@\", additionalData[@\"actionSelected\"]]];\n        }\n        \n        UIAlertView* alertView = [[UIAlertView alloc] initWithTitle:messageTitle\n                                                            message:fullMessage\n                                                           delegate:self\n                                                  cancelButtonTitle:@\"Close\"\n                                                  otherButtonTitles:nil, nil];\n        [alertView show];\n\n    } settings:@{kOSSettingsKeyInAppAlerts : @NO, kOSSettingsKeyAutoPrompt : @NO}];\n  \n}",
      "language": "objectivec"
    },
    {
      "code": "func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {\n\nOneSignal.initWithLaunchOptions(launchOptions, appId: \"YOUR_ONESIGNAL_APP_ID\", handleNotificationReceived: { (notification) in\n                print(\"Received Notification - \\(notification.payload.notificationID)\")\n            }, handleNotificationAction: { (result) in\n                \n                // This block gets called when the user reacts to a notification received\n                let payload = result.notification.payload\n                var fullMessage = payload.title\n                \n                //Try to fetch the action selected\n                if let additionalData = payload.additionalData, actionSelected = additionalData[\"actionSelected\"] as? String {\n                    fullMessage =  fullMessage + \"\\nPressed ButtonId:\\(actionSelected)\"\n                }\n                print(fullMessage)\n            }, settings: [kOSSettingsKeyAutoPrompt : false, kOSSettingsKeyInAppAlerts : false])\n\n}",
      "language": "swift",
      "name": null
    }
  ]
}
[/block]
### `kOSSettingsKeyAutoPrompt`
<div class="label-all label-type">Interface Element</div>

Pass `[kOSSettingsKeyAutoPrompt : false]` to the [initWithLaunchOptions](#initWithLaunchOptions) settings in order to disable auto prompt.

### `kOSSettingsKeyInAppAlerts`
<div class="label-all label-type">Interface Element</div>

Pass `[kOSSettingsKeyInAppAlerts : false]` to the [initWithLaunchOptions](#initWithLaunchOptions) disable the automatic display of inapp alerts when a notification is received when your app is in focus.

### `kOSSettingsKeyInAppLaunchURL`
<div class="label-all label-type">Interface Element</div>

Pass `[kOSSettingsKeyInAppLaunchURL : false]` to the [initWithLaunchOptions](#initWithLaunchOptions) disable the display of launch URLs in-app but instead open the URL in Safari or other app (if deep linked or custom URL scheme passed).

## Registering Push
### `registerForPushNotifications`
<div class="label-all label-type">Method</div>

Call when you want to prompt the user to accept push notifications. Only call once and only if you passed false to `initWithLaunchOptions autoRegister:`.
[block:code]
{
  "codes": [
    {
      "code": "[OneSignal registerForPushNotifications];",
      "language": "objectivec"
    },
    {
      "code": "OneSignal.registerForPushNotifications()",
      "language": "swift",
      "name": "Swift"
    }
  ]
}
[/block]

## User IDs

### `IdsAvailable`
<div class="label-all label-type">Method</div>

Lets you retrieve the OneSignal user id and push token. Your callback block is called after the device is successfully registered with OneSignal. pushToken will be nil if the user did not accept push notifications.
[block:parameters]
{
  "data": {
    "0-0": "`IdsAvailableBlock`",
    "0-1": "OneSignalIdsAvailableBlock",
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-2": "Called when the user id is available"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "[OneSignal IdsAvailable:^(NSString* userId, NSString* pushToken) {\n\tNSLog(@\"UserId:%@\", userId);\n\tif (pushToken != nil)\n\t\tNSLog(@\"pushToken:%@\", pushToken);\n}];",
      "language": "objectivec"
    },
    {
      "code": "OneSignal.IdsAvailable({ (userId, pushToken) in\n\tNSLog(\"UserId:%@\", userId)\n  if (pushToken != nil) {\n  \tNSLog(\"pushToken:%@\", pushToken)\n  }\n})",
      "language": "swift",
      "name": "Swift"
    }
  ]
}
[/block]
### `OSIdsAvailableBlock`
<div class="label-all label-type">Callback</div>

Lets you retrieve the OneSignal user id and device token. Your block is called after the device is successfully registered with OneSignal.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-1": "NSString*",
    "1-1": "NSString*",
    "0-0": "`userId`",
    "1-0": "`pushToken`",
    "0-2": "OneSignal userId is a UUID formatted string.(_unique per device per app_)",
    "1-2": "pushToken is a Apple assigned identifier(_unique per device per app_)"
  },
  "cols": 3,
  "rows": 2
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "[OneSignal IdsAvailable:^(NSString *userId, NSString *pushToken) {\n        if(pushToken) {\n            NSLog(@\"Received push token - %@\", pushToken);\n            NSLog(@\"User ID - %@\", userId);\n        }\n    }];",
      "language": "objectivec"
    },
    {
      "code": "OneSignal.IdsAvailable({ (userId, pushToken) in\n            NSLog(\"UserId:%@\", userId);\n            if (pushToken != nil) {\n                NSLog(\"Sending Test Noification to this device now\");\n                OneSignal.postNotification([\"contents\": [\"en\": \"Test Message\"], \"include_player_ids\": [userId]]);\n            }\n        });",
      "language": "swift"
    }
  ]
}
[/block]
The response may be `nil` if the user does not accept push notifications for your app or there was a connection issue.

If you disable auto prompt or the user waits over 30 seconds to say yes to the system prompt then your call back will be called twice. First with just the userId field and then a 2nd time to with the push token included. See below:
[block:code]
{
  "codes": [
    {
      "code": "[OneSignal IdsAvailable:^(NSString* userId, NSString* pushToken) {\n\tNSLog(@\"UserId:%@\", userId);\n\tif (pushToken != nil)\n\t\tNSLog(@\"pushToken:\", pushToken);\n}];",
      "language": "objectivec"
    },
    {
      "code": "oneSignal.IdsAvailable({ (userId, pushToken) in\n\tNSLog(\"UserId:%@\", userId)\n  if (pushToken != nil) {\n  \tNSLog(\"pushToken:%@\", pushToken)\n  }\n})",
      "language": "swift",
      "name": "Swift"
    }
  ]
}
[/block]
### `OSResultSuccessBlock`
<div class="label-all label-type">Callback</div>

Block that gets called when the OneSignal server is contacted successfully.
[block:parameters]
{
  "data": {
    "0-1": "NSDictionary",
    "0-0": "`result`",
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-2": "The resulting JSON received from the OneSignal server"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "[OneSignal getTags:^(NSDictionary* result) {\n\tNSLog(@\"%@\", result);\n}];",
      "language": "objectivec"
    },
    {
      "code": "oneSignal.getTags({ (tags) in\n\tNSLog(\"%@\", tags)\n})",
      "language": "swift",
      "name": "Swift"
    }
  ]
}
[/block]
### `OSFailureBlock`
<div class="label-all label-type">Callback</div>

Block that gets called when the OneSignal server can't be contacted or there was a error in the response.
[block:parameters]
{
  "data": {
    "0-1": "NSError*",
    "h-1": "Type",
    "h-0": "Parameter",
    "h-2": "Description",
    "0-0": "`error`",
    "0-2": "errorWithDomain == \"OneSignalError\", code  == HTTP error code from the OneSignal server, userInfo == JSON OneSignal responded with."
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "[OneSignal sendTags:@{@\"key\" : @\"value\"} onSuccess:^(NSDictionary *result) {\n        NSLog(@\"success!\");\n    } onFailure:^(NSError *error) {\n        NSLog(@\"Error - %@\", error.localizedDescription);\n    }];",
      "language": "objectivec"
    },
    {
      "code": "OneSignal.sendTags([\"some_key\" : \"some_value\"], onSuccess: { (result) in\n            print(\"success!\")\n            }) { (error) in\n                print(\"Error sending tags - \\(error.localizedDescription)\")\n        }",
      "language": "swift"
    }
  ]
}
[/block]
### `getTags`
<div class="label-all label-type">Method</div>

Retrieve a list of tags that have been set on the user from the OneSignal server.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-1": "OneSignalResultSuccessBlock",
    "0-0": "`successBlock`",
    "0-2": "Called when tags are received from OneSignal's server",
    "1-2": "Called if there was an error.",
    "1-0": "`onFailure(Optional)`",
    "1-1": "OneSignalFailureBlock"
  },
  "cols": 3,
  "rows": 2
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "[oneSignal getTags:^(NSDictionary* tags) {\n\tNSLog(@\"%@\", tags);\n}];",
      "language": "objectivec"
    },
    {
      "code": "oneSignal.getTags({ (tags) in\n\tNSLog(\"%@\", tags)\n})",
      "language": "swift",
      "name": "Swift"
    }
  ]
}
[/block]
### `sendTag`
<div class="label-all label-type">Method</div>

Tag a user based on an app event of your choosing so later you can create segments on [onesignal.com](https://onesignal.com) to target these users. Recommend using sendTags over sendTag if you need to set more than one tag on a user at a time.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-1": "NSString*",
    "1-1": "NSString*",
    "0-0": "`key`",
    "1-0": "`value`",
    "0-2": "Key of your choosing to create or update",
    "1-2": "Value to set on the key. _NOTE:_ Passing in a blank String deletes the key, you can also call `deleteTag` or `deleteTags`.",
    "2-0": "`onSuccess(Optional)`",
    "3-0": "`onFailure(Optional)`",
    "2-2": "Call if there were no errors sending the tag",
    "3-2": "Called if there was an error",
    "3-1": "OneSignalFailureBlock",
    "2-1": "OneSignalResultSuccessBlock"
  },
  "cols": 3,
  "rows": 4
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "[OneSignal sendTag:@\"key\" value:@\"value\"];",
      "language": "objectivec"
    },
    {
      "code": "OneSignal.sendTag(\"key\", value: \"value\")",
      "language": "swift",
      "name": "Swift"
    }
  ]
}
[/block]
### `sendTags`
<div class="label-all label-type">Method</div>

Tag a user based on an app event of your choosing so later you can create segments on [onesignal.com](https://onesignal.com) to target these users.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-1": "NSDictionary*",
    "0-0": "`keyValues`",
    "0-2": "Key value pairs of your choosing to create or update. _NOTE:_ Passing in a blank `NSString*` as a value deletes the key, you can also call `deleteTag` or `deleteTags`.",
    "1-1": "OneSignalResultSuccessBlock",
    "2-1": "OneSignalFailureBlock",
    "1-0": "`onSuccess(Optional)`",
    "2-0": "`onFailure(Optional)`",
    "1-2": "Call if there were no errors sending the tag",
    "2-2": "Called if there was an error"
  },
  "cols": 3,
  "rows": 3
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "[OneSignal sendTags:@{@\"key1\" : @\"value1\", @\"key2\" : @\"value2\"}];",
      "language": "objectivec"
    },
    {
      "code": "OneSignal.sendTags([\"key1\": \"value1\", \"key2\": \"value2\"])",
      "language": "swift",
      "name": "Swift"
    }
  ]
}
[/block]
### `deleteTag`
<div class="label-all label-type">Method</div>

Deletes a single tag that was previously set on a user with `sendTag` or `sendTags`. Use `deleteTags` if you need to delete more than one.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`key`",
    "1-0": "`onSuccess(Optional)`",
    "2-0": "`onFailure(Optional)`",
    "1-1": "OneSignalResultSuccessBlock",
    "2-1": "OneSignalFailureBlock",
    "0-1": "NSString*",
    "1-2": "Call if there were no errors",
    "2-2": "Called if there was an error",
    "0-2": "Key to remove"
  },
  "cols": 3,
  "rows": 3
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "[OneSignal deleteTag:@\"key\"];",
      "language": "objectivec"
    },
    {
      "code": "OneSignal.deleteTag(\"key\")",
      "language": "swift",
      "name": "Swift"
    }
  ]
}
[/block]
### `deleteTags`
<div class="label-all label-type">Method</div>

Deletes one or more tags that were previously set on a user with `sendTag` or `sendTags`.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`keys`",
    "1-1": "OneSignalResultSuccessBlock",
    "2-1": "OneSignalFailureBlock",
    "0-1": "NSArray*",
    "1-0": "`onSuccess(Optional)`",
    "2-0": "`onFailure(Optional)`",
    "2-2": "Called if there was an error",
    "1-2": "Call if there were no errors",
    "0-2": "Keys to remove"
  },
  "cols": 3,
  "rows": 3
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "[OneSignal deleteTags:@[@\"key1\", @\"key2\"]];",
      "language": "objectivec"
    },
    {
      "code": "OneSignal.deleteTags([\"key1\", \"key2\"])",
      "language": "swift",
      "name": "Swift"
    }
  ]
}
[/block]
## Data

### `promptLocation`
<div class="label-all label-type">Method</div>

Prompts the user for location permissions to allow geotagging from the OneSignal dashboard. This lets you send notifications based on the device's location.

Note: Requires the follow entries in your .plist file.
- `NSLocationUsageDescription`
- `NSLocationWhenInUseUsageDescription`
[block:code]
{
  "codes": [
    {
      "code": "[OneSignal promptLocation];",
      "language": "objectivec"
    },
    {
      "code": "OneSignal.promptLocation()",
      "language": "swift"
    }
  ]
}
[/block]
### `syncHashedEmail`
<div class="label-all label-type">Method</div>

Allow OneSignal to save the MD5 and SHA1 hashes of a user's email address. This replaces the deprecated setEmail (pre-2.0) method that would save the user's plain text email address.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-2": "the email address to hash and save with OneSignal",
    "0-0": "`email`",
    "0-1": "NSString"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "[OneSignal syncHashedEmail:@\"johndoe@example.com\"];",
      "language": "objectivec"
    },
    {
      "code": "OneSignal.syncHashedEmail(\"johndoe@example.com\")",
      "language": "swift"
    }
  ]
}
[/block]
## Sending Notifications
### `postNotification`
<div class="label-all label-type">Method</div>

Allows you to send notifications from user to user or schedule ones in the future to be delivered to the current device.

See the [Create notification](ref:create-notification) REST API POST call for a list of all possible options. Note: You can only use `include_player_ids` as a targeting parameter from your app. Other target options such as `tags` and `included_segments` require your OneSignal App REST API key which can only be used from your server.
[block:parameters]
{
  "data": {
    "2-0": "`onFailure(Optional)`",
    "1-0": "`onSuccess(Optional)`",
    "1-1": "OneSignalResultSuccessBlock",
    "2-1": "OneSignalFailureBlock",
    "0-1": "NSDictionary*",
    "0-0": "`parameters`",
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-2": "Dictionary of notification options, see our [Create notification](ref:create-notification) POST call for all options.",
    "1-2": "Called if there were no errors sending the notification",
    "2-2": "Called if there was an error"
  },
  "cols": 3,
  "rows": 3
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "[OneSignal postNotification:@{\n   @\"contents\" : @{@\"en\": @\"Test Message\"},\n   @\"include_player_ids\": @[@\"3009e210-3166-11e5-bc1b-db44eb02b120\"]\n}];",
      "language": "objectivec"
    },
    {
      "code": "OneSignal.postNotification([\"contents\": [\"en\": \"Test Message\"], \"include_player_ids\": [\"3009e210-3166-11e5-bc1b-db44eb02b120\"]])",
      "language": "swift"
    }
  ]
}
[/block]

### `ClearOneSignalNotifications`
<div class="label-all label-type">Method</div>

iOS provides a standard way to clear notifications by clearing badge count, thus there is no specific OneSignal API call for clearing notifications. 

TODO: Joseph / Josh to extrapolate on this



### `setSubscription`
<div class="label-all label-type">Method</div>

You can call this method with false to opt users out of receiving all notifications through OneSignal. You can pass true later to opt users back into notifications.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`enable`",
    "0-1": "BOOL"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "[OneSignal setSubscription:false];",
      "language": "objectivec"
    },
    {
      "code": "OneSignal.setSubscription(false)",
      "language": "swift"
    }
  ]
}
[/block]
## Receiving Notifications

### `OSHandleNotificationReceivedBlock`
<div class="label-all label-type">Callback</div>

Called when the app receives a notification. *Note: This is called when your app is in focus only. If you need this to be called when your app is in the background to set `content_available` to `true` when you send your notification.*
[block:parameters]
{
  "data": {
    "0-0": "`notification`",
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-1": "[OSNotification](#OSNotification)"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "^(OSNotification *notification) {\n\tNSLog(@\"Received Notification - %@ - %@\", notification.payload.notificationID, notification.payload.title);\n}",
      "language": "objectivec"
    },
    {
      "code": "{ (notification) in\n\tprint(\"Received Notification - \\(notification.payload.notificationID) - \\(notification.payload.title)\")\n}",
      "language": "swift"
    }
  ]
}
[/block]
### `handleNotificationReceived`
<div class="label-all label-type">Parameter</div>

Optional parameter within `initWithLaunchOptions` in iOS to set callback handlers


### `OSHandleNotificationActionBlock`
<div class="label-all label-type">Callback</div>

Called when the user opens or taps an action on a notification.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`result`",
    "0-1": "[OSNotificationAction](#OSNotificationAction)"
  },
  "cols": 3,
  "rows": 1
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "^(OSNotificationOpenedResult *result) {\n        \n\t// This block gets called when the user opens or taps an action on a notification\n\tOSNotificationPayload* payload = result.notification.payload;\n        \n\tNSString* messageTitle = @\"OneSignal Example\";\n\tNSString* fullMessage = [payload.body copy];\n        \n\tif (payload.additionalData) {\n\t\tif (payload.title)\n\t\t   messageTitle = payload.title;\n            \n\t\tNSDictionary* additionalData = payload.additionalData;\n            \n\t\tif (additionalData[@\"actionSelected\"])\n\t\t\tfullMessage = [fullMessage stringByAppendingString:[NSString stringWithFormat:@\"\\nPressed ButtonId:%@\", additionalData[@\"actionSelected\"]]];\n\t}\n        \n\tUIAlertView* alertView = [[UIAlertView alloc] initWithTitle:messageTitle\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tmessage:fullMessage\n                                                delegate:self\n                                                cancelButtonTitle:@\"Close\"\n                                                otherButtonTitles:nil, nil];\n\t[alertView show];\n}",
      "language": "objectivec"
    },
    {
      "code": "{ (result) in\n                \n\t// This block gets called when the user reacts to a notification received\n\tlet payload = result.notification.payload\n\tvar fullMessage = payload.title\n                \n\t//Try to fetch the action selected\n\tif let additionalData = payload.additionalData, actionSelected = additionalData[\"actionSelected\"] as? String {\n\t\tfullMessage =  fullMessage + \"\\nPressed ButtonId:\\(actionSelected)\"\n\t}\n\tprint(fullMessage)\n}",
      "language": "swift",
      "name": "Swift"
    }
  ]
}
[/block]
### `handleNotificationAction`
<div class="label-all label-type">Parameter</div>

Optional parameter within `initWithLaunchOptions` in iOS to set callback handlers


### `OSNotification` (*Class*)
<div class="label-all label-type">Interface Element</div>

Class describing a received notification.
[block:parameters]
{
  "data": {
    "h-0": "Properties",
    "0-0": "`payload`([OSNotificationPayload](#OSNotificationPayload));",
    "0-1": "",
    "1-0": "`displayType`([OSNotificationDisplayType](#OSNotificationDisplayType));",
    "1-1": "",
    "2-0": "`shown`(*BOOL*);",
    "2-1": "True when the user was able to see the notification. False when app is in focus and in-app alerts are disabled, or the remote notification is silent.",
    "3-1": "True when the received notification is silent. Silent means there is no alert, sound, or badge payload in the APS dictionary. Requires remote-notification within UIBackgroundModes array of the Info.plist",
    "3-0": "`silentNotification`(*BOOL*);"
  },
  "cols": 2,
  "rows": 4
}
[/block]
### `OSNotificationAction` (*Class*)
<div class="label-all label-type">Interface Element</div>

Class describing the action taken by a user once he reacts to a notification received.
[block:parameters]
{
  "data": {
    "0-0": "`actionID`(*NSString*);",
    "h-0": "Properties",
    "0-1": "The ID associated with the button tapped. NULL when the actionType is NotificationTapped or InAppAlertClosed.",
    "1-0": "`type`([OSNotificationActionType](#OSNotificationActionType));",
    "1-1": "The type of the notification action."
  },
  "cols": 2,
  "rows": 2
}
[/block]
### `OSNotificationActionType` (*NSUInteger Enum*)
<div class="label-all label-type">Interface Element</div>

The action type associated to an OSNotificationAction object. 
[block:parameters]
{
  "data": {
    "1-0": "`ActionTaken`",
    "0-0": "`Opened`",
    "h-0": "Properties"
  },
  "cols": 1,
  "rows": 2
}
[/block]
### `OSNotificationDisplayType` (*NSUInteger Enum*)
<div class="label-all label-type">Interface Element</div>

The way in which a notification was displayed to the user. 
[block:parameters]
{
  "data": {
    "0-0": "`Notification`",
    "1-0": "`InAppAlert`",
    "2-0": "`None`",
    "2-1": "Notification is silent, or app is in focus but InAppAlertNotifications are disabled.",
    "1-1": "Default UIAlertView display.",
    "0-1": "iOS native notification display.",
    "h-0": "Properties"
  },
  "cols": 2,
  "rows": 3
}
[/block]
### `OSNotificationPayload` (*Class*)
<div class="label-all label-type">Interface Element</div>

Class holding the payload data of a received [OSNotification](#OSNotification).
[block:parameters]
{
  "data": {
    "h-0": "Properties",
    "0-0": "`notificationID` (*NSString*);",
    "1-0": "`contentAvailable`(*BOOL*);",
    "0-1": "OneSignal notification UUID",
    "1-1": "Provide this key with a value of 1 to indicate that new content is available. Including this key and value means that when your app is launched in the background or resumed `application:didReceiveRemoteNotification:fetchCompletionHandler:` is called.",
    "2-0": "`badge`(*NSInteger*);",
    "3-0": "`sound`(*NSString*);",
    "3-1": "The sound parameter passed to the notification. By default set to `UILocalNotificationDefaultSoundName`",
    "2-1": "The badge number assigned to the application icon",
    "4-0": "`title`(*NSString*);",
    "4-1": "Title text of the notification",
    "5-1": "Body text of the notification",
    "6-1": "iOS 10+; subtitle text of the notification",
    "7-1": "Web address to launch within the app via a `UIWebView`",
    "8-1": "Additional Data add to the notification by you",
    "9-1": "iOS 10+; Attachments sent as part of the rich notification",
    "10-1": "Action buttons set on the notification",
    "11-1": "Holds the raw APS payload received",
    "5-0": "`body` (*NSString*);",
    "6-0": "`subtitle` (*NSString*)",
    "11-0": "`rawPayload`(*NSDictionary*);",
    "10-0": "`actionButtons`(*NSDictionary*);",
    "9-0": "`attachments`(*NSDictionary*) -",
    "8-0": "`additionalData`(*NSDictionary*);",
    "7-0": "`launchURL`(*NSString*);"
  },
  "cols": 2,
  "rows": 12
}
[/block]
### `OSNotificationOpenedResult` (*Class*)
<div class="label-all label-type">Interface Element</div>

Resulting class passed to [OSHandleNotificationActionBlock](#OSHandleNotificationActionBlock).
[block:parameters]
{
  "data": {
    "0-0": "`notification`([OSNotification](#OSNotification));",
    "1-0": "`action`([OSNotificationAction](#OSNotificationAction));",
    "h-0": "Properties"
  },
  "cols": 1,
  "rows": 2
}
[/block]

## Debug
### `setLogLevel`
<div class="label-all label-type">Method</div>

Enable logging to help debug if you run into an issue setting up OneSignal. This selector is static so you can call it before OneSignal init. The following options are available with increasingly more information; `ONE_S_LL_NONE`, `ONE_S_LL_FATAL`, `ONE_S_LL_ERROR`, `ONE_S_LL_WARN`, `ONE_S_LL_INFO`, `ONE_S_LL_DEBUG`, `ONE_S_LL_VERBOSE`.
[block:parameters]
{
  "data": {
    "h-0": "Parameters",
    "0-0": "`logLevel`",
    "1-0": "`visualLevel`",
    "1-1": "LOG_LEVEL",
    "0-1": "LOG_LEVEL",
    "0-2": "Sets the logging level to print to the Xcode log",
    "1-2": "Sets the logging level to show as alert dialogs.",
    "h-1": "Type",
    "h-2": "Description"
  },
  "cols": 3,
  "rows": 2
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "[OneSignal setLogLevel:ONE_S_LL_DEBUG visualLevel:ONE_S_LL_DEBUG];",
      "language": "objectivec"
    },
    {
      "code": "OneSignal.setLogLevel(.LL_DEBUG, visualLevel: .LL_DEBUG)",
      "language": "swift"
    }
  ]
}
[/block]
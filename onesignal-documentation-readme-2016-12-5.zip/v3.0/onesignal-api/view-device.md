---
title: "View device"
excerpt: "View the details of an existing device in one of your OneSignal apps"
---
See our [Add a device](ref:add-a-device) documentation for descriptions of the fields.

## Path Parameters
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`id`",
    "0-1": "String",
    "0-2": "Player's OneSignal ID"
  },
  "cols": 3,
  "rows": 1
}
[/block]
## Query Parameters
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`app_id`",
    "0-1": "String",
    "0-2": "Your app_id for this device"
  },
  "cols": 3,
  "rows": 1
}
[/block]
## Example Code
[block:code]
{
  "codes": [
    {
      "code": "curl --include \\ \nhttps://onesignal.com/api/v1/players/ffffb794-ba37-11e3-8077-031d62f86ebf?app_id=f69739a6-3ef1-4aaf-90d9-fec35b7c9c13",
      "language": "curl"
    }
  ]
}
[/block]
## Result Format
[block:code]
{
  "codes": [
    {
      "code": "{\n  \"identifier\":\"ce777617da7f548fe7a9ab6febb56cf39fba6d382000c0395666288d961ee566\",\n  \"session_count\":1,\n  \"language\":\"en\",\n  \"timezone\":-28800,\n  \"game_version\":\"1.0\",\n  \"device_os\":\"7.0.4\",\n  \"device_type\":0,\n  \"device_model\":\"iPhone\",\n  \"ad_id\":null,\n  \"tags\":{\"a\":\"1\",\"foo\":\"bar\"},\n  \"last_active\":1395096859,\n  \"amount_spent\":0.0,\n  \"created_at\":1395096859,\n  \"invalid_identifier\":false,\n  \"badge_count\": 0\n}",
      "language": "javascript",
      "name": "200 OK"
    }
  ]
}
[/block]
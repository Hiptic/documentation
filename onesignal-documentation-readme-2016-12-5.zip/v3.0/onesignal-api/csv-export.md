---
title: "CSV export"
excerpt: "Generate a compressed CSV export of all of your current user data"
---
This method can be used to generate a compressed CSV export of all of your current user data. It is a much faster alternative than retrieving this data using the ./players API endpoint.

You can test if it is complete by making a GET request to the csv_file_url value. If the file is not ready, a 404 error will be returned. Otherwise the file itself will be returned.

The file will be compressed using GZip.

The file may take several minutes to generate depending on the number of users in your app.
[block:callout]
{
  "type": "warning",
  "body": "Requires your OneSignal App Auth Key, available in <a class=\"dash-link\" href=\"/docs/accounts-and-keys#section-keys-ids\">Keys & IDs</a>.",
  "title": "Requires Authentication Key"
}
[/block]
## Header Parameters
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-2": "<span class=\"label-all label-required\">Required</span> The app ID that you want to export devices from",
    "0-0": "`app_id`",
    "0-1": "String"
  },
  "cols": 3,
  "rows": 1
}
[/block]
## Body Parameters
[block:parameters]
{
  "data": {
    "0-0": "`extra_fields`",
    "0-1": "Array of Strings",
    "0-2": "<span class=\"label-ios\">iOS</span> <span class=\"label-android\">Android</span>\nAdditional fields that you wish to include. Currently supports `location`, `country`, and `rooted`."
  },
  "cols": 3,
  "rows": 1
}
[/block]
## Example Code
[block:code]
{
  "codes": [
    {
      "code": "curl --include \\\n     --request POST \\\n     --header \"Content-Type: application/json\" \\\n     --header \"Authorization: Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\" \\\n     --data-binary \"{\\\"extra_fields\\\" : [\\\"location\\\",\\\"rooted\\\"]}\" \\\n     https://onesignal.com/api/v1/players/csv_export?app_id={appId}",
      "language": "curl"
    }
  ]
}
[/block]
## Result Format
[block:code]
{
  "codes": [
    {
      "code": "{ \"csv_file_url\": \"https://onesignal.com/csv_exports/b2f7f966-d8cc-11e4-bed1-df8f05be55ba/users_184948440ec0e334728e87228011ff41_2015-11-10.csv.gz\" }",
      "language": "json",
      "name": "200 OK"
    },
    {
      "code": "{}",
      "language": "json",
      "name": "400 Bad Request"
    }
  ]
}
[/block]
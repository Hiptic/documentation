---
title: "Edit device"
excerpt: "Update an existing device in one of your OneSignal apps"
---
## Path Parameters
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`id`",
    "0-1": "String",
    "0-2": "<span class=\"label-all label-required\">Required</span> The device's OneSignal ID"
  },
  "cols": 3,
  "rows": 1
}
[/block]
## Body Parameters
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`app_id`",
    "0-2": "<span class=\"label-all label-required\">Required</span> Your OneSignal App Id found in <a class=\"dash-link\" href=\"/docs/accounts-and-keys#section-keys-ids\">Keys & IDs</a>",
    "0-1": "String",
    "2-0": "`identifier`",
    "2-2": "Push notification identifier from Google or Apple. For Apple push identifiers, you must strip all non alphanumeric characters. Example: `ce777617da7f548fe7a9ab6febb56`",
    "3-2": "Language code. Typically lower case two letters, except for Chinese where it must be one of `zh-Hans` or `zh-Hant`. Example: `en`",
    "4-2": "Number of seconds away from UTC. Example: `-28800`",
    "5-2": "Version of your app. Example: `1.1`",
    "8-2": "The ad id for the device's platform:\nAndroid = `Advertising Id`\niOS = `identifierForVendor`\nWP8.0 = `DeviceUniqueId`\nWP8.1 = `AdvertisingId`",
    "7-2": "Device operating system version. Example: `7.0.4`",
    "6-2": "Device make and model. Example: `iPhone5,1`",
    "3-0": "`language`",
    "4-0": "`timezone`",
    "4-1": "Int",
    "3-1": "String",
    "2-1": "String",
    "5-0": "`game_version`",
    "5-1": "String",
    "6-0": "`device_model`",
    "6-1": "String",
    "7-1": "String",
    "7-0": "`device_os`",
    "8-0": "`ad_id`",
    "8-1": "String",
    "9-0": "`sdk`",
    "9-1": "String",
    "9-2": "Name and version of the sdk/plugin that's calling this API method (if any)",
    "10-0": "`session_count`",
    "11-0": "`tags`",
    "11-1": "Hash",
    "12-0": "`amount_spent`",
    "12-1": "String",
    "13-0": "`created_at`",
    "13-1": "Int",
    "14-0": "`playtime`",
    "14-1": "Int",
    "15-0": "`badge_count`",
    "15-1": "Int",
    "16-0": "`last_active`",
    "16-1": "Int",
    "18-0": "`test_type`",
    "18-1": "Int",
    "10-1": "Int",
    "10-2": "Number of times the user has played the game, defaults to 1",
    "11-2": "Custom tags for the player. Only support string key value pairs. Does not support arrays or other nested objects. Example: `{\"foo\":\"bar\",\"this\":\"that\"}`",
    "12-2": "Amount the user has spent in USD, up to two decimal places",
    "13-2": "Unixtime when the player joined the game",
    "14-2": "Seconds player was running your app.",
    "15-2": "Current iOS badge count displayed on the app icon",
    "16-2": "Unixtime when the player was last active",
    "18-2": "This is used in deciding whether to use your iOS Sandbox or Production push certificate when sending a push when both have been uploaded. Set to the iOS provisioning profile that was used to build your app. \n`1` = Development\n`2` = Ad-Hoc\nOmit this field for App Store builds.",
    "19-0": "`long`",
    "19-1": "Double",
    "19-2": "Longitude of the device, used for geotagging to segment on.",
    "20-0": "`lat`",
    "20-1": "Double",
    "20-2": "Latitude of the device, used for geotagging to segment on.",
    "1-0": "`device_type`",
    "1-1": "Int",
    "1-2": "The device's platform:\n`0` = iOS\n`1` = Android\n`2` = Amazon\n`3` = WindowsPhone(MPNS)\n`4` = Chrome Apps / Extensions\n`5` = Chrome Web Push\n`6` = WindowsPhone(WNS)\n`7` = Safari\n`8` = Firefox\n`9` = MacOS",
    "17-0": "`notification_types`",
    "17-1": "String",
    "17-2": "`1` = subscribed\n`-2` = unsubscribed\n\niOS - These values are set each time the user opens the app from the SDK. Use the SDK function set Subscription instead.\n\nAndroid - You may set this but you can no longer use the SDK method setSubscription later in your app as it will create synchronization issues."
  },
  "cols": 3,
  "rows": 21
}
[/block]

[block:callout]
{
  "type": "info",
  "title": "Deleting Tags",
  "body": "To delete a tag, *include* its key and *set its value to blank*. Omitting a key/value will not delete it.\n\nFor example, if I wanted to delete two existing tanks `rank` and `category` while simultaneously adding a new tag `class`, the `tags` JSON would look like the following:\n\n```\n\"tags\": {\n           \"rank\": \"\",\n           \"category\": \"\",\n           \"class\": \"my_new_value\"\n        }\n```"
}
[/block]

## Example Code
[block:code]
{
  "codes": [
    {
      "code": "curl --include \\\n     --request PUT \\\n     --header \"Content-Type: application/json\" \\\n     --data-binary \"{\\\"app_id\\\" : \\\"xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx\\\",\n\\\"language\\\":\\\"es\\\",\n\\\"timezone\\\":-28800,\n\\\"game_version\\\":\\\"1.0\\\",\n\\\"device_os\\\":\\\"7.0.4\\\",\n\\\"device_type\\\":0,\n\\\"device_model\\\":\\\"iPhone\\\",\n\\\"tags\\\":{\\\"a\\\":\\\"1\\\",\\\"foo\\\":\\\"\\\"}}\" \\\n     https://onesignal.com/api/v1/players/:id",
      "language": "shell"
    },
    {
      "code": "<?PHP\n$playerID = '8dee0e23-410d-4a9a-b8ce-bfe4c5257ccc';\n$fields = array( \n'app_id' => '02b297e7-abb5-4e7e-9c2a-9ce7e2c82ff5', \n'tags' => array('OneSignal_Example_Tag' => 'YES')\n); \n$fields = json_encode($fields); \n\n$ch = curl_init(); \ncurl_setopt($ch, CURLOPT_URL, 'https://onesignal.com/api/v1/players/'.$playerID); \ncurl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json')); \ncurl_setopt($ch, CURLOPT_RETURNTRANSFER, true); \ncurl_setopt($ch, CURLOPT_HEADER, false); \ncurl_setopt($ch, CURLOPT_CUSTOMREQUEST, \"PUT\");\ncurl_setopt($ch, CURLOPT_POSTFIELDS, $fields); \ncurl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); \n$response = curl_exec($ch); \ncurl_close($ch); \n\n$resultData = json_decode($response, true);\necho $resultData;\n?>",
      "language": "php"
    }
  ]
}
[/block]
## Result Format
[block:code]
{
  "codes": [
    {
      "code": "{\"success\": true }",
      "language": "javascript",
      "name": "200 OK"
    }
  ]
}
[/block]
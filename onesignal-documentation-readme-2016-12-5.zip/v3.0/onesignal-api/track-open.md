---
title: "Track open"
excerpt: "Track when users open a notification"
---
## Path Parameters
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`id`",
    "0-1": "String",
    "0-2": "<span class=\"label-all label-required\">Required</span> Notification id"
  },
  "cols": 3,
  "rows": 1
}
[/block]
## Body Parameters
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`app_id`",
    "0-1": "String",
    "0-2": "<span class=\"label-all label-required\">Required</span> OneSignal app id, available in <a class=\"dash-link\" href=\"/docs/accounts-and-keys#section-keys-ids\">Keys & IDs</a>",
    "1-0": "`opened`",
    "1-1": "boolean",
    "1-2": "<span class=\"label-all label-required\">Required</span> Set to `true`"
  },
  "cols": 3,
  "rows": 2
}
[/block]
## Example Code
[block:code]
{
  "codes": [
    {
      "code": "curl --include \\\n     --request PUT \\\n     --header \"Content-Type: application/json\" \\\n     --data-binary \"{\\\"opened\\\":true, \\\"app_id\\\":\"YOUR APP ID\"}\" \\\n     https://onesignal.com/api/v1/notifications/{notificationId}",
      "language": "curl"
    }
  ]
}
[/block]
## Result Format
[block:code]
{
  "codes": [
    {
      "code": "{\"success\": true}",
      "language": "json",
      "name": "200 OK"
    },
    {
      "code": "{}",
      "language": "json",
      "name": "400 Bad Request"
    }
  ]
}
[/block]
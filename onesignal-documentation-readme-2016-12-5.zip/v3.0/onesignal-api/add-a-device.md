---
title: "Add a device"
excerpt: "Register a new device to one of your OneSignal apps"
---
This method is used to register a new device with OneSignal.

If a device is already registered with the specified identifier, then this will update the existing device record instead of creating a new one.

The returned player is a player / user ID. Use the returned ID to send push notifications to this specific user later, or to include this player when sending to a set of users.

## Body Parameters
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`app_id`",
    "0-2": "<span class=\"label-all label-required\">Required</span> Your OneSignal App Id found in <a class=\"dash-link\" href=\"/docs/accounts-and-keys#section-keys-ids\">Keys & IDs</a>",
    "0-1": "String",
    "1-0": "`device_type`",
    "1-1": "Int",
    "1-2": "<span class=\"label-all label-required\">Required</span> The device's platform:\n`0` = <span class=\"label-all label-ios\">iOS</span>\n`1` = <span class=\"label-all label-android\">Android</span>\n`2` = <span class=\"label-all label-amazon\">Amazon</span>\n`3` = <span class=\"label-all label-windows\">WindowsPhone</span> (MPNS)\n`4` = <span class=\"label-all\">Chrome Apps / Extensions</span>\n`5` = <span class=\"label-all label-chrome\">Chrome Web Push</span>\n`6` = <span class=\"label-all label-windows\">WindowsPhone</span> (WNS)\n`7` = <span class=\"label-all label-safari\">Safari</span> \n`8` = <span class=\"label-all label-firefox\">Firefox</span> \n`9` = <span class=\"label-all\">MacOS</span>",
    "2-0": "`identifier`",
    "2-2": "<span class=\"label-all label-recommended\">Recommended</span> Push notification identifier from Google or Apple. For Apple push identifiers, you must strip all non alphanumeric characters. Example: `ce777617da7f548fe7a9ab6febb56`",
    "3-2": "<span class=\"label-all label-recommended\">Recommended</span> Language code. Typically lower case two letters, except for Chinese where it must be one of `zh-Hans` or `zh-Hant`. Example: `en`",
    "4-2": "<span class=\"label-all label-recommended\">Recommended</span> Number of seconds away from UTC. Example: `-28800`",
    "5-2": "<span class=\"label-all label-recommended\">Recommended</span> Version of your app. Example: `1.1`",
    "8-2": "<span class=\"label-all label-recommended\">Recommended</span> The ad id for the device's platform:\n<span class=\"label-all label-android\">Android</span> = `Advertising Id`\n<span class=\"label-all label-ios\">iOS</span> = `identifierForVendor`\n<span class=\"label-all label-windows\">WP8.0</span> = `DeviceUniqueId`\n<span class=\"label-all label-windows\">WP8.1</span> = `AdvertisingId`",
    "7-2": "<span class=\"label-all label-recommended\">Recommended</span> Device operating system version. Example: `7.0.4`",
    "6-2": "<span class=\"label-all label-recommended\">Recommended</span> Device make and model. Example: `iPhone5,1`",
    "3-0": "`language`",
    "4-0": "`timezone`",
    "4-1": "Int",
    "3-1": "String",
    "2-1": "String",
    "5-0": "`game_version`",
    "5-1": "String",
    "6-0": "`device_model`",
    "6-1": "String",
    "7-1": "String",
    "7-0": "`device_os`",
    "8-0": "`ad_id`",
    "8-1": "String",
    "9-0": "`sdk`",
    "9-1": "String",
    "9-2": "<span class=\"label-all label-recommended\">Recommended</span> Name and version of the plugin that's calling this API method (if any)",
    "10-0": "`session_count`",
    "11-0": "`tags`",
    "11-1": "Hash",
    "12-0": "`amount_spent`",
    "12-1": "String",
    "13-0": "`created_at`",
    "13-1": "Int",
    "14-0": "`playtime`",
    "14-1": "Int",
    "15-0": "`badge_count`",
    "15-1": "Int",
    "16-0": "`last_active`",
    "16-1": "Int",
    "18-0": "`test_type`",
    "18-1": "Int",
    "10-1": "Int",
    "10-2": "Number of times the user has played the game, defaults to 1",
    "11-2": "Custom tags for the player. Only support string key value pairs. Does not support arrays or other nested objects. Example: `{\"foo\":\"bar\",\"this\":\"that\"}`",
    "12-2": "Amount the user has spent in USD, up to two decimal places",
    "13-2": "Unixtime when the player joined the game",
    "14-2": "Seconds player was running your app.",
    "15-2": "Current iOS badge count displayed on the app icon",
    "16-2": "Unixtime when the player was last active",
    "18-2": "This is used in deciding whether to use your iOS Sandbox or Production push certificate when sending a push when both have been uploaded. Set to the iOS provisioning profile that was used to build your app.\n`1` = Development\n`2` = Ad-Hoc\nOmit this field for App Store builds.",
    "20-0": "`lat`",
    "19-0": "`long`",
    "19-2": "Longitude of the device, used for geotagging to segment on.",
    "20-2": "Latitude of the device, used for geotagging to segment on.",
    "19-1": "Double",
    "20-1": "Double",
    "17-0": "`notification_types`",
    "17-1": "String",
    "17-2": "`1` = subscribed\n`-2` = unsubscribed\n\n<span class=\"label-all label-ios\">iOS</span> - These values are set each time the user opens the app from the SDK. Use the SDK function set Subscription instead.\n\n<span class=\"label-all label-android\">Android</span> - You may set this but you can no longer use the SDK method setSubscription later in your app as it will create synchronization issues."
  },
  "cols": 3,
  "rows": 21
}
[/block]
## Example Code
[block:code]
{
  "codes": [
    {
      "code": "curl --include \\\n     --request POST \\\n     --header \"Content-Type: application/json\" \\\n     --data-binary \"{\\\"app_id\\\" : \\\"xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx\\\",\n\\\"identifier\\\":\\\"ce777617da7f548fe7a9ab6febb56cf39fba6d382000c0395666288d961ee566\\\",\n\\\"language\\\":\\\"en\\\",\n\\\"timezone\\\":-28800,\n\\\"game_version\\\":\\\"1.0\\\",\n\\\"device_os\\\":\\\"7.0.4\\\",\n\\\"device_type\\\":0,\n\\\"device_model\\\":\\\"iPhone 8,2\\\",\n\\\"tags\\\":{\\\"a\\\":\\\"1\\\",\\\"foo\\\":\\\"bar\\\"}}\" \\\n     https://onesignal.com/api/v1/players",
      "language": "shell"
    },
    {
      "code": "<?PHP\n$fields = array( \n'app_id' => \"xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx\", \n'identifier' => \"ce777617da7f548fe7a9ab6febb56cf39fba6d382000c0395666288d961ee566\", \n'language' => \"en\", \n'timezone' => \"-28800\", \n'game_version' => \"1.0\", \n'device_os' => \"9.1.3\", \n'device_type' => \"0\", \n'device_model' => \"iPhone 8,2\", \n'tags' => array(\"foo\" => \"bar\") \n); \n\n$fields = json_encode($fields); \nprint(\"\\nJSON sent:\\n\"); \nprint($fields); \n\n$ch = curl_init(); \ncurl_setopt($ch, CURLOPT_URL, \"https://onesignal.com/api/v1/players\"); \ncurl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json')); \ncurl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE); \ncurl_setopt($ch, CURLOPT_HEADER, FALSE); \ncurl_setopt($ch, CURLOPT_POST, TRUE); \ncurl_setopt($ch, CURLOPT_POSTFIELDS, $fields); \ncurl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE); \n\n$response = curl_exec($ch); \ncurl_close($ch); \n\n$return[\"allresponses\"] = $response; \n$return = json_encode( $return); \n\nprint(\"\\n\\nJSON received:\\n\"); \nprint($return); \nprint(\"\\n\");\n\n?>",
      "language": "php"
    }
  ]
}
[/block]
## Result Format
[block:code]
{
  "codes": [
    {
      "code": "{\"success\": true, \"id\": \"ffffb794-ba37-11e3-8077-031d62f86ebf\" }",
      "language": "javascript",
      "name": "200 OK"
    }
  ]
}
[/block]
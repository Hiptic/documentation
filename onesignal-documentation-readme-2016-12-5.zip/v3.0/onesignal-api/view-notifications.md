---
title: "View notifications"
excerpt: "View the details of multiple notifications"
---
[block:callout]
{
  "type": "warning",
  "title": "Requires Authentication Key",
  "body": "Requires your OneSignal App Auth Key, available in <a class=\"dash-link\" href=\"/docs/accounts-and-keys#section-keys-ids\">Keys & IDs</a>."
}
[/block]
## Path Parameters
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Description",
    "0-0": "`app_id`",
    "0-1": "String",
    "1-0": "`limit`",
    "1-1": "String",
    "2-0": "`offset`",
    "2-1": "String",
    "0-2": "<span class=\"label-all label-required\">Required</span> The app ID that you want to view notifications from",
    "1-2": "How many notifications to return. Max is 50. Default is 50",
    "2-2": "Result offset. Default is 0. Results are sorted by queued_at in descending order. queued_at is the unixtime representation of the time that the notification was queued."
  },
  "cols": 3,
  "rows": 3
}
[/block]
## Example Code
[block:code]
{
  "codes": [
    {
      "code": "curl --include \\\n     --header \"Authorization: Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\" \\\n     https://onesignal.com/api/v1/notifications?app_id={appId}",
      "language": "curl"
    },
    {
      "code": "<?PHP\n$curl = curl_init();\n\ncurl_setopt_array($curl, array(\n  CURLOPT_URL => \"https://onesignal.com/api/v1/notifications?app_id=3cb5beaa-e6ca-5932-aad9-fdabaa3b83ce&limit=50&offset=0\",\n  CURLOPT_RETURNTRANSFER => true,\n  CURLOPT_ENCODING => \"\",\n  CURLOPT_MAXREDIRS => 10,\n  CURLOPT_TIMEOUT => 30,\n  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,\n  CURLOPT_CUSTOMREQUEST => \"GET\",\n  CURLOPT_HTTPHEADER => array(\n    \"authorization: Basic ONESIGNAL_APP_REST_API_KEY_HERE\",\n  ),\n));\n\n$response = curl_exec($curl);\n$err = curl_error($curl);\n\ncurl_close($curl);\n\necho $response;\n?>",
      "language": "php"
    }
  ]
}
[/block]
## Result Format
[block:code]
{
  "codes": [
    {
      "code": "{\n \"total_count\":3,\n \"offset\":2,\n \"limit\":2,\n \"notifications\":\n [\n   {\n    \"id\":\"481a2734-6b7d-11e4-a6ea-4b53294fa671\",\n    \"successful\":15,\n    \"failed\":1,\n    \"converted\":3,\n    \"remaining\":0,\n    \"queued_at\":1415914655,\n    \"send_after\":1415914655,\n    \"canceled\": false,\n    \"url\": \"https://yourWebsiteToOpen.com\",\n    \"data\":null,\n\t\t\"headings\":{\n      \"en\":\"English and default langauge heading\",\n      \"es\":\"Spanish language heading\"\n    },     \n    \"contents\":{\n      \"en\":\"English and default content\",\n      \"es\":\"Hola\"\n    }\n   },\n   {\n    \"id\":\"b6b326a8-40aa-13e5-b91b-bf8bc3fa26f7\",\n    \"successful\":5,\n    \"failed\":2,\n    \"converted\":0,\n    \"remaining\":0,\n    \"queued_at\":1415915123,\n    \"send_after\":1415915123,\n    \"canceled\": false,\n    \"url\": nil,\n    \"data\":{\n      \"foo\":\"bar\",\n      \"your\":\"custom metadata\"\n    },\n    \"headings\":{\n      \"en\":\"English and default langauge heading\",\n      \"es\":\"Spanish language heading\"\n    },\n    \"contents\":{\n      \"en\":\"English and default content\",\n      \"es\":\"Hola\"\n    }\n   }\n ]\n}",
      "language": "json",
      "name": "200 OK"
    }
  ]
}
[/block]
---
title: "Create Notification (OLD)"
excerpt: "<div class=\"tag-all tag-developers\">For Developers</div>"
---
The Create Notification method is used when you want your app to programmatically send notifications to your users. You may target users in one of three ways using this method: by **Segment**, by **Filter**, or by **Device**. At least one targeting parameter must be specified. 
[block:callout]
{
  "type": "warning",
  "title": "You may only use one method of targeting users",
  "body": "If a targeting parameter of one type is used, then targeting parameters from other types may not be used. For instance, you cannot use the `included_segments` parameter (from segments) with the `include_ios_tokens` (from specific devices)."
}
[/block]
## Send to Segments
[Segments](doc:segmentation) are the most common way developers send notifications via OneSignal. Sending to segments is easy: you simply specify which segments you want to send to, and, optionally, which ones you don't. 

Tip: If you want to send to all your users, just send to the `All Users` segment, which is available in every app you create in OneSignal. 
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Description",
    "0-0": "`included_segments`",
    "1-0": "`excluded_segments`",
    "1-1": "_(Optional)_ Segment that will be excluded when sending. Requires usage of `included_segments`.",
    "0-1": "_(Required)_ The segment you want to target"
  },
  "cols": 2,
  "rows": 2
}
[/block]
#### Example Code
[block:code]
{
  "codes": [
    {
      "code": "curl - -include \\\n     - -request POST \\\n     - -header \"Content-Type: application/json\" \\\n     - -header \"Authorization: Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\" \\\n     - -data-binary \"{\\\"app_id\\\": \\\"5eb5a37e-b458-11e3-ac11-000c2940e62c\\\",\n\\\"contents\\\": {\\\"en\\\": \\\"English Message\\\"},\n\\\"included_segments\\\": [\\\"All\\\"]}\" \\\n     https://onesignal.com/api/v1/notifications",
      "language": "shell"
    },
    {
      "code": "{\n  \"app_id\": \"5eb5a37e-b458-11e3-ac11-000c2940e62c\",\n  \"included_segments\": [\"All\"],\n  \"data\": {\"foo\": \"bar\"},\n  \"contents\": {\"en\": \"English Message\"}\n}",
      "language": "json"
    },
    {
      "code": "<?PHP\n\tfunction sendMessage(){\n\t\t$content = array(\n\t\t\t\"en\" => 'English Message'\n\t\t\t);\n\t\t\n\t\t$fields = array(\n\t\t\t'app_id' => \"5eb5a37e-b458-11e3-ac11-000c2940e62c\",\n\t\t\t'included_segments' => array('All'),\n      'data' => array(\"foo\" => \"bar\"),\n\t\t\t'contents' => $content\n\t\t);\n\t\t\n\t\t$fields = json_encode($fields);\n    print(\"\\nJSON sent:\\n\");\n    print($fields);\n\t\t\n\t\t$ch = curl_init();\n\t\tcurl_setopt($ch, CURLOPT_URL, \"https://onesignal.com/api/v1/notifications\");\n\t\tcurl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json',\n\t\t\t\t\t\t\t\t\t\t\t\t   'Authorization: Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj'));\n\t\tcurl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);\n\t\tcurl_setopt($ch, CURLOPT_HEADER, FALSE);\n\t\tcurl_setopt($ch, CURLOPT_POST, TRUE);\n\t\tcurl_setopt($ch, CURLOPT_POSTFIELDS, $fields);\n\t\tcurl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);\n\n\t\t$response = curl_exec($ch);\n\t\tcurl_close($ch);\n\t\t\n\t\treturn $response;\n\t}\n\t\n\t$response = sendMessage();\n\t$return[\"allresponses\"] = $response;\n\t$return = json_encode( $return);\n\t\n  print(\"\\n\\nJSON received:\\n\");\n\tprint($return);\n  print(\"\\n\");\n?>",
      "language": "csharp",
      "name": "PHP"
    },
    {
      "code": "using System.IO;\nusing System.Net;\nusing System.Text;\n\nvar request = WebRequest.Create(\"https://onesignal.com/api/v1/notifications\") as HttpWebRequest;\n\nrequest.KeepAlive = true;\nrequest.Method = \"POST\";\nrequest.ContentType = \"application/json\";\n\nrequest.Headers.Add(\"authorization\", \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\");\n\nbyte[] byteArray = Encoding.UTF8.GetBytes(\"{\"\n                                        + \"\\\"app_id\\\": \\\"5eb5a37e-b458-11e3-ac11-000c2940e62c\\\",\"\n                                        + \"\\\"contents\\\": {\\\"en\\\": \\\"English Message\\\"},\"\n                                        + \"\\\"included_segments\\\": [\\\"All\\\"]}\");\n\nstring responseContent = null;\n\ntry {\n    using (var writer = request.GetRequestStream()) {\n        writer.Write(byteArray, 0, byteArray.Length);\n    }\n\n    using (var response = request.GetResponse() as HttpWebResponse) {\n        using (var reader = new StreamReader(response.GetResponseStream())) {\n            responseContent = reader.ReadToEnd();\n        }\n    }\n}\ncatch (WebException ex) {\n    System.Diagnostics.Debug.WriteLine(ex.Message);\n    System.Diagnostics.Debug.WriteLine(new StreamReader(ex.Response.GetResponseStream()).ReadToEnd());\n}\n\nSystem.Diagnostics.Debug.WriteLine(responseContent);",
      "language": "csharp",
      "name": "C# (.NET standard)"
    },
    {
      "code": "using System.IO;\nusing System.Net;\nusing System.Text;\n\nvar request = WebRequest.Create(\"https://onesignal.com/api/v1/notifications\") as HttpWebRequest;\n\nrequest.KeepAlive = true;\nrequest.Method = \"POST\";\nrequest.ContentType = \"application/json\";\n\nrequest.Headers.Add(\"authorization\", \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\");\n\nvar serializer = new JavaScriptSerializer();\nvar obj = new { app_id = \"5eb5a37e-b458-11e3-ac11-000c2940e62c\",\n               contents = new { en = \"English Message\" },\n               included_segments = new string[] {\"All\"} };\nvar param = serializer.Serialize(obj);\nbyte[] byteArray = Encoding.UTF8.GetBytes(param);\n\nstring responseContent = null;\n\ntry {\n    using (var writer = request.GetRequestStream()) {\n        writer.Write(byteArray, 0, byteArray.Length);\n    }\n\n    using (var response = request.GetResponse() as HttpWebResponse) {\n        using (var reader = new StreamReader(response.GetResponseStream())) {\n            responseContent = reader.ReadToEnd();\n        }\n    }\n}\ncatch (WebException ex) {\n    System.Diagnostics.Debug.WriteLine(ex.Message);\n    System.Diagnostics.Debug.WriteLine(new StreamReader(ex.Response.GetResponseStream()).ReadToEnd());\n}\n\nSystem.Diagnostics.Debug.WriteLine(responseContent);",
      "language": "csharp",
      "name": "C# (ASP.NET)"
    },
    {
      "code": "params = {\"app_id\" => \"5eb5a37e-b458-11e3-ac11-000c2940e62c\", \n          \"contents\" => {\"en\" => \"English Message\"},\n  \t\t\t\t\"included_segments\" => [\"All\"]}\nuri = URI.parse('https://onesignal.com/api/v1/notifications')\nhttp = Net::HTTP.new(uri.host, uri.port)\nhttp.use_ssl = true\n\nrequest = Net::HTTP::Post.new(uri.path,\n                              'Content-Type'  => 'application/json',\n                              'Authorization' => \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\")\nrequest.body = params.as_json.to_json\nresponse = http.request(request) \nputs response.body",
      "language": "ruby",
      "name": "Ruby (Rails)"
    },
    {
      "code": "import requests\nimport json\n\nheader = {\"Content-Type\": \"application/json\",\n          \"Authorization\": \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\"}\n\npayload = {\"app_id\": \"5eb5a37e-b458-11e3-ac11-000c2940e62c\",\n           \"included_segments\": [\"All\"],\n           \"contents\": {\"en\": \"English Message\"}}\n \nreq = requests.post(\"https://onesignal.com/api/v1/notifications\", headers=header, data=json.dumps(payload))\n \nprint(req.status_code, req.reason)",
      "language": "python",
      "name": null
    },
    {
      "code": "var sendNotification = function(data) {\n  var headers = {\n    \"Content-Type\": \"application/json\",\n    \"Authorization\": \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\"\n  };\n  \n  var options = {\n    host: \"onesignal.com\",\n    port: 443,\n    path: \"/api/v1/notifications\",\n    method: \"POST\",\n    headers: headers\n  };\n  \n  var https = require('https');\n  var req = https.request(options, function(res) {  \n    res.on('data', function(data) {\n      console.log(\"Response:\");\n      console.log(JSON.parse(data));\n    });\n  });\n  \n  req.on('error', function(e) {\n    console.log(\"ERROR:\");\n    console.log(e);\n  });\n  \n  req.write(JSON.stringify(data));\n  req.end();\n};\n\nvar message = { \n  app_id: \"5eb5a37e-b458-11e3-ac11-000c2940e62c\",\n  contents: {\"en\": \"English Message\"},\n  included_segments: [\"All\"]\n};\n\nsendNotification(message);",
      "language": "javascript",
      "name": "NodeJS"
    },
    {
      "code": "#!/usr/bin/perl -w\n \nuse strict;\nuse warnings;\nuse Net::Curl::Easy qw(/^CURLOPT_.*/);;\nuse JSON;\nuse Data::Dumper;\n \nsub SendNotification\n{\n    my ($url , $authorisation , $app_id , $contents) = @_;\n    my $curl = Net::Curl::Easy->new;\n    my $json = JSON->new();\n    my $response_body;\n \n    my $json_string = $json->encode({ app_id => $app_id ,\n                                      included_segments => [\"All\"] ,\n                                      data => { \"key1\" => \"Value 1\" } ,\n                                      ios_badgeType => \"Increase\" ,\n                                      ios_badgeCount => 1 ,\n                                      contents => { en => $contents}\n                                    });\n \n    $curl->setopt( CURLOPT_URL, $url);\n    $curl->setopt( CURLOPT_SSL_VERIFYHOST , 0);\n    $curl->setopt( CURLOPT_SSL_VERIFYPEER , 0);\n \n    $curl->setopt( CURLOPT_HTTPHEADER, ['Content-Type: application/json' ,\n                                        \"Authorization: Basic $authorisation\"]);\n    $curl->setopt( CURLOPT_POST , 1);\n    $curl->setopt( CURLOPT_POSTFIELDS , $json_string);\n \n    $curl->setopt( CURLOPT_WRITEDATA , \\$response_body);\n \n    $curl->perform;\n    print Dumper($response_body);\n}\n \nSendNotification(\"https://onesignal.com/api/v1/notifications\" ,\n                 \"<< PUT YOUR REST API KEY HERE>>\" ,\n                 \"<< PUT YOUR APP ID KEY HERE >>\" ,\n                 \"Hello World\");\n \nexit(0);",
      "language": "perl"
    },
    {
      "code": "send = function(params) {\n\nvar promise = new Parse.Promise();\n\nvar jsonBody = { \n  app_id: \"5eb5a37e-b458-11e3-ac11-000c2940e62c\", \n  included_segments: [\"All\"],\n  contents: {en: \"English Message\"},\n  data: {foo: \"bar\"}\n};\n\nParse.Cloud.httpRequest({\n    method: \"POST\",\n    url: \"https://onesignal.com/api/v1/notifications\",\n    headers: {\n      \"Content-Type\": \"application/json;charset=utf-8\",\n      \"Authorization\": \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\"\n    },\n    body: JSON.stringify(jsonBody)\n  }).then(function (httpResponse) {\n    promise.resolve(httpResponse)\n  },\n  function (httpResponse) {\n    promise.reject(httpResponse);\n});\n\nreturn promise;\n};\n\nexports.send = send;",
      "language": "javascript",
      "name": "Parse Cloud"
    },
    {
      "code": "function SendNewNotification() {\n\n  var jsonBody = {\n\n    app_id: \"5eb5a37e-b458-11e3-ac11-000c2940e62c\",\n\n    included_segments: [\"All\"],\n\n    contents: {en: \"English Message\"},\n\n  };\n\n  var promise = Spark.getHttp(\"https://onesignal.com/api/v1/notifications\").setHeaders({\n\n    \"Content-Type\": \"application/json;charset=utf-8\",\n\n    \"Authorization\": \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\"\n\n  }).postJson(jsonBody);\n  \n\n  return promise;\n\n}\n\nvar response = SendNewNotification().getResponseJson();\n\nSpark.setScriptData(\"response\", response)",
      "language": "javascript",
      "name": "GameSparks"
    },
    {
      "code": "try {\n   String jsonResponse;\n   \n   URL url = new URL(\"https://onesignal.com/api/v1/notifications\");\n   HttpURLConnection con = (HttpURLConnection)url.openConnection();\n   con.setUseCaches(false);\n   con.setDoOutput(true);\n   con.setDoInput(true);\n\n   con.setRequestProperty(\"Content-Type\", \"application/json; charset=UTF-8\");\n   con.setRequestProperty(\"Authorization\", \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\");\n   con.setRequestMethod(\"POST\");\n\n   String strJsonBody = \"{\"\n                      +   \"\\\"app_id\\\": \\\"5eb5a37e-b458-11e3-ac11-000c2940e62c\\\",\"\n                      +   \"\\\"included_segments\\\": [\\\"All\\\"],\"\n                      +   \"\\\"data\\\": {\\\"foo\\\": \\\"bar\\\"},\"\n                      +   \"\\\"contents\\\": {\\\"en\\\": \\\"English Message\\\"}\"\n                      + \"}\";\n         \n   \n   System.out.println(\"strJsonBody:\\n\" + strJsonBody);\n\n   byte[] sendBytes = strJsonBody.getBytes(\"UTF-8\");\n   con.setFixedLengthStreamingMode(sendBytes.length);\n\n   OutputStream outputStream = con.getOutputStream();\n   outputStream.write(sendBytes);\n\n   int httpResponse = con.getResponseCode();\n   System.out.println(\"httpResponse: \" + httpResponse);\n\n   if (  httpResponse >= HttpURLConnection.HTTP_OK\n      && httpResponse < HttpURLConnection.HTTP_BAD_REQUEST) {\n      Scanner scanner = new Scanner(con.getInputStream(), \"UTF-8\");\n      jsonResponse = scanner.useDelimiter(\"\\\\A\").hasNext() ? scanner.next() : \"\";\n      scanner.close();\n   }\n   else {\n      Scanner scanner = new Scanner(con.getErrorStream(), \"UTF-8\");\n      jsonResponse = scanner.useDelimiter(\"\\\\A\").hasNext() ? scanner.next() : \"\";\n      scanner.close();\n   }\n   System.out.println(\"jsonResponse:\\n\" + jsonResponse);\n   \n} catch(Throwable t) {\n   t.printStackTrace();\n}",
      "language": "java"
    }
  ]
}
[/block]



## Send to Users Based on Filters
[Filters](doc:filters) are a powerful way to target users, allowing you to use both data that OneSignal has about a user and any [Tags](doc:tags) your app may send OneSignal. Filters can be combined together to form advanced, highly precise user targeting. OneSignal customers use all sorts of filters to send notifications, including language, location, user activity, and more.

The `filters` parameter targets notification recipients using an array of JSON objects containing field conditions to check. The following are filter field options:
[block:parameters]
{
  "data": {
    "h-0": "Option",
    "h-1": "Description",
    "0-0": "last_session",
    "0-1": "`relation` = `\">\"` or `\"<\"`\n`hours_ago` = number of hours before or after the users last session. Example: `\"1.1\"`",
    "1-0": "first_session",
    "1-1": "`relation` = `\">\"` or `\"<\"`\n`hours_ago` = number of hours before or after the users first session. Example: `\"1.1\"`",
    "2-0": "session_count",
    "2-1": "`relation` = `\">\"`, `\"<\"`, `\"=\"`, or `\" !=\"`\n`value` = number sessions. Example: `\" 1\"`",
    "3-0": "session_time",
    "3-1": "`relation` = `\">\"` or `\"<\"`. \n`value` = Time in seconds the user has been in your app. Example: `\"3600\"`",
    "4-0": "amount_spent",
    "4-1": "`relation` = `\">\"`, `\"<\"`, or `\"=\"`\n`value` = Amount in USD a user has spent on IAP (In App Purchases). Example: `\"0.99\"`",
    "5-0": "bought_sku",
    "5-1": "`relation` = `\">\"`, `\"<\"`, or `\"=\"`\n`key` = SKU purchased in your app as an IAP (In App Purchases). Example: `\"com.domain.100coinpack\"`\n`value` = value of SKU to compare to. Example: `\"0.99\"`",
    "6-0": "tag",
    "6-1": "`relation` = `\">\"`, `\"<\"`, `\"=\"`, `\"!=\"`\n`key` = Tag key to compare.\n`value` = Tag value to compare. Example: See tag example below",
    "7-0": "language",
    "7-1": "`relation` = `\"=\"`, `\"!=\"`. \n`value` = 2 character language code. Example: `\"en\"`. For a list of all language codes [go here](doc:language-localization)",
    "8-0": "app_version",
    "8-1": "`relation` = `\">\"`, `\"<\"`, `\"=\"`, `\"!=\"`\n`value` = app version. Example: `\"1.0.0\"`",
    "9-0": "location",
    "9-1": "`radius` = in meters\n`lat` = latitude\n`long` = longitude",
    "10-0": "email",
    "10-1": "`value` = email address"
  },
  "cols": 2,
  "rows": 11
}
[/block]
#### Filter Usage
- Your REST API key is required for authentication. It can be found in <a class="dash-link">Keys & IDs</a>.
- Filter entires use `AND` by default; insert `{"operator ": "OR"}` between entries to `OR` the parameters together.
- For performance reasons, a *maximum of 200 entries* can be used at a time. 
- This filter targeting parameter cannot be combined with any other targeting parameters.

#### Filter Usage Examples
The power of filters comes from combining several fields and operators to precisely target your users. Here are three examples:

1. A user *is* level 10 *and* purchased an item:
`[{"field ": "tag ", "key ": "level ", "relation ": ">", "value": "10"}, {"field": "amount_spent", "relation": ">","value": "0"}]`

2. A user *is* level 10 *or* 20:
`[{"field": "tag", "key": "level", "relation": "=", "value": "10"}, {"operator": "OR"}, {"field": "tag", "key": "level", "relation": "=", "value": "20"}]`

3. A user *is not* VIP *or* is admin:
`[{"field": "tag", "key": "is_vip", "relation": "!=", "value": "true"}, {"operator": "OR"}, {"field": "tag","key": "is_admin", "relation": "=", "value": "true"}]`


#### Example Code
[block:code]
{
  "codes": [
    {
      "code": "curl - -include \\\n     - -request POST \\\n     - -header \"Content-Type: application/json\" \\\n     - -header \"Authorization: Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\" \\\n     - -data-binary \"{\\\"app_id\\\": \\\"5eb5a37e-b458-11e3-ac11-000c2940e62c\\\",\n\\\"contents\\\": {\\\"en\\\": \\\"English Message\\\"},\n\\\"included_segments\\\": [\\\"All\\\"]}\" \\\n     https://onesignal.com/api/v1/notifications",
      "language": "shell"
    },
    {
      "code": "{\n  \"app_id\": \"5eb5a37e-b458-11e3-ac11-000c2940e62c\",\n  \"included_segments\": [\"All\"],\n  \"data\": {\"foo\": \"bar\"},\n  \"contents\": {\"en\": \"English Message\"}\n}",
      "language": "json"
    },
    {
      "code": "<?PHP\n\tfunction sendMessage(){\n\t\t$content = array(\n\t\t\t\"en\" => 'English Message'\n\t\t\t);\n\t\t\n\t\t$fields = array(\n\t\t\t'app_id' => \"5eb5a37e-b458-11e3-ac11-000c2940e62c\",\n\t\t\t'included_segments' => array('All'),\n      'data' => array(\"foo\" => \"bar\"),\n\t\t\t'contents' => $content\n\t\t);\n\t\t\n\t\t$fields = json_encode($fields);\n    print(\"\\nJSON sent:\\n\");\n    print($fields);\n\t\t\n\t\t$ch = curl_init();\n\t\tcurl_setopt($ch, CURLOPT_URL, \"https://onesignal.com/api/v1/notifications\");\n\t\tcurl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json',\n\t\t\t\t\t\t\t\t\t\t\t\t   'Authorization: Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj'));\n\t\tcurl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);\n\t\tcurl_setopt($ch, CURLOPT_HEADER, FALSE);\n\t\tcurl_setopt($ch, CURLOPT_POST, TRUE);\n\t\tcurl_setopt($ch, CURLOPT_POSTFIELDS, $fields);\n\t\tcurl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);\n\n\t\t$response = curl_exec($ch);\n\t\tcurl_close($ch);\n\t\t\n\t\treturn $response;\n\t}\n\t\n\t$response = sendMessage();\n\t$return[\"allresponses\"] = $response;\n\t$return = json_encode( $return);\n\t\n  print(\"\\n\\nJSON received:\\n\");\n\tprint($return);\n  print(\"\\n\");\n?>",
      "language": "csharp",
      "name": "PHP"
    },
    {
      "code": "using System.IO;\nusing System.Net;\nusing System.Text;\n\nvar request = WebRequest.Create(\"https://onesignal.com/api/v1/notifications\") as HttpWebRequest;\n\nrequest.KeepAlive = true;\nrequest.Method = \"POST\";\nrequest.ContentType = \"application/json\";\n\nrequest.Headers.Add(\"authorization\", \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\");\n\nbyte[] byteArray = Encoding.UTF8.GetBytes(\"{\"\n                                        + \"\\\"app_id\\\": \\\"5eb5a37e-b458-11e3-ac11-000c2940e62c\\\",\"\n                                        + \"\\\"contents\\\": {\\\"en\\\": \\\"English Message\\\"},\"\n                                        + \"\\\"included_segments\\\": [\\\"All\\\"]}\");\n\nstring responseContent = null;\n\ntry {\n    using (var writer = request.GetRequestStream()) {\n        writer.Write(byteArray, 0, byteArray.Length);\n    }\n\n    using (var response = request.GetResponse() as HttpWebResponse) {\n        using (var reader = new StreamReader(response.GetResponseStream())) {\n            responseContent = reader.ReadToEnd();\n        }\n    }\n}\ncatch (WebException ex) {\n    System.Diagnostics.Debug.WriteLine(ex.Message);\n    System.Diagnostics.Debug.WriteLine(new StreamReader(ex.Response.GetResponseStream()).ReadToEnd());\n}\n\nSystem.Diagnostics.Debug.WriteLine(responseContent);",
      "language": "csharp",
      "name": "C# (.NET standard)"
    },
    {
      "code": "using System.IO;\nusing System.Net;\nusing System.Text;\n\nvar request = WebRequest.Create(\"https://onesignal.com/api/v1/notifications\") as HttpWebRequest;\n\nrequest.KeepAlive = true;\nrequest.Method = \"POST\";\nrequest.ContentType = \"application/json\";\n\nrequest.Headers.Add(\"authorization\", \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\");\n\nvar serializer = new JavaScriptSerializer();\nvar obj = new { app_id = \"5eb5a37e-b458-11e3-ac11-000c2940e62c\",\n               contents = new { en = \"English Message\" },\n               included_segments = new string[] {\"All\"} };\nvar param = serializer.Serialize(obj);\nbyte[] byteArray = Encoding.UTF8.GetBytes(param);\n\nstring responseContent = null;\n\ntry {\n    using (var writer = request.GetRequestStream()) {\n        writer.Write(byteArray, 0, byteArray.Length);\n    }\n\n    using (var response = request.GetResponse() as HttpWebResponse) {\n        using (var reader = new StreamReader(response.GetResponseStream())) {\n            responseContent = reader.ReadToEnd();\n        }\n    }\n}\ncatch (WebException ex) {\n    System.Diagnostics.Debug.WriteLine(ex.Message);\n    System.Diagnostics.Debug.WriteLine(new StreamReader(ex.Response.GetResponseStream()).ReadToEnd());\n}\n\nSystem.Diagnostics.Debug.WriteLine(responseContent);",
      "language": "csharp",
      "name": "C# (ASP.NET)"
    },
    {
      "code": "params = {\"app_id\" => \"5eb5a37e-b458-11e3-ac11-000c2940e62c\", \n          \"contents\" => {\"en\" => \"English Message\"},\n          \"included_segments\" => [\"All\"]}\nuri = URI.parse('https://onesignal.com/api/v1/notifications')\nhttp = Net::HTTP.new(uri.host, uri.port)\nhttp.use_ssl = true\n\nrequest = Net::HTTP::Post.new(uri.path,\n                              'Content-Type'  => 'application/json',\n                              'Authorization' => \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\")\nrequest.body = params.as_json.to_json\nresponse = http.request(request) \nputs response.body",
      "language": "ruby",
      "name": "Ruby (Rails)"
    },
    {
      "code": "import requests\nimport json\n\nheader = {\"Content-Type\": \"application/json\",\n          \"Authorization\": \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\"}\n\npayload = {\"app_id\": \"5eb5a37e-b458-11e3-ac11-000c2940e62c\",\n           \"included_segments\": [\"All\"],\n           \"contents\": {\"en\": \"English Message\"}}\n \nreq = requests.post(\"https://onesignal.com/api/v1/notifications\", headers=header, data=json.dumps(payload))\n \nprint(req.status_code, req.reason)",
      "language": "python",
      "name": null
    },
    {
      "code": "var sendNotification = function(data) {\n  var headers = {\n    \"Content-Type\": \"application/json\",\n    \"Authorization\": \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\"\n  };\n  \n  var options = {\n    host: \"onesignal.com\",\n    port: 443,\n    path: \"/api/v1/notifications\",\n    method: \"POST\",\n    headers: headers\n  };\n  \n  var https = require('https');\n  var req = https.request(options, function(res) {  \n    res.on('data', function(data) {\n      console.log(\"Response:\");\n      console.log(JSON.parse(data));\n    });\n  });\n  \n  req.on('error', function(e) {\n    console.log(\"ERROR:\");\n    console.log(e);\n  });\n  \n  req.write(JSON.stringify(data));\n  req.end();\n};\n\nvar message = { \n  app_id: \"5eb5a37e-b458-11e3-ac11-000c2940e62c\",\n  contents: {\"en\": \"English Message\"},\n  included_segments: [\"All\"]\n};\n\nsendNotification(message);",
      "language": "javascript",
      "name": "NodeJS"
    },
    {
      "code": "#!/usr/bin/perl -w\n \nuse strict;\nuse warnings;\nuse Net::Curl::Easy qw(/^CURLOPT_.*/);;\nuse JSON;\nuse Data::Dumper;\n \nsub SendNotification\n{\n    my ($url , $authorisation , $app_id , $contents) = @_;\n    my $curl = Net::Curl::Easy->new;\n    my $json = JSON->new();\n    my $response_body;\n \n    my $json_string = $json->encode({ app_id => $app_id ,\n                                      included_segments => [\"All\"] ,\n                                      data => { \"key1\" => \"Value 1\" } ,\n                                      ios_badgeType => \"Increase\" ,\n                                      ios_badgeCount => 1 ,\n                                      contents => { en => $contents}\n                                    });\n \n    $curl->setopt( CURLOPT_URL, $url);\n    $curl->setopt( CURLOPT_SSL_VERIFYHOST , 0);\n    $curl->setopt( CURLOPT_SSL_VERIFYPEER , 0);\n \n    $curl->setopt( CURLOPT_HTTPHEADER, ['Content-Type: application/json' ,\n                                        \"Authorization: Basic $authorisation\"]);\n    $curl->setopt( CURLOPT_POST , 1);\n    $curl->setopt( CURLOPT_POSTFIELDS , $json_string);\n \n    $curl->setopt( CURLOPT_WRITEDATA , \\$response_body);\n \n    $curl->perform;\n    print Dumper($response_body);\n}\n \nSendNotification(\"https://onesignal.com/api/v1/notifications\" ,\n                 \"<< PUT YOUR REST API KEY HERE>>\" ,\n                 \"<< PUT YOUR APP ID KEY HERE >>\" ,\n                 \"Hello World\");\n \nexit(0);",
      "language": "perl"
    },
    {
      "code": "send = function(params) {\n\nvar promise = new Parse.Promise();\n\nvar jsonBody = { \n  app_id: \"5eb5a37e-b458-11e3-ac11-000c2940e62c\", \n  included_segments: [\"All\"],\n  contents: {en: \"English Message\"},\n  data: {foo: \"bar\"}\n};\n\nParse.Cloud.httpRequest({\n    method: \"POST\",\n    url: \"https://onesignal.com/api/v1/notifications\",\n    headers: {\n      \"Content-Type\": \"application/json;charset=utf-8\",\n      \"Authorization\": \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\"\n    },\n    body: JSON.stringify(jsonBody)\n  }).then(function (httpResponse) {\n    promise.resolve(httpResponse)\n  },\n  function (httpResponse) {\n    promise.reject(httpResponse);\n});\n\nreturn promise;\n};\n\nexports.send = send;",
      "language": "javascript",
      "name": "Parse Cloud"
    },
    {
      "code": "function SendNewNotification() {\n\n  var jsonBody = {\n\n    app_id: \"5eb5a37e-b458-11e3-ac11-000c2940e62c\",\n\n    included_segments: [\"All\"],\n\n    contents: {en: \"English Message\"},\n\n  };\n\n  var promise = Spark.getHttp(\"https://onesignal.com/api/v1/notifications\").setHeaders({\n\n    \"Content-Type\": \"application/json;charset=utf-8\",\n\n    \"Authorization\": \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\"\n\n  }).postJson(jsonBody);\n  \n\n  return promise;\n\n}\n\nvar response = SendNewNotification().getResponseJson();\n\nSpark.setScriptData(\"response\", response)",
      "language": "javascript",
      "name": "GameSparks"
    },
    {
      "code": "try {\n   String jsonResponse;\n   \n   URL url = new URL(\"https://onesignal.com/api/v1/notifications\");\n   HttpURLConnection con = (HttpURLConnection)url.openConnection();\n   con.setUseCaches(false);\n   con.setDoOutput(true);\n   con.setDoInput(true);\n\n   con.setRequestProperty(\"Content-Type\", \"application/json; charset=UTF-8\");\n   con.setRequestProperty(\"Authorization\", \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\");\n   con.setRequestMethod(\"POST\");\n\n   String strJsonBody = \"{\"\n                      +   \"\\\"app_id\\\": \\\"5eb5a37e-b458-11e3-ac11-000c2940e62c\\\",\"\n                      +   \"\\\"included_segments\\\": [\\\"All\\\"],\"\n                      +   \"\\\"data\\\": {\\\"foo\\\": \\\"bar\\\"},\"\n                      +   \"\\\"contents\\\": {\\\"en\\\": \\\"English Message\\\"}\"\n                      + \"}\";\n         \n   \n   System.out.println(\"strJsonBody:\\n\" + strJsonBody);\n\n   byte[] sendBytes = strJsonBody.getBytes(\"UTF-8\");\n   con.setFixedLengthStreamingMode(sendBytes.length);\n\n   OutputStream outputStream = con.getOutputStream();\n   outputStream.write(sendBytes);\n\n   int httpResponse = con.getResponseCode();\n   System.out.println(\"httpResponse: \" + httpResponse);\n\n   if (  httpResponse >= HttpURLConnection.HTTP_OK\n      && httpResponse < HttpURLConnection.HTTP_BAD_REQUEST) {\n      Scanner scanner = new Scanner(con.getInputStream(), \"UTF-8\");\n      jsonResponse = scanner.useDelimiter(\"\\\\A\").hasNext() ? scanner.next() : \"\";\n      scanner.close();\n   }\n   else {\n      Scanner scanner = new Scanner(con.getErrorStream(), \"UTF-8\");\n      jsonResponse = scanner.useDelimiter(\"\\\\A\").hasNext() ? scanner.next() : \"\";\n      scanner.close();\n   }\n   System.out.println(\"jsonResponse:\\n\" + jsonResponse);\n   \n} catch(Throwable t) {\n   t.printStackTrace();\n}",
      "language": "java"
    }
  ]
}
[/block]




## Send to Specific Devices
Finally, you may also target specific devices with the create notification method. Targeting devices is typically used in two ways:

1. For notifications that target individual users, such as if they've received a message from someone. 

2. For apps that wish to manage their own segments, such as tracking a user's followers and sending notifications to them when that user posts.

When targeting specific devices, you may use any of the following parameters together:
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Description",
    "0-0": "`include_player_ids`",
    "1-0": "`include_ios_tokens`",
    "2-0": "`include_wp_urls`",
    "3-0": "`include_wp_wns_uris`",
    "4-0": "`include_amazon_reg_ids`",
    "5-0": "`include_chrome_reg_ids`",
    "6-0": "`include_chrome_web_reg_ids`",
    "0-1": "Target using OneSignal player_ids",
    "1-1": "Target using iOS device tokens",
    "2-1": "Target using Windows Phone URIs",
    "3-1": "Target using Windows Phone WNS URIs",
    "4-1": "Target using Amazon IDs",
    "5-1": "Target using Chrome App IDsf",
    "6-1": "Target using Chrome Web Push IDs",
    "7-0": "`include_android_reg_ids`",
    "7-1": "Target using Android device IDs. Please consider using `include_player_ids` as an alternative."
  },
  "cols": 2,
  "rows": 8
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "curl - -include \\\n     - -request POST \\\n     - -header \"Content-Type: application/json\" \\\n     - -header \"Authorization: Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\" \\\n     - -data-binary \"{\\\"app_id\\\": \\\"5eb5a37e-b458-11e3-ac11-000c2940e62c\\\",\n\\\"contents\\\": {\\\"en\\\": \\\"English Message\\\"},\n\\\"included_segments\\\": [\\\"All\\\"]}\" \\\n     https://onesignal.com/api/v1/notifications",
      "language": "shell"
    },
    {
      "code": "{\n  \"app_id\": \"5eb5a37e-b458-11e3-ac11-000c2940e62c\",\n  \"included_segments\": [\"All\"],\n  \"data\": {\"foo\": \"bar\"},\n  \"contents\": {\"en\": \"English Message\"}\n}",
      "language": "json"
    },
    {
      "code": "<?PHP\n\tfunction sendMessage(){\n\t\t$content = array(\n\t\t\t\"en\" => 'English Message'\n\t\t\t);\n\t\t\n\t\t$fields = array(\n\t\t\t'app_id' => \"5eb5a37e-b458-11e3-ac11-000c2940e62c\",\n\t\t\t'included_segments' => array('All'),\n      'data' => array(\"foo\" => \"bar\"),\n\t\t\t'contents' => $content\n\t\t);\n\t\t\n\t\t$fields = json_encode($fields);\n    print(\"\\nJSON sent:\\n\");\n    print($fields);\n\t\t\n\t\t$ch = curl_init();\n\t\tcurl_setopt($ch, CURLOPT_URL, \"https://onesignal.com/api/v1/notifications\");\n\t\tcurl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json',\n\t\t\t\t\t\t\t\t\t\t\t\t   'Authorization: Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj'));\n\t\tcurl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);\n\t\tcurl_setopt($ch, CURLOPT_HEADER, FALSE);\n\t\tcurl_setopt($ch, CURLOPT_POST, TRUE);\n\t\tcurl_setopt($ch, CURLOPT_POSTFIELDS, $fields);\n\t\tcurl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);\n\n\t\t$response = curl_exec($ch);\n\t\tcurl_close($ch);\n\t\t\n\t\treturn $response;\n\t}\n\t\n\t$response = sendMessage();\n\t$return[\"allresponses\"] = $response;\n\t$return = json_encode( $return);\n\t\n  print(\"\\n\\nJSON received:\\n\");\n\tprint($return);\n  print(\"\\n\");\n?>",
      "language": "csharp",
      "name": "PHP"
    },
    {
      "code": "using System.IO;\nusing System.Net;\nusing System.Text;\n\nvar request = WebRequest.Create(\"https://onesignal.com/api/v1/notifications\") as HttpWebRequest;\n\nrequest.KeepAlive = true;\nrequest.Method = \"POST\";\nrequest.ContentType = \"application/json\";\n\nrequest.Headers.Add(\"authorization\", \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\");\n\nbyte[] byteArray = Encoding.UTF8.GetBytes(\"{\"\n                                        + \"\\\"app_id\\\": \\\"5eb5a37e-b458-11e3-ac11-000c2940e62c\\\",\"\n                                        + \"\\\"contents\\\": {\\\"en\\\": \\\"English Message\\\"},\"\n                                        + \"\\\"included_segments\\\": [\\\"All\\\"]}\");\n\nstring responseContent = null;\n\ntry {\n    using (var writer = request.GetRequestStream()) {\n        writer.Write(byteArray, 0, byteArray.Length);\n    }\n\n    using (var response = request.GetResponse() as HttpWebResponse) {\n        using (var reader = new StreamReader(response.GetResponseStream())) {\n            responseContent = reader.ReadToEnd();\n        }\n    }\n}\ncatch (WebException ex) {\n    System.Diagnostics.Debug.WriteLine(ex.Message);\n    System.Diagnostics.Debug.WriteLine(new StreamReader(ex.Response.GetResponseStream()).ReadToEnd());\n}\n\nSystem.Diagnostics.Debug.WriteLine(responseContent);",
      "language": "csharp",
      "name": "C# (.NET standard)"
    },
    {
      "code": "using System.IO;\nusing System.Net;\nusing System.Text;\n\nvar request = WebRequest.Create(\"https://onesignal.com/api/v1/notifications\") as HttpWebRequest;\n\nrequest.KeepAlive = true;\nrequest.Method = \"POST\";\nrequest.ContentType = \"application/json\";\n\nrequest.Headers.Add(\"authorization\", \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\");\n\nvar serializer = new JavaScriptSerializer();\nvar obj = new { app_id = \"5eb5a37e-b458-11e3-ac11-000c2940e62c\",\n               contents = new { en = \"English Message\" },\n               included_segments = new string[] {\"All\"} };\nvar param = serializer.Serialize(obj);\nbyte[] byteArray = Encoding.UTF8.GetBytes(param);\n\nstring responseContent = null;\n\ntry {\n    using (var writer = request.GetRequestStream()) {\n        writer.Write(byteArray, 0, byteArray.Length);\n    }\n\n    using (var response = request.GetResponse() as HttpWebResponse) {\n        using (var reader = new StreamReader(response.GetResponseStream())) {\n            responseContent = reader.ReadToEnd();\n        }\n    }\n}\ncatch (WebException ex) {\n    System.Diagnostics.Debug.WriteLine(ex.Message);\n    System.Diagnostics.Debug.WriteLine(new StreamReader(ex.Response.GetResponseStream()).ReadToEnd());\n}\n\nSystem.Diagnostics.Debug.WriteLine(responseContent);",
      "language": "csharp",
      "name": "C# (ASP.NET)"
    },
    {
      "code": "params = {\"app_id\" => \"5eb5a37e-b458-11e3-ac11-000c2940e62c\", \n          \"contents\" => {\"en\" => \"English Message\"},\n          \"included_segments\" => [\"All\"]}\nuri = URI.parse('https://onesignal.com/api/v1/notifications')\nhttp = Net::HTTP.new(uri.host, uri.port)\nhttp.use_ssl = true\n\nrequest = Net::HTTP::Post.new(uri.path,\n                              'Content-Type'  => 'application/json',\n                              'Authorization' => \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\")\nrequest.body = params.as_json.to_json\nresponse = http.request(request) \nputs response.body",
      "language": "ruby",
      "name": "Ruby (Rails)"
    },
    {
      "code": "import requests\nimport json\n\nheader = {\"Content-Type\": \"application/json\",\n          \"Authorization\": \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\"}\n\npayload = {\"app_id\": \"5eb5a37e-b458-11e3-ac11-000c2940e62c\",\n           \"included_segments\": [\"All\"],\n           \"contents\": {\"en\": \"English Message\"}}\n \nreq = requests.post(\"https://onesignal.com/api/v1/notifications\", headers=header, data=json.dumps(payload))\n \nprint(req.status_code, req.reason)",
      "language": "python",
      "name": null
    },
    {
      "code": "var sendNotification = function(data) {\n  var headers = {\n    \"Content-Type\": \"application/json\",\n    \"Authorization\": \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\"\n  };\n  \n  var options = {\n    host: \"onesignal.com\",\n    port: 443,\n    path: \"/api/v1/notifications\",\n    method: \"POST\",\n    headers: headers\n  };\n  \n  var https = require('https');\n  var req = https.request(options, function(res) {  \n    res.on('data', function(data) {\n      console.log(\"Response:\");\n      console.log(JSON.parse(data));\n    });\n  });\n  \n  req.on('error', function(e) {\n    console.log(\"ERROR:\");\n    console.log(e);\n  });\n  \n  req.write(JSON.stringify(data));\n  req.end();\n};\n\nvar message = { \n  app_id: \"5eb5a37e-b458-11e3-ac11-000c2940e62c\",\n  contents: {\"en\": \"English Message\"},\n  included_segments: [\"All\"]\n};\n\nsendNotification(message);",
      "language": "javascript",
      "name": "NodeJS"
    },
    {
      "code": "#!/usr/bin/perl -w\n \nuse strict;\nuse warnings;\nuse Net::Curl::Easy qw(/^CURLOPT_.*/);;\nuse JSON;\nuse Data::Dumper;\n \nsub SendNotification\n{\n    my ($url , $authorisation , $app_id , $contents) = @_;\n    my $curl = Net::Curl::Easy->new;\n    my $json = JSON->new();\n    my $response_body;\n \n    my $json_string = $json->encode({ app_id => $app_id ,\n                                      included_segments => [\"All\"] ,\n                                      data => { \"key1\" => \"Value 1\" } ,\n                                      ios_badgeType => \"Increase\" ,\n                                      ios_badgeCount => 1 ,\n                                      contents => { en => $contents}\n                                    });\n \n    $curl->setopt( CURLOPT_URL, $url);\n    $curl->setopt( CURLOPT_SSL_VERIFYHOST , 0);\n    $curl->setopt( CURLOPT_SSL_VERIFYPEER , 0);\n \n    $curl->setopt( CURLOPT_HTTPHEADER, ['Content-Type: application/json' ,\n                                        \"Authorization: Basic $authorisation\"]);\n    $curl->setopt( CURLOPT_POST , 1);\n    $curl->setopt( CURLOPT_POSTFIELDS , $json_string);\n \n    $curl->setopt( CURLOPT_WRITEDATA , \\$response_body);\n \n    $curl->perform;\n    print Dumper($response_body);\n}\n \nSendNotification(\"https://onesignal.com/api/v1/notifications\" ,\n                 \"<< PUT YOUR REST API KEY HERE>>\" ,\n                 \"<< PUT YOUR APP ID KEY HERE >>\" ,\n                 \"Hello World\");\n \nexit(0);",
      "language": "perl"
    },
    {
      "code": "send = function(params) {\n\nvar promise = new Parse.Promise();\n\nvar jsonBody = { \n  app_id: \"5eb5a37e-b458-11e3-ac11-000c2940e62c\", \n  included_segments: [\"All\"],\n  contents: {en: \"English Message\"},\n  data: {foo: \"bar\"}\n};\n\nParse.Cloud.httpRequest({\n    method: \"POST\",\n    url: \"https://onesignal.com/api/v1/notifications\",\n    headers: {\n      \"Content-Type\": \"application/json;charset=utf-8\",\n      \"Authorization\": \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\"\n    },\n    body: JSON.stringify(jsonBody)\n  }).then(function (httpResponse) {\n    promise.resolve(httpResponse)\n  },\n  function (httpResponse) {\n    promise.reject(httpResponse);\n});\n\nreturn promise;\n};\n\nexports.send = send;",
      "language": "javascript",
      "name": "Parse Cloud"
    },
    {
      "code": "function SendNewNotification() {\n\n  var jsonBody = {\n\n    app_id: \"5eb5a37e-b458-11e3-ac11-000c2940e62c\",\n\n    included_segments: [\"All\"],\n\n    contents: {en: \"English Message\"},\n\n  };\n\n  var promise = Spark.getHttp(\"https://onesignal.com/api/v1/notifications\").setHeaders({\n\n    \"Content-Type\": \"application/json;charset=utf-8\",\n\n    \"Authorization\": \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\"\n\n  }).postJson(jsonBody);\n  \n\n  return promise;\n\n}\n\nvar response = SendNewNotification().getResponseJson();\n\nSpark.setScriptData(\"response\", response)",
      "language": "javascript",
      "name": "GameSparks"
    },
    {
      "code": "try {\n   String jsonResponse;\n   \n   URL url = new URL(\"https://onesignal.com/api/v1/notifications\");\n   HttpURLConnection con = (HttpURLConnection)url.openConnection();\n   con.setUseCaches(false);\n   con.setDoOutput(true);\n   con.setDoInput(true);\n\n   con.setRequestProperty(\"Content-Type\", \"application/json; charset=UTF-8\");\n   con.setRequestProperty(\"Authorization\", \"Basic NGEwMGZmMjItY2NkNy0xMWUzLTk5ZDUtMDAwYzI5NDBlNjJj\");\n   con.setRequestMethod(\"POST\");\n\n   String strJsonBody = \"{\"\n                      +   \"\\\"app_id\\\": \\\"5eb5a37e-b458-11e3-ac11-000c2940e62c\\\",\"\n                      +   \"\\\"included_segments\\\": [\\\"All\\\"],\"\n                      +   \"\\\"data\\\": {\\\"foo\\\": \\\"bar\\\"},\"\n                      +   \"\\\"contents\\\": {\\\"en\\\": \\\"English Message\\\"}\"\n                      + \"}\";\n         \n   \n   System.out.println(\"strJsonBody:\\n\" + strJsonBody);\n\n   byte[] sendBytes = strJsonBody.getBytes(\"UTF-8\");\n   con.setFixedLengthStreamingMode(sendBytes.length);\n\n   OutputStream outputStream = con.getOutputStream();\n   outputStream.write(sendBytes);\n\n   int httpResponse = con.getResponseCode();\n   System.out.println(\"httpResponse: \" + httpResponse);\n\n   if (  httpResponse >= HttpURLConnection.HTTP_OK\n      && httpResponse < HttpURLConnection.HTTP_BAD_REQUEST) {\n      Scanner scanner = new Scanner(con.getInputStream(), \"UTF-8\");\n      jsonResponse = scanner.useDelimiter(\"\\\\A\").hasNext() ? scanner.next() : \"\";\n      scanner.close();\n   }\n   else {\n      Scanner scanner = new Scanner(con.getErrorStream(), \"UTF-8\");\n      jsonResponse = scanner.useDelimiter(\"\\\\A\").hasNext() ? scanner.next() : \"\";\n      scanner.close();\n   }\n   System.out.println(\"jsonResponse:\\n\" + jsonResponse);\n   \n} catch(Throwable t) {\n   t.printStackTrace();\n}",
      "language": "java"
    }
  ]
}
[/block]

[block:callout]
{
  "type": "warning",
  "title": "'REST API Key' Required",
  "body": "This method requires an application 'REST API Key' when using `include_segments` or `tags`.<br>**NEVER** use your 'REST API key' in client code, it is intended for use on your system or server only.\n\nAdd the REST API Key to the HTTP 'Authorization' header as basic authentication. Check out our examples above (except the JSON one) for some tips."
}
[/block]
## Common Parameters
The following are parameters in Create Notifications common to all methods of targeting users. 

#### App
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "0-0": "`app_id`",
    "0-1": "string",
    "h-1": "Type",
    "0-2": "All",
    "h-2": "Description",
    "1-0": "`app_ids`",
    "1-1": "array of strings",
    "1-2": "All",
    "h-3": "Description",
    "0-3": "**REQUIRED** Your OneSignal application ID, which can be found in <a class=\"dash-link\">Keys & IDs</a>. It is a UUID and looks similar to `8250eaf6-1a58-489e-b136-7c74a864b434`.",
    "1-3": "<p>An array of OneSignal app IDs. All users within these apps will receive at most one notification.</p>\n<p>[Your User Auth API key is required for authentication.](https://documentation.onesignal.com/docs/frequently-asked-questions#section-where-can-i-find-my-user-auth-key-)</p> <p>Example: `[\"2dd608f2-a6a1-11e3-251d-400c2940e62b\", \"2dd608f2-a6a1-11e3-251d-500f2950e61c\"]`</p>"
  },
  "cols": 4,
  "rows": 2
}
[/block]
#### Content & Language
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Platform",
    "h-3": "Description",
    "0-0": "`contents`",
    "0-1": "object",
    "0-2": "All",
    "0-3": "<p>**REQUIRED** unless `content_available=true` or `template_id` is set.</p>\n<p>The notification's content (excluding the title), a map of language codes to text for each language.</p>\n<p>Each hash must have a language code string for a key, mapped to the localized text you would like users to receive for that language. **English must be included in the hash**. [Read more: supported languages.](doc:language-localization#section-supported-languages)</p>\n<p>Example: `{\"en\": \"English Message\", \"es\": \"Spanish Message\"}`</p>",
    "3-3": "Sends `content-available=1` to wake your app to run custom native code.",
    "3-2": "iOS",
    "3-1": "boolean",
    "3-0": "`content_available`",
    "4-0": "`mutable_content`",
    "4-1": "boolean",
    "4-2": "iOS 10+",
    "4-3": "Allows you to change the notification content in your app before it is displayed. Triggers `didReceive(_:withContentHandler:)` on your [UNNotificationServiceExtension](https://developer.apple.com/reference/usernotifications/unnotificationserviceextension).",
    "2-0": "`template_id`",
    "2-1": "string",
    "2-2": "All",
    "2-3": "<p>Use a template you setup on our dashboard. You can override the template values by sending other parameters with the request. The template_id is the UUID found in the URL when viewing a template on our dashboard.</p>\n<p>Example: `be4a8044-bbd6-11e4-a581-000c2940e62c`</p>",
    "1-0": "`headings`",
    "1-1": "object",
    "1-2": "All",
    "1-3": "<p>The notification's title, a map of language codes to text for each language. Each hash must have a language code string for a key, mapped to the localized text you would like users to receive for that language. A default title may be displayed if a title is not provided. [Read more: supported languages.](doc:language-localization#section-supported-languages)</p>\n<p>Example: `{\"en\": \"English Title\", \"es\": \"Spanish Title\"}`</p>"
  },
  "cols": 4,
  "rows": 5
}
[/block]
#### Attachments
These are additional content attached to notifications, primarily images.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Platform",
    "h-3": "Description",
    "0-0": "`data`",
    "0-3": "<p>A custom map of data that is passed back to your app.</p> \n<p>Example: `{\"abc\": \"123\", \"foo\": \"bar\"}`</p>",
    "0-1": "object",
    "0-2": "All",
    "2-0": "`ios_attachments`",
    "2-1": "object",
    "2-2": "iOS 10+",
    "2-3": "<p>Adds media attachments to notifications. Set as JSON object, key as a media id of your choice and the value as a valid local file name or URL. User must press and hold on the notification to view.</p>\n<p>Example: `{\"id1\": \"https://domain.com/image.jpg\"}`</p>",
    "3-0": "`big_picture`",
    "3-1": "string",
    "3-2": "Android",
    "3-3": "Picture to display in the expanded view. Can be a drawable resource name or a URL.",
    "4-3": "Picture to display in the expanded view. Can be a drawable resource name or a URL.",
    "4-0": "`adm_big_picture`",
    "4-1": "string",
    "4-2": "Amazon",
    "5-0": "`chrome_big_picture`",
    "5-1": "string",
    "5-2": "ChromeApp",
    "5-3": "Large picture to display below the notification text. Must be a local URL.",
    "1-0": "`url`",
    "1-1": "string",
    "1-2": "All",
    "1-3": "<p>The URL to open in the browser when a user clicks on the notification.</p> <p>Example: `http://www.google.com`</p>"
  },
  "cols": 4,
  "rows": 6
}
[/block]
#### Action Buttons
These add buttons to notifications, allowing the user to take more than one action on a notification. [Learn more about Action Buttons](doc:action-buttons-1).
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Platform",
    "h-3": "Description",
    "0-1": "array_object",
    "0-0": "`buttons`",
    "0-2": "iOS 8.0+, Android 4.1+",
    "0-3": "<p>Buttons to add to the notification. Icon only works for Android.</p>\n<p>Example: <code class=\"inline-code\">[{\"id\": \"id1\", \"text\": \"button1\", \"icon\": \"ic_menu_share\"}, {\"id\": \"id2\", \"text\": \"button2\", \"icon\": \"ic_menu_send\"}]</code></p>",
    "2-0": "`ios_category`",
    "2-3": "[Category APS](https://developer.apple.com/library/ios/documentation/UIKit/Reference/UIUserNotificationCategory_class/index.html#//apple_ref/occ/cl/UIUserNotificationCategory) payload, use with `registerUserNotificationSettings:categories` in your Objective-C / Swift code.</p>\n\n<p>Example: `calendar` category which contains actions like `accept` and `decline`</p>",
    "2-2": "iOS",
    "2-1": "string",
    "1-0": "`web_buttons`",
    "1-1": "array_object",
    "1-3": "Add action buttons to the notification. The `id` field is required.</p>\n\n<p>Example: <code class=\"inline-code\">[{\"id\": \"like-button\", \"text\": \"Like\", \"icon\": \"http://i.imgur.com/N8SN8ZS.png\", \"url\": \"https://yoursite.com\"}, {\"id\": \"read-more-button\", \"text\": \"Read more\", \"icon\": \"http://i.imgur.com/MIxJp1L.png\", \"url\": \"https://yoursite.com\"}]</code></p>",
    "1-2": "Chrome Web 48+"
  },
  "cols": 4,
  "rows": 3
}
[/block]
#### Appearance
These parameters let you adjust notification icons, sounds, badges, and other appearance changes to your notifications.

**Icons** - Different platforms handle icons differently. Typically, the app icon is shown. 

**Sounds** - By default, the device notification sound plays when a new notification arrives. You may alter this by specifying a different sound asset.

**Badges** - shows the number of notifications outstanding. Note: Android badges are automatically handled by OneSignal.
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Platform",
    "h-3": "Description",
    "0-0": "`android_background_layout`",
    "0-1": "object",
    "0-2": "Android",
    "0-3": "<p>Allowing setting a background image for the notification. This is a JSON object containing the following keys.</p>\n\n<p>`image` - Asset file, android resource name, or URL to remote image. recommend size: 1582x256</p>\n\n<p>`headings_color` - Title text color ARGB Hex format. Example(Blue): `\"FF0000FF\"`.</p>\n\n<p>`contents_color` - Body text color ARGB Hex format. Example(Red): `\"FFFF0000\"`</p>\n\n<p>Example: `{\"image\": \"https://domain.com/background_image.jpg\", \"headings_color\": \"FFFF0000\", \"contents_color\": \"FF00FF00\"}`",
    "2-0": "`large_icon`",
    "2-1": "string",
    "2-2": "Android",
    "2-3": "If blank the `small_icon` is used. Can be a drawable resource name or a URL.",
    "15-0": "`ios_badgeType`",
    "15-1": "string",
    "15-2": "iOS",
    "15-3": "<p>Describes whether to *set* or *increase/decrease* your app's iOS badge count by the `ios_badgeCount` specified count. Can specify `None`, `SetTo`, or `Increase`.</p>\n\n<p>`None` leaves the count unaffected.</p>\n\n<p>`SetTo` directly sets the badge count to the number specified in `ios_badgeCount`.</p>\n\n<p>`Increase` adds the number specified in `ios_badgeCount` to the total. Use a negative number to decrease the badge count.</p>",
    "16-3": "<p>Used with `ios_badgeType`, describes the value to *set* or amount to *increase/decrease* your app's iOS badge count by.</p> <p>You can use a negative number to decrease the badge count when used with an `ios_badgeType` of `Increase`.</p>",
    "16-0": "`ios_badgeCount`",
    "16-1": "string",
    "16-2": "iOS",
    "3-0": "`chrome_web_icon`",
    "4-0": "`firefox_icon`",
    "5-0": "`adm_small_icon`",
    "6-0": "`adm_large_icon`",
    "7-0": "`chrome_icon`",
    "3-1": "string",
    "4-1": "string",
    "5-1": "string",
    "6-1": "string",
    "7-1": "string",
    "3-3": "Sets the web push notification's icon. An image URL linking to a valid image. Common image types are supported; GIF will not animate. We recommend 256x256 (at least 80x80) to display well on high DPI devices. This icon is also used a default for Firefox if not provided.",
    "3-2": "ChromeWeb",
    "7-2": "ChromeApp",
    "4-3": "_Infrequently used_ - Recommend setting `chrome_web_icon` instead, which Firefox will use.\n\nSets the web push notification's icon for Firefox. An image URL linking to a valid image. Common image types are supported; GIF will not animate. We recommend 256x256 (at least 80x80) to display well on high DPI devices.",
    "4-2": "Firefox",
    "5-3": "Specific Amazon icon to use. If blank the app icon is used.  Must be the drawable resource name.",
    "6-3": "Specific Amazon icon to display to the left of the notification. If blank the `adm_small_icon` is used. Can be a drawable resource name or a URL.",
    "6-2": "Amazon",
    "5-2": "Amazon",
    "7-3": "_Infrequently Used_ - NOT for Chrome web push (please see `chrome_web_icon` instead). The local URL to an icon to use. if blank the app icon will be used.",
    "1-0": "`small_icon`",
    "1-1": "string",
    "1-2": "Android",
    "1-3": "If blank the app icon is used.  Must be the drawable resource name.",
    "8-0": "`ios_sound`",
    "9-0": "`android_sound`",
    "9-1": "string",
    "8-1": "string",
    "10-1": "string",
    "11-1": "string",
    "12-1": "string",
    "13-1": "string",
    "10-0": "`adm_sound`",
    "11-0": "`wp_sound`",
    "12-0": "`wp_wns_sound`",
    "9-3": "<p>Sound file that is included in your app to play instead of the default device notification sound. NOTE: Leave off file extension for Android.</p>\n<p>Example: `\"notification\"`",
    "9-2": "Android",
    "8-2": "iOS",
    "10-2": "Amazon",
    "11-2": "Windows 8.0",
    "12-2": "Windows 8.1",
    "8-3": "<p>Sound file that is included in your app to play instead of the default device notification sound. Pass \"nil\" to disable vibration and sound for the notification.</p>\n<p>Example: `\"notification.wav\"`</p>",
    "10-3": "<p>**Amazon devices** -  Sound file that is included in your app to play instead of the default device notification sound.</p><p>NOTE: Leave off file extension for Android.</p>\n<p>Example: `\"notification\"`</p>",
    "11-3": "<p>**Windows Phone 8.0** - Sound file that is included in your app to play instead of the default device notification sound.</p><p>Example: `\"notification.wav\"`</p>",
    "12-3": "<p>**Windows Phone 8.1** - sound file that is included in your app to play instead of the default device notification sound.</p><p>Example: `\"notification.wav\"`</p>",
    "13-0": "`android_led_color`",
    "14-0": "`android_accent_color`",
    "14-1": "string",
    "14-3": "<p>Sets the background color of the notification circle to the left of the notification text. Only applies to apps targeting Android API level 21+ on Android 5.0+ devices.</p><p>Example(Red): `\"FFFF0000\"`</p>",
    "14-2": "Android",
    "13-2": "Android",
    "13-3": "<p>Sets the devices LED notification light if the device has one. ARGB Hex format.</p><p>Example(Blue): `\"FF0000FF\"`</p>"
  },
  "cols": 4,
  "rows": 17
}
[/block]
#### Delivery
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Platform",
    "0-0": "`send_after`",
    "0-1": "string",
    "0-2": "All",
    "1-0": "`delayed_option`",
    "1-1": "string",
    "1-2": "All",
    "2-0": "`delivery_time_of_day`",
    "2-1": "string",
    "2-2": "All",
    "h-3": "Description",
    "0-3": "Schedule notification for future delivery.<br>Examples:<br>*All examples are the exact same date & time.*<br>`\"Thu Sep 24 2015 14:00:00 GMT-0700 (PDT)\"`<br>`\"September 24th 2015, 2:00:00 pm UTC-07:00\"`<br>`\"2015-09-24 14:00:00 GMT-0700\"`<br>`\"Sept 24 2015 14:00:00 GMT-0700\"`<br>`\"Thu Sep 24 2015 14:00:00 GMT-0700 (Pacific Daylight Time)\"`",
    "1-3": "Possible values are:</p>\n<p>`\"timezone\"` (Deliver at a specific time-of-day in each users own timezone)</p>\n<p>`\"last-active\"` (Deliver at the same time of day as each user last used your app).</p>\n<p>If \"send_after\" is used, this takes effect after the \"send_after' time has elapsed.</p>",
    "2-3": "<p>Use with delayed_option=timezone.</p>\n<p>Example: `\"9:00AM\"`</p>",
    "3-0": "`ttl`",
    "3-1": "integer",
    "3-2": "iOS, Android, ChromeWeb",
    "3-3": "Time To Live - In seconds. The notification will be expired if the device does not come back online within this time. The default is 259,200 seconds (3 days)."
  },
  "cols": 4,
  "rows": 4
}
[/block]
#### Grouping & Collapsing
Grouping lets you combine multiple notifications into a single notification to improve the user experience. [Learn more about Notification Grouping](doc:notification-grouping). Collapsing lets you dismiss old notifications in favor of newer ones. [Learn more about Notification Collapsing](doc:notification-collapsing).
[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Platform",
    "h-3": "Description",
    "0-0": "`android_group`",
    "0-1": "string",
    "0-2": "Android",
    "0-3": "All Android notifications with the same group will be stacked together using Android's [Notification Stacking](https://developer.android.com/training/wearables/notifications/stacks.html) feature.",
    "1-3": "Summary message to display when 2+ notifications are stacked together. Default is \"# new messages\". Include $[notif_count] in your message and it will be replaced with the current number.  \"en\" (English) is required. The key of each hash is either a a 2 character language code or one of zh-Hans/zh-Hant for Simplified or Traditional Chinese. The value of each key is the message that will be sent to users for that language.<br>Example: `\"{ \"en\" : \"You have $[notif_count] new messages\"}`",
    "1-2": "Android",
    "1-1": "object",
    "1-0": "`android_group_message`",
    "2-3": "All Amazon notifications with the same group will be stacked together using Android's [Notification Stacking](https://developer.android.com/training/wearables/notifications/stacks.html) feature.",
    "2-2": "Amazon",
    "2-1": "string",
    "2-0": "`adm_group`",
    "3-0": "`adm_group_message`",
    "3-1": "object",
    "3-2": "Amazon",
    "3-3": "Summary message to display when 2+ notifications are stacked together. Default is \"# new messages\". Include $[notif_count] in your message and it will be replaced with the current number.  \"en\" (English) is required. The key of each hash is either a a 2 character language code or one of zh-Hans/zh-Hant for Simplified or Traditional Chinese. The value of each key is the message that will be sent to users for that language.<br>Example: `\"{ \"en\" : \"You have $[notif_count] new messages\"}`"
  },
  "cols": 4,
  "rows": 4
}
[/block]
#### Platform to Deliver To
These parameters let you select which device platforms to include or exclude from delivery.

[block:parameters]
{
  "data": {
    "h-0": "Parameter",
    "h-1": "Type",
    "h-2": "Platform",
    "h-3": "Description",
    "0-0": "`isIos`",
    "0-1": "boolean",
    "1-1": "boolean",
    "2-1": "boolean",
    "6-1": "boolean",
    "7-1": "boolean",
    "8-1": "boolean",
    "9-1": "boolean",
    "1-0": "`isAndroid`",
    "2-0": "`isAnyWeb`",
    "6-0": "`isWP`",
    "7-0": "`isWP_WNS`",
    "8-0": "`isAdm`",
    "9-0": "`isChrome`",
    "0-2": "iOS",
    "1-2": "Android",
    "2-2": "Web",
    "9-2": "ChromeApp",
    "8-2": "Amazon",
    "7-2": "Windows",
    "6-2": "Windows",
    "0-3": "Indicates whether to send to all devices registered under your app's Apple iOS platform.",
    "1-3": "Indicates whether to send to all devices registered under your app's Google Android platform.",
    "2-3": "<p>Indicates whether to send to all subscribed web browser users, including Chrome, Firefox, and Safari.</p>\n\n<p>You may use this instead as a combined flag instead of separately enabling `isChromeWeb`, `isFirefox`, and `isSafari`, though the three options are equivalent to this one.</p>",
    "6-3": "Indicates whether to send to all devices registered under your app's Windows Phone 8.0 platform.",
    "7-3": "Indicates whether to send to all devices registered under your app's Windows Phone 8.1+ platform.",
    "8-3": "Indicates whether to send to all devices registered under your app's Amazon Fire platform.",
    "9-3": "Indicates whether to send to all devices registered under your app's Google Chrome Apps & Extension platform.\n\n**This flag is not used for web push.** Please see `isChromeWeb` for sending to web push users. This flag only applies to Google Chrome Apps & Extensions.",
    "3-0": "`isChromeWeb`",
    "4-0": "`isFirefox`",
    "3-1": "boolean",
    "4-1": "boolean",
    "5-1": "boolean",
    "3-2": "Web",
    "4-2": "Web",
    "5-2": "Web",
    "5-0": "`isSafari`",
    "3-3": "Indicates whether to send to all Google Chrome, Chrome on Android, and Mozilla Firefox users registered under your Chrome & Firefox web push platform.",
    "4-3": "Indicates whether to send to all Mozilla Firefox desktop users registered under your Firefox web push platform.",
    "5-3": "Indicates whether to send to all Apple's Safari desktop users registered under your Safari web push platform. [This is not supported on iOS.](doc:why-doesnt-web-push-work-with-ios)"
  },
  "cols": 4,
  "rows": 10
}
[/block]
## Postman Example

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/fKb06zZaQgW3AtnQqXUX_PostmanExample2.png",
        "PostmanExample2.png",
        "838",
        "220",
        "#1b96cc",
        ""
      ]
    }
  ]
}
[/block]

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/AWhI22Y7T8O4YUmgZba2_PostmanExample1.png",
        "PostmanExample1.png",
        "604",
        "208",
        "#485492",
        ""
      ]
    }
  ]
}
[/block]
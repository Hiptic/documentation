---
title: "Opt-Out of Web Push"
excerpt: ""
---
[block:api-header]
{
  "type": "basic",
  "title": "Opting out of Web Push from a website on Chrome"
}
[/block]
### Step 1: Click the three dots in the top right of your browser window, then select "Settings"
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/e7a6a33-Screenshot_2016-11-22_17.32.29.png",
        "Screenshot 2016-11-22 17.32.29.png",
        543,
        439,
        "#efefef"
      ]
    }
  ]
}
[/block]
### Step 2: Click the "Show Advanced Settings" link
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/284a184-Screenshot_2016-11-22_17.32.42.png",
        "Screenshot 2016-11-22 17.32.42.png",
        731,
        511,
        "#397461"
      ]
    }
  ]
}
[/block]
### Step 3: Under "Privacy" Click the "Content Settings" button.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/ee0bc01-Screenshot_2016-11-22_17.32.56.png",
        "Screenshot 2016-11-22 17.32.56.png",
        549,
        367,
        "#3a6964"
      ]
    }
  ]
}
[/block]
### Step 4: Scroll down to "Notifications" then click the "Manage exceptions" button.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/60d0ee2-Screenshot_2016-11-22_17.33.09.png",
        "Screenshot 2016-11-22 17.33.09.png",
        508,
        273,
        "#387657"
      ]
    }
  ]
}
[/block]
### Step 5: Select "Block" next to any sites you would like to stop receiving notifications from
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/332e541-Screenshot_2016-11-22_17.33.48.png",
        "Screenshot 2016-11-22 17.33.48.png",
        583,
        149,
        "#d5dce9"
      ]
    }
  ]
}
[/block]
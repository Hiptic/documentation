---
title: "Security"
excerpt: ""
---
#### How secure is OneSignal? 
All OneSignal SDKs connect to our servers with HTTPS and our REST API enforces an API key where it is needed.

<span class="label-all label-ios">iOS</span> - OneSignal uses the TLS encryption for sending notifications as required by the [Apple APNS specifications](https://developer.apple.com/library/content/documentation/NetworkingInternet/Conceptual/RemoteNotificationsPG/APNSOverview.html#//apple_ref/doc/uid/TP40008194-CH8-SW11).

<span class="label-all label-android">Android</span> - OneSignal uses Google's GCM/FCM service which uses the HTTPS protocol.
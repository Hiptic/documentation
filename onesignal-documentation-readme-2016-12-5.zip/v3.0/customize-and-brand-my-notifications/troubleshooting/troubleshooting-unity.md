---
title: "Troubleshooting Unity"
excerpt: "Common setup issues with Unity (<span class=\"label-all label-ios\">iOS</span>, <span class=\"label-all label-android\">Android</span> (and derivatives like <span class=\"label-all label-amazon\">Amazon</span>) and <span class=\"label-all label-windows\">Windows Phone 8.1</span>.\n<div class=\"tag-all tag-troubleshooting\">Troubleshooting</div> <div class=\"tag-all tag-developers\">For Developers</div>"
---
## Build Error
<div class="label-all label-type"><span class="label-android">Android</span>, <span class="label-amazon">Amazon</span></div>

<ol><li><p>Run `Assets` > `Play Services Resolver` > `Android Resolver` > `Resolve Client Jars` from the menu bar.</p>
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/7972891-UnityOneSignalUnity1.2.2Reslover.png",
        "UnityOneSignalUnity1.2.2Reslover.png",
        684,
        481,
        "#d1d3d4"
      ]
    }
  ]
}
[/block]
<li><p>You should now see the following .aar and .jar files in your `Assets/Plugins/Android` folder. <br>*NOTE: These will be folders if you are using Unity 4.7 instead of 5*</p><p><img src="https://files.readme.io/b744aa9-Unity5AARfiles.png"/></p></li><li><p>If these files do not appear check the Unity log for errors and follow the JarResolover error instructions below.</p></li><li><p>Build your Android app again.</p></li></ol>
[block:callout]
{
  "type": "success",
  "body": "Done! If the problem persists, send your console log, Unity version, and other plugins in your project to OneSignal. support."
}
[/block]
----

## Google Play Services JarResolver Error
<div class="label-all label-type"><span class="label-android">Android</span>, <span class="label-amazon">Amazon</span></div>

<ol><li><p>The Google Play Services Jar resolver won't be able to import the required Android libraries if your Android SDK is out of date or is incomplete. If this is the case you may see an error like this:</p><p>`Google.JarResolver.ResolutionException: Cannot find candidate artifact for com.google.android.gms:play-services-gcm:9+`</p></li><li><p>Open the Android SDK Manager.</p></li><li><p>Make sure to install and update the following under Extras:</p><ul><li><p>Android Support **Repository**</p></li><li><p>Google **Repository**</p></li></ul><p><img src="https://files.readme.io/0e32855-AndroidSDKGoogleRepository.png"/></p></li><li><p>Run `Assets > Google Play Services > Resolve Client Jars` from the menu bar then build again.</p></li><li><p>If you are still seeing the same error make sure the Android SDK Manager path and the SDK you have set in Unity match. This is under `Edit` > `Preferences`, then External Tools and `Android` > `SDK`.</p></ol>
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/4eaccb2-UnityAndroidSDKPath.png",
        "UnityAndroidSDKPath.png",
        580,
        431,
        "#cacaca"
      ]
    }
  ]
}
[/block]

[block:callout]
{
  "type": "success",
  "body": "Done!"
}
[/block]
----

## "No resource found that matches the given name" build errors
<div class="label-all label-type"><span class="label-android">Android</span>, <span class="label-amazon">Amazon</span></div>

You may receive errors like the following if your project's path is to long.
```
C:\full\path\to\project\Temp\StagingArea\android-libraries\play-services-base-9.4.0\res\drawable\common_google_signin_btn_text_light.xml:12: error:
Error: No resource found that matches the given name (at 'drawable' with value '@drawable/common_google_signin_btn_text_light_normal').
```

Close Unity and move your project to the root of your drive. Then open the new location in Unity and build again.
[block:callout]
{
  "type": "success",
  "body": "Done! Unity should now find your project"
}
[/block]
----

## Xcode - Undefined symbols for architecture xxxx - OneSignal
<div class="label-all label-type"><span class="label-ios">iOS</span></div>

<ol><li><p>If you are seeing the following error then the OneSignal library was not correctly enabled for iOS builds.</p><p>```Undefined symbols for architecture arm64: 
"_OBJC_CLASS_$_OneSignal", referenced from: 
objc-class-ref in OneSignalUnityRuntime.o 
ld: symbol(s) not found for architecture arm64```</p></li><li><p>Make sure `iOS` is checked on `Assets/OneSignal/Platforms/iOS/libOneSignal` under the inspector view.</p><p><img src="https://files.readme.io/cbabe85-UnityIosEnabled.png"/></p></li><li><p>Rebuild from Unity then rebuild in Xcode.</p></li></ol>
[block:callout]
{
  "type": "success",
  "body": "Done!"
}
[/block]
----

## Build error with Facebook SDK
<div class="label-all label-type"><span class="label-android">Android</span></div>

The Facebook SDK comes with a few Android libraries that OneSignal already includes. Please remove the following 2 files.
* `FacebookSDK/plugins/android/libs/support-v4-23.4.0.aar`
* `FacebookSDK/plugins/android/libs/support-annotations-23.4.0.aar`

The numbers in the file names by be different depending on the version of the Facebook SDK you are using.
[block:callout]
{
  "type": "success",
  "body": "Done!"
}
[/block]
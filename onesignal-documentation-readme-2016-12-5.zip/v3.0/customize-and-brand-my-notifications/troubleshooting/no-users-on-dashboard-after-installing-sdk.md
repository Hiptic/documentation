---
title: "No users on dashboard"
excerpt: "<div class=\"tag-all tag-troubleshooting\">Troubleshooting</div> <div class=\"tag-all tag-developers\">For Developers</div>"
---
The following are all reasons why you may not see users on the dashboard after installing your SDK:

#### Incorrect OneSignal AppID 
Double check your passing the correct id to OneSignal init in your app's code. Your app id is shown in <a class="dash-link" href="user-accounts#section-keys-ids">Keys & IDs</a>.

#### OneSignal Init isn't called
Add logging before and after you call OneSignal init. To make sure the code is running.

#### Device Logs show errors
Check the device log for any errors or warnings.

<span class="label-all label-android">Android</span> - Check the logcat in Android Studio or Eclipse. You can also run ddms found in `<android-sdk>/tools/ddms` or run `adb logical`

<span class="label-all label-ios">iOS</span> - Open Xcode and go to **Window -> Devices**. Select your device on the right then the log will show on the bottom. If you don't see the log click the small up arrow on the bottom of the window.
[block:callout]
{
  "type": "info",
  "body": "You may wish to enable **Extra Logging** to further troubleshoot these problems. Look for the `SetLogLevel` function in API Reference for the SDK you using to enable."
}
[/block]
#### Other Problems
If the above don't resolve, please check the [Troubleshooting](doc:known-issues) section for more possible solutions.
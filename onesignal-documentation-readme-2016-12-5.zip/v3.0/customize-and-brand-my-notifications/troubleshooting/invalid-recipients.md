---
title: "Invalid Recipients"
excerpt: "Configuration Notice - <span class=\"label-all label-android\">Android</span>, <span class=\"label-all label-webpush\">Web Push</span> (<span class=\"label-all label-chrome\">Chrome</span>, <span class=\"label-all label-firefox\">Firefox</span>)\n<div class=\"tag-all tag-troubleshooting\">Troubleshooting</div> <div class=\"tag-all tag-developers\">For Developers</div>"
---
**Invalid Recipients** is thrown when Google returns an `InvalidRegistration` error. Each device (user) has a unique GCM/FCM registration token that Google assigns when the device subscribes. This registration token is used to uniquely identify a recipient. Some device registration tokens are either in an invalid format or do not point to any known device.

## Steps to Resolve
This error can occur if you manually add devices to our system via our REST APIs and use an invalid `identifier` when you add the device to our system. 

Please make sure your imported device registration tokens are valid.

A valid identifier (registration token) looks like:

`f2D78SMl4Nc:APA91bHOrhe13io3OM3y67C8bfXNLgc2ehhv1guDMN6a3n9t0CI18m7Wef-i4ylpWHBzf4qQt1gbvg_y4pmKCy0wTUneK9haUwMPHlhC2oGjIl-G4MZ-47lMHd-XsjBnY_rq5CTvJ_Nn`

The number of characters can vary. You can confirm the InvalidRegistration message using Google's API by passing in your Google Server API Key and the registration token, like so:
[block:code]
{
  "codes": [
    {
      "code": "curl -X POST -H \"Authorization: key=<YOUR_GOOGLE_SERVER_API_KEY>\" -H \"Content-Type: application/json\" -H \"Cache-Control: no-cache\" -d '{\n    \"registration_ids\": [\"<YOUR_REGISTRATION_TOKEN>\"]\n}' \"https://gcm-http.googleapis.com/gcm/send?dry_run=true\"",
      "language": "curl"
    }
  ]
}
[/block]
Please <a href="" class="contact-support">contact support</a> if you have never imported devices but are receiving this error.
---
title: "Using Postman"
excerpt: "How to use postman for Server REST API testing\n<div class=\"tag-all tag-developers\">For Developers</div>"
---
You can also use [Postman](https://www.getpostman.com) to work with our [Server REST API](ref:create-notification). Follow the screenshots below to see how to use Postman for our [Create notification API endpoint](ref:create-notification).
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/fKb06zZaQgW3AtnQqXUX_PostmanExample2.png",
        "PostmanExample2.png",
        "838",
        "220",
        "#1b96cc",
        ""
      ]
    }
  ]
}
[/block]

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/AWhI22Y7T8O4YUmgZba2_PostmanExample1.png",
        "PostmanExample1.png",
        "604",
        "208",
        "#485492",
        ""
      ]
    }
  ]
}
[/block]
---
title: "Mismatched User Environment"
excerpt: "Configuration Notice - <span class=\"label-all label-ios\">iOS</span>\n<div class=\"tag-all tag-troubleshooting\">Troubleshooting</div> <div class=\"tag-all tag-developers\">For Developers</div>"
---
**Mismatched User Environment** is thrown when Apple returns a `BadDeviceToken` error. This means some users are tied to a different environment from your sending environment.


## Steps to Resolve
1. If you recently updated to XCode 8 you will need to enable "Push Notifications" under Capabilities. See [Add Required Capabilities](ios-sdk-setup#section-2-add-required-capabilities) for detailed steps.

2. Please make sure you're using our latest SDK. Our SDK is frequently updated to meet Apple's changing push standards.

3. If you're directly [importing users via our REST API](ref:edit-device), please make sure the `test_type` field is set correctly according to our documentation.

4. If you've only uploaded a sandbox push certificate, please upload a production push certificate as well.
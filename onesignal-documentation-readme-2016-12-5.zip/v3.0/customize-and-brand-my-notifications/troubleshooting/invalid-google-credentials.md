---
title: "Invalid Google Credentials"
excerpt: "Configuration Notice - <span class=\"label-all label-webpush\">Web Push</span> (<span class=\"label-all label-chrome\">Chrome</span>, <span class=\"label-all label-firefox\">Firefox</span>)\n<div class=\"tag-all tag-troubleshooting\">Troubleshooting</div> <div class=\"tag-all tag-developers\">For Developers</div>"
---
**Invalid Google Credentials** is thrown when your Google Server API Key is entered incorrectly. This error can also happen to keys that were generated using the Google Cloud Console due to a bug with Google's systems. 

## Steps to Resolve

Follow this guide to generate a new Server API Key: https://documentation.onesignal.com/docs/generate-a-google-server-api-key.

Make sure you are generating an API key for the correct Google Project.

Replace your Server API Key on your platform settings with the newly generated key. You will not lose any users doing this (each Google project may have multiple Server API keys).

After saving your settings, you can try sending a test message, and you should no longer see a 401 Unauthorized error. 
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/5ba14ba-create-6.jpg",
        "create-6.jpg",
        1860,
        1109,
        "#565656"
      ],
      "caption": ""
    }
  ]
}
[/block]
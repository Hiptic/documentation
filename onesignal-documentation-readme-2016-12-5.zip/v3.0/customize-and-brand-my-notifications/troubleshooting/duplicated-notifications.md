---
title: "Duplicated notifications"
excerpt: "<div class=\"tag-all tag-troubleshooting\">Troubleshooting</div> <div class=\"tag-all tag-developers\">For Developers</div>"
---
<span class="label-all label-android">Android</span> - Check to make sure you don't have another push notification plugin/SDK in your app as it could be displaying a 2nd notification. Our Android SDKs prevent duplicate notifications by checking for the notification id so two will never be created from our official SDKs.

<span class="label-all label-ios">iOS</span> - There is a bug with iOS that can display a push notification twice in development after reinstall your app many times. You will need to reboot the iOS device to fix the issue. See [this github issue](https://github.com/one-signal/OneSignal-iOS-SDK/issues/18) for more details.
[block:callout]
{
  "type": "info",
  "body": "We answer most support queries in under 4 hours during the week, and under 24 hours on weekends. Simply email us at [support@onesignal.com](mailto:support@onesignal.com). \n\nInclude as much as you can of the following to help us find your issue quicker: \n\n- Version of our SDK \n- Version of the SDK\n- Device OS version\n- Building on Mac or Windows\n- Xcode log or logcat of the app starting and the problem point\n- Any other libraries or plugins in your app\n- Details on reproducing your problem.",
  "title": "Still having problems? We're happy to help!"
}
[/block]
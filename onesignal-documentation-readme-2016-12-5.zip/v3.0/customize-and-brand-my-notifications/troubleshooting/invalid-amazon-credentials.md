---
title: "Invalid Amazon Credentials"
excerpt: "Configuration Notice - <span class=\"label-all label-amazon\">Amazon</span>\n<div class=\"tag-all tag-troubleshooting\">Troubleshooting</div> <div class=\"tag-all tag-developers\">For Developers</div>"
---
**Invalid Amazon Credentials** is thrown when Amazon returns a `401 INVALID_CLIENT` error. Your Client ID and Client Secret are invalid for your Amazon app's security profile.

## Steps to Resolve
Please follow steps 1.1 - 1.5 of our [generate an Amazon API Key](doc:generate-an-amazon-api-key) guide to correctly retrieve your Client ID and Client Secret.
---
title: "Invalid Push Certificate"
excerpt: "Configuration Notice - <span class=\"label-all label-ios\">iOS</span>\n<div class=\"tag-all tag-troubleshooting\">Troubleshooting</div> <div class=\"tag-all tag-developers\">For Developers</div>"
---
**Invalid Push Certificate** is thrown when Apple returns a `BadCertificate` error. This means your certificate was rejected by Apple and may be expired, revoked, or invalid.

## Steps to Resolve
Please generate a new push certificate by using our [provisionator tool](https://onesignal.com/provisionator) (recommended) or by following step 1 in [Generate an iOS Push Certificate](doc:generate-an-iso-push-certificate).
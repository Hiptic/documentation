---
title: "How fast are notifications delivered?"
excerpt: ""
---

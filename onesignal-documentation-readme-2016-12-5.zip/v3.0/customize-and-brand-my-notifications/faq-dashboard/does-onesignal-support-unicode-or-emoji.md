---
title: "Does OneSignal support Unicode or Emoji?"
excerpt: ""
---

---
title: "What data do you use and how do you use it"
excerpt: ""
---
The data that you pass us is limited to the data that is collected via our SDK or sent to us via our REST API. 

[Insert list of data parameters that the SDK passes] 

Our business model is based on using the wide distribution of our SDK to help advertisers and research companies better understand mobile user behavior, similar to services like AppAnnie and Flurry Analytics. Specifically we work with ad technology companies and advertisers directly to help them match the data with their users for their campaigns (eg, match an email to a deviceID), build behavioral segments bases on app category (eg provide a list of users who have 2 or more travel apps) or user behavior (eg highly active user) and we work with market research companies leveraging our aggregate data by working to provide high level data (eg avg time spend by OS by category). 

For companies that do not want us to work with 3rd parties to monetize the data and would prefer to pay us to keep that data private we do offer enterprise plans for customers interested in a higher level of support or for customers who may require special terms. 

Enterprise starts at $40/month for up to 500K users. [Link to Pricing] 

If you want to discuss this plan please email us a little about your company at sales@onesignal.com
---
title: "Why is OneSignal Free"
excerpt: ""
---
Our business model is based on using the wide distribution of our SDKs to help advertisers with targeting and user matching as well as helping research companies with aggregate high level data.
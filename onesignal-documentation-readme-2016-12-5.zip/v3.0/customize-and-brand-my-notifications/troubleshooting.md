---
title: "Troubleshooting"
excerpt: "Troubleshooting common issues setting up and running OneSignal.\n<div class=\"tag-all tag-troubleshooting\">Troubleshooting</div> <div class=\"tag-all tag-developers\">For Developers</div>"
---
## By Platform
- [Troubleshooting iOS](doc:troubleshooting-ios) 
- [Troubleshooting Android](doc:troubleshooting-android)
- [Troubleshooting Unity](doc:troubleshooting-unity)
- [Troubleshooting Cordova Variants](doc:troubleshooting-cordova-variants) 
- [Troubleshooting Web Push](doc:troubleshooting-web-push)

## Notifications
- [Duplicated notifications](doc:duplicated-notifications) 
- [Notifications show successful but are not being shown](doc:notifications-show-successful-but-are-not-being-shown) 
- [Notifications are blank](doc:notifications-are-blank) 

## Users
- [No users on dashboard after installing SDK](doc:no-users-on-dashboard-after-installing-sdk) 
- [All users are shown as not subscribed](doc:all-users-are-shown-as-not-subscribed) 

## Configuration Notices
- [Mismatched Push Certificate](doc:mismatched-push-certificate) 
- [Mismatched User Environment](doc:mismatched-user-environment) 
- [Mismatched Bundle ID](doc:mismatched-bundle-id) 
- [Mismatched Web ID](doc:mismatched-web-id) 
- [Mismatched Users](doc:mismatched-users) 
- [Possible Bundle / Certificate Mismatch](doc:possible-bundle-certificate-mismatch) 
- [Invalid Push Certificate](doc:invalid-push-certificate) 
- [Invalid Google Credentials](doc:invalid-google-credentials) 
- [Invalid Recipients](doc:invalid-recipients) 
- [Invalid Amazon Credentials](doc:invalid-amazon-credentials) 

## Other
- [Using Postman](doc:using-postman)
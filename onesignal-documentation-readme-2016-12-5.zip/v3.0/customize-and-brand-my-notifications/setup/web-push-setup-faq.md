---
title: "Web Push Setup FAQ"
excerpt: ""
---
# Customizing Welcome Notifications, Permission Messages, Subscription Bell

## Welcome Notifications
<img src="http://i.imgur.com/UAB5LEg.jpg" style="max-width: 60%;"/>
[block:parameters]
{
  "data": {
    "0-0": "If You're *Using* Our WordPress Plugin:",
    "1-0": "If You're *Not Using* Our WordPress Plugin:",
    "0-1": "<a href=\"https://i.imgur.com/6QhD6Vx.png\" target=\"support\">See Image</a>",
    "1-1": "[Customize Welcome Notifications](doc:welcome-notifications#section-how-do-i-customize-or-disable-the-automatic-welcome-notification-when-a-new-site-visitor-subscribes-)"
  },
  "cols": 2,
  "rows": 2
}
[/block]
## Fullscreen Permission Message
<div style="display: flex; align-items: center; justify-content: center; padding: 1em;">
<img src="https://i.imgur.com/KuQcvEV.png"  style="float: left; max-width: 50%;">
<img src="https://files.readme.io/19a6714-Fullscreen_PrePermission_Message_HTTPS.png" style="max-width: 50%;"/>
</div>
[block:parameters]
{
  "data": {
    "0-0": "If You're *Using* Our WordPress Plugin:",
    "1-0": "If You're *Not Using* Our WordPress Plugin:",
    "1-1": "[Customize Fullscreen Permission Messages](doc:customize-permission-messages#section-customize-fullscreen-permission-message)",
    "0-1": "[See Image](http://i.imgur.com/rIURbaq.png)"
  },
  "cols": 2,
  "rows": 2
}
[/block]
[Extra Documentation: Fullscreen Permission Message](doc:permission-requests#section-fullscreen-permission-message) 

## Slidedown Permission Message
<img src="https://files.readme.io/94b280b-Slidedown_PrePermission_Message.png" style="max-width: 70%;"/>
[block:parameters]
{
  "data": {
    "0-0": "If You're *Using* Our WordPress Plugin:",
    "1-0": "If You're *Not Using* Our WordPress Plugin:",
    "0-1": "[See Image](http://i.imgur.com/rIURbaq.png). Customize the fields Action Message, Accept Button Text, and Cancel Button Text.",
    "1-1": "[Customize Slidedown Permission Messages](doc:customize-permission-messages#section-customize-slidedown-permission-message)"
  },
  "cols": 2,
  "rows": 2
}
[/block]
[Extra Documentation: Permission Messages & Requests](doc:permission-requests#section-slidedown-permission-message) 

## Subscription Bell
<img src="https://files.readme.io/70a7cb8-Subscription_Button.png" style="max-width: 70%;"/>
[block:parameters]
{
  "data": {
    "0-0": "If You're *Using* Our WordPress Plugin:",
    "1-0": "If You're *Not Using* Our WordPress Plugin:",
    "0-1": "[See Image](http://i.imgur.com/lEvY8Zx.png)",
    "1-1": "[Customize Subscription Bell](doc:customize-permission-messages#section-customize-subscription-bell)"
  },
  "cols": 2,
  "rows": 2
}
[/block]
[Extra Documentation: Subscription Bell](doc:permission-requests#section-subscription-bell)
---
title: "Migrating from Another Service"
excerpt: "How to migrate from other push services. For <span class=\"label-all label-ios\">iOS</span>, <span class=\"label-all label-android\">Android</span> (and derivatives like <span class=\"label-all label-amazon\">Amazon</span>), and <span class=\"label-all\">web push</span> (<span class=\"label-all label-chrome\">Chrome</span>, <span class=\"label-all label-firefox\">Firefox</span>, and <span class=\"label-all label-safari\">Safari</span>).\n<div class=\"tag-all tag-developers\">For Developers</div>"
---
## Migrating from Web Push Providers
Due to the way Web Push works, you cannot migrate data from one service to another. We suggest the following:

<ol><li><p>Install the [OneSignal website SDK](doc:web-push-setup) onto your site</p></li><li><p>Send a message to your existing subscribers to get them to come back and resubscribe with OneSignal on your site.</p>

If your site is HTTPS, then any user who subscribed before will be automatically resubscribed when they revisit your site with OneSignal installed. 

Thanks!
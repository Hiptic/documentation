---
title: "Generate a Google Server API Key"
excerpt: "Required for all <span class=\"label-all label-android\">Android</span> apps and <span class=\"label-all\">Chrome Apps & Extensions</span>, and optional for <span class=\"label-all label-amazon\">Amazon</span>.\n<div class=\"tag-all tag-developers\">For Developers</div>"
---
Your **Google Server API Key** and **Google Project Number** are used to send push notifications to <span class="label-all label-android">Android</span> devices.

To begin, we'll obtain a Google Server API Key and Google Project Number. These keys allow OneSignal to use Google's web push services for your notifications.

## 1. Create a Google app

**1.1** Visit the [Google Services Wizard](https://developers.google.com/mobile/add?platform=android&cntapi=gcm).

**1.2** Type any name to create a new app, or select an existing Google app from the dropdown.

In this example, we create an app named `test-app`.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/PHatQxW0QgOmpBdaa16s_chrome-settings-1.jpg",
        "chrome-settings-1.jpg",
        "1110",
        "801",
        "#94a3c5",
        ""
      ]
    }
  ]
}
[/block]
**1.3** We *do not* use the Android package name, but you must enter a value to continue. Please use the value `test.test` as shown below.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/Wx3l0GEdTJCAYsKNbu1n_chrome-settings-2.jpg",
        "chrome-settings-2.jpg",
        "1110",
        "801",
        "#94a2c6",
        ""
      ]
    }
  ]
}
[/block]
**1.4** Click **Choose and configure services** to continue.

Wait a minute for the project to be created.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/h606TncoSguNVhl7qIRE_chrome-settings-3.jpg",
        "chrome-settings-3.jpg",
        "1110",
        "801",
        "#78a4c9",
        ""
      ]
    }
  ]
}
[/block]
## 2. Enable Google Cloud Messaging

**2.1** Click **Enable Google Cloud Messaging**.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/teVDuhuEQhsceDjXsBHZ_chrome-settings-4.jpg",
        "chrome-settings-4.jpg",
        "1100",
        "793",
        "#551f17",
        ""
      ],
      "sizing": "smart"
    }
  ]
}
[/block]
## 3. Get your Google keys

**3.1** Save the two values listed:

- You'll need your **Server API Key** later in our SDK Installation guide
- You'll need your **Sender ID**, also known as the **Google Project Number**, later as well
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/sHVHOxIaQ7WvVvvnQoT0_chrome-settings-5.jpg",
        "chrome-settings-5.jpg",
        "1110",
        "801",
        "#61bc71",
        ""
      ]
    }
  ]
}
[/block]

[block:callout]
{
  "type": "info",
  "body": "The Sender ID is also known as the Google Project Number. You'll need this later in the SDK installation guide.",
  "title": "SENDER ID / GOOGLE PROJECT NUMBER"
}
[/block]
## 4. Configure your OneSignal app's Android platform settings

**4.1** Go to <a class="dash-link">App Settings</a> and press the _Configure_ button to the right of _Google Android_.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/87b7b6d-1.png",
        "1.png",
        2624,
        1682,
        "#5c5c5c"
      ]
    }
  ]
}
[/block]
**4.2** Paste your Google API Key and Google Project Number in here and press Save.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/2605d3d-2.png",
        "2.png",
        2624,
        1682,
        "#3d3d3d"
      ]
    }
  ]
}
[/block]

[block:callout]
{
  "type": "success",
  "title": "Configuration Complete",
  "body": "- The next step is to setup up the [Android SDK](doc:android-sdk-setup) or [Amazon SDK](doc:amazon-sdk-setup) !"
}
[/block]
---
title: "Generate an iOS Push Certificate"
excerpt: "Required for all <span class=\"label-all label-ios\">iOS</span> apps.\n<div class=\"tag-all tag-developers\">For Developers</div>"
---
The goals of this section are to provision your app with Apple and grant OneSignal access to manage your notifications.  
[block:callout]
{
  "type": "info",
  "body": "The Apple Push Notification Service (APNs) is a service created by Apple Inc. way back in 2009 to securely send push notifications from third party apps to their users' Apple devices. \n\nYour backend sends notifications through Apple's servers to your application. To ensure that unwanted parties are not sending notifications to your application, Apple needs to know that only your servers can connect with theirs.\n\nApple therefore requires you to create an SSL certificate. Although app provisioning can be confusing at times, follow along and it should only take a couple minutes.",
  "title": "Learn more: What are iOS Push Certificates?"
}
[/block]
## 1. Provisioning

### Option A: Try out our Automatic Provisioning Tool
We recently released a tool to automate this process!

Simply follow the directions on this page [http://onesignal.com/provisionator](https://onesignal.com/provisionator) then **[continue to Step 4](#4-upload-your-push-certificate-to-onesignal)**.

 **-- OR --** 

### Option B: Create Certificate Request Manually

**1.1** Open Keychain Access on your Mac OS X system. It may be located in "Applications" > "Utilities" > "Keychain Access"

**1.2** Select "Keychain Access">"Certificate Assistant">"Request a Certificate From a Certificate Authority..."
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/sc7fGG3gRgWaL168mmS4_SC_KeychainAccess.png",
        "SC_KeychainAccess.png",
        "670",
        "247",
        "#238a86",
        ""
      ]
    }
  ]
}
[/block]
**1.3** Select the "Save to disk" option and enter your information in the required fields. This creates a certification request file that will be used later.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/Xl1qWa7fSVKf7Hhjhucr_SC_CertificateAssistant.png",
        "SC_CertificateAssistant.png",
        "619",
        "441",
        "#854b14",
        ""
      ]
    }
  ]
}
[/block]
## 2. Enable Push Notifications and apply the Certification Request to generate Certificate

**2.1** Select your app from the [Apple's Developer site](https://developer.apple.com/account/ios/identifier/bundle) and press "Edit"
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/NHddNnCsRB2qDbvz4nkK_SC_SelectAppId.png",
        "SC_SelectAppId.png",
        "670",
        "366",
        "#1b67a0",
        ""
      ]
    }
  ]
}
[/block]
**2.2** Scroll down to the bottom and enable Push Notifications. Press Done, but do not configure either Production or Development certificate.

Instead, go to [Create new certificate page](https://developer.apple.com/account/ios/certificate/create) and select "**Apple Push Notification service SSL (Sandbox & Production)**" and click Continue.

This certificate will be applicable to both Sandbox and Production environments, so you do not need a separate key for each one.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/5011511-Screenshot_2016-09-22_00.36.35.png",
        "Screenshot 2016-09-22 00.36.35.png",
        996,
        1185,
        "#f1f1f1"
      ],
      "sizing": "80"
    }
  ]
}
[/block]
**2.3** Choose an App ID from the App ID pop-up menu, and click Continue.

**2.4** Press Continue

**2.5** Press "Choose File..", select the "certSigningRequest" file you saved in step 1, press open, and then press "Generate".
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/s8GTOvNdTz6RxlzgTOA1_SC_PressChooseFile.png",
        "SC_PressChooseFile.png",
        "670",
        "575",
        "#45689f",
        ""
      ]
    }
  ]
}
[/block]
**2.6** Press Download to save your certificate
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/4f5ccb7-Screen_Shot_2016-08-29_at_1.44.36_PM-fs8.png",
        "Screen Shot 2016-08-29 at 1.44.36 PM-fs8.png",
        2880,
        1880,
        "#f2f2f2"
      ]
    }
  ]
}
[/block]
## 3. Creating a Private Key
**3.1** Open the .cer file you downloaded in the last step by double clicking on it in Finder.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/0e27ab2-cert-fs8.png",
        "cert-fs8.png",
        1708,
        968,
        "#efefee"
      ],
      "caption": ""
    }
  ]
}
[/block]
**3.2** After a few seconds the "Keychain Access" program should pop up. Select Login > Keys then right click on your key in the list and select "Export"
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/eQfKSpOTBtc5qBa9CCw9_SC_KeychainAccessPopup.png",
        "SC_KeychainAccessPopup.png",
        "670",
        "203",
        "#38589e",
        ""
      ]
    }
  ]
}
[/block]
**3.3** Give the file a unique name and press save. You will have an option to protect the file with a password. If you add a password, you need to enter this same password on OneSignal.

## 4. Upload Your Push Certificate to OneSignal

**4.1** From [OneSignal](https://onesignal.com), go to "App Settings" and press Configure to the right of the Apple iOS Settings.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/5tg4f2y1STSxDVxnd7l4_ConfigureiOS.png",
        "ConfigureiOS.png",
        "1230",
        "368",
        "#ec1c24",
        ""
      ]
    }
  ]
}
[/block]
**4.2** Select the .p12 you exported along with a password if you added one and press Save.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/e0975c7-Screen_Shot_2016-08-19_at_1.53.08_PM-fs8.png",
        "Screen Shot 2016-08-19 at 1.53.08 PM-fs8.png",
        1580,
        1020,
        "#ededed"
      ]
    }
  ]
}
[/block]

[block:callout]
{
  "type": "danger",
  "title": "Important Requirement!",
  "body": "**You must make sure `Push Notifications` are enabled on your provisioning profiles before building your app! Please fully follow Step 5 below or your users will NOT be subscribed.**"
}
[/block]
## 5. Provisioning Profiles

**5.1** On the left to go to All > Provisioning Profiles. Next find any that are for your app and delete them if they do not have `Push Notifications` in `Enabled Services:`.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/VIcaAcEpQ2ejTIdXqsjo_SC_DeleteProvProfile.png",
        "SC_DeleteProvProfile.png",
        "670",
        "241",
        "#23689a",
        ""
      ]
    }
  ]
}
[/block]
**5.2** Recreate the ones you need by pressing the "+" button on the upper right.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/dH0BUuTkTaiscunk0jb0_SC_RecreateProvProfile.png",
        "SC_RecreateProvProfile.png",
        "670",
        "403",
        "#fa5c54",
        ""
      ]
    }
  ]
}
[/block]
**5.3** When recreating new ones make sure to enter a unique name in the "Profile Name:" field.

*Example, here we created an Ad-Hoc Provisioning Profile so we can test push notifications with our Production Push Certificate .p12 file. We used the format AppName_AdHoc so we know the app and type it is.*
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/dVSHSnBeSnuRbGRNjbQp_Create_ad-hoc_provisioning_profile.png",
        "Create_ad-hoc_provisioning_profile.png",
        "981",
        "608",
        "#eb1c24",
        ""
      ]
    }
  ]
}
[/block]
** 5.4 ** Re-sync your Developer Account in Xcode by going to Xcode > Preferences...  then click on the "View Details..." button. Lastly, click the refresh button on the bottom left of the popup. See [Apple's documentation](https://developer.apple.com/library/mac/recipes/xcode_help-accounts_preferences/articles/obtain_certificates_and_provisioning_profiles.html) for more detailed instructions.

**5.5** Make sure you pick your new provisioning profile from Build Settings>Code Signing>Provisioning Profile in Xcode.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/YeEXaxKT8mRAxhWRthnU_Ad-Hoc_in_xcode.png",
        "Ad-Hoc_in_xcode.png",
        "912",
        "301",
        "#254275",
        ""
      ]
    }
  ]
}
[/block]

[block:callout]
{
  "type": "success",
  "title": "Congratulations! OneSignal is now setup to push out notifications to your app!",
  "body": "Next, install the OneSignal SDK in your app. \n\n- Next step for [iOS native SDK Setup](doc:ios-sdk-setup) \n- Next step for [Unity SDK Setup](doc:unity-sdk-setup) \n- Next step for [Corona SDK Setup](doc:corona-sdk-setup) \n- Next step for [Marmalade SDK Setup](doc:marmalade-sdk-setup)"
}
[/block]

[block:callout]
{
  "type": "warning",
  "title": "TROUBLESHOOTING",
  "body": "If you are running into any issues you can try troubleshooting them with our [Troubleshooting iOS](doc:troubleshooting-ios)."
}
[/block]
---
title: "Page Anchor Issue"
excerpt: ""
---
### Issue Demo
[block:parameters]
{
  "data": {
    "0-0": "",
    "1-0": "Link *Without* Anchor",
    "0-1": "**Link**",
    "1-1": "[Click Here](doc:readme-anchor-issue-example-page)",
    "0-2": "**Actually Links To**",
    "2-0": "Link *With* Anchor",
    "2-1": "[Click Here](doc:readme-anchor-issue-example-page#section-section-b)",
    "0-3": "**Should Link To**",
    "1-2": "Top of Page",
    "1-3": "Top of Page",
    "2-2": "Top of Page",
    "2-3": "Section B, middle of Page",
    "3-0": "",
    "3-1": ""
  },
  "cols": 4,
  "rows": 3
}
[/block]
### Issue Summary

- Opening an anchored link in a new tab (via Right Click -> Open in new tab, or middle-clicking the link) correctly jumps to the anchored section
- Opening an anchored link in the same page (just left clicking the link normally) incorrectly places the user at the top of the page, not in the anchored section
    - Refreshing the same URL still leaves you at the top of the page

[Add a device](ref:add-a-device)
---
title: "Setup"
excerpt: "OneSignal FAQ - Questions related to setting up and configuring OneSignal\n<div class=\"tag-all tag-developers\">For Developers</div>"
---
## Setting up Keys and IDs
- [Generate an iOS Push Certificate](doc:generate-an-ios-push-certificate) 
- [Generate a Google Server API Key](doc:generate-a-google-server-api-key) 
- [Generate a Windows Phone Package SID and Secret](doc:generate-a-windows-phone-package-sid-and-secret) 
- [Generate an Amazon API Key](doc:generate-an-amazon-api-key) 

## Upgrading Your OneSignal SDKs
- [Upgrading to Android SDK 3.0](doc:upgrading-to-android-sdk-30) 
- [Upgrading to iOS SDK 2.0](doc:upgrading-to-ios-sdk-20) 

## Other
- [About Firebase Cloud Messaging (FCM)](doc:firebase-cloud-messaging-fcm)